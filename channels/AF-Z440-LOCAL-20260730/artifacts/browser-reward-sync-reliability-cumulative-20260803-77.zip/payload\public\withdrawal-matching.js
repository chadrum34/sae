(function exposeWithdrawalMatching(root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.AndroidFleetWithdrawalMatching = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createWithdrawalMatching() {
  function withdrawalBelongsToDevice(withdrawal, device) {
    if (!withdrawal || !device) return false;
    if (clean(withdrawal.subjectKind).toLowerCase() === "custom") return false;
    const storedSerial = normalizeSerial(withdrawal.serial);
    const deviceSerial = normalizeSerial(device.serial);

    // A saved serial is permanent. A recycled management ID must not override it.
    if (storedSerial) return Boolean(deviceSerial && storedSerial === deviceSerial);

    const storedManagementId = clean(withdrawal.managementId);
    const deviceManagementId = clean(device.managementId || device.laixiNumber);
    return Boolean(storedManagementId && deviceManagementId && storedManagementId === deviceManagementId);
  }

  function hasStableWithdrawalIdentity(withdrawal) {
    return Boolean(stableWithdrawalSubjectId(withdrawal));
  }

  function stableWithdrawalSubjectId(withdrawal) {
    if (!withdrawal) return "";
    const subjectKind = clean(withdrawal.subjectKind).toLowerCase();
    const subjectId = clean(withdrawal.subjectId).toLowerCase();
    const deviceName = clean(withdrawal.deviceName);
    if (subjectKind === "custom") {
      if (normalizeSerial(withdrawal.serial)) return "";
      return /^custom:[0-9a-f]{32}$/.test(subjectId) && deviceName ? subjectId : "";
    }
    const serial = normalizeSerial(withdrawal.serial);
    if (serial) return `serial:${serial}`;
    return "";
  }

  function normalizeSerial(value) {
    return clean(value).toLowerCase();
  }

  function clean(value) {
    return String(value === undefined || value === null ? "" : value).trim();
  }

  return { withdrawalBelongsToDevice, hasStableWithdrawalIdentity, stableWithdrawalSubjectId };
});
