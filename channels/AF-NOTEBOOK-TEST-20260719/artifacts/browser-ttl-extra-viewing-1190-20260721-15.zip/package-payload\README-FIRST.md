# Android Fleet ブラウザ版

## 最初に行うこと

1. `XIAOWEI-OFFICIAL.url` を開き、公式サイトから效卫（XiaoWei）Android投屏版をインストールします。
2. XiaoWeiを起動してログインし、スマホをUSB接続します。
3. `START-ANDROID-FLEET.cmd` をダブルクリックします。
4. Windows標準ブラウザでAndroid Fleetが開きます。
5. Fleet上部の「接続準備・新規取込」から端末を取り込みます。

Fleetを終了するときは `STOP-ANDROID-FLEET.cmd` をダブルクリックします。ブラウザを閉じるだけでは、裏側のFleet Agentは終了しません。

## 更新について

- 起動時に更新情報を確認し、配布元が署名した正規の更新だけを自動適用します。
- DB、チェック、履歴、顧客情報は更新で消えません。
- 更新ファイルが壊れている、別のお客様用、通信できない場合は適用せず、現在版でそのまま起動します。
- 手動で今すぐ確認するときは `CHECK-FOR-UPDATES.cmd` を使用します。
- 更新サーバー未設定のパッケージでは更新確認を行いません。

## APKについて

APKは同梱していません。Google Playから最新版を入れた基準端末を1台選び、Fleetの「スマホアプリ吸い出し」を使用してください。

吸い出し時は `base.apk` と端末用のsplit APKをまとめて `.apkm` として保存します。保存後は「APKインストール」から複数端末へ導入できます。

## USBドライバーについて

USBドライバーは同梱していません。WindowsまたはXiaoWeiで端末を認識できない場合に限り、販売者へ機種名と型番を伝えて該当ドライバーを受け取ってください。

## 動作範囲

- 通常は同じWindows PCのブラウザから使用します。
- Fleet Agentは `127.0.0.1:8787` でのみ待ち受けるため、同一LANの別端末から直接操作されません。
- 上部の「リモート接続」からTailscaleを設定すると、許可したノートPC・タブレット・スマホから出先でもFleetを操作できます。
- リモート接続はTailscale Serveの標準HTTPS `443` を使用します。URLにポート番号を付ける必要はありません。ルーターのポート開放や、一般公開用のTailscale Funnelは使用しません。
- リモート側にもTailscaleをインストールし、このWindows PCと同じアカウントまたは許可済みネットワークへログインしてください。
- 出先から利用する間は、このWindows PC、XiaoWei、Fleet Agentを起動したままにしてください。
- リモート接続で操作できるのはFleetだけです。XiaoWeiの画面そのものは配信しません。
- USB復旧など管理者権限が必要な処理では、Windowsの確認画面が表示されます。
- 起動中に配布フォルダを移動・削除しないでください。

## 顧客情報

- Customer ID: `__CUSTOMER_ID__`
- Customer Name: `__CUSTOMER_NAME__`
- Package ID: `__PACKAGE_ID__`
- License Mode: `__LICENSE_MODE__`

このパッケージは、最初に起動した1台のWindows PCへ固定されます。

## 公式ダウンロード

- XiaoWei公式Android投屏版: https://www.xiaowei.xin/android
