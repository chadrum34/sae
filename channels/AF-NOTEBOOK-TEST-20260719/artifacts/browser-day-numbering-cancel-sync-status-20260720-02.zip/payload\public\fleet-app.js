﻿const state = {
  summary: null,
  deviceMaster: null,
  clipboardItems: [],
  clipboardEditingId: "",
  offlineEditingId: "",
  clipboardTargetSerials: new Set(),
  adbDevices: null,
  adbMissingSerials: new Set(),
  busy: false,
  swipeStopBusy: false,
  adbSwipe: {
    jobId: "",
    pollTimer: 0,
    selected: new Set(),
    minutesBySerial: {},
    currentJob: null,
  },
  swipeAgent: {
    jobId: "",
    pollTimer: 0,
    selected: new Set(),
    minutesBySerial: {},
    currentJob: null,
    errorToggleBusy: false,
  },
  uptimeTickTimer: 0,
  adbConnectionMonitorTimer: 0,
  adbConnectionMonitorBusy: false,
  deviceFactsAutoTimer: 0,
  deviceFactsAutoBusy: false,
  remoteAccess: null,
  pendingDeviceRows: null,
  deviceRenderFlushTimer: 0,
  fleetDbRecoveryChecked: false,
  fleetDbRecoveryPrompted: false,
  syncLogs: [],
  syncLogPending: [],
  syncLogFlushTimer: 0,
  scriptBuilder: {
    steps: [],
    latestScreenshotUrl: "",
    autoRefreshTimer: 0,
    logBaseline: null,
  },
};

const el = (id) => document.getElementById(id);
const LOG_STORAGE_KEY = "androidFleetUiLogLines";
const LOG_STORAGE_LIMIT = 300;
const ADB_CONNECTED_COUNT_KEY = "androidFleetLastAdbConnectedCount";
const ADB_CONNECTED_SERIALS_KEY = "androidFleetLastAdbConnectedSerials";
const ADB_DROP_ALERT_KEY = "androidFleetLastAdbDropAlert";
const ADB_LAST_SEEN_KEY = "androidFleetAdbLastSeenBySerial";
const ALERT_SUPPRESS_KEY_PREFIX = "androidFleetSuppressAlert:";
const ALERT_ADB_DROP = "adbDrop";
const ADB_CONNECTION_MONITOR_INTERVAL_MS = 45 * 1000;
const DEVICE_FACTS_AUTO_INTERVAL_MS = 10 * 60 * 1000;
const DEVICE_FACTS_AUTO_START_DELAY_MS = 8 * 1000;
const SWIPE_JOB_MERGE_GRACE_MS = 60 * 60 * 1000;
const MAX_DEVICE_NAME_SEQUENCE = 999;
const INVITE_FACTOR_OPTIONS = Object.freeze({
  simStatus: [["", "SIM?"], ["SIMあり", "SIMあり"], ["SIMなし", "SIMなし"], ["不明", "不明"]],
  networkType: [["", "通信?"], ["Wi-Fi", "Wi-Fi"], ["SIM通信", "SIM通信"], ["併用", "併用"], ["不明", "不明"]],
  ttlRegisterMethod: [["", "導入方法"], ["Google Play", "Google Play"], ["APK自動", "APK自動"]],
  inviteType: [["", "招待"], ["QR", "QR"], ["豚箱", "豚箱"], ["通常", "通常"]],
  inviteRole: [["", "親 or 子"], ["親", "親"], ["子", "子"]],
  inviteResult: [["", "OK or NG"], ["OK", "OK"], ["NG", "NG"]],
});
const INVITE_EDIT_FIELDS = new Set([
  "simStatus",
  "networkType",
  "ttlRegisterMethod",
  "networkSwitchedDay",
  "osVersion",
  "inviteType",
  "inviteRole",
  "inviteResult",
  "invitePartner",
  "inviteOpsNote",
]);
const CI_MULTIPLIERS = Object.freeze([3, 3, 3, 1, 1, 1, 5, 1, 1, 2, 3, 5, 6, 10]);
const CI_MULTIPLIER_TOTAL = CI_MULTIPLIERS.reduce((sum, value) => sum + value, 0);
const VIDEO_TASK_DAYS = 10;
const CALC_OPTIONS = Object.freeze({
  ci: [
    { label: "チェックイン 未設定", yen: 0 },
    { label: "チェックイン 1350円", yen: 1350 },
    { label: "チェックイン 1971円", yen: 1971 },
    { label: "チェックイン 2565円", yen: 2565 },
    { label: "チェックイン 2700円", yen: 2700 },
    { label: "チェックイン 3847円", yen: 3847 },
  ],
  video180: [
    { label: "動画180分 未設定", points: 0 },
    { label: "動画180分 7500P/日", points: 7500 },
    { label: "動画180分 15000P/日", points: 15000 },
    { label: "動画180分 22500P/日", points: 22500 },
  ],
  video10: [
    { label: "追加視聴 未設定", yen: 0 },
    { label: "追加視聴 1438円", yen: 1438 },
    { label: "追加視聴 2262円", yen: 2262 },
    { label: "手入力", yen: "custom" },
  ],
});
const DEVICE_TASK_SELECTS = Object.freeze({
  ci: {
    tags: ["CI_1350", "CI_1971", "CI_2565", "CI_2700", "CI_3847"],
    options: [["", "?"], ["CI_1350", "1350"], ["CI_1971", "1971"], ["CI_2565", "2565"], ["CI_2700", "2700"], ["CI_3847", "3847"]],
  },
  video180: {
    tags: ["V180_7500", "V180_15000", "V180_22500"],
    options: [["", "?"], ["V180_7500", "7500P"], ["V180_15000", "15000P"], ["V180_22500", "22500P"]],
  },
  video10: {
    tags: ["V10_1438", "V10_2262"],
    options: [["", "?"], ["V10_1438", "1438"], ["V10_2262", "2262"]],
  },
});
const SCRIPT_PACKAGE_OPTIONS = Object.freeze([
  { label: "Chrome", packageName: "com.android.chrome", appName: "Chrome", launchUrl: "https://www.google.com/" },
  { label: "TikTok", packageName: "com.zhiliaoapp.musically", appName: "TikTok" },
  { label: "TikTok Lite", packageName: "com.zhiliaoapp.musically.go", appName: "TikTok-Lite" },
  { label: "設定", packageName: "com.android.settings", appName: "設定" },
  { label: "Play Store", packageName: "com.android.vending", appName: "Play Store" },
  { label: "Files", packageName: "com.google.android.apps.nbu.files", appName: "Files" },
  { label: "Gmail", packageName: "com.google.android.gm", appName: "Gmail" },
  { label: "YouTube", packageName: "com.google.android.youtube", appName: "YouTube" },
  { label: "手入力", packageName: "custom" },
]);
const APN_FIELD_LABELS = Object.freeze({
  name: "名前",
  apn: "APN",
  username: "ユーザー",
  password: "パス",
  auth: "認証",
  apnType: "タイプ",
  protocol: "プロトコル",
  roamingProtocol: "ローミング",
  mcc: "MCC",
  mnc: "MNC",
});
const APN_PRESETS = Object.freeze([
  { carrier: "docomo / ahamo / irumo", profile: "spモード", note: "多くは自動設定", fields: { name: "spmode", apn: "spmode.ne.jp", auth: "未設定", protocol: "IPv4/IPv6" } },
  { carrier: "Rakuten Mobile", profile: "楽天モバイル", note: "MNO", fields: { name: "Rakuten", apn: "rakuten.jp", apnType: "default,supl", protocol: "IPv4/IPv6", roamingProtocol: "IPv4/IPv6", mcc: "440", mnc: "11" } },
  { carrier: "povo 2.0", profile: "KDDI", note: "au系", fields: { name: "povo2.0", apn: "povo.jp", auth: "未設定", apnType: "default,supl", protocol: "IPv4/IPv6" } },
  { carrier: "UQ mobile", profile: "KDDI", note: "au系", fields: { name: "UQ mobile", apn: "uqmobile.jp", username: "uq@uqmobile.jp", password: "uq", auth: "CHAP", apnType: "default,mms,supl,hipri,dun", protocol: "IPv4/IPv6" } },
  { carrier: "LINEMO", profile: "SoftBank", note: "SB系", fields: { name: "LINEMO", apn: "plus.acs.jp.v6", username: "lm", password: "lm", auth: "CHAP", apnType: "default,ia,mms,supl,hipri", protocol: "IPv4/IPv6" } },
  { carrier: "Y!mobile", profile: "SoftBank", note: "SB系", fields: { name: "Y!mobile", apn: "plus.acs.jp.v6", username: "ym", password: "ym", auth: "CHAP", apnType: "default,ia,mms,supl,hipri", protocol: "IPv4/IPv6" } },
  { carrier: "SoftBank", profile: "4G/5G", note: "端末差あり", fields: { name: "SoftBank 4G", apn: "plus.4g", username: "plus", password: "4g", auth: "CHAP", apnType: "default,mms,supl,hipri", protocol: "IPv4/IPv6" } },
  { carrier: "mineo D", profile: "docomo回線", note: "MVNO", fields: { name: "mineo-d", apn: "mineo-d.jp", username: "mineo@k-opti.com", password: "mineo", auth: "CHAP" } },
  { carrier: "mineo A", profile: "au回線", note: "MVNO", fields: { name: "mineo-a", apn: "mineo.jp", username: "mineo@k-opti.com", password: "mineo", auth: "CHAP" } },
  { carrier: "mineo S", profile: "SoftBank回線", note: "MVNO", fields: { name: "mineo-s", apn: "mineo-s.jp", username: "mineo@k-opti.com", password: "mineo", auth: "CHAP" } },
  { carrier: "IIJmio", profile: "D/A共通", note: "MVNO", fields: { name: "IIJmio", apn: "iijmio.jp", username: "mio@iij", password: "iij", auth: "PAPまたはCHAP" } },
  { carrier: "OCN モバイル ONE", profile: "docomo回線", note: "新旧要確認", fields: { name: "OCN", apn: "lte.ocn.ne.jp", username: "mobileid@ocn", password: "mobile", auth: "CHAP" } },
  { carrier: "BIGLOBEモバイル", profile: "D/A", note: "MVNO", fields: { name: "BIGLOBE", apn: "biglobe.jp", username: "user", password: "0000", auth: "PAPまたはCHAP" } },
  { carrier: "NUROモバイル", profile: "D/A/S", note: "プラン差確認", fields: { name: "nuro mobile", apn: "so-net.jp", username: "nuro", password: "nuro", auth: "PAPまたはCHAP" } },
  { carrier: "イオンモバイル type1", profile: "docomo回線", note: "MVNO", fields: { name: "AEON mobile", apn: "i-aeonmobile.com", username: "user", password: "0000", auth: "PAPまたはCHAP" } },
  { carrier: "イオンモバイル type2", profile: "docomo回線", note: "MVNO", fields: { name: "AEON mobile type2", apn: "n-aeonmobile.com", username: "user", password: "0000", auth: "PAPまたはCHAP" } },
  { carrier: "日本通信SIM / b-mobile", profile: "docomo回線", note: "MVNO", fields: { name: "b-mobile", apn: "bmobile.ne.jp", username: "bmobile@4g", password: "bmobile", auth: "PAPまたはCHAP" } },
  { carrier: "HISモバイル", profile: "docomo回線", note: "MVNO", fields: { name: "HIS Mobile", apn: "dm.jplat.net", username: "his@his", password: "his", auth: "PAPまたはCHAP" } },
  { carrier: "LinksMate", profile: "docomo回線", note: "MVNO", fields: { name: "LinksMate", apn: "linksmate.jp", username: "usermate", password: "lms", auth: "CHAP" } },
  { carrier: "LIBMO", profile: "docomo回線", note: "MVNO", fields: { name: "LIBMO", apn: "libmo.jp", username: "user@libmo", password: "libmo", auth: "PAPまたはCHAP" } },
  { carrier: "QTモバイル D", profile: "docomo回線", note: "MVNO", fields: { name: "QTmobile D", apn: "vmobile.jp", username: "qtnet@bbiq.jp", password: "qtnet", auth: "CHAP" } },
  { carrier: "y.u mobile", profile: "docomo回線", note: "要確認", fields: { name: "y.u mobile", apn: "yumobile.jp", username: "yumobile@yumobile.jp", password: "yumobile", auth: "PAPまたはCHAP" } },
]);
const BUTTON_HELP = Object.freeze({
  saveSiteNameBtn: "",
  firstRunSetupBtn: "ADB起動、USB再スキャン、接続確認、新規端末取込をまとめて行います。スマホ画面のUSBデバッグ許可だけは手動でOKしてください。",
  tagSyncBtn: "チェック一覧の変更をDBへ反映してから、必要に応じてXiaoWeiへ名前と番号を同期します。チェック情報そのものはローカルDBで管理します。",
  dayAdvanceBtn: "",
  deviceCodeSyncBtn: "端末マスタを元に、未設定や古い端末名をDB内で再取得します。XiaoWeiへ反映する時は別途XiaoWei名同期を押します。",
  deviceUptimeRefreshBtn: "",
  adbMissingListBtn: "",
  usbAdbDiagnosisBtn: "端末が見えない/動かない原因を確認し、対象だけ自動復旧します。",
  xiaoweiMissingListBtn: "",
  deviceCodeAuditBtn: "",
  retiredDevicesBtn: "管理対象から外した端末を確認し、必要なら一覧へ戻します。",
  deviceNameSequenceEditBtn: "A25-01などの末尾連番を01〜999で変更します。メイン番号とXiaoWeiの機種順は変わりません。",
  deviceDayOrderBtn: "元の採番方式です。稼働端末はDAYが大きい順、非稼働端末は機種・キャリア順にメイン番号を振り直し、XiaoWeiへ反映します。",
  deviceModelOrderBtn: "メイン番号を機種・キャリア・名前連番の順に振り直し、XiaoWeiへ反映します。DAY順とチェック状態は変わりません。",
  deviceMasterReloadBtn: "",
  deviceMasterSaveBtn: "",
  deviceMasterCancelBtn: "",
  deviceMasterImportBtn: "",
  xiaoweiNameSyncBtn: "",
  xiaoweiNumberSyncBtn: "",
  importAdbNewBtn: "ADB/XiaoWeiで見えていてDBに未登録の端末を取り込みます。取り込み後にDB側で名前とXiaoWei番号を整え、同期ボタンでXiaoWeiへ反映します。",
  saveDeviceNamesBtn: "",
  saveInviteFactorsBtn: "招待検証欄で選んだ内容をDBへ保存します。",
  adbSwipeApplyBulkBtn: "",
  adbSwipeSelectAllBtn: "",
  adbSwipeSelectActiveBtn: "",
  adbSwipeClearSelectionBtn: "",
  adbSwipeRefreshBtn: "",
  adbSwipeRestartTtlBtn: "",
  adbSwipeStartBtn: "",
  adbSwipeStopBtn: "",
  swipeAgentApplyBulkBtn: "",
  swipeAgentSelectAllBtn: "",
  swipeAgentSelectActiveBtn: "",
  swipeAgentClearSelectionBtn: "",
  swipeAgentRefreshBtn: "",
  swipeAgentStatusBtn: "",
  swipeAgentInstallBtn: "",
  swipeRecoveryTestBtn: "",
  swipeLiveRecoveryTestBtn: "",
  swipeAgentStartBtn: "",
  swipeAgentStopBtn: "",
  clipboardSaveBtn: "",
  clipboardCaptureBtn: "",
  clipboardClearBtn: "",
  clipboardReloadBtn: "",
  clipboardSelectActiveBtn: "",
  clipboardSelectAllBtn: "",
  clipboardManualSelectBtn: "",
  clipboardClearTargetsBtn: "",
  clipboardInstallApkBtn: "APKフォルダ内のAPK/APKM/XAPKを一覧表示し、選んだ複数アプリをチェック済み端末へまとめてインストールします。splitや大容量APKにも対応します。",
  clipboardTtlInviteDiagnosticsBtn: "チェック済み端末で、TikTok Liteが招待URLの受け皿としてAndroidに認識されているか確認します。",
  clipboardTtlCleanupBtn: "APKフォルダ内のTikTok Liteと一致するパッケージを残し、重複したTTL候補を確認付きで整理します。",
  clipboardOpenApkFolderBtn: "APKを置くdata/apkフォルダを開きます。",
  clipboardExtractAppBtn: "チェックしたスマホ1台からインストール済みアプリ一覧を出し、選んだアプリをsplit込みでdata/apkへ吸い出します。",
  clipboardLaunchTtlBtn: "チェック済み端末でTikTok Liteを起動します。",
  clipboardLaunchLineBtn: "チェック済み端末でLINEを起動します。",
  clipboardOpenApkLinksBtn: "APKの入手先メモを開きます。",
  apnOpenSettingsBtn: "",
  emergencyOffBtn: "",
  autoRotateOffBtn: "",
  dataSaverBtn: "",
  nfcOffBtn: "",
  soundOffBtn: "",
  baselineSettingsBtn: "DBの初期設定状態を元に、接続中の未完了端末へ実行します。稼働中端末も対象です。内容は、緊急メールOFF、画面回転OFF、データセーバーON、NFC OFF、サイレントONの5項目です。APKは端末操作のAPKインストールから別に導入します。",
  xiaomiMiuiOptimizeBtn: "接続中のXiaomi/Redmi/POCO端末だけに、MIUI広告・解析・フィードバック系の無効化を実行します。稼働中も対象です。",
  remoteAccessBtn: "許可したノートPCやタブレットから、Tailscale経由でFleetだけを安全に操作します。XiaoWeiの画面共有は行いません。",
  baselineSettingsRefreshBtn: "接続中の端末を読み込んで、初期設定5項目の完了状態をDBへ更新します。普段の初期設定ボタンはDBを元にスキップするため、状態確認したい時だけ使います。",
  pageReloadBtn: "画面全体を読み直します。表示が固まった時や真っ暗に見える時に使います。F5 / Ctrl+R でも実行できます。",
  reloadBtn: "",
  exportSheetsBtn: "",
  saveDbBtn: "",
  backupBtn: "",
  migrationExportBtn: "PC移行用の AndroidFleet-移行データ フォルダを作ります。ローカルDB、履歴、保管リスト、APKなどを入れ、PC固定ライセンス情報は入れません。",
  migrationOpenBtn: "移行データをコピーするためのフォルダを開きます。旧PCではこのフォルダを丸ごとコピーし、新PCでは同じ場所へ置きます。",
  migrationImportBtn: "新PC側で AndroidFleet-移行データ を取り込みます。現在のデータはバックアップしてから上書きし、PC固定ライセンス情報は取り込みません。",
  addWithdrawalBtn: "",
  cancelWithdrawalEditBtn: "",
  exportBranchReportBtn: "",
  importBranchReportBtn: "",
  scriptRefreshShotBtn: "",
  scriptCopyScreenTextBtn: "",
  scriptCopyDeviceClipboardBtn: "",
  scriptAdbChromeTestBtn: "",
  scriptMinimalPresetBtn: "",
  scriptDebugPresetBtn: "",
  scriptChromePresetBtn: "",
  scriptAddLaunchBtn: "",
  scriptAddWaitBtn: "",
  scriptAddTextBtn: "",
  scriptAddBackBtn: "",
  scriptAddHomeBtn: "",
  scriptClearBtn: "",
  scriptInstallTestsBtn: "",
  scriptFolderCheckBtn: "",
  scriptLogTailBtn: "",
  scriptLogMarkBtn: "",
  scriptLogDeltaBtn: "",
  scriptCopyAdminInstallBtn: "",
  scriptCopyBtn: "",
  scriptDownloadBtn: "",
  scriptRunXiaoweiBtn: "",
});
const BUTTON_CLASS_HELP = Object.freeze({
  "edit-withdrawal-btn": "",
  "delete-withdrawal-btn": "",
  "reset-action": "",
  "clipboard-task-run-btn": "",
  "clipboard-send-btn": "",
  "clipboard-copy-btn": "",
  "clipboard-number-step-btn": "",
  "clipboard-move-up-btn": "",
  "clipboard-move-down-btn": "",
  "clipboard-edit-btn": "",
  "clipboard-delete-btn": "",
  "apn-paste-btn": "",
  "script-step-delete": "",
});

document.addEventListener("DOMContentLoaded", () => {
  restoreLogLines();
  bindTabs();
  bindManualTabs();
  bindButtonHelp();
  bindActions();
  clearOfflineDeviceForm();
  bindPageReloadShortcut();
  window.addEventListener("message", handleAppMessage);
  setupRewardCalculator();
  renderApnPalette();
  loadClipboardItems();
  loadPersistentSyncLogs();
  loadSummary({ includeAdb: true, includeUptime: false });
  refreshRunningSwipeJobs();
  startUptimeTicker();
  startAdbConnectionMonitor();
  startDeviceFactsAutoRefresh();
  initializeRemoteAccess();
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) refreshAdbConnectionSnapshot();
  });
  window.addEventListener("focus", refreshAdbConnectionSnapshot);
});

async function handleAppMessage(event) {
  if (!event || !event.data || event.data.type !== "tag-board-db-updated") return;
  try {
    await loadLocalSummaryOnly();
    logLine("チェック一覧の変更をDBへ反映しました");
  } catch (error) {
    logLine("チェック一覧変更後のDB再読込 NG: " + error.message);
  }
}

function bindTabs() {
  for (const button of document.querySelectorAll(".tab")) {
    button.addEventListener("click", () => {
      for (const item of document.querySelectorAll(".tab")) item.classList.toggle("active", item === button);
      for (const panel of document.querySelectorAll(".panel")) panel.classList.toggle("active", panel.id === button.dataset.tab);
      document.body.dataset.activeTab = button.dataset.tab || "";
    });
  }
  for (const button of document.querySelectorAll(".auto-op-tab")) {
    button.addEventListener("click", () => switchAutoOperationPanel(button.dataset.autoOp || "autoSwipe"));
  }
  const active = document.querySelector(".tab.active");
  document.body.dataset.activeTab = active?.dataset.tab || "";
}

function switchAutoOperationPanel(panelId) {
  for (const button of document.querySelectorAll(".auto-op-tab")) {
    button.classList.toggle("active", button.dataset.autoOp === panelId);
  }
  for (const panel of document.querySelectorAll(".auto-op-panel")) {
    panel.classList.toggle("active", panel.id === panelId);
  }
}

function switchToTab(tabId) {
  const button = document.querySelector(`.tab[data-tab="${tabId}"]`);
  if (button) button.click();
}

function bindManualTabs() {
  const buttons = [...document.querySelectorAll(".manual-tab")];
  const pages = [...document.querySelectorAll(".manual-page")];
  for (const button of buttons) {
    button.addEventListener("click", () => {
      const target = button.dataset.manualPage;
      for (const item of buttons) item.classList.toggle("active", item === button);
      for (const page of pages) page.classList.toggle("active", page.dataset.manualPage === target);
    });
  }
}

function bindButtonHelp() {
  const popup = document.createElement("div");
  popup.id = "buttonHelpPopup";
  popup.className = "button-help-popover";
  popup.setAttribute("role", "tooltip");
  popup.hidden = true;
  document.body.appendChild(popup);
  let activeButton = null;

  const show = (button) => {
    const text = buttonHelpText(button);
    if (!text) return;
    activeButton = button;
    popup.textContent = text;
    popup.hidden = false;
    popup.classList.add("visible");
    positionButtonHelp(button, popup);
  };
  const hide = () => {
    activeButton = null;
    popup.classList.remove("visible");
    popup.hidden = true;
  };

  document.addEventListener("pointerover", (event) => {
    const button = event.target.closest("button");
    if (button) show(button);
  });
  document.addEventListener("pointerout", (event) => {
    if (!activeButton) return;
    const next = event.relatedTarget;
    if (next && activeButton.contains(next)) return;
    hide();
  });
  document.addEventListener("focusin", (event) => {
    const button = event.target.closest("button");
    if (button) show(button);
  });
  document.addEventListener("focusout", hide);
  document.addEventListener("click", hide);
  window.addEventListener("scroll", hide, true);
  window.addEventListener("resize", hide);
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") hide();
  });
}

function buttonHelpText(button) {
  if (!button) return "";
  if (button.classList.contains("tab") || button.classList.contains("manual-tab")) return "";
  if (button.dataset.help) return button.dataset.help;
  if (button.id && Object.prototype.hasOwnProperty.call(BUTTON_HELP, button.id)) return BUTTON_HELP[button.id] || "";
  for (const [className, text] of Object.entries(BUTTON_CLASS_HELP)) {
    if (button.classList.contains(className)) return text;
  }
  const label = button.textContent.trim();
  if (!label) return "";
  return `${label}を実行します`;
}

function positionButtonHelp(button, popup) {
  const rect = button.getBoundingClientRect();
  const gap = 8;
  const maxWidth = Math.min(360, window.innerWidth - 18);
  popup.style.maxWidth = `${maxWidth}px`;
  popup.style.left = "0px";
  popup.style.top = "0px";
  const width = popup.offsetWidth;
  const height = popup.offsetHeight;
  let left = rect.left + rect.width / 2 - width / 2;
  left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
  let top = rect.bottom + gap;
  let arrowBottom = false;
  if (top + height > window.innerHeight - 8) {
    top = rect.top - height - gap;
    arrowBottom = true;
  }
  const arrowLeft = Math.max(14, Math.min(width - 14, rect.left + rect.width / 2 - left));
  popup.style.left = `${left}px`;
  popup.style.top = `${Math.max(8, top)}px`;
  popup.style.setProperty("--arrow-left", `${arrowLeft}px`);
  popup.classList.toggle("arrow-bottom", arrowBottom);
}

function bindActions() {
  el("remoteAccessBtn")?.addEventListener("click", (event) => showRemoteAccessDialog(event.currentTarget));
  el("pageReloadBtn").addEventListener("click", reloadWholePage);
  el("firstRunSetupBtn").addEventListener("click", (event) => runFirstSetup(event.currentTarget));
  el("reloadBtn").addEventListener("click", () => loadSummary({ includeAdb: true, includeUptime: false }));
  el("saveSiteNameBtn").addEventListener("click", saveSiteName);
  el("siteNameInput").addEventListener("keydown", (event) => {
    if (event.key === "Enter") saveSiteName();
  });
  el("withdrawalForm").addEventListener("submit", addManualWithdrawal);
  el("cancelWithdrawalEditBtn").addEventListener("click", clearWithdrawalForm);
  el("withdrawalRows").addEventListener("click", handleWithdrawalRowAction);
  el("offlineDeviceForm").addEventListener("submit", saveOfflineDevice);
  el("offlineDeviceCancelBtn").addEventListener("click", clearOfflineDeviceForm);
  el("offlineDeviceRows").addEventListener("click", handleOfflineDeviceRowAction);
  el("offlineDeviceRows").addEventListener("change", handleOfflineDeviceTaskChange);
  el("deviceRows").addEventListener("click", handleDeviceRowAction);
  el("deviceRows").addEventListener("input", handleDeviceNameInput);
  el("deviceRows").addEventListener("change", handleDeviceTaskSelectChange);
  el("deviceRows").addEventListener("focusout", schedulePendingDeviceRender);
  el("saveDeviceNamesBtn").addEventListener("click", saveChangedDeviceNames);
  el("saveInviteFactorsBtn").addEventListener("click", saveChangedDeviceNames);
  el("deviceNameSequenceEditBtn").addEventListener("click", openDeviceNameSequenceDialog);
  el("deviceDayOrderBtn").addEventListener("click", (event) => runDeviceNumberResequence(event.currentTarget, "day"));
  el("deviceModelOrderBtn").addEventListener("click", (event) => runDeviceNumberResequence(event.currentTarget, "model"));
  el("deviceUptimeRefreshBtn").addEventListener("click", (event) => refreshDeviceUptime(event.currentTarget));
  el("usbAdbDiagnosisBtn").addEventListener("click", (event) => showUsbAdbDiagnosisDialog(event.currentTarget));
  el("deviceCodeAuditBtn").addEventListener("click", (event) => showDeviceCodeAuditDialog(event.currentTarget));
  el("retiredDevicesBtn").addEventListener("click", (event) => showRetiredDevicesDialog(event.currentTarget));
  el("deviceMasterReloadBtn").addEventListener("click", loadDeviceMaster);
  el("deviceMasterSearchInput").addEventListener("input", () => renderDeviceMaster(state.deviceMaster));
  el("deviceMasterForm").addEventListener("submit", saveDeviceMasterEntry);
  el("deviceMasterCancelBtn").addEventListener("click", clearDeviceMasterForm);
  el("deviceMasterRows").addEventListener("click", handleDeviceMasterRowAction);
  el("deviceMasterRows").addEventListener("change", handleDeviceMasterInlineChange);
  el("deviceMasterRows").addEventListener("keydown", handleDeviceMasterInlineKeydown);
  el("deviceMasterImportBtn").addEventListener("click", importDeviceMasterCsv);
  el("syncLogFilter").addEventListener("change", renderSyncLogs);
  el("syncLogSearch").addEventListener("input", renderSyncLogs);
  el("syncLogSaveBtn").addEventListener("click", downloadSyncLogs);
  el("syncLogClearBtn").addEventListener("click", clearSyncLogs);
  el("exportBranchReportBtn").addEventListener("click", exportBranchReport);
  el("importBranchReportBtn").addEventListener("click", () => el("branchReportFileInput").click());
  el("branchReportFileInput").addEventListener("change", importBranchReportFile);
  el("tagSyncBtn").addEventListener("click", (event) => runXiaoweiFullSync(event.currentTarget));
  el("dayAdvanceBtn").addEventListener("click", (event) => runDayAdvance(event.currentTarget));
  el("deviceCodeSyncBtn").addEventListener("click", (event) => runDeviceCodeSync(event.currentTarget));
  el("xiaoweiNameSyncBtn").addEventListener("click", (event) => runXiaoweiNameSync(event.currentTarget));
  el("xiaoweiNumberSyncBtn").addEventListener("click", (event) => runXiaoweiNumberSync(event.currentTarget));
  el("importAdbNewBtn").addEventListener("click", (event) => importNewAdbDevices(event.currentTarget));
  setupAdbSwipeControls();
  el("adbSwipeApplyBulkBtn").addEventListener("click", applyAdbSwipeBulkMinutes);
  el("adbSwipeSelectAllBtn").addEventListener("click", () => setAdbSwipeSelection("all"));
  el("adbSwipeSelectActiveBtn").addEventListener("click", () => setAdbSwipeSelection("active"));
  el("adbSwipeClearSelectionBtn").addEventListener("click", () => setAdbSwipeSelection("none"));
  el("adbSwipeRefreshBtn").addEventListener("click", refreshAdbSwipeDevices);
  el("adbSwipeRestartTtlBtn").addEventListener("click", (event) => restartTtlForSelectedAdbSwipeDevices(event.currentTarget));
  el("adbSwipeStartBtn").addEventListener("click", (event) => startAdbSwipeJobFromPanel(event.currentTarget));
  el("adbSwipeStopBtn").addEventListener("click", (event) => stopAllSwipeJobs(event.currentTarget));
  el("adbSwipeDeviceGrid").addEventListener("change", handleAdbSwipeGridChange);
  setupSwipeAgentControls();
  el("swipeAgentApplyBulkBtn").addEventListener("click", applySwipeAgentBulkMinutes);
  el("swipeAgentSelectAllBtn").addEventListener("click", () => setSwipeAgentSelection("all"));
  el("swipeAgentSelectActiveBtn").addEventListener("click", () => setSwipeAgentSelection("active"));
  el("swipeAgentClearSelectionBtn").addEventListener("click", () => setSwipeAgentSelection("none"));
  el("swipeAgentRefreshBtn").addEventListener("click", refreshSwipeAgentDevices);
  el("swipeAgentStatusBtn").addEventListener("click", (event) => runSwipeAgentInstallAction("", "/api/swipe-agent/install-status", event.currentTarget));
  el("swipeAgentInstallBtn").addEventListener("click", (event) => runSwipeAgentInstallAction("Agent準備", "/api/swipe-agent/install", event.currentTarget));
  el("swipeRecoveryTestBtn").addEventListener("click", (event) => runSwipeRecoveryTest(event.currentTarget));
  el("swipeLiveRecoveryTestBtn").addEventListener("click", (event) => runSwipeRecoveryTest(event.currentTarget, { stopAgent: false }));
  el("swipeAgentStartBtn").addEventListener("click", (event) => startSwipeAgentJobFromPanel(event.currentTarget));
  el("swipeAgentStopBtn").addEventListener("click", (event) => stopAllSwipeJobs(event.currentTarget));
  el("swipeAgentDeviceGrid").addEventListener("click", handleSwipeAgentGridClick, true);
  el("swipeAgentDeviceGrid").addEventListener("change", handleSwipeAgentGridChange);
  el("swipeAgentJobPanel").addEventListener("click", handleSwipeJobPanelClick);
  el("swipePastLogsModal").addEventListener("click", handleSwipePastLogsModalClick);
  document.addEventListener("keydown", handleSwipePastLogsKeydown);
  el("clipboardForm").addEventListener("submit", saveClipboardForm);
  el("clipboardTitlePreset").addEventListener("change", syncClipboardTitleInputVisibility);
  syncClipboardTitleInputVisibility();
  el("clipboardCaptureBtn").addEventListener("click", captureSelectedDeviceClipboardToVault);
  el("clipboardClearBtn").addEventListener("click", clearClipboardForm);
  el("clipboardReloadBtn").addEventListener("click", loadClipboardItems);
  el("clipboardItems").addEventListener("click", handleClipboardItemAction);
  el("clipboardTargetGrid").addEventListener("change", handleClipboardTargetChange);
  el("clipboardSelectActiveBtn").addEventListener("click", () => selectClipboardTargets("active"));
  el("clipboardSelectAllBtn").addEventListener("click", () => selectClipboardTargets("all"));
  el("clipboardManualSelectBtn").addEventListener("click", () => selectClipboardTargets("manual"));
  el("clipboardClearTargetsBtn").addEventListener("click", () => selectClipboardTargets("clear"));
  el("clipboardCloseTtlBtn").addEventListener("click", (event) => closeTtlForSelectedClipboardTargets(event.currentTarget));
  el("clipboardLaunchTtlBtn").addEventListener("click", (event) => launchAppForSelectedClipboardTargets("ttl", "", event.currentTarget));
  el("clipboardLaunchLineBtn").addEventListener("click", (event) => launchAppForSelectedClipboardTargets("line", "", event.currentTarget));
  el("clipboardInstallApkBtn").addEventListener("click", (event) => installApksForSelectedClipboardTargets(event.currentTarget));
  el("clipboardExtractAppBtn").addEventListener("click", (event) => extractAppBundleFromSelectedClipboardTarget(event.currentTarget));
  el("clipboardTtlInviteDiagnosticsBtn").addEventListener("click", (event) => diagnoseTtlInviteForSelectedClipboardTargets(event.currentTarget));
  el("clipboardTtlCleanupBtn").addEventListener("click", (event) => cleanupTtlInviteForSelectedClipboardTargets(event.currentTarget));
  el("clipboardOpenApkFolderBtn").addEventListener("click", (event) => openApkFolder(event.currentTarget));
  el("clipboardOpenApkLinksBtn").addEventListener("click", () => window.open("/apk-download-links.html", "_blank", "noopener"));
  el("clipboardActiveOnlyInput").addEventListener("change", () => {
    pruneClipboardTargets();
    renderClipboardTargets(state.summary?.devices || []);
  });
  el("clipboardExcludeSourceInput").addEventListener("change", () => renderClipboardTargets(state.summary?.devices || []));
  el("apnOpenSettingsBtn").addEventListener("click", (event) => openApnSettingsForSelectedDevice(event.currentTarget));
  el("apnPalette").addEventListener("click", handleApnPaletteAction);
  el("baselineSettingsBtn").addEventListener("click", (event) => {
    const ok = window.confirm("端末初期設定を接続中の未完了端末へ実行します。稼働中端末も対象です。DBで完了済みの項目はスキップします。よろしいですか？");
    if (!ok) return;
    runDeviceSettingAction("端末初期設定", "/api/adb/baseline-device-settings", event.currentTarget);
  });
  el("xiaomiMiuiOptimizeBtn").addEventListener("click", (event) => {
    const ok = window.confirm("接続中のXiaomi/Redmi/POCO端末だけにMIUI広告・解析・フィードバック無効化を実行します。稼働中端末も対象です。よろしいですか？");
    if (!ok) return;
    runDeviceSettingAction("Xiaomi最適化", "/api/adb/xiaomi-miui-optimize", event.currentTarget);
  });
  el("baselineSettingsRefreshBtn").addEventListener("click", (event) =>
    refreshBaselineSettings(event.currentTarget)
  );
  el("exportSheetsBtn").addEventListener("click", (event) =>
    runAction("", "/api/fleet-db/export-sheets", event.currentTarget)
  );
  el("saveDbBtn").addEventListener("click", (event) => saveDbFile(event.currentTarget));
  el("backupBtn").addEventListener("click", (event) => runAction("DBバックアップ", "/api/fleet-db/backup", event.currentTarget));
  el("migrationExportBtn").addEventListener("click", (event) => runAction("移行データ作成", "/api/migration/export", event.currentTarget));
  el("migrationOpenBtn").addEventListener("click", (event) => runAction("移行フォルダ", "/api/migration/open", event.currentTarget));
  el("migrationImportBtn").addEventListener("click", (event) => importMigrationDataFromFolder(event.currentTarget));
  bindScriptBuilderActions();
}

async function initializeRemoteAccess() {
  const button = el("remoteAccessBtn");
  if (!button) return;
  try {
    const status = await fetchJson("/api/remote-access/status");
    if (!status.available) return;
    state.remoteAccess = status;
    button.classList.remove("hidden");
    updateRemoteAccessButton(status);
  } catch {
    button.classList.add("hidden");
  }
}

function updateRemoteAccessButton(status) {
  const button = el("remoteAccessBtn");
  if (!button) return;
  button.textContent = status?.enabled ? "リモートON" : "リモート接続";
  button.classList.toggle("is-active", Boolean(status?.enabled));
}

async function showRemoteAccessDialog(button = null) {
  if (button) setBusy(true, button, "確認中...");
  try {
    const status = await fetchJson("/api/remote-access/status");
    state.remoteAccess = status;
    updateRemoteAccessButton(status);
    renderRemoteAccessDialog(status);
  } catch (error) {
    logLine("リモート接続 状態確認NG: " + error.message);
    window.alert("リモート接続の状態を確認できませんでした。\n" + error.message);
  } finally {
    if (button) setBusy(false);
  }
}

function renderRemoteAccessDialog(status) {
  document.querySelector(".remote-access-dialog-backdrop")?.remove();
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop remote-access-dialog-backdrop";
  const installedLabel = status.installed ? "インストール済み" : "未インストール";
  const connectedLabel = status.connected ? "ログイン済み" : "未接続";
  const sharingLabel = status.enabled ? "リモートON" : "リモートOFF";
  const viewerLabel = status.viewer?.remote
    ? `リモート接続中${status.viewer.name || status.viewer.login ? `: ${status.viewer.name || status.viewer.login}` : ""}`
    : "このWindows PCから表示中";
  const remoteUrl = status.remoteUrl || "開始後に表示されます";
  const startDisabled = !status.installed || !status.connected || status.enabled;
  const stopDisabled = !status.enabled;
  const installNotice = !status.installed
    ? `<div class="remote-access-notice warn"><strong>最初にTailscaleをインストール</strong><span>このWindows PCと、外から使うノートPC・タブレットの両方へ入れ、同じアカウントでログインします。</span></div>`
    : !status.connected
      ? `<div class="remote-access-notice warn"><strong>Tailscaleへログインしてください</strong><span>WindowsのTailscaleを起動し、外から使う端末と同じネットワークへ接続します。</span></div>`
      : "";
  const consentNotice = status.consentUrl
    ? `<div class="remote-access-notice warn"><strong>初回の許可が必要です</strong><span>Tailscaleの確認画面を開き、HTTPS公開を許可してから再度開始してください。</span><a class="remote-access-link" href="${esc(status.consentUrl)}" target="_blank" rel="noopener">確認画面を開く</a></div>`
    : "";
  overlay.innerHTML = `
    <div class="adb-drop-dialog remote-access-dialog" role="dialog" aria-modal="true" aria-labelledby="remoteAccessDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="remoteAccessDialogTitle">Fleetリモート接続</h3>
          <p>許可した端末からFleetだけを操作します。インターネットへ一般公開はしません。</p>
        </div>
        <button class="adb-drop-close remote-access-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="remote-access-dialog-body">
        <div class="remote-access-status-grid">
          <div><span>Tailscale</span><strong class="${status.installed ? "ok" : "warn"}">${installedLabel}</strong></div>
          <div><span>接続状態</span><strong class="${status.connected ? "ok" : "warn"}">${connectedLabel}</strong></div>
          <div><span>Fleet公開</span><strong class="${status.enabled ? "ok" : "muted"}">${sharingLabel}</strong></div>
          <div><span>現在の表示</span><strong>${esc(viewerLabel)}</strong></div>
        </div>
        ${installNotice}
        ${consentNotice}
        <div class="remote-access-url-panel">
          <span>このPC</span>
          <code>${esc(status.localUrl || "http://127.0.0.1:8787/app")}</code>
          <span>出先用URL</span>
          <code class="remote-access-url-value">${esc(remoteUrl)}</code>
        </div>
        <div class="remote-access-rules">
          <p>・Windows PC、XiaoWei、Fleet Agentは起動したままにします。</p>
          <p>・外から使う端末もTailscaleへログインして、このURLをブラウザで開きます。</p>
          <p>・公開専用ポートはHTTPS ${Number(status.httpsPort || 8443)}です。ルーターのポート開放は不要です。</p>
        </div>
      </div>
      <div class="remote-access-dialog-actions">
        <a class="remote-access-link button-like" href="${esc(status.installUrl || "https://tailscale.com/download/windows")}" target="_blank" rel="noopener">Tailscale公式</a>
        <button class="remote-access-refresh" type="button">状態更新</button>
        <button class="remote-access-copy" type="button" ${status.enabled && status.remoteUrl ? "" : "disabled"}>URLコピー</button>
        <button class="remote-access-open" type="button" ${status.enabled && status.remoteUrl ? "" : "disabled"}>URLを開く</button>
        <button class="remote-access-start primary-action" type="button" ${startDisabled ? "disabled" : ""}>リモート開始</button>
        <button class="remote-access-stop danger-action" type="button" ${stopDisabled ? "disabled" : ""}>リモート停止</button>
        <button class="adb-drop-close-action remote-access-close" type="button">閉じる</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);

  overlay.querySelectorAll(".remote-access-close").forEach((closeButton) => {
    closeButton.addEventListener("click", () => overlay.remove());
  });
  overlay.querySelector(".remote-access-refresh")?.addEventListener("click", (event) => refreshRemoteAccessDialog(event.currentTarget));
  overlay.querySelector(".remote-access-start")?.addEventListener("click", (event) => changeRemoteAccess("start", event.currentTarget));
  overlay.querySelector(".remote-access-stop")?.addEventListener("click", (event) => changeRemoteAccess("stop", event.currentTarget));
  overlay.querySelector(".remote-access-copy")?.addEventListener("click", (event) => copyRemoteAccessUrl(status.remoteUrl, event.currentTarget));
  overlay.querySelector(".remote-access-open")?.addEventListener("click", () => window.open(status.remoteUrl, "_blank", "noopener"));
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) overlay.remove();
  });
}

async function refreshRemoteAccessDialog(button) {
  button.disabled = true;
  button.textContent = "確認中...";
  try {
    const status = await fetchJson("/api/remote-access/status");
    state.remoteAccess = status;
    updateRemoteAccessButton(status);
    renderRemoteAccessDialog(status);
  } catch (error) {
    window.alert("状態を更新できませんでした。\n" + error.message);
    button.disabled = false;
    button.textContent = "状態更新";
  }
}

async function changeRemoteAccess(action, button) {
  const isStart = action === "start";
  button.disabled = true;
  button.textContent = isStart ? "開始中..." : "停止中...";
  try {
    const response = await fetch(`/api/remote-access/${action}`, { method: "POST" });
    const status = await response.json();
    state.remoteAccess = status;
    updateRemoteAccessButton(status);
    logLine(`リモート接続 ${status.enabled ? "ON" : "OFF"}: ${status.remoteUrl || status.code || ""}`);
    renderRemoteAccessDialog(status);
  } catch (error) {
    window.alert(`リモート接続を${isStart ? "開始" : "停止"}できませんでした。\n${error.message}`);
    await showRemoteAccessDialog();
  }
}

async function copyRemoteAccessUrl(url, button) {
  if (!url) return;
  try {
    await navigator.clipboard.writeText(url);
  } catch {
    const input = document.createElement("textarea");
    input.value = url;
    document.body.appendChild(input);
    input.select();
    document.execCommand("copy");
    input.remove();
  }
  flashButtonResult(button, "コピー済み");
}

function bindPageReloadShortcut() {
  document.addEventListener("keydown", (event) => {
    const key = String(event.key || "").toLowerCase();
    if (event.key === "F5" || ((event.ctrlKey || event.metaKey) && key === "r")) {
      event.preventDefault();
      reloadWholePage();
    }
  });
}

function reloadWholePage() {
  window.location.reload();
}

function announceUnregisteredDeviceMaster(result, contextLabel = "端末確認") {
  const rows = Array.isArray(result?.masterUnregisteredDevices)
    ? result.masterUnregisteredDevices
    : Array.isArray(result?.identityRefresh?.masterUnregisteredDevices)
      ? result.identityRefresh.masterUnregisteredDevices
      : [];
  if (!rows.length) return 0;

  for (const row of rows) {
    const number = row.xiaoweiNumber ? `No.${row.xiaoweiNumber}` : row.managementId || "番号未定";
    logLine(`端末マスタ未登録: ${number} / 型番 ${row.modelCode || "不明"} / XiaoWei名 ${row.xiaoweiName || "不明"} / キャリア ${row.carrierCode || "UNKNOWN"}`);
  }
  const visibleRows = rows.slice(0, 12).map((row) => {
    const number = row.xiaoweiNumber ? `No.${row.xiaoweiNumber}` : row.managementId || "番号未定";
    return `・${number} / 型番 ${row.modelCode || "不明"} / XiaoWei名 ${row.xiaoweiName || "不明"} / キャリア ${row.carrierCode || "UNKNOWN"}`;
  });
  if (rows.length > visibleRows.length) visibleRows.push(`・ほか ${rows.length - visibleRows.length}台（全件は同期ログに表示）`);
  window.alert([
    `端末マスタに登録されていない機種があります（${rows.length}台）`,
    "",
    ...visibleRows,
    "",
    "端末マスタへ登録した後、「端末名を再取得」を押してください。",
  ].join("\n"));
  logLine(`${contextLabel} 要確認: 端末マスタ未登録 ${rows.length}台`);
  return rows.length;
}

function waitForMs(delayMs) {
  return new Promise((resolve) => window.setTimeout(resolve, Math.max(0, Number(delayMs) || 0)));
}

function mergeNewDeviceImportResults(results = []) {
  const rows = results.filter(Boolean);
  const latest = rows[rows.length - 1] || {};
  const importedBySerial = new Map();
  const masterIssueBySerial = new Map();
  for (const result of rows) {
    for (const device of result.devices || []) {
      const key = String(device.serial || device.managementId || importedBySerial.size);
      importedBySerial.set(key, device);
    }
    for (const issue of result.masterUnregisteredDevices || []) {
      const key = String(issue.serial || issue.xiaoweiNumber || issue.managementId || masterIssueBySerial.size);
      masterIssueBySerial.set(key, issue);
    }
  }
  const devices = [...importedBySerial.values()];
  const masterUnregisteredDevices = [...masterIssueBySerial.values()];
  return {
    ...latest,
    ok: rows.length > 0 && rows.every((result) => result.ok !== false),
    passes: rows.length,
    scanned: Math.max(0, ...rows.map((result) => Number(result.scanned || 0))),
    adbScanned: Math.max(0, ...rows.map((result) => Number(result.adbScanned || 0))),
    xiaoweiScanned: Math.max(0, ...rows.map((result) => Number(result.xiaoweiScanned || 0))),
    windowsUsbSeen: Math.max(0, ...rows.map((result) => Number(result.windowsUsbSeen || 0))),
    xiaoweiUsbConfirmed: Math.max(0, ...rows.map((result) => Number(result.xiaoweiUsbConfirmed || 0))),
    imported: devices.length,
    devices,
    masterUnregisteredCount: masterUnregisteredDevices.length,
    masterUnregisteredDevices,
  };
}

async function importNewDevicesUntilStable(options = {}) {
  const label = options.label || "新規端末取込";
  const minPasses = Math.max(1, Number(options.minPasses || 3));
  const maxPasses = Math.max(minPasses, Number(options.maxPasses || 5));
  const initialDelayMs = Math.max(0, Number(options.initialDelayMs ?? 0));
  const intervalMs = Math.max(0, Number(options.intervalMs ?? 3000));
  const results = [];
  let consecutiveNoNew = 0;

  if (initialDelayMs) {
    logLine(`${label}: 接続が揃うまで${Math.ceil(initialDelayMs / 1000)}秒待機`);
    await waitForMs(initialDelayMs);
  }
  for (let pass = 1; pass <= maxPasses; pass += 1) {
    const result = await fetchJson("/api/fleet-db/import-adb-new", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    results.push(result);
    const imported = Number(result.imported || 0);
    consecutiveNoNew = imported > 0 ? 0 : consecutiveNoNew + 1;
    logLine(`${label} 自動確認 ${pass}/${maxPasses}: 現在検出 ${result.scanned || 0}台 / 追加 ${imported}台`);
    if (pass >= minPasses && consecutiveNoNew >= 2) break;
    if (pass < maxPasses) await waitForMs(intervalMs);
  }
  return mergeNewDeviceImportResults(results);
}

async function launchUsbOnlyAutoRepair() {
  const diagnosis = await fetchJson("/api/adb/usb-diagnosis?all=1&xiaoweiOnly=1");
  const rows = (diagnosis.rows || []).filter((row) => row.diagnosis === "usb_only" && row.serial);
  if (!rows.length) return { launched: false, count: 0, rows: [] };
  const serials = [...new Set(rows.map((row) => String(row.serial)).filter(Boolean))];
  logLine(`接続準備: USBだけ見えている端末 ${serials.length}台を自動復旧します`);
  const result = await fetchJson("/api/adb/usb-repair", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ serials, allowXiaoweiKnown: true, deep: false }),
  });
  logLine(`USB自動復旧 起動: ${serials.length}台 / UACが表示されたら「はい」を押してください`);
  return { ...result, launched: true, count: serials.length, rows };
}

async function runFirstSetup(button = null) {
  const ok = window.confirm("接続準備と新規端末取込を実行します。\nADB起動、USB再スキャン、接続確認、DB未登録端末の取込をまとめて行います。\nスマホ側にUSBデバッグ許可が出たらOKを押してください。");
  if (!ok) return;
  setBusy(true, button);
  logLine("接続準備・新規取込 実行中: ADB起動 / USB再スキャン / 接続確認");
  let flash = { message: "完了", type: "ok" };
  try {
    const setup = await fetchJson("/api/setup/first-run", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    const adbKind = setup.bundledAdb ? "同梱ADB" : "外部ADB";
    const xiaoweiCount = setup.xiaoweiPort?.connected ?? 0;
    logLine(`接続準備 OK: ${adbKind} / XiaoWei接続 ${xiaoweiCount}台 / ${setup.adbPath || ""}`);
    let imported = await importNewDevicesUntilStable({
      label: "接続準備・新規取込",
      initialDelayMs: 2500,
      minPasses: 3,
      maxPasses: 5,
      intervalMs: 3000,
    });
    try {
      const repair = await launchUsbOnlyAutoRepair();
      if (repair.launched) {
        logLine("USB自動復旧 完了待ち: 18秒後に接続と新規端末を再確認します");
        await waitForMs(18000);
        const afterRepair = await importNewDevicesUntilStable({
          label: "USB復旧後の新規取込",
          minPasses: 3,
          maxPasses: 4,
          intervalMs: 3000,
        });
        const totalPasses = Number(imported.passes || 0) + Number(afterRepair.passes || 0);
        imported = mergeNewDeviceImportResults([imported, afterRepair]);
        imported.passes = totalPasses;
        const recheck = await fetchJson("/api/adb/usb-diagnosis?all=1&xiaoweiOnly=1");
        const remainingUsbOnly = (recheck.rows || []).filter((row) => row.diagnosis === "usb_only").length;
        if (remainingUsbOnly) {
          flash = { message: "復旧確認", type: "warn" };
          logLine(`USB自動復旧 要確認: USBだけ見えている端末が残り${remainingUsbOnly}台あります。UAC許可後、必要なら抜き差ししてください`);
        } else {
          logLine("USB自動復旧 確認OK: USBだけ見えている端末は残っていません");
        }
      }
    } catch (repairError) {
      flash = { message: "復旧確認", type: "warn" };
      logLine(`USB自動復旧 要確認: ${repairError.message}`);
    }
    const labels = (imported.devices || []).slice(0, 5).map((device) => `${device.managementId} ${device.name || device.model || device.serial}`).join(" / ");
    logLine(`新規端末取込 OK: 自動確認 ${imported.passes || 0}回 / 検出 ${imported.scanned || 0}台（ADB ${imported.adbScanned || 0}台 / XiaoWei現役 ${imported.xiaoweiScanned || 0}台） / 新規 ${imported.imported || 0}台 / 登録済 ${imported.skipped || 0}台${labels ? " / " + labels : ""}`);
    if (Number(imported.xiaoweiHistorySkipped || 0) > 0) {
      logLine(`新規端末取込 除外: XiaoWeiの未接続保存履歴 ${imported.xiaoweiHistorySkipped}台`);
    }
    if (announceUnregisteredDeviceMaster(imported, "接続準備・新規取込")) {
      flash = { message: "マスタ未登録", type: "warn" };
    }
    if (!Number(imported.scanned || 0)) {
      flash = { message: "要確認", type: "warn" };
      logLine("接続準備・新規取込 要確認: 端末を検出できません。USBデバッグを許可して、同じボタンをもう一度押してください");
    }
    await loadSummary({ includeAdb: true, includeUptime: false });
    reloadTagBoardFrame();
  } catch (error) {
    flash = { message: "失敗", type: "error" };
    logLine("接続準備・新規取込 NG: " + error.message);
    window.alert("接続準備・新規端末取込に失敗しました。\n" + error.message);
  } finally {
    setBusy(false, button);
    flashButtonResult(button, flash.message, flash.type);
  }
}

function setupRewardCalculator() {
  fillSelect(el("calcCiSelect"), CALC_OPTIONS.ci, "yen");
  fillSelect(el("calc180Select"), CALC_OPTIONS.video180, "points");
  fillSelect(el("calc10Select"), CALC_OPTIONS.video10, "yen");
  el("calcCiSelect").value = "0";
  el("calc180Select").value = "0";
  el("calc10Select").value = "0";
  for (const id of ["calcCiSelect", "calc180Select", "calc10Select", "calc10CustomInput"]) {
    el(id).addEventListener("input", renderRewardCalculator);
    el(id).addEventListener("change", renderRewardCalculator);
  }
  renderRewardCalculator();
}

function fillSelect(select, options, valueKey) {
  select.innerHTML = options.map((option) => {
    const value = option[valueKey];
    return `<option value="${esc(value)}">${esc(option.label)}</option>`;
  }).join("");
}

function rowXiaoweiNumber(row) {
  return row?.xiaoweiNumber || row?.laixiNumber || row?.managementId || row?.xiaoweiSort || "";
}

async function loadSummary(options = {}) {
  const includeAdb = Boolean(options.includeAdb);
  const includeUptime = options.includeUptime !== false;
  setBusy(true);
  try {
    const [result, master, adbDevices, xiaoweiMissing] = await Promise.all([
      fetchJson("/api/fleet-db/summary"),
      fetchJson("/api/device-master").catch((error) => ({ ok: false, error: error.message, entries: [] })),
      includeAdb
        ? fetchJson(`/api/adb/devices${includeUptime ? "" : "?uptime=0"}`).catch((error) => ({ ok: false, error: error.message, devices: [] }))
        : Promise.resolve(state.adbDevices || { ok: true, skipped: true, devices: [] }),
      includeAdb
        ? fetchJson("/api/xiaowei/missing-from-xiaowei").catch((error) => ({ ok: false, error: error.message, rows: [] }))
        : Promise.resolve(null),
    ]);
    state.summary = result;
    state.deviceMaster = master;
    if (includeAdb || !state.adbDevices) storeAdbDevices(adbDevices);
    renderAll(result);
    renderDeviceMaster(master);
    const adbRows = state.adbDevices?.devices || [];
    renderAdbSwipePanel(result.devices || [], adbRows);
    renderSwipeAgentPanel(result.devices || [], adbRows);
    if (xiaoweiMissing) logXiaoweiMissingDevices(xiaoweiMissing);
    logLine(includeAdb ? `DB再読込 OK / ADB${includeUptime ? "稼働時間込み" : "軽量"}` : "DB再読込 OK");
  } catch (error) {
    logLine("DB再読込 NG: " + error.message);
  } finally {
    setBusy(false);
    checkFleetDbRecovery();
  }
}

async function loadLocalSummaryOnly() {
  const [result, master] = await Promise.all([
    fetchJson("/api/fleet-db/summary"),
    fetchJson("/api/device-master").catch((error) => ({ ok: false, error: error.message, entries: [] })),
  ]);
  state.summary = result;
  state.deviceMaster = master;
  renderAll(result);
  renderDeviceMaster(master);
  renderAdbSwipePanel(result.devices || [], state.adbDevices?.devices || []);
  renderSwipeAgentPanel(result.devices || [], state.adbDevices?.devices || []);
  return result;
}

async function checkFleetDbRecovery() {
  if (state.fleetDbRecoveryChecked || state.fleetDbRecoveryPrompted) return;
  state.fleetDbRecoveryChecked = true;
  try {
    const status = await fetchJson("/api/fleet-db/recovery-status");
    const candidate = (status.candidates || []).find((item) => item.candidateId === status.recommendedCandidateId);
    if (!status.recoveryNeeded || !candidate) return;
    state.fleetDbRecoveryPrompted = true;
    showFleetDbRecoveryDialog(status, candidate);
  } catch (error) {
    logLine("端末DB復旧確認 NG: " + error.message);
  }
}

function showFleetDbRecoveryDialog(status, candidate) {
  closeAdbDropDialog();
  const current = status.current || {};
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop fleet-db-recovery-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog" role="dialog" aria-modal="true" aria-labelledby="fleetDbRecoveryTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="fleetDbRecoveryTitle">端末DBを復旧できます</h3>
          <p>現在 接続${esc(current.devices || 0)}台・未接続${esc(current.offlineDevices || 0)}台 / チェック一覧 ${esc(status.tagBoardRows || 0)}台 / 更新直前バックアップ 接続${esc(candidate.devices || 0)}台・未接続${esc(candidate.offlineDevices || 0)}台</p>
        </div>
        <button class="adb-drop-close fleet-db-recovery-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="adb-missing-empty">
        <strong>更新前の端末DBが残っています。</strong><br>
        復旧前の現在DBも別の安全バックアップへ保存してから戻します。端末名、DAY、出金履歴を含むDBが対象です。<br>
        候補: ${esc(candidate.sourceLabel || "更新前バックアップ")} / ${esc(formatDateTime(candidate.backupAt || candidate.modifiedAt || ""))}
      </div>
      <div class="adb-drop-actions">
        <button class="section-head-action fleet-db-recovery-close" type="button">今は戻さない</button>
        <button class="section-head-action action-sync fleet-db-recover-action" type="button">更新直前DBを復旧</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".fleet-db-recovery-close").forEach((button) => {
    button.addEventListener("click", closeFleetDbRecoveryDialog);
  });
  overlay.querySelector(".fleet-db-recover-action")?.addEventListener("click", (event) => {
    recoverFleetDbFromDialog(status, candidate, event.currentTarget);
  });
}

async function recoverFleetDbFromDialog(status, candidate, button) {
  button.disabled = true;
  const originalLabel = button.textContent;
  button.textContent = "復旧中...";
  try {
    const result = await fetchJson("/api/fleet-db/recover", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        candidateId: candidate.candidateId,
        expectedCurrentDevices: Number(status.current?.devices || 0),
      }),
    });
    closeFleetDbRecoveryDialog();
    await loadLocalSummaryOnly();
    reloadTagBoardFrame();
    logLine(`端末DB復旧 OK: 接続${result.restored?.devices || 0}台・未接続${result.restored?.offlineDevices || 0}台 / 復旧前DBも保存済み`);
    window.alert(`端末DBを接続${result.restored?.devices || 0}台・未接続${result.restored?.offlineDevices || 0}台で復旧しました。\nチェック一覧と端末DBを再読込しました。`);
  } catch (error) {
    logLine("端末DB復旧 NG: " + error.message);
    window.alert("端末DBの復旧に失敗しました。\n" + error.message);
    button.disabled = false;
    button.textContent = originalLabel;
  }
}

function closeFleetDbRecoveryDialog() {
  document.querySelector(".fleet-db-recovery-backdrop")?.remove();
}

async function refreshDeviceMasterAndLocalSummary() {
  state.deviceMaster = await fetchJson("/api/device-master");
  renderDeviceMaster(state.deviceMaster);
  await loadLocalSummaryOnly();
}

function storeAdbDevices(adbDevices) {
  const fetchedAt = Date.now();
  const devices = Array.isArray(adbDevices?.devices) ? adbDevices.devices : [];
  rememberAdbLastSeen(devices, adbDevices, fetchedAt);
  const missingSerials = notifyAdbConnectionDrop(devices, adbDevices);
  state.adbMissingSerials = new Set(missingSerials);
  state.adbDevices = {
    ...(adbDevices || { ok: false, devices: [] }),
    devices: devices.map((device) => ({
      ...device,
      uptimeFetchedAt: Number.isFinite(Number(device.uptimeSeconds)) ? fetchedAt : 0,
    })),
    uptimeFetchedAt: fetchedAt,
  };
}

function rememberAdbLastSeen(devices = [], adbDevices = {}, fetchedAt = Date.now()) {
  if (!adbDevices || adbDevices.ok === false || adbDevices.skipped) return;
  const lastSeen = safeJsonObject(localStorage.getItem(ADB_LAST_SEEN_KEY));
  for (const device of devices) {
    if (!device?.serial || !(device.status === "device" || device.connected === true)) continue;
    lastSeen[String(device.serial)] = fetchedAt;
  }
  localStorage.setItem(ADB_LAST_SEEN_KEY, JSON.stringify(lastSeen));
}

function notifyAdbConnectionDrop(devices = [], adbDevices = {}) {
  if (!adbDevices || adbDevices.ok === false || adbDevices.skipped) return;
  const connectedSerials = devices
    .filter((device) => device && device.serial && (device.status === "device" || device.connected === true))
    .map((device) => String(device.serial))
    .sort();
  const connected = Number(adbDevices.connected ?? connectedSerials.length);
  const previousRaw = localStorage.getItem(ADB_CONNECTED_COUNT_KEY);
  const previous = previousRaw === null ? null : Number(previousRaw);
  const previousSerials = safeJsonArray(localStorage.getItem(ADB_CONNECTED_SERIALS_KEY));
  localStorage.setItem(ADB_CONNECTED_COUNT_KEY, String(connected));
  localStorage.setItem(ADB_CONNECTED_SERIALS_KEY, JSON.stringify(connectedSerials));
  if (!Number.isFinite(previous)) return [];
  if (previous <= connected) {
    if (previous < connected) localStorage.removeItem(ADB_DROP_ALERT_KEY);
    return [];
  }
  const missing = previousSerials.filter((serial) => !connectedSerials.includes(serial));
  if (!missing.length) return [];
  const alertKey = `dialog:${previous}->${connected}:${missing.slice(0, 20).join(",")}`;
  if (localStorage.getItem(ADB_DROP_ALERT_KEY) !== alertKey) {
    localStorage.setItem(ADB_DROP_ALERT_KEY, alertKey);
    const missingRows = missing.map(adbDropDeviceInfo);
    const missingText = ` / 消えた端末: ${missingRows.slice(0, 12).map((row) => row.label).join(", ")}${missing.length > 12 ? "..." : ""}`;
    const message = `ADB接続が減りました: ${previous}台 -> ${connected}台${missingText}`;
    logLine(message);
    if (!isAlertSuppressed(ALERT_ADB_DROP)) showAdbDropDialog({ previous, connected, missing, missingRows });
  }
  return missing;
}

function adbDropDeviceInfo(serial) {
  const row = (state.summary?.devices || []).find((device) => String(device.serial || "") === String(serial)) || {};
  const number = rowXiaoweiNumber(row);
  const name = row.laixiName || row.deviceLabel || row.deviceName || row.xiaoweiName || row.modelGroup || "";
  const master = row.deviceName || row.originalName || "";
  const label = [number, name].filter(Boolean).join(" / ") || String(serial || "");
  return {
    serial: String(serial || ""),
    number,
    name,
    master,
    status: row.status || "",
    label,
  };
}

function showAdbDropDialog({ previous, connected, missing, missingRows = null }) {
  closeAdbDropDialog();
  const rows = Array.isArray(missingRows) ? missingRows : missing.map(adbDropDeviceInfo);
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog" role="alertdialog" aria-modal="true" aria-labelledby="adbDropDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="adbDropDialogTitle">ADB接続が切れた端末があります</h3>
          <p>${esc(previous)}台 → ${esc(connected)}台 / 切断 ${esc(missing.length)}台</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="adb-drop-list">
        ${rows.map((row) => `
          <div class="adb-drop-device">
            <div class="adb-drop-device-main">
              <strong>${esc(row.number || "-")}</strong>
              <span>${esc(row.name || "端末名なし")}</span>
            </div>
            <div class="adb-drop-device-sub">
              ${row.master && row.master !== row.name ? `<span>マスタ: ${esc(row.master)}</span>` : ""}
              ${row.status ? `<span>状態: ${esc(row.status)}</span>` : ""}
              <code>${esc(row.serial)}</code>
            </div>
          </div>
        `).join("")}
      </div>
      <div class="adb-drop-actions">
        ${renderAlertSuppressCheckbox("ADB切断アラートを今後出さない")}
        <button class="section-head-action primary-action adb-drop-diagnose-action" type="button">処置する</button>
        <button class="section-head-action adb-drop-ignore-action" type="button" title="意図的に抜いた端末として、今回の切断を集計しません">意図的に外した</button>
        <button class="section-head-action adb-alert-ok-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  bindAlertOkAction(overlay, ALERT_ADB_DROP);
  overlay.querySelector(".adb-drop-diagnose-action")?.addEventListener("click", (event) => {
    showUsbAdbDiagnosisDialog(event.currentTarget);
  });
  overlay.querySelector(".adb-drop-ignore-action")?.addEventListener("click", (event) => {
    ignoreAdbDropHistory(missing, event.currentTarget);
  });
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((button) => {
    button.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

async function ignoreAdbDropHistory(serials, button = null) {
  const clean = [...new Set((serials || []).map((serial) => String(serial || "").trim()).filter(Boolean))];
  if (!clean.length) return;
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/fleet-db/connection-incidents/ignore", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ serials: clean }),
    });
    logLine(`意図的な取り外し: ${result.serials?.length || clean.length}台を切断集計から除外`);
    closeAdbDropDialog();
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine("切断履歴の除外 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function closeAdbDropDialog() {
  document.querySelector(".adb-drop-dialog-backdrop")?.remove();
}

function adbMissingRows() {
  const rows = Array.isArray(state.summary?.devices) ? state.summary.devices : [];
  const adbRows = Array.isArray(state.adbDevices?.devices) ? state.adbDevices.devices : [];
  const lastSeen = safeJsonObject(localStorage.getItem(ADB_LAST_SEEN_KEY));
  const connectedSerials = new Set(adbRows
    .filter((device) => device && device.serial && (device.status === "device" || device.connected === true))
    .map((device) => String(device.serial)));
  return rows
    .filter((row) => row && row.serial && !connectedSerials.has(String(row.serial)))
    .map((row) => ({
      number: rowXiaoweiNumber(row),
      xiaoweiNumber: rowXiaoweiNumber(row),
      laixiNumber: row.laixiNumber || row.managementId || "",
      name: row.deviceLabel || row.laixiName || row.deviceName || row.modelGroup || "",
      xiaoweiName: row.laixiName || "",
      model: row.modelGroup || "",
      status: row.status || "",
      serial: row.serial || "",
      lastSeenAt: adbMissingLastSeenAt(row, lastSeen),
    }))
    .sort((a, b) => managementNumber(a) - managementNumber(b) || String(a.name).localeCompare(String(b.name), "ja"));
}

async function showAdbMissingListDialog(button = null) {
  setBusy(true, button);
  try {
    const adbDevices = await fetchJson("/api/adb/devices?uptime=0");
    storeAdbDevices(adbDevices);
    if (adbDevices.connectionHistoryChanged) {
      await loadLocalSummaryOnly();
    } else if (state.summary?.devices) {
      renderDevices(state.summary.devices);
    }
  } catch (error) {
    logLine("ADB未認識一覧の再読込 NG: " + error.message);
  } finally {
    setBusy(false);
  }
  const rows = adbMissingRows();
  const activeRows = rows.filter((row) => String(row.status || "").toUpperCase() === "ACTIVE");
  closeAdbDropDialog();
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog" role="dialog" aria-modal="true" aria-labelledby="adbMissingDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="adbMissingDialogTitle">ADB未認識端末</h3>
          <p>DB登録 ${esc((state.summary?.devices || []).length)}台 / ADB認識 ${esc(state.adbDevices?.connected ?? "-")}台 / 未認識 ${esc(rows.length)}台${activeRows.length ? ` / ACTIVE ${esc(activeRows.length)}台` : ""}</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      ${rows.length ? `
        <div class="adb-missing-table-wrap">
          <table class="adb-missing-table">
            <thead>
              <tr>
                <th>選択</th>
                <th>番号</th>
                <th>名前</th>
                <th>状態</th>
                <th>最終認識</th>
                <th>端末ID</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map((row) => `
                <tr class="${String(row.status || "").toUpperCase() === "ACTIVE" ? "adb-missing-active" : ""}">
                  <td>${esc(row.number)}</td>
                  <td>
                    <strong>${esc(row.name)}</strong>
                    ${row.xiaoweiName && row.xiaoweiName !== row.name ? `<span>${esc(row.xiaoweiName)}</span>` : ""}
                  </td>
                  <td>${esc(row.status || "-")}</td>
                  <td>${esc(formatAdbLastSeen(row.lastSeenAt))}</td>
                  <td><code>${esc(row.serial)}</code></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">ADB未認識端末はありません。</div>`}
      <div class="adb-drop-actions">
        <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((button) => {
    button.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

async function showUsbAdbDiagnosisDialog(button = null) {
  setBusy(true, button);
  let result = null;
  try {
    result = await fetchJson("/api/adb/usb-diagnosis");
    logLine(`端末トラブル診断: DB ${result.dbCount || 0}台 / ADB ${result.adbCount || 0}台 / 要確認 ${(result.rows || []).length}台`);
  } catch (error) {
    logLine("端末トラブル診断 NG: " + error.message);
    result = { ok: false, rows: [], error: error.message, warning: error.message, counts: {} };
  } finally {
    setBusy(false);
  }
  const rows = Array.isArray(result.rows) ? result.rows : [];
  const hasRepairableRows = rows.some((row) => row.diagnosis !== "adb_ok" && row.serial);
  closeAdbDropDialog();
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog usb-adb-diagnosis-dialog" role="dialog" aria-modal="true" aria-labelledby="usbAdbDiagnosisDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="usbAdbDiagnosisDialogTitle">端末トラブル診断</h3>
          <p>DB ${esc(result.dbCount ?? "-")}台 / ADB ${esc(result.adbCount ?? "-")}台 / 要確認 ${esc(rows.length)}台</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      ${result.warning ? `<div class="adb-missing-empty">警告: ${esc(result.warning)}</div>` : ""}
      <div class="usb-diagnosis-summary">
        ${usbDiagnosisCountChip(result.counts, "adb_unauthorized", "許可待ち")}
        ${usbDiagnosisCountChip(result.counts, "projection_ok_adb_ng", "画面だけ見える")}
        ${usbDiagnosisCountChip(result.counts, "usb_mode_no_adb", "USBモード要確認")}
        ${usbDiagnosisCountChip(result.counts, "usb_only", "半分見えてる")}
        ${usbDiagnosisCountChip(result.counts, "pnp_phantom", "記録だけ")}
        ${usbDiagnosisCountChip(result.counts, "not_seen", "線が届いてない")}
      </div>
      ${hasRepairableRows ? `
        <div class="usb-diagnosis-top-actions">
          <span>直したい端末へチェックを入れて実行</span>
          <button class="section-head-action usb-auto-repair-selected-btn usb-auto-repair-selected-top" type="button" disabled>選択した端末を復旧（0台）</button>
        </div>
      ` : ""}
      ${rows.length ? `
        <div class="adb-missing-table-wrap">
          <table class="adb-missing-table usb-adb-diagnosis-table">
            <thead>
              <tr>
                <th>選択</th>
                <th>番号</th>
                <th>名前</th>
                <th>今の状態</th>
                <th>ADB</th>
                <th>XiaoWei</th>
                <th>Windows</th>
                <th>次にやること</th>
                <th>端末ID</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map((row) => `
                <tr class="usb-diagnosis-row ${esc(row.severity || "")}">
                  <td class="usb-repair-select-cell">
                    ${row.serial && row.diagnosis !== "adb_ok" ? `<input class="usb-repair-select" type="checkbox" value="${esc(row.serial)}" aria-label="${esc(row.number || row.name || row.serial)}を復旧対象にする">` : ""}
                  </td>
                  <td>${esc(row.number || row.managementId || "-")}</td>
                  <td>
                    <strong>${esc(row.name || "端末名なし")}</strong>
                    ${row.model ? `<span>${esc(row.model)}</span>` : ""}
                  </td>
                  <td>${usbDiagnosisChip(row)}</td>
                  <td>
                    <strong>${esc(row.adbStatus || "なし")}</strong>
                    ${row.adbPort ? `<span>port ${esc(row.adbPort)}</span>` : ""}
                    ${row.adbModel ? `<span>${esc(row.adbModel)}</span>` : ""}
                  </td>
                  <td>
                    <strong>${esc(row.xiaoweiState || "-")}</strong>
                    ${row.xiaoweiName ? `<span>${esc(row.xiaoweiName)}</span>` : ""}
                  </td>
                  <td>
                    <strong>${esc(row.pnpStatus || "-")}</strong>
                    ${usbPnpDetail(row.pnpRows)}
                  </td>
                  <td>
                    <strong>${esc(row.action || "-")}</strong>
                    ${row.recoveryCommand && row.diagnosis !== "adb_ok" ? `
                      <button class="section-head-action usb-auto-repair-row-btn" data-serial="${esc(row.serial || "")}" type="button">自動復旧</button>
                      <span class="usb-recovery-label">${esc(row.recoveryCommandLabel || "対象だけ復旧コマンド")}</span>
                      <code class="usb-recovery-command">${esc(row.recoveryCommand)}</code>
                    ` : ""}
                  </td>
                  <td><code>${esc(row.serial || "")}</code></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">要確認端末はありません。</div>`}
      <div class="usb-diagnosis-guide">
        <strong>見方</strong>
        <span>許可待ち: スマホ画面で許可</span>
        <span>半分見えてる: USBは届いてるが操作用の接続が死んでる</span>
        <span>記録だけ: Windowsに古い記録だけ残っている</span>
        <span>線が届いてない: ケーブル/ハブ/電源/端末端子を確認</span>
      </div>
      <div class="adb-drop-actions">
        ${isAlertSuppressed(ALERT_ADB_DROP)
          ? `<button class="section-head-action adb-drop-alert-resume-action" type="button">切断アラートを再開</button>`
          : `<span class="usb-alert-status">切断アラート ON</span>`}
        ${hasRepairableRows ? `<button class="section-head-action usb-auto-repair-selected-btn" type="button" disabled>選択した端末を復旧（0台）</button>` : ""}
        <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".usb-auto-repair-row-btn").forEach((repairButton) => {
    repairButton.addEventListener("click", () => launchUsbAutoRepair([repairButton.dataset.serial], repairButton));
  });
  const selectedRepairButtons = [...overlay.querySelectorAll(".usb-auto-repair-selected-btn")];
  const repairCheckboxes = [...overlay.querySelectorAll(".usb-repair-select")];
  const updateSelectedRepairButton = () => {
    const count = repairCheckboxes.filter((checkbox) => checkbox.checked).length;
    selectedRepairButtons.forEach((repairButton) => {
      repairButton.disabled = count === 0;
      repairButton.textContent = `選択した端末を復旧（${count}台）`;
    });
  };
  repairCheckboxes.forEach((checkbox) => checkbox.addEventListener("change", () => {
    checkbox.closest("tr")?.classList.toggle("repair-selected", checkbox.checked);
    updateSelectedRepairButton();
  }));
  overlay.querySelector(".adb-drop-alert-resume-action")?.addEventListener("click", (event) => {
    localStorage.removeItem(ALERT_SUPPRESS_KEY_PREFIX + ALERT_ADB_DROP);
    event.currentTarget.outerHTML = `<span class="usb-alert-status">切断アラート ON</span>`;
    logLine("ADB切断アラートを再開しました");
  });
  selectedRepairButtons.forEach((repairButton) => {
    repairButton.addEventListener("click", (event) => {
      const serials = repairCheckboxes.filter((checkbox) => checkbox.checked).map((checkbox) => checkbox.value);
      launchUsbAutoRepair(serials, event.currentTarget);
    });
  });
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((closeButton) => {
    closeButton.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

async function launchUsbAutoRepair(serials = [], button = null) {
  const clean = [...new Set((serials || []).map((serial) => String(serial || "").trim()).filter(Boolean))];
  if (!clean.length) return logLine("USB自動復旧: 対象端末がありません");
  const ok = window.confirm(`${clean.length}台のUSB/ADB強制復旧を開始します。\nWindowsの確認画面が出たら「はい」を押してください。\n戻らない選択端末はWindowsのUSB記録を現役分も作り直し、ADB 5037を停止して5038へ戻します。USBハブ全体は再起動しません。`);
  if (!ok) return;
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/adb/usb-repair", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ serials: clean, deep: true, takeover5038: true }),
    });
    logLine(`USB自動復旧 起動: ${result.serials?.length || clean.length}台 / UACが出たら許可`);
    if (result.logPath) logLine(`USB自動復旧ログ: ${result.logPath}`);
    flashButtonResult(button, "起動", "ok", 2200);
  } catch (error) {
    logLine("USB自動復旧 NG: " + error.message);
    flashButtonResult(button, "失敗", "error", 2200);
  } finally {
    setBusy(false);
  }
}

function usbDiagnosisCountChip(counts = {}, key, label) {
  const value = Number(counts && counts[key] || 0);
  return `<span class="${value ? "active" : ""}">${esc(label)} ${esc(value)}台</span>`;
}

function usbDiagnosisChip(row) {
  const severity = String(row?.severity || "");
  return `<span class="usb-diagnosis-chip ${esc(severity)}">${esc(row?.diagnosisLabel || "-")}</span>`;
}

function usbPnpDetail(rows = []) {
  const list = Array.isArray(rows) ? rows.slice(0, 3) : [];
  if (!list.length) return "";
  return list.map((item) => `<span>${esc([item.status, item.class, item.friendlyName].filter(Boolean).join(" / "))}</span>`).join("");
}

async function showXiaoweiMissingListDialog(button = null) {
  setBusy(true, button);
  let result = null;
  try {
    result = await fetchJson("/api/xiaowei/missing-from-xiaowei");
    logLine(`XiaoWei未認識一覧: DB ${result.dbCount || 0}台 / XiaoWei ${result.xiaoweiCount || 0}台 / 未認識 ${result.missingCount || 0}台`);
  } catch (error) {
    logLine("XiaoWei未認識一覧 NG: " + error.message);
    result = { ok: false, rows: [], error: error.message };
  } finally {
    setBusy(false);
  }
  closeAdbDropDialog();
  const rows = Array.isArray(result.rows) ? result.rows : [];
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog" role="dialog" aria-modal="true" aria-labelledby="xiaoweiMissingDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="xiaoweiMissingDialogTitle">XiaoWei未認識端末</h3>
          <p>DB登録 ${esc(result.dbCount ?? "-")}台 / XiaoWei認識 ${esc(result.xiaoweiApiCount ?? result.xiaoweiCount ?? "-")}台 / 未認識 ${esc(rows.length)}台</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      ${result.warning ? `<div class="adb-missing-empty">警告: ${esc(result.warning)}</div>` : ""}
      ${rows.length ? `
        <div class="adb-missing-table-wrap">
          <table class="adb-missing-table">
            <thead>
              <tr>
                <th>番号</th>
                <th>名前</th>
                <th>状態</th>
                <th>見え方</th>
                <th>管理ID</th>
                <th>端末ID</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map((row) => `
                <tr>
                  <td>${esc(rowXiaoweiNumber(row) || "-")}</td>
                  <td>
                    <strong>${esc(row.name || "端末名なし")}</strong>
                    ${row.deviceName && row.deviceName !== row.name ? `<span>${esc(row.deviceName)}</span>` : ""}
                  </td>
                  <td>${esc(row.status || "-")}</td>
                  <td>${esc(xiaoweiSourceLabel(row.xiaoweiSource))}</td>
                  <td>${esc(row.managementId || "-")}</td>
                  <td><code>${esc(row.serial || "")}</code></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">XiaoWei未認識端末はありません。</div>`}
      <div class="adb-drop-actions">
        <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((closeButton) => {
    closeButton.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

function logXiaoweiMissingDevices(result) {
  const rows = Array.isArray(result?.rows) ? result.rows : [];
  if (!rows.length) return;
  logLine(`XiaoWei未認識: ${rows.length}台 / ${rows.slice(0, 8).map((row) => `${rowXiaoweiNumber(row) || row.managementId} ${row.name || row.serial}`).join(", ")}${rows.length > 8 ? "..." : ""}`);
}

function renderAlertSuppressCheckbox(label) {
  return `
    <label class="adb-alert-suppress">
      <input type="checkbox" class="adb-alert-suppress-checkbox">
      <span>${esc(label)}</span>
    </label>
  `;
}

function bindAlertOkAction(overlay, alertKey) {
  overlay.querySelectorAll(".adb-alert-ok-action").forEach((button) => {
    button.addEventListener("click", () => {
      if (overlay.querySelector(".adb-alert-suppress-checkbox")?.checked) suppressAlert(alertKey);
      closeAdbDropDialog();
    });
  });
}

function isAlertSuppressed(alertKey) {
  return localStorage.getItem(ALERT_SUPPRESS_KEY_PREFIX + alertKey) === "1";
}

function suppressAlert(alertKey) {
  localStorage.setItem(ALERT_SUPPRESS_KEY_PREFIX + alertKey, "1");
  const label = alertKey === ALERT_ADB_DROP ? "ADB切断" : alertKey;
  logLine(`${label}アラートを停止しました`);
}

function xiaoweiIssueChips(values = []) {
  const labels = Array.isArray(values) ? values : [];
  if (!labels.length) return `<span>-</span>`;
  return `<div class="xiaowei-issue-chips">${labels.map((label) => `<span>${esc(xiaoweiIssueLabel(label))}</span>`).join("")}</div>`;
}

function xiaoweiIssueLabel(value) {
  return {
    fleet_missing: "DB未登録",
    xiaowei_missing: "XiaoWei未認識",
    not_projected: "未投影",
    resolution_zero: "0x0",
    number_missing: "番号なし",
    name_missing: "名前なし",
    number_mismatch: "番号違い",
    name_mismatch: "名前違い",
  }[String(value || "")] || String(value || "");
}

async function showDeviceCodeAuditDialog(button = null) {
  setBusy(true, button);
  let result = null;
  try {
    result = await fetchJson("/api/fleet-db/device-code-audit");
    logLine(`DB連番監査: グループ ${result.groupCount || 0}件 / 異常 ${result.issueCount || 0}件`);
  } catch (error) {
    logLine("DB連番監査 NG: " + error.message);
    result = { ok: false, rows: [], groups: [], error: error.message };
  } finally {
    setBusy(false);
  }
  closeAdbDropDialog();
  const rows = Array.isArray(result.rows) ? result.rows : [];
  const groups = Array.isArray(result.groups) ? result.groups : [];
  const repairableGroups = groups.filter((group) =>
    (Array.isArray(group.missingSequences) && group.missingSequences.length) ||
    (Array.isArray(group.duplicateSequences) && group.duplicateSequences.length)
  );
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog xiaowei-projection-dialog" role="dialog" aria-modal="true" aria-labelledby="deviceCodeAuditDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="deviceCodeAuditDialogTitle">DB連番監査</h3>
          <p>DB ${esc(result.dbCount ?? "-")}台 / グループ ${esc(result.groupCount ?? "-")}件 / 異常 ${esc(rows.length)}件</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      ${groups.length ? `
        <div class="device-code-audit-groups">
          ${groups.map((group) => `
            <div class="device-code-audit-group">
              <strong>${esc([group.base, group.carrier].filter(Boolean).join(" / "))}</strong>
               <span>${esc(group.count)}台</span>
               ${Array.isArray(group.reservedSequences) && group.reservedSequences.length ? `<span>管理対象外で使用済み: ${esc(group.reservedSequences.map((seq) => String(seq).padStart(2, "0")).join(", "))}</span>` : ""}
               ${Array.isArray(group.missingSequences) && group.missingSequences.length ? `<span>抜け: ${esc(group.missingSequences.map((seq) => String(seq).padStart(2, "0")).join(", "))}</span>` : ""}
              ${Array.isArray(group.duplicateSequences) && group.duplicateSequences.length ? `<span>重複: ${esc(group.duplicateSequences.map((seq) => String(seq).padStart(2, "0")).join(", "))}</span>` : ""}
              <span>異常: ${esc(group.issueCount || 0)}</span>
            </div>
          `).join("")}
        </div>
      ` : ""}
      ${rows.length ? `
        <div class="adb-missing-table-wrap">
          <table class="adb-missing-table xiaowei-projection-table device-code-audit-table">
            <thead>
              <tr>
                <th>番号</th>
                <th>現在</th>
                <th>期待</th>
                <th>グループ</th>
                <th>異常</th>
                <th>端末ID</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map((row) => `
                <tr>
                  <td>
                    <strong>${esc(row.xiaoweiNumber || "-")}</strong>
                    ${row.managementId ? `<span>${esc(row.managementId)}</span>` : ""}
                  </td>
                  <td>
                    <strong>${esc(row.deviceLabel || row.deviceCode || "端末名なし")}</strong>
                    ${row.xiaoweiName ? `<span>XiaoWei: ${esc(row.xiaoweiName)}</span>` : ""}
                  </td>
                  <td>
                    <strong>${esc(row.expectedLabel || "-")}</strong>
                    ${row.expectedSequenceByOrder ? `<span>順番上は ${esc(String(row.expectedSequenceByOrder).padStart(2, "0"))}</span>` : ""}
                  </td>
                  <td>${esc([row.base, row.carrier].filter(Boolean).join(" / ") || "-")}</td>
                  <td>${xiaoweiIssueChips(row.issueLabels || row.issues)}</td>
                  <td><code>${esc(row.serial || "")}</code></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">DB連番の異常はありません。</div>`}
      <div class="adb-drop-actions">
        ${repairableGroups.length ? `<button id="repairDeviceCodeGapsBtn" class="section-head-action" type="button">重複/抜けを修正</button>` : ""}
        <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelector("#repairDeviceCodeGapsBtn")?.addEventListener("click", (event) => repairDeviceCodeGaps(event.currentTarget));
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((closeButton) => {
    closeButton.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

async function repairDeviceCodeGaps(button = null) {
  if (!window.confirm("DB内の重複/抜け連番を並び順で修正します。修正後はXiaoWei名同期で反映できます。実行しますか？")) return;
  setBusy(true, button);
  let result = null;
  try {
    result = await fetchJson("/api/fleet-db/device-code-repair", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    logLine(`DB連番修正: グループ ${result.repaired || 0}件 / 端末 ${result.changedDevices || 0}台 / バックアップ ${result.backup || "-"}`);
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine("DB連番修正 NG: " + error.message);
    result = { ok: false, rows: [], groups: [], error: error.message };
  } finally {
    setBusy(false);
  }
  if (result?.audit) {
    renderDeviceCodeRepairResultDialog(result);
  }
}

function renderDeviceCodeRepairResultDialog(result) {
  closeAdbDropDialog();
  const changes = Array.isArray(result.changes) ? result.changes : [];
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog xiaowei-projection-dialog" role="dialog" aria-modal="true" aria-labelledby="deviceCodeRepairDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="deviceCodeRepairDialogTitle">DB連番修正結果</h3>
          <p>修正グループ ${esc(result.repaired || 0)}件 / 変更 ${esc(result.changedDevices || 0)}台 / 残り異常 ${esc(result.audit?.issueCount ?? "-")}件</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      ${changes.length ? `
        <div class="adb-missing-table-wrap">
          <table class="adb-missing-table xiaowei-projection-table device-code-audit-table">
            <thead>
              <tr>
                <th>番号</th>
                <th>変更前</th>
                <th>変更後</th>
                <th>グループ</th>
                <th>管理ID</th>
                <th>端末ID</th>
              </tr>
            </thead>
            <tbody>
              ${changes.map((row) => `
                <tr>
                  <td>${esc(row.xiaoweiNumber || "-")}</td>
                  <td><strong>${esc(row.beforeCode || "-")}</strong>${row.beforeLabel ? `<span>${esc(row.beforeLabel)}</span>` : ""}</td>
                  <td><strong>${esc(row.afterCode || "-")}</strong>${row.afterLabel ? `<span>${esc(row.afterLabel)}</span>` : ""}</td>
                  <td>${esc([row.base, row.carrier].filter(Boolean).join(" / ") || "-")}</td>
                  <td>${esc(row.managementId || "-")}</td>
                  <td><code>${esc(row.serial || "")}</code></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">${esc(result.message || "変更はありません。")}</div>`}
      <div class="adb-drop-actions">
        <button id="openDeviceCodeAuditAfterRepairBtn" class="section-head-action" type="button">監査を開く</button>
        <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelector("#openDeviceCodeAuditAfterRepairBtn")?.addEventListener("click", () => showDeviceCodeAuditDialog());
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((closeButton) => {
    closeButton.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

function xiaoweiSourceLabel(source) {
  return {
    api: "API認識",
    db_only: "DBのみ",
    db: "XiaoWei DB",
    "db+api": "DB+API",
    missing: "未認識",
  }[String(source || "")] || "-";
}

function adbMissingLastSeenAt(row, lastSeen = {}) {
  const serial = String(row?.serial || "");
  const fromLocal = Number(lastSeen[serial] || 0);
  if (Number.isFinite(fromLocal) && fromLocal > 0) return fromLocal;
  const fallback = Date.parse(row?.adbLastBatteryCheckedAt || row?.adbLastUptimeCheckedAt || "");
  return Number.isFinite(fallback) ? fallback : 0;
}

function formatAdbLastSeen(value) {
  const ms = Number(value || 0);
  if (!Number.isFinite(ms) || ms <= 0) return "不明";
  const date = new Date(ms);
  const pad = (number) => String(number).padStart(2, "0");
  return `${pad(date.getMonth() + 1)}/${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function startAdbConnectionMonitor() {
  if (state.adbConnectionMonitorTimer) window.clearInterval(state.adbConnectionMonitorTimer);
  state.adbConnectionMonitorTimer = window.setInterval(refreshAdbConnectionSnapshot, ADB_CONNECTION_MONITOR_INTERVAL_MS);
}

async function refreshAdbConnectionSnapshot() {
  if (state.busy || state.adbConnectionMonitorBusy || document.hidden) return;
  state.adbConnectionMonitorBusy = true;
  try {
    const adbDevices = await fetchJson("/api/adb/devices?uptime=0");
    storeAdbDevices(adbDevices);
    if (state.summary?.devices) renderDevices(state.summary.devices);
  } catch (error) {
    logLine("ADB接続確認 NG: " + error.message);
  } finally {
    state.adbConnectionMonitorBusy = false;
  }
}

function startDeviceFactsAutoRefresh() {
  if (state.deviceFactsAutoTimer) window.clearInterval(state.deviceFactsAutoTimer);
  window.setTimeout(() => refreshDeviceUptime(null, { silent: true, auto: true }), DEVICE_FACTS_AUTO_START_DELAY_MS);
  state.deviceFactsAutoTimer = window.setInterval(
    () => refreshDeviceUptime(null, { silent: true, auto: true }),
    DEVICE_FACTS_AUTO_INTERVAL_MS
  );
}

function safeJsonArray(value) {
  try {
    const parsed = JSON.parse(value || "[]");
    return Array.isArray(parsed) ? parsed.map((item) => String(item)).filter(Boolean) : [];
  } catch {
    return [];
  }
}

function safeJsonObject(value) {
  try {
    const parsed = JSON.parse(value || "{}");
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

async function refreshDeviceUptime(button = null, options = {}) {
  const silent = Boolean(options.silent);
  const auto = Boolean(options.auto);
  if (auto) {
    if (state.busy || state.deviceFactsAutoBusy || document.hidden) return;
    state.deviceFactsAutoBusy = true;
  }
  if (!silent) setBusy(true, button);
  try {
    const endpoint = auto ? "/api/adb/devices?persist=1" : "/api/adb/devices?facts=1&persist=1";
    const adbDevices = await fetchJson(endpoint);
    storeAdbDevices(adbDevices);
    if (adbDevices.includeFacts || adbDevices.includeUptime) {
      state.summary = await fetchJson("/api/fleet-db/summary");
    }
    renderDevices(state.summary?.devices || []);
    if (!silent) logLine(`UPTIME/電池取得OK: 接続 ${adbDevices.connected || 0}台`);
  } catch (error) {
    logLine((auto ? "自動UPTIME/電池取得NG: " : "UPTIME/電池取得NG: ") + error.message);
  } finally {
    if (auto) state.deviceFactsAutoBusy = false;
    if (!silent) setBusy(false);
  }
}

function setupAdbSwipeControls() {
  const options = adbSwipeMinuteOptions();
  const select = el("adbSwipeBulkMinutesSelect");
  select.innerHTML = options.map((minutes) =>
    `<option value="${minutes}" ${minutes === 60 ? "selected" : ""}>${minutes}分</option>`
  ).join("");
}

function adbSwipeMinuteOptions() {
  return Array.from({ length: 10 }, (_, index) => (index + 1) * 10);
}

function renderAdbSwipePanel(devices = state.summary?.devices || [], adbDevices = state.adbDevices?.devices || []) {
  const grid = el("adbSwipeDeviceGrid");
  if (!grid) return;
  const rows = adbSwipeRows(devices, adbDevices);
  const connected = rows.filter((row) => row.connected).length;
  const active = rows.filter((row) => row.connected && row.group === "稼働中").length;
  el("adbSwipeMeta").textContent = `ADB接続 ${connected}台 / 稼働中 ${active}台`;
  if (!rows.length) {
    grid.innerHTML = `<div class="adb-empty">ADB接続中の端末がありません。USB接続を確認してください。</div>`;
    return;
  }
  grid.innerHTML = rows.map((row) => {
    const selected = state.adbSwipe.selected.has(row.serial);
    const minutes = state.adbSwipe.minutesBySerial[row.serial] || 60;
    const disabled = row.connected ? "" : "disabled";
    const statusClass = row.group === "稼働中" ? "active" : row.group === "非稼働" ? "idle" : "rest";
    const mode = swipeModeChip(row);
    return `
      <article class="adb-device-card ${selected ? "selected" : ""} ${row.connected ? "" : "offline"} ${swipeModeCardClass(row)}" data-serial="${esc(row.serial)}">
        <label class="adb-device-select-line">
          <input class="adb-swipe-select" type="checkbox" data-serial="${esc(row.serial)}" ${selected ? "checked" : ""} ${disabled}>
          <span class="adb-device-number">${esc(row.laixiNumber || "-")}</span>
          <span class="adb-device-main">${esc(row.label || row.serial)}</span>
        </label>
        <div class="adb-device-sub">${esc(row.serial)}</div>
        <div class="adb-device-meta">
          ${mode}
          <span class="adb-group-chip ${statusClass}">${esc(row.group || "未分類")}</span>
          <span>${row.connected ? "接続中" : "未接続"}</span>
          <span>${row.adbPort ? `P${esc(row.adbPort)}` : "default"}</span>
        </div>
        <label class="adb-minute-line">
          <span>時間</span>
          <select class="adb-swipe-device-minutes" data-serial="${esc(row.serial)}" ${disabled}>
            ${adbSwipeMinuteOptions().map((value) => `<option value="${value}" ${Number(minutes) === value ? "selected" : ""}>${value}分</option>`).join("")}
          </select>
        </label>
      </article>
    `;
  }).join("");
}


function adbSwipeRows(devices = [], adbDevices = []) {
  const dbBySerial = new Map((devices || []).filter((row) => row && row.serial).map((row) => [String(row.serial), row]));
  const adbBySerial = new Map((adbDevices || []).filter((row) => row && row.serial).map((row) => [String(row.serial), row]));
  const serials = new Set([...dbBySerial.keys(), ...adbBySerial.keys()]);
  return [...serials].map((serial) => {
    const db = dbBySerial.get(serial) || {};
    const adb = adbBySerial.get(serial) || {};
    return {
      serial,
      connected: adb.status === "device" || adb.connected === true,
      adbPort: adb.adbPort || "",
      laixiNumber: db.laixiNumber || adb.laixiNumber || "",
      label: db.deviceLabel || adb.label || db.name || adb.model || serial,
      group: db.group || adb.group || "",
      model: db.deviceName || adb.model || "",
      tags: db.tags || [],
      swipeAgentInstalled: db.swipeAgentInstalled,
      swipeAgentAccessibilityEnabled: db.swipeAgentAccessibilityEnabled === true ? true : db.swipeAgentAccessibilityEnabled === false ? false : null,
      swipeAgentVersionName: db.swipeAgentVersionName || "",
      swipeAgentVersionCode: db.swipeAgentVersionCode || "",
      swipeAgentCheckedAt: db.swipeAgentCheckedAt || "",
      swipeAgentLastError: db.swipeAgentLastError || "",
      swipeModePreference: db.swipeModePreference || "auto",
      swipeModeRecommendation: db.swipeModeRecommendation || null,
    };
  }).sort((a, b) =>
    Number(a.connected ? 0 : 1) - Number(b.connected ? 0 : 1) ||
    Number(a.laixiNumber || 9999) - Number(b.laixiNumber || 9999) ||
    String(a.label || "").localeCompare(String(b.label || ""), "ja") ||
    String(a.serial).localeCompare(String(b.serial), "en")
  );
}

function handleAdbSwipeGridChange(event) {
  const checkbox = event.target.closest(".adb-swipe-select");
  if (checkbox) {
    const serial = checkbox.dataset.serial || "";
    if (checkbox.checked) state.adbSwipe.selected.add(serial);
    else state.adbSwipe.selected.delete(serial);
    checkbox.closest(".adb-device-card")?.classList.toggle("selected", checkbox.checked);
    return;
  }
  const minutesSelect = event.target.closest(".adb-swipe-device-minutes");
  if (minutesSelect) {
    state.adbSwipe.minutesBySerial[minutesSelect.dataset.serial || ""] = Number(minutesSelect.value || 60);
  }
}

function applyAdbSwipeBulkMinutes() {
  const minutes = Number(el("adbSwipeBulkMinutesSelect")?.value || 60);
  for (const serial of state.adbSwipe.selected) state.adbSwipe.minutesBySerial[serial] = minutes;
  for (const select of document.querySelectorAll(".adb-swipe-device-minutes")) {
    if (state.adbSwipe.selected.has(select.dataset.serial || "")) select.value = String(minutes);
  }
  logLine(`ADBスワイプ: 選択端末へ${minutes}分を適用`);
}

function setAdbSwipeSelection(mode) {
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  state.adbSwipe.selected.clear();
  for (const row of rows) {
    if (!row.connected) continue;
    if (mode === "all" || (mode === "active" && row.group === "稼働中")) state.adbSwipe.selected.add(row.serial);
  }
  renderAdbSwipePanel();
}

async function refreshAdbSwipeDevices() {
  setBusy(true, el("adbSwipeRefreshBtn"));
  try {
    const adbDevices = await fetchJson("/api/adb/devices");
    storeAdbDevices(adbDevices);
    renderDevices(state.summary?.devices || []);
    renderAdbSwipePanel(state.summary?.devices || [], state.adbDevices.devices || []);
    renderSwipeAgentPanel(state.summary?.devices || [], state.adbDevices.devices || []);
    logLine(`ADB再読込 OK: 接続 ${adbDevices.connected || 0}台`);
  } catch (error) {
    logLine("ADB再読込 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function setupSwipeAgentControls() {
  const select = el("swipeAgentBulkMinutesSelect");
  if (!select) return;
  select.innerHTML = adbSwipeMinuteOptions().map((minutes) =>
    `<option value="${minutes}" ${minutes === 60 ? "selected" : ""}>${minutes}分</option>`
  ).join("");
}

function renderSwipeAgentPanel(devices = state.summary?.devices || [], adbDevices = state.adbDevices?.devices || []) {
  const grid = el("swipeAgentDeviceGrid");
  if (!grid) return;
  const rows = adbSwipeRows(devices, adbDevices);
  const connected = rows.filter((row) => row.connected).length;
  const active = rows.filter((row) => row.connected && row.group === "稼働中").length;
  el("swipeAgentMeta").textContent = `ADB接続 ${connected}台 / 稼働中 ${active}台 / 端末自走方式`;
  if (!rows.length) {
    grid.innerHTML = `<div class="adb-empty">ADB接続中の端末がありません。USB接続を確認してください。</div>`;
    return;
  }
  grid.innerHTML = rows.map((row) => {
    const selected = state.swipeAgent.selected.has(row.serial);
    const minutes = state.swipeAgent.minutesBySerial[row.serial] || 60;
    const disabled = row.connected ? "" : "disabled";
    const statusClass = row.group === "稼働中" ? "active" : row.group === "非稼働" ? "idle" : "rest";
    const mode = swipeModeChip(row);
    const agent = swipeAgentCardStatus(row);
    const tags = Array.isArray(row.tags) ? row.tags : [];
    const hasError = tags.includes("STATE_ERROR");
    const hasErrorHistory = tags.includes("STATE_ERROR_HISTORY");
    const errorDisabled = "disabled";
    return `
      <article class="adb-device-card ${selected ? "selected" : ""} ${hasError ? "has-error" : ""} ${hasErrorHistory ? "has-error-history" : ""} ${row.connected ? "" : "offline"} ${swipeModeCardClass(row)}" data-serial="${esc(row.serial)}">
        <label class="adb-device-select-line">
          <input class="swipe-agent-select" type="checkbox" data-serial="${esc(row.serial)}" ${selected ? "checked" : ""} ${disabled}>
          <span class="adb-device-number">${esc(row.laixiNumber || "-")}</span>
          <span class="adb-device-main">${esc(row.label || row.serial)}</span>
        </label>
        <div class="adb-device-sub">${esc(row.serial)}</div>
        <div class="adb-device-meta">
          ${mode}
          <span class="adb-group-chip ${statusClass}">${esc(row.group || "未分類")}</span>
          <span class="agent-install-chip ${agent.klass}" title="${esc(agent.title)}">${esc(agent.label)}</span>
          ${appInstallChip("TTL", row.ttlInstalled, row.ttlCheckedAt, row.ttlInstallLastError)}
          ${appInstallChip("LINE", row.lineInstalled, row.lineCheckedAt, row.lineInstallLastError)}
          <span>${row.connected ? "接続中" : "未接続"}</span>
          <span>${row.adbPort ? `P${esc(row.adbPort)}` : "default"}</span>
        </div>
        <div class="swipe-error-row">
          <label class="swipe-error-toggle">
            <input class="swipe-error-checkbox" type="checkbox" data-serial="${esc(row.serial)}" ${hasError ? "checked" : ""} ${errorDisabled}>
            <span class="swipe-error-label" title="ERRORはチェック一覧で変更し、DBへ反映します">ERROR中</span>
          </label>
          ${hasErrorHistory ? `<em title="過去にERRORが付いた端末です">ERROR歴あり</em>` : ""}
        </div>
        <label class="adb-minute-line">
          <span>時間</span>
          <select class="swipe-agent-device-minutes" data-serial="${esc(row.serial)}" ${disabled}>
            ${adbSwipeMinuteOptions().map((value) => `<option value="${value}" ${Number(minutes) === value ? "selected" : ""}>${value}分</option>`).join("")}
          </select>
        </label>
      </article>
    `;
  }).join("");
}


function swipeAgentCardStatus(row) {
  if (row.swipeAgentInstalled === true) {
    const version = [row.swipeAgentVersionName, row.swipeAgentVersionCode].filter(Boolean).join("/");
    if (row.swipeAgentAccessibilityEnabled === false) {
      return {
        klass: "missing",
        label: "導入済 / 権限OFF",
        title: "",
      };
    }
    return {
      klass: "installed",
      label: version ? `導入済 ${version}` : "導入済",
      title: row.swipeAgentCheckedAt || "",
    };
  }
  if (row.swipeAgentInstalled === false) {
    return {
      klass: "missing",
      label: "未導入",
      title: row.swipeAgentLastError || row.swipeAgentCheckedAt || "",
    };
  }
  return {
    klass: "unknown",
    label: "",
    title: "",
  };
}

function appInstallChip(label, installed, checkedAt, lastError) {
  if (installed === true) {
    return `<span class="app-install-chip installed" title="${esc(checkedAt || "")}">${esc(label)}済</span>`;
  }
  if (installed === false) {
    return `<span class="app-install-chip missing" title="${esc(lastError || checkedAt || "")}">${esc(label)}未</span>`;
  }
  return `<span class="app-install-chip unknown" title="">${esc(label)}未確認</span>`;
}

function baselineSettingsStatus(row, options = {}) {
  const settings = row.baselineSettings || row.initialSettings || {};
  const checks = [
    settings.emergencyOff,
    settings.autoRotateOff,
    settings.dataSaverOn,
    settings.nfcOff,
    settings.silentOn,
  ];
  const done = checks.filter((value) => value === true).length;
  const total = checks.length;
  const errors = [settings.lastError].filter(Boolean);
  const checkedAt = settings.checkedAt || "";
  const label = done === total ? "": `${done}/${total}`;
  const klass = errors.length ? "error" : done === total ? "done" : done ? "partial" : "unknown";
  const title = [
    `初期設定 ${done}/${total}`,
    checkedAt ? `確認 ${checkedAt}` : "",
    errors.length ? `エラー ${errors.join(" / ")}` : "",
  ].filter(Boolean).join(" / ");
  return `<span class="baseline-settings-chip ${klass}" title="${esc(title)}">${esc(label)}</span>`;
}

function baselineSettingsStatusDetail(row) {
  const settings = row.deviceSettings && typeof row.deviceSettings === "object" ? row.deviceSettings : {};
  const settingItems = [
    { key: "emergencyAlertsOff", label: "緊急メールOFF" },
    { key: "autoRotateOff", label: "画面回転OFF" },
    { key: "dataSaverOn", label: "データセーバーON" },
    { key: "nfcOff", label: "NFC OFF" },
    { key: "silentOn", label: "サイレントON" },
  ];
  const statusItems = settingItems.map((item) => {
      const value = settings[item.key] && typeof settings[item.key] === "object" ? settings[item.key] : {};
      return {
        label: item.label,
        done: Boolean(value.appliedAt || value.source === "legacy"),
        checkedAt: value.checkedAt || value.appliedAt || "",
        error: value.lastError || value.error || "",
      };
    });
  const doneItems = statusItems.filter((item) => item.done);
  const pendingItems = statusItems.filter((item) => !item.done);
  const errors = statusItems
    .filter((item) => item.error)
    .map((item) => `${item.label}: ${item.error}`);
  const latestCheckedAt = statusItems
    .map((item) => item.checkedAt)
    .filter(Boolean)
    .sort()
    .pop() || "";
  const done = doneItems.length;
  const total = statusItems.length;
  const klass = errors.length ? "error" : done === total ? "complete" : done ? "partial" : "empty";
  const title = [
    `初期設定 ${done}/${total}`,
    doneItems.length ? `完了: ${doneItems.map((item) => item.label).join("、")}` : "",
    pendingItems.length ? `未完了: ${pendingItems.map((item) => item.label).join("、")}` : "",
    latestCheckedAt ? `確認: ${latestCheckedAt}` : "",
    errors.length ? `エラー: ${errors.join(" / ")}` : "",
  ].filter(Boolean).join("\n");
  return `<span class="baseline-settings-chip ${klass}" title="${esc(title)}">${esc(`${done}/${total}`)}</span>`;
}

function handleSwipeAgentGridChange(event) {
  const errorToggle = event.target.closest(".swipe-agent-error-toggle");
  if (errorToggle) {
    event.preventDefault();
    renderSwipeAgentPanel();
    return;
  }
  const checkbox = event.target.closest(".swipe-agent-select");
  if (checkbox) {
    const serial = checkbox.dataset.serial || "";
    if (checkbox.checked) state.swipeAgent.selected.add(serial);
    else state.swipeAgent.selected.delete(serial);
    checkbox.closest(".adb-device-card")?.classList.toggle("selected", checkbox.checked);
    return;
  }
  const minutesSelect = event.target.closest(".swipe-agent-device-minutes");
  if (minutesSelect) {
    state.swipeAgent.minutesBySerial[minutesSelect.dataset.serial || ""] = Number(minutesSelect.value || 60);
  }
}

function handleSwipeAgentGridClick(event) {
  const input = event.target.closest(".swipe-agent-error-toggle");
  if (!input) return;
  event.preventDefault();
  event.stopPropagation();
  logLine("");
}

function cssEscape(value) {
  if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(String(value || ""));
  return String(value || "").replace(/["\\]/g, "\\$&");
}

function applySwipeAgentBulkMinutes() {
  const minutes = Number(el("swipeAgentBulkMinutesSelect")?.value || 60);
  for (const serial of state.swipeAgent.selected) state.swipeAgent.minutesBySerial[serial] = minutes;
  for (const select of document.querySelectorAll(".swipe-agent-device-minutes")) {
    if (state.swipeAgent.selected.has(select.dataset.serial || "")) select.value = String(minutes);
  }
  logLine(`Swipe Agent: 選択端末へ${minutes}分を適用`);
}

function setSwipeAgentSelection(mode) {
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  state.swipeAgent.selected.clear();
  for (const row of rows) {
    if (!row.connected) continue;
    if (mode === "all" || (mode === "active" && row.group === "稼働中")) state.swipeAgent.selected.add(row.serial);
  }
  renderSwipeAgentPanel();
}

async function refreshSwipeAgentDevices() {
  setBusy(true, el("swipeAgentRefreshBtn"));
  try {
    const adbDevices = await fetchJson("/api/adb/devices");
    storeAdbDevices(adbDevices);
    renderDevices(state.summary?.devices || []);
    renderAdbSwipePanel(state.summary?.devices || [], state.adbDevices.devices || []);
    renderSwipeAgentPanel(state.summary?.devices || [], state.adbDevices.devices || []);
    logLine(`Swipe Agent ADB再読込 OK: 接続 ${adbDevices.connected || 0}台`);
  } catch (error) {
    logLine("Swipe Agent ADB再読込 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function runSwipeAgentInstallAction(label, endpoint, button = null) {
  const ok = endpoint.endsWith("/install") ? window.confirm("Swipe Agentを導入/更新します。よろしいですか？") : true;
  if (!ok) return;
  setBusy(true, button);
  logLine(label + " 実行中...");
  try {
    const response = await fetch(endpoint, { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    const result = await response.json();
    logLine(label + " OK: 接続 " + (result.connected || 0) + "台 / 成功 " + (result.installed || result.succeeded || 0) + " / スキップ " + (result.skipped || 0) + " / 失敗 " + (result.failed || 0));
    const failed = (result.results || []).filter((row) => !row.ok);
    for (const row of failed.slice(0, 20)) {
      logLine("- " + (row.label || row.serial) + ": " + (row.error || row.after?.error || "理由不明"));
    }
    if (!response.ok || result.ok === false) logLine(label + ": 一部失敗");
    await loadSummary();
  } catch (error) {
    logLine(label + " NG: " + error.message);
  } finally {
    setBusy(false);
  }
}


async function saveSiteName() {
  const siteName = el("siteNameInput").value.trim() || "Android Fleet";
  setBusy(true);
  logLine("名前保存 実行中...");
  try {
    const result = await fetchJson("/api/fleet-db/settings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ siteName }),
    });
    renderSiteName(result.settings?.siteName || siteName);
    logLine("名前保存 OK: " + (result.settings?.siteName || siteName));
    await loadSummary();
  } catch (error) {
    logLine("名前保存 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function addManualWithdrawal(event) {
  event.preventDefault();
  const withdrawalId = el("withdrawalIdInput").value;
  const deviceValue = el("withdrawalDeviceSelect").value;
  const amountYen = Number(el("withdrawalAmountInput").value);
  const withdrawalDate = el("withdrawalDateInput").value;
  const memo = el("withdrawalMemoInput").value.trim();
  if (!deviceValue || !withdrawalDate || !Number.isFinite(amountYen) || amountYen <= 0) {
    logLine("出金登録 NG: 日付・端末・金額を確認してください");
    return;
  }
  setBusy(true);
  logLine((withdrawalId ? "出金訂正" : "出金登録") + " 実行中...");
  try {
    const endpoint = withdrawalId ? "/api/fleet-db/withdrawals/update" : "/api/fleet-db/withdrawals";
    const result = await fetchJson(endpoint, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ withdrawalId, device: deviceValue, withdrawalDate, amountYen, memo }),
    });
    logLine((withdrawalId ? "出金訂正" : "出金登録") + " OK: " + result.withdrawal.managementId + " " + yen(result.withdrawal.amountYen));
    clearWithdrawalForm();
    await loadSummary();
  } catch (error) {
    logLine((withdrawalId ? "出金訂正" : "出金登録") + " NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function clearWithdrawalForm() {
  el("withdrawalIdInput").value = "";
  el("withdrawalAmountInput").value = "";
  el("withdrawalMemoInput").value = "";
  el("addWithdrawalBtn").textContent = "出金登録";
  el("cancelWithdrawalEditBtn").classList.add("hidden");
}

async function runAction(label, endpoint, button = null) {
  setBusy(true, button);
  logLine(label + " 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson(endpoint, { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    logLine(label + " OK: " + summarizeActionResult(result));
    await loadSummary();
  } catch (error) {
    logLine(label + " NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

async function importMigrationDataFromFolder(button = null) {
  const ok = window.confirm("移行データを取り込みます。現在のデータはバックアップしてから上書きします。実行しますか？");
  if (!ok) return;
  setBusy(true, button);
  logLine("移行データ取込 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson("/api/migration/import", { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    logLine("移行データ取込 OK: " + summarizeActionResult(result));
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("移行データ取込 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

async function applyPendingTagBoardChangesBeforeXiaoweiSync() {
  const tagChanges = collectPendingTagChanges();
  if (!tagChanges.length) return { applied: 0, requested: 0 };

  logLine(`チェック変更保存 実行中: ${tagChanges.length}件`);
  const result = await fetchJson("/api/tag-board/tags/apply", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ changes: tagChanges }),
  });
  const failed = result.failed || 0;
  logLine(`チェック変更保存 OK: ${result.applied || 0}/${result.requested || tagChanges.length}件${failed ? ` / 失敗 ${failed}件` : ""}`);
  if (failed) {
    const failedRows = (result.results || []).filter((row) => !row.ok).slice(0, 8);
    for (const row of failedRows) logLine(`チェック変更保存 失敗: ${row.serial || "-"} ${row.tag || "-"} ${row.error || row.message || ""}`);
  }
  reloadTagBoardFrame();
  await loadSummary();
  return result;
}

async function runTagBoardSync(button = null) {
  setBusy(true, button);
  logLine("XiaoWei名/番号同期 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    await applyPendingTagBoardChangesBeforeXiaoweiSync();
    const result = await fetchJson("/api/xiaowei/sync", { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    logLine("XiaoWei名/番号同期 OK: " + summarizeActionResult(result));
    const warningSteps = result.warningSteps || [];
    const xiaoweiWarnings = warningSteps.filter((step) => step !== "sheets");
    if (warningSteps.includes("sheets")) logLine("Google Sheets同期待ち: XiaoWei名/番号は反映済み");
    if ((result.failedSteps || []).length || xiaoweiWarnings.length) flash = { message: "要確認", type: "warn" };
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("XiaoWei名/番号同期 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

async function runXiaoweiFullSync(button = null) {
  setBusy(true, button);
  logLine("XiaoWei名/番号同期 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const applyResult = await applyPendingTagBoardChangesBeforeXiaoweiSync();
    if (applyResult.requested || applyResult.applied) {
      logLine(`XiaoWei名/番号同期: DB反映 ${applyResult.applied || 0}/${applyResult.requested || 0}件`);
    }

    const dayResult = await fetchJson("/api/day-tags/advance", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ syncXiaowei: false, syncLegacyMirror: false }),
    });
    logLine(dayResult.skipped
      ? "XiaoWei名/番号同期: DAY更新 変更なし"
      : `XiaoWei名/番号同期: DAY更新 ${dayResult.changed || 0}件`);

    const syncResult = await fetchJson("/api/xiaowei/sync", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    const failed = (syncResult.failedSteps || []).length;
    const warningSteps = syncResult.warningSteps || [];
    const xiaoweiWarnings = warningSteps.filter((step) => step !== "sheets");
    const sheetsPending = warningSteps.includes("sheets");
    const numberStep = syncResult.refresh && syncResult.refresh.numbers || {};
    const codeStep = syncResult.refresh && syncResult.refresh.deviceCodeSync || {};
    logLine(`XiaoWei名/番号同期: 端末名再取得 ${codeStep.changedDevices || 0}件`);
    logLine(`XiaoWei名/番号同期: 名前/番号 ${failed ? "一部NG" : "OK"} / 対象 ${numberStep.logicalRequested ?? numberStep.requested ?? 0}件 / 失敗 ${failed}件 / XiaoWei警告 ${xiaoweiWarnings.length}件`);
    if (sheetsPending) logLine("Google Sheets同期待ち: XiaoWei名/番号は反映済み");
    const timings = summarizeSyncStepDurations(syncResult.refresh);
    if (timings) logLine(`XiaoWei名/番号同期: 所要 ${timings}`);
    if (failed || xiaoweiWarnings.length) flash = { message: "要確認", type: "warn" };

    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("XiaoWei名/番号同期 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}


async function runXiaoweiNameSync(button = null) {
  setBusy(true, button);
  logLine("XiaoWei名同期 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    await applyPendingTagBoardChangesBeforeXiaoweiSync();
    const result = await fetchJson("/api/xiaowei/display-names/sync", { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    const failed = (result.failedSteps || []).length;
    const codeStep = result.refresh && result.refresh.deviceCodeSync || {};
    logLine(`XiaoWei名同期: 端末名再取得 ${codeStep.changedDevices || 0}件`);
    logLine(`XiaoWei名同期 ${failed ? "一部NG" : "OK"}: 失敗 ${failed}件`);
    if (failed) flash = { message: "要確認", type: "warn" };
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("XiaoWei名同期 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}


async function runDayAdvance(button = null) {
  setBusy(true, button);
  logLine("DAY更新 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson("/api/day-tags/advance", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ syncXiaowei: false, syncLegacyMirror: false }) });
    logLine(result.skipped ? "DAY更新: 変更なし" : `DAY更新 OK: ${result.changed || 0}件 / DB反映`);
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("DAY更新 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}


async function runDeviceCodeSync(button = null) {
  const ok = window.confirm("端末名を再取得します。DBへ反映してよろしいですか？");
  if (!ok) return;
  setBusy(true, button);
  logLine("端末名再取得 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson("/api/fleet-db/device-codes/sync", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ force: true, refreshIdentity: true }) });
    const corrected = result.identityRefresh?.correctedDevices || 0;
    logLine(`端末名再取得 OK: 機種修正 ${corrected}件 / 端末名 ${result.changedDevices || 0}件 / 出金履歴 ${result.changedWithdrawals || 0}件`);
    if (announceUnregisteredDeviceMaster(result, "端末名再取得")) {
      flash = { message: "マスタ未登録", type: "warn" };
    }
    reloadTagBoardFrame();
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine("端末名再取得 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}


async function runXiaoweiNumberSync(button = null) {
  const ok = window.confirm(["DBの内容をXiaoWeiへ同期します。", "よろしいですか？"].join("\n"));
  if (!ok) return;
  setBusy(true, button);
  logLine("XiaoWei番号反映 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    await applyPendingTagBoardChangesBeforeXiaoweiSync();
    const result = await fetchJson("/api/xiaowei/numbers/sync", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ apply: true }) });
    logLine(`XiaoWei番号反映 OK: 対象 ${result.logicalRequested ?? result.requested ?? 0}件 / 成功 ${result.succeeded || 0} / 失敗 ${result.failed || 0}`);
    if (Number(result.failed || 0) > 0) flash = { message: "要確認", type: "warn" };
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("XiaoWei番号反映 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}


async function importNewAdbDevices(button = null) {
  const ok = window.confirm("新規端末をDBへ取り込みます。よろしいですか？");
  if (!ok) return;
  setBusy(true, button);
  logLine("新規端末取込 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await importNewDevicesUntilStable({
      label: "新規端末取込",
      minPasses: 3,
      maxPasses: 5,
      intervalMs: 3000,
    });
    const labels = (result.devices || []).slice(0, 5).map((device) => `${device.managementId} ${device.name || device.model || device.serial}`).join(" / ");
    logLine(`新規端末取込 OK: 自動確認 ${result.passes || 0}回 / 検出 ${result.scanned || 0}台（ADB ${result.adbScanned || 0}台 / XiaoWei投影 ${result.xiaoweiScanned || 0}台 / USB実機救済 ${result.xiaoweiUsbConfirmed || 0}台） / 取込 ${result.imported || 0}台 / 既存 ${result.skipped || 0}台${labels ? " / " + labels : ""}`);
    if (Number(result.xiaoweiHistorySkipped || 0) > 0) {
      logLine(`新規端末取込 除外: XiaoWeiの未接続保存履歴 ${result.xiaoweiHistorySkipped}台`);
    }
    if (announceUnregisteredDeviceMaster(result, "新規端末取込")) {
      flash = { message: "マスタ未登録", type: "warn" };
    }
    await loadSummary();
    reloadTagBoardFrame();
  } catch (error) {
    logLine("新規端末取込 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}


function devicePreviewLabel(row = {}) {
  const candidates = [
    row.laixiNumber ? `No.${row.laixiNumber}` : "",
    row.deviceDisplayCode ? `${row.deviceDisplayCode}${row.carrierCode ? ` ${row.carrierCode}` : ""}` : "",
    row.deviceLabel,
    row.desiredName ? String(row.desiredName).replace(/^(?:DAY\d+\s+)?(?:180分[○〇]\s+)?(?:追加[○〇]\s+)?/, "") : "",
    row.currentName ? String(row.currentName).replace(/^(?:DAY\d+\s+)?(?:180分[○〇]\s+)?(?:追加[○〇]\s+)?/, "") : "",
  ].map((value) => String(value || "").trim()).filter((value) => value && !/^A-\d+$/i.test(value));
  if (candidates.length) return candidates[0];
  const id = String(row.serial || row.deviceSerial || row.deviceId || "").trim();
  return id ? `ID ${id.slice(-8)}` : "端末";
}

async function startAdbSwipeJobFromPanel(button = null) {
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  const selectedRows = rows
    .filter((row) => state.adbSwipe.selected.has(row.serial) && row.connected)
    .map((row) => ({
      ...row,
      minutes: Number(state.adbSwipe.minutesBySerial[row.serial] || 60),
    }));
  if (!selectedRows.length) {
    logLine("ADBスワイプ NG: 対象端末が選択されていません");
    return;
  }
  const sample = selectedRows.slice(0, 10).map((row) => `${row.laixiNumber || "-"} ${row.label} ${row.minutes}?`).join("\n");
  const ok = window.confirm([
    `ADBスワイプを開始します。対象 ${selectedRows.length}台`,
    "",
    sample,
    selectedRows.length > 10 ? `...ほか ${selectedRows.length - 10}台` : "",
  ].join("\n"));
  if (!ok) return;
  await startAdbSwipeJob(selectedRows, button, `${selectedRows.length}台`);
}

async function restartTtlForSelectedAdbSwipeDevices(button = null) {
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  const selectedRows = rows
    .filter((row) => state.adbSwipe.selected.has(row.serial) && row.connected)
    .map((row) => ({
      serial: row.serial,
      adbPort: row.adbPort || "",
      label: `${row.laixiNumber ? row.laixiNumber + " " : ""}${row.label || row.serial}`,
    }));
  if (!selectedRows.length) {
    logLine("TTL再起動 NG: 対象端末が選択されていません");
    return;
  }
  const sample = selectedRows.slice(0, 10).map((row) => row.label || row.serial).join("\n");
  const ok = window.confirm([
    `選択端末のTikTok Liteを再起動します。対象 ${selectedRows.length}台`,
    "",
    sample,
    selectedRows.length > 10 ? `...ほか${selectedRows.length - 10}台` : "",
  ].join("\n"));
  if (!ok) return;
  setBusy(true, button);
  logLine(`TTL再起動 実行中: ${selectedRows.length}台`);
  try {
    const result = await fetchJson("/api/adb/restart-ttl", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ targets: selectedRows }),
    });
    logLine(`TTL再起動 ${result.ok ? "OK" : "NG"}: 成功 ${result.succeeded || 0} / 失敗 ${result.failed || 0}`);
    logFailedDeviceRows("TTL再起動", result.results || []);
    await refreshAdbSwipeDevices();
  } catch (error) {
    logLine("TTL再起動 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function runSwipeRecoveryTest(button = null, options = {}) {
  if (state.swipeStopBusy) { logLine("停止処理中です"); return; }
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  const selectedRows = rows.filter((row) => state.swipeAgent.selected.has(row.serial) && row.connected).map((row) => ({
    serial: row.serial, adbPort: row.adbPort || "", label: `${row.laixiNumber ? row.laixiNumber + " " : ""}${row.label || row.serial}`, laixiNumber: row.laixiNumber || "", minutes: Number(state.swipeAgent.minutesBySerial[row.serial] || 10), swipeMode: normalizeSwipeModeRecommendation(row).mode,
  }));
  if (!selectedRows.length) { logLine("対象端末が選択されていません"); return; }
  const stopAgent = options.stopAgent !== false;
  const title = stopAgent ? "選択端末のスワイプ停止" : "スワイプ本体停止";
  const sample = selectedRows.slice(0, 6).map((row) => `${row.label || row.serial} / ${row.minutes}分`).join("\n");
  const ok = window.confirm([`${title} 対象 ${selectedRows.length}台`, sample, selectedRows.length > 6 ? `ほか ${selectedRows.length - 6}台` : ""].join("\n"));
  if (!ok) return;
  setBusy(true, button);
  logLine(`${title} 実行中: ${selectedRows.length}台`);
  try {
    const result = await fetchJson("/api/swipe-agent/recovery-test", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ targets: selectedRows, stopAgent }) });
    logLine(`${title} ${result.ok ? "OK" : "NG"}: 成功 ${result.succeeded || 0} / 失敗 ${result.failed || 0}`);
    for (const row of result.results || []) {
      const name = row.label || row.serial || "-";
      logLine(`${title}: ${name}${row.screenshotUrl ? ` / ${row.screenshotUrl}` : ""}`);
      for (const step of (row.steps || []).slice(0, 12)) { logLine(`- ${formatTime(step.at)} ${name}: ${step.name} ${step.ok ? "OK" : "NG"}${step.error ? ` / ${step.error}` : ""}`); }
    }
    await refreshSwipeAgentDevices();
  } catch (error) {
    logLine(`${title} NG: ${error.message}`);
  } finally {
    setBusy(false);
  }
}
async function startAdbSwipeJob(rows, button = null, targetLabel = "") {
  if (!rows.length) {
    logLine("ADBスワイプ NG: ADB接続端末がありません");
    return;
  }
  setBusy(true, button);
  logLine(`ADBスワイプ起動中: ${targetLabel || rows.length + "台"}`);
  try {
    const result = await fetchJson("/api/adb/swipe-jobs", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        minutes: 60,
        minIntervalSeconds: 10,
        maxIntervalSeconds: 15,
        targets: rows.map((row) => ({
          serial: row.serial,
          adbPort: row.adbPort || "",
          label: `${row.laixiNumber ? row.laixiNumber + " " : ""}${row.label || row.serial}`,
          laixiNumber: row.laixiNumber || "",
          minutes: row.minutes || 60,
        })),
      }),
    });
    state.adbSwipe.jobId = result.job?.jobId || "";
    renderAdbSwipeJob(result.job);
    startAdbSwipePolling();
    logLine(`ADBスワイプ ${result.merged ? "合流OK" : "開始OK"}: ${targetLabel || rows.length + "台"} / job ${state.adbSwipe.jobId || "-"}`);
    logFailedSwipeDevices(result.job, "ADBスワイプ");
  } catch (error) {
    logLine("ADBスワイプ NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function startAdbSwipePolling() {
  if (state.adbSwipe.pollTimer) window.clearInterval(state.adbSwipe.pollTimer);
  if (!state.adbSwipe.jobId) return;
  state.adbSwipe.pollTimer = window.setInterval(loadAdbSwipeJobStatus, 2000);
  loadAdbSwipeJobStatus();
}

async function refreshRunningSwipeJobs() {
  const [agentList, adbList] = await Promise.all([
    fetchJson("/api/swipe-agent/jobs").catch(() => ({ jobs: [] })),
    fetchJson("/api/adb/swipe-jobs").catch(() => ({ jobs: [] })),
  ]);
  const pickJob = (jobs = []) =>
    jobs.find((job) => ["running", "stopping"].includes(job.status || "")) ||
    jobs.find((job) => job.jobId === state.swipeAgent.jobId || job.jobId === state.adbSwipe.jobId) ||
    jobs[0] ||
    null;
  const agentJob = pickJob(agentList.jobs || []);
  const adbJob = pickJob(adbList.jobs || []);
  state.swipeAgent.jobId = agentJob?.jobId || "";
  state.adbSwipe.jobId = adbJob?.jobId || "";
  renderSwipeAgentJob(agentJob);
  renderAdbSwipeJob(adbJob);
  if (state.swipeAgent.jobId && ["running", "stopping"].includes(agentJob?.status || "")) startSwipeAgentPolling();
  if (state.adbSwipe.jobId && ["running", "stopping"].includes(adbJob?.status || "")) startAdbSwipePolling();
}

async function loadAdbSwipeJobStatus() {
  if (!state.adbSwipe.jobId) return;
  try {
    const result = await fetchJson(`/api/adb/swipe-jobs/${encodeURIComponent(state.adbSwipe.jobId)}`);
    renderAdbSwipeJob(result.job);
    if (!["running", "stopping"].includes(result.job?.status || "")) {
      logFailedSwipeDevices(result.job, "ADBスワイプ");
      window.clearInterval(state.adbSwipe.pollTimer);
      state.adbSwipe.pollTimer = 0;
    }
  } catch (error) {
    logLine("ADBスワイプ進捗 NG: " + error.message);
    window.clearInterval(state.adbSwipe.pollTimer);
    state.adbSwipe.pollTimer = 0;
  }
}

function logFailedSwipeDevices(job, label) {
  const failed = (job?.devices || []).filter((device) =>
    device.state === "failed" ||
    device.state === "missing" ||
    Number(device.failCount || 0) > 0 ||
    device.lastError
  );
  if (!failed.length) return;
  logLine(`${label} 失敗端末:`);
  for (const device of failed.slice(0, 20)) {
    const name = device.label || device.serial || "unknown";
    const reason = device.lastError || device.state || "理由不明";
    logLine(`- ${name}: ${reason}`);
  }
  if (failed.length > 20) logLine(`- ...ほか${failed.length - 20}台`);
}

function logFailedDeviceRows(label, rows = []) {
  const failed = (rows || []).filter((row) => !row.ok);
  if (!failed.length) return;
  logLine(`${label} 失敗端末:`);
  for (const row of failed.slice(0, 20)) {
    const name = row.label || row.serial || "unknown";
    const reason = row.error || row.message || row.status || "理由不明";
    logLine(`- ${name}: ${reason}`);
  }
  if (failed.length > 20) logLine(`- ...ほか${failed.length - 20}台`);
}

async function stopAdbSwipeJob(button = null) {
  if (!state.adbSwipe.jobId) return;
  setBusy(true, button);
  try {
    const result = await fetchJson(`/api/adb/swipe-jobs/${encodeURIComponent(state.adbSwipe.jobId)}/stop`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    renderAdbSwipeJob(result.job);
    logLine("ADBスワイプ 停止要求OK");
  } catch (error) {
    logLine("ADBスワイプ停止 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function stopAllSwipeJobs(button = null) {
  if (state.swipeStopBusy) return;
  state.swipeStopBusy = true;
  setSwipeStopControlsLocked(true);
  setBusy(true, button, "停止中...");
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  const selectedSerials = new Set([...state.swipeAgent.selected, ...state.adbSwipe.selected]);
  const selectedTargets = rows
    .filter((row) => selectedSerials.has(row.serial) && row.connected)
    .map((row) => ({
      serial: row.serial,
      adbPort: row.adbPort || "",
      label: `${row.laixiNumber ? row.laixiNumber + " " : ""}${row.label || row.serial}`,
      laixiNumber: row.laixiNumber || "",
    }));
  const selectedOnly = selectedTargets.length > 0;
  logLine(selectedOnly
    ? `停止中... 対象 ${selectedTargets.length}台`
    : "停止中...");
  try {
    const result = await fetchJson("/api/swipe/stop-all", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(selectedOnly
        ? { selectedOnly: true, includeConnected: false, targets: selectedTargets }
        : { includeConnected: true }),
    });
    logLine(`${result.selectedOnly ? "スワイプ選択停止" : "スワイプ全体停止"}完了 Agentジョブ ${result.agentJobs || 0} / ADBジョブ ${result.adbJobs || 0} / Agent停止 ${result.directSucceeded || 0}/${result.directTargets || 0}台`);
    const failed = (result.directResults || []).filter((item) => !item.ok);
    for (const item of failed.slice(0, 12)) logLine(`スワイプ停止 NG: ${item.label || item.serial} ${item.error || ""}`);
    if (failed.length > 12) logLine(`スワイプ停止 NG: ほか${failed.length - 12}台`);
    await refreshRunningSwipeJobs();
  } catch (error) {
    logLine("スワイプ停止 NG: " + error.message);
  } finally {
    state.swipeStopBusy = false;
    setBusy(false);
    setSwipeStopControlsLocked(false);
    await refreshRunningSwipeJobs().catch(() => null);
  }
}

async function startSwipeAgentJobFromPanel(button = null) {
  if (state.swipeStopBusy) {
    logLine("スワイプ開始 NG: 停止処理が終わるまで待ってください");
    return;
  }
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  const selectedRows = rows
    .filter((row) => state.swipeAgent.selected.has(row.serial) && row.connected)
    .map((row) => ({
      ...row,
      minutes: Number(state.swipeAgent.minutesBySerial[row.serial] || 60),
    }));
  if (!selectedRows.length) {
    logLine("スワイプ NG: 対象端末が選択されていません");
    return;
  }
  const agentRows = selectedRows.filter((row) => normalizeSwipeModeRecommendation(row).mode !== "adb");
  const adbRows = selectedRows.filter((row) => normalizeSwipeModeRecommendation(row).mode === "adb");
  const sample = selectedRows.slice(0, 10).map((row) => {
    const mode = normalizeSwipeModeRecommendation(row).mode === "adb" ? "ADB" : "Agent";
    return `${row.laixiNumber || "-"} ${row.label} ${row.minutes}分 / ${mode}`;
  }).join("\n");
  const ok = window.confirm([
    `スワイプを開始します。対象 ${selectedRows.length}台`,
    `Agent ${agentRows.length}台 / ADB ${adbRows.length}台`,
    "Agent推奨端末は端末側アプリ、ADB推奨端末はPC側ADBで実行します。",
    "",
    sample,
    selectedRows.length > 10 ? `...ほか ${selectedRows.length - 10}台` : "",
  ].join("\n"));
  if (!ok) return;
  if (agentRows.length) await startSwipeAgentJob(agentRows, button, `Agent ${agentRows.length}台`);
  if (adbRows.length) await startAdbSwipeJob(adbRows, button, `ADB ${adbRows.length}台`);
}

async function startSwipeAgentJob(rows, button = null, targetLabel = "") {
  setBusy(true, button);
  logLine(`Swipe Agent 起動中: ${targetLabel || rows.length + "台"}`);
  try {
    const result = await fetchJson("/api/swipe-agent/jobs", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        minutes: 60,
        monitorIntervalSeconds: 30,
        staleSeconds: 90,
        targets: rows.map((row) => ({
          serial: row.serial,
          adbPort: row.adbPort || "",
          label: `${row.laixiNumber ? row.laixiNumber + " " : ""}${row.label || row.serial}`,
          laixiNumber: row.laixiNumber || "",
          minutes: row.minutes || 60,
        })),
      }),
    });
    state.swipeAgent.jobId = result.job?.jobId || "";
    renderSwipeAgentJob(result.job);
    trackSwipeAgentFallbackAdbJob(result.job);
    startSwipeAgentPolling();
    logLine(`Swipe Agent ${result.merged ? "合流OK" : "開始OK"}: ${targetLabel || rows.length + "台"} / job ${state.swipeAgent.jobId || "-"}`);
    logFailedSwipeDevices(result.job, "Swipe Agent");
  } catch (error) {
    logLine("Swipe Agent NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function startSwipeAgentPolling() {
  if (state.swipeAgent.pollTimer) window.clearInterval(state.swipeAgent.pollTimer);
  if (!state.swipeAgent.jobId) return;
  state.swipeAgent.pollTimer = window.setInterval(loadSwipeAgentJobStatus, 5000);
  loadSwipeAgentJobStatus();
}

function trackSwipeAgentFallbackAdbJob(job) {
  const fallbackIds = Array.isArray(job?.fallbackAdbJobIds) ? job.fallbackAdbJobIds.filter(Boolean) : [];
  if (!fallbackIds.length) return;
  const latest = fallbackIds[fallbackIds.length - 1];
  if (!latest || state.adbSwipe.jobId === latest) return;
  state.adbSwipe.jobId = latest;
  logLine(`Swipe Agent: Agent失敗端末をADBへ自動切替 / job ${latest}`);
  startAdbSwipePolling();
}

async function loadSwipeAgentJobStatus() {
  if (!state.swipeAgent.jobId) return;
  try {
    const result = await fetchJson(`/api/swipe-agent/jobs/${encodeURIComponent(state.swipeAgent.jobId)}`);
    renderSwipeAgentJob(result.job);
    trackSwipeAgentFallbackAdbJob(result.job);
    if (!["running", "stopping"].includes(result.job?.status || "")) {
      logFailedSwipeDevices(result.job, "Swipe Agent");
      window.clearInterval(state.swipeAgent.pollTimer);
      state.swipeAgent.pollTimer = 0;
    }
  } catch (error) {
    logLine("Swipe Agent進捗取得 NG: " + error.message);
    window.clearInterval(state.swipeAgent.pollTimer);
    state.swipeAgent.pollTimer = 0;
  }
}

async function stopSwipeAgentJob(button = null) {
  if (!state.swipeAgent.jobId) return;
  setBusy(true, button);
  try {
    const result = await fetchJson(`/api/swipe-agent/jobs/${encodeURIComponent(state.swipeAgent.jobId)}/stop`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    renderSwipeAgentJob(result.job);
    logLine("Swipe Agent 停止要求 OK");
  } catch (error) {
    logLine("Swipe Agent停止 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function renderSwipeAgentJob(job) {
  const panel = el("swipeAgentJobPanel");
  if (!panel) return;
  state.swipeAgent.currentJob = job || null;
  renderCombinedSwipeJobs();
  return;
  el("swipeAgentStopBtn").disabled = !job || !["running", "stopping"].includes(job.status || "");
  if (!job) {
    panel.innerHTML = `<div class="adb-job-empty">実行中のSwipe Agentジョブはありません</div>`;
    return;
  }
  const totals = job.totals || {};
  panel.innerHTML = `
    <div class="adb-job-summary">
      <div>
        <span class="adb-job-label">状態</span>
        <strong>${esc(adbJobStatusLabel(job.status))}</strong>
      </div>
      <div>
        <span class="adb-job-label">監視</span>
        <strong>${esc(job.monitorIntervalSeconds || 30)}秒ごと</strong>
      </div>
      <div>
        <span class="adb-job-label">Agent対象</span>
        <strong>${esc(totals.devices || 0)}台</strong>
      </div>
      <div>
        <span class="adb-job-label">再投入</span>
        <strong>${esc(totals.restarts || 0)}</strong>
      </div>
      <div>
        <span class="adb-job-label">ADB切替</span>
        <strong>${esc(totals.adbFallback || 0)}</strong>
      </div>
      <div>
        <span class="adb-job-label">失敗</span>
        <strong>${esc(totals.failed || 0)}</strong>
      </div>
    </div>
    <details class="adb-job-details" open>
      ${swipeLogSummaryHtml()}
      <div class="adb-progress-list">
        ${(job.devices || []).slice(0, 120).map((device) => `
          <div class="adb-progress-row ${esc(device.state || "")}">
            <div>
              <strong>${esc(device.label || device.serial)}</strong>
              <span>${esc(device.serial)}</span>
            </div>
            <div><span class="swipe-mode-chip agent">Agent</span></div>
            <div>${esc(adbJobStatusLabel(device.state))}</div>
            <div>実働 ${esc(formatSeconds(Number(device.elapsedSeconds || 0)))}</div>
            <div>再投入 ${esc(device.restartCount || 0)}</div>
            <div>${esc(lastActivityLabel(device.lastSeenAt || device.lastStatusAt || device.lastStartCommandAt || ""))}</div>
            <div class="adb-error-text">${esc(device.lastError || "")}</div>
          </div>
        `).join("")}
        ${(job.devices || []).length > 120 ? `<div class="adb-progress-more">仁E{(job.devices || []).length - 120}台</div>` : ""}
      </div>
      <div class="adb-job-log">
        ${(job.logs || []).slice(-40).map((row) => `<div><span>${esc(formatTime(row.at))}</span>${formatSwipeLogMessage(row.message || "")}</div>`).join("")}
      </div>
    </details>
  `;
}

function renderAdbSwipeJob(job) {
  const panel = el("adbSwipeJobPanel");
  if (!panel) return;
  state.adbSwipe.currentJob = job || null;
  renderAdbSwipeMeta(job);
  renderCombinedSwipeJobs();
  return;
  el("adbSwipeStopBtn").disabled = !job || !["running", "stopping"].includes(job.status || "");
  if (!job) {
    panel.innerHTML = `<div class="adb-job-empty">実行中のADBスワイプはありません</div>`;
    return;
  }
  const totals = job.totals || {};
  panel.innerHTML = `
    <div class="adb-job-summary">
      <div>
        <span class="adb-job-label">状態</span>
        <strong>${esc(adbJobStatusLabel(job.status))}</strong>
      </div>
      <div>
        <span class="adb-job-label">残り</span>
        <strong>${esc(formatAdbRemaining(job))}</strong>
      </div>
      <div>
        <span class="adb-job-label">ADB対象</span>
        <strong>${esc(totals.devices || 0)}台</strong>
      </div>
      <div>
        <span class="adb-job-label">失敗</span>
        <strong>${esc(totals.failed || 0)}</strong>
      </div>
    </div>
    <details class="adb-job-details" open>
      ${swipeLogSummaryHtml()}
      <div class="adb-progress-list">
        ${(job.devices || []).slice(0, 120).map((device) => `
          <div class="adb-progress-row ${esc(device.state || "")}">
            <div>
              <strong>${esc(device.label || device.serial)}</strong>
              <span>${esc(device.serial)}</span>
            </div>
            <div><span class="swipe-mode-chip adb">ADB</span></div>
            <div>${esc(adbJobStatusLabel(device.state))}</div>
            <div>${esc(formatAdbDeviceRemaining(device))}</div>
            <div>-</div>
            <div>${esc(lastActivityLabel(device.lastRunAt || device.lastSwipeAt || device.finishedAt || device.startedAt || ""))}</div>
            <div class="adb-error-text">${esc(device.lastError || "")}</div>
          </div>
        `).join("")}
        ${(job.devices || []).length > 120 ? `<div class="adb-progress-more">仁E{(job.devices || []).length - 120}台</div>` : ""}
      </div>
      <div class="adb-job-log">
        ${(job.logs || []).slice(-40).map((row) => `<div><span>${esc(formatTime(row.at))}</span>${formatSwipeLogMessage(row.message || "")}</div>`).join("")}
      </div>
    </details>
  `;
}

function renderCombinedSwipeJobs() {
  const panel = el("swipeAgentJobPanel");
  if (!panel) return;
  const adbPanel = el("adbSwipeJobPanel");
  if (adbPanel) adbPanel.innerHTML = `<div class="adb-job-empty">ADBログは上の端末モニタに統合しました</div>`;
  const agentJob = state.swipeAgent.currentJob;
  const adbJob = state.adbSwipe.currentJob;
  const agentDevices = (agentJob?.devices || []).map((device) => ({ ...device, mode: "agent" }));
  const adbDevices = (adbJob?.devices || []).map((device) => ({ ...device, mode: "adb" }));
  const devices = [...agentDevices, ...adbDevices];
  annotateSwipeAttemptNumbers(devices);
  const running = devices.filter((device) => ["queued", "starting", "running", "stopping"].includes(device.state || ""));
  const hasActive = running.length > 0;
  if (el("swipeAgentStopBtn")) el("swipeAgentStopBtn").disabled = state.swipeStopBusy || !hasActive;
  if (el("adbSwipeStopBtn")) el("adbSwipeStopBtn").disabled = state.swipeStopBusy || !hasActive;
  if (state.swipeStopBusy) setSwipeStopControlsLocked(true);
  if (!agentJob && !adbJob) {
    panel.innerHTML = `<div class="adb-job-empty">実行中のスワイプはありません</div>`;
    renderAdbSwipeMeta(null);
    return;
  }
  const agentCount = agentDevices.length;
  const adbCount = adbDevices.length;
  const failed = running.filter((device) => device.state === "failed" || device.state === "missing" || device.lastError).length;
  const restarts = agentDevices.reduce((sum, device) => sum + Number(device.restartCount || 0), 0);
  const fallback = agentDevices.filter((device) => device.state === "adb_fallback").length;
  const logs = [
    ...(agentJob?.logs || []).map((row) => ({ ...row, mode: "Agent" })),
    ...(adbJob?.logs || []).map((row) => ({ ...row, mode: "ADB" })),
  ].sort((a, b) => String(a.at || "").localeCompare(String(b.at || "")));
  if (!hasActive) {
    panel.innerHTML = `
      <div class="adb-job-summary">
        <div>
          <span class="adb-job-label">状態</span>
          <strong>停止</strong>
        </div>
        <div>
          <span class="adb-job-label">対象</span>
          <strong>${esc(devices.length)}台</strong>
        </div>
        <div>
          <span class="adb-job-label">内訳</span>
          <strong>Agent ${esc(agentCount)} / ADB ${esc(adbCount)}</strong>
        </div>
        <div>
          <span class="adb-job-label">再投入</span>
          <strong>${esc(restarts)}</strong>
        </div>
        <div>
          <span class="adb-job-label">ADB切替</span>
          <strong>${esc(fallback)}</strong>
        </div>
        <div>
          <span class="adb-job-label">要確認</span>
          <strong>${esc(failed)}</strong>
        </div>
      </div>
      <details class="adb-job-details recent-job-details" open>
        ${swipeLogSummaryHtml()}
        <p class="swipe-log-note">${esc(swipeLogRetentionText())}</p>
        <div class="adb-progress-list">
          ${devices.map((device) => renderCombinedSwipeDeviceRow(device)).join("")}
        </div>
        <div class="adb-job-log">
          ${logs.map((row) => `<div><span>${esc(formatTime(row.at))}</span><b>${esc(row.mode)}</b> ${formatSwipeLogMessage(row.message || "")}</div>`).join("")}
        </div>
      </details>
    `;
    renderAdbSwipeMeta(null);
    return;
  }
  panel.innerHTML = `
    <div class="adb-job-summary">
      <div>
        <span class="adb-job-label">状態</span>
        <strong>${esc(hasActive ? "実行中" : "停止")}</strong>
      </div>
      <div>
        <span class="adb-job-label">対象</span>
        <strong>${esc(devices.length)}台</strong>
      </div>
      <div>
        <span class="adb-job-label">内訳</span>
        <strong>Agent ${esc(agentCount)} / ADB ${esc(adbCount)}</strong>
      </div>
      <div>
        <span class="adb-job-label">再投入</span>
        <strong>${esc(restarts)}</strong>
      </div>
      <div>
        <span class="adb-job-label">ADB切替</span>
        <strong>${esc(fallback)}</strong>
      </div>
      <div>
        <span class="adb-job-label">要確認</span>
        <strong>${esc(failed)}</strong>
      </div>
    </div>
    <details class="adb-job-details" open>
      ${swipeLogSummaryHtml()}
      <p class="swipe-log-note">${esc(swipeLogRetentionText())}</p>
      <div class="adb-progress-list">
        ${devices.map((device) => renderCombinedSwipeDeviceRow(device)).join("")}
      </div>
      <div class="adb-job-log">
        ${logs.map((row) => `<div><span>${esc(formatTime(row.at))}</span><b>${esc(row.mode)}</b> ${formatSwipeLogMessage(row.message || "")}</div>`).join("")}
      </div>
    </details>
  `;
}

function swipeLogRetentionText() {
  return "";
}

function swipeLogSummaryHtml() {
  return `
    <summary class="swipe-log-summary">
      <span>端末モニタ / ログ</span>
      <button class="swipe-past-log-btn" type="button" data-action="swipe-past-logs">過去ログ</button>
    </summary>
  `;
}

function handleSwipeJobPanelClick(event) {
  const button = event.target.closest("[data-action='swipe-past-logs']");
  if (!button) return;
  event.preventDefault();
  event.stopPropagation();
  openSwipePastLogsModal();
}

function handleSwipePastLogsModalClick(event) {
  if (event.target === el("swipePastLogsModal")) closeSwipePastLogsModal();
}

function handleSwipePastLogsKeydown(event) {
  if (event.key !== "Escape") return;
  const modal = el("swipePastLogsModal");
  if (!modal || modal.classList.contains("hidden")) return;
  closeSwipePastLogsModal();
}

async function openSwipePastLogsModal() {
  const modal = el("swipePastLogsModal");
  const text = el("swipePastLogsText");
  if (!modal || !text) return;
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  text.value = "過去ログを読み込み中...";
  try {
    const [agentList, adbList] = await Promise.all([
      fetchJson("/api/swipe-agent/jobs").catch(() => ({ jobs: [] })),
      fetchJson("/api/adb/swipe-jobs").catch(() => ({ jobs: [] })),
    ]);
    text.value = buildSwipePastLogsText(agentList.jobs || [], adbList.jobs || []);
    text.focus();
    text.setSelectionRange(0, 0);
  } catch (error) {
    text.value = `過去ログの読み込みに失敗しました。\n${error.message}`;
  }
}

function closeSwipePastLogsModal() {
  const modal = el("swipePastLogsModal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
}

function buildSwipePastLogsText(agentJobs = [], adbJobs = []) {
  const currentIds = new Set([
    state.swipeAgent.currentJob?.jobId,
    state.adbSwipe.currentJob?.jobId,
  ].filter(Boolean));
  const jobs = [
    ...agentJobs.map((job) => ({ ...job, mode: "Agent" })),
    ...adbJobs.map((job) => ({ ...job, mode: "ADB" })),
  ]
    .filter((job) => job && job.jobId && !currentIds.has(job.jobId))
    .filter((job) => !isSwipeJobAppendable(job))
    .sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));

  if (!jobs.length) {
    return [
      "過去ログはまだありません。",
      "",
      "現在表示中のログ、または完了後1時間以内で追加できるログはここには出ません。",
    ].join("\n");
  }

  return jobs.map(formatSwipePastLogJob).join("\n\n" + "=".repeat(72) + "\n\n");
}

function isSwipeJobAppendable(job) {
  if (!job || job.stopRequested) return false;
  if (job.status === "running") return true;
  if (job.status !== "done") return false;
  const finishedMs = Date.parse(job.finishedAt || 0);
  return Boolean(finishedMs && Date.now() - finishedMs <= SWIPE_JOB_MERGE_GRACE_MS);
}

function formatSwipePastLogJob(job) {
  const devices = Array.isArray(job.devices) ? job.devices : [];
  annotateSwipeAttemptNumbers(devices);
  const logs = Array.isArray(job.logs) ? job.logs : [];
  const header = [
    `[${job.mode}] ${job.jobId || "-"}`,
    `状態 ${adbJobStatusLabel(job.status)}`,
    `開始 ${formatDateTime(job.startedAt || job.createdAt || "")}`,
    `完了 ${formatDateTime(job.finishedAt || "") || "-"}`,
    `端末: ${devices.length}台`,
  ];
  const deviceLines = devices.map((device) => {
    const no = device.laixiNumber ? `${device.laixiNumber} ` : "";
    const name = device.label || device.serial || "-";
    const stateLabel = adbJobStatusLabel(device.state);
    const attempt = Number(device.attemptNo || 1) > 1 ? ` ${Number(device.attemptNo)}回目` : "";
    const detail = device.lastError ? ` / ${device.lastError}` : "";
    return `- ${no}${name} [${job.mode}]${attempt} ${stateLabel}${detail}`;
  });
  const logLines = logs.map((row) => `${formatDateTime(row.at || "")}  ${row.message || ""}`);
  return [
    ...header,
    "",
    "端末",
    ...(deviceLines.length ? deviceLines : ["- なし"]),
    "",
    "ログ",
    ...(logLines.length ? logLines : ["- なし"]),
  ].join("\n");
}

function formatSwipeLogMessage(message) {
  const text = translateSwipeLogMessage(String(message || ""));
  const match = /^(\d{1,3})(\s+)(.+)$/.exec(text);
  if (!match) return esc(text);
  return `<strong class="swipe-log-device-no">${esc(match[1])}</strong>${esc(match[2])}${esc(match[3])}`;
}

function translateSwipeLogMessage(message) {
  let text = String(message || "");
  text = text.replace(/agent still running, wait remaining (\d+)m/gi, "Agent稼働中: 残り$1分待機");
  text = text.replace(/agent elapsed (\d+)s\/(\d+)s -> wait (\d+)m/gi, "Agent経過 $1秒/$2秒 -> $3分待機");
  text = text.replace(/real time elapsed but agent worked (\d+)s -> restart (\d+)m/gi, "実働不足: $2分後に復旧");
  text = text.replace(/stop requested/gi, "停止要求");
  text = text.replace(/job stopped/gi, "ジョブ停止");
  text = text.replace(/job done/gi, "ジョブ完了");
  text = text.replace(/job started: (\d+)\/(\d+) devices/gi, "ジョブ開始: $1/$2台");
  text = text.replace(/start (\d+)m \(initial\)/gi, "$1分開始");
  return text;
}


function renderCombinedSwipeDeviceRow(device) {
  const isAdb = device.mode === "adb";
  const activityAt = isAdb
    ? device.lastRunAt || device.lastSwipeAt || device.lastHeartbeatAt || device.finishedAt || device.startedAt || ""
    : device.lastSeenAt || device.lastStatusAt || device.lastStartCommandAt || "";
  const stateLabel = swipeDeviceStateLabel(device, activityAt);
  const adbActiveSeconds = Math.floor(Number(device.activeElapsedMs || 0) / 1000);
  const timing = isAdb ? `実働 ${formatSeconds(adbActiveSeconds)}` : `実働 ${formatSeconds(Number(device.elapsedSeconds || 0))}`;
  const requestedMinutes = isAdb ? Number(device.minutes || 0) : Number(device.currentMinutes || device.requestedMinutes || device.totalRequestedMinutes || 0);
  const requestedBadge = requestedMinutes > 0 ? `<em class="swipe-duration-badge">指定 ${esc(requestedMinutes)}分</em>` : "";
  const attemptNo = Number(device.attemptNo || device.displayAttemptNo || 1);
  const repeatBadge = attemptNo > 1 ? `<em class="swipe-repeat-badge">${esc(attemptNo)}回目</em>` : "";
  return `
    <div class="adb-progress-row ${esc(device.state || "")}">
      <div>
        <strong>${esc(device.label || device.serial)}</strong>
        <span>${esc(device.serial)}</span>
      </div>
      <div><span class="swipe-mode-chip ${isAdb ? "adb" : "agent"}">${isAdb ? "ADB" : "Agent"}</span></div>
      <div>${esc(stateLabel)}</div>
      <div class="adb-timing-cell"><span>${esc(timing)}</span>${requestedBadge}</div>
      <div>${isAdb ? "-" : `再投入 ${esc(device.restartCount || 0)}`}</div>
      <div class="adb-last-activity">${esc(lastActivityLabel(activityAt))}${repeatBadge}</div>
      <div class="adb-error-text">${esc(translateSwipeLogMessage(device.lastError || ""))}</div>
    </div>
  `;
}

function annotateSwipeAttemptNumbers(devices = []) {
  const countBySerial = new Map();
  for (const device of devices) {
    const serial = String(device.serial || "");
    if (!serial) continue;
    const next = (countBySerial.get(serial) || 0) + 1;
    countBySerial.set(serial, next);
    if (!Number(device.attemptNo || 0)) device.displayAttemptNo = next;
  }
}

function swipeDeviceStateLabel(device, activityAt) {
  const status = device && device.state || "";
  if (["running", "starting", "queued"].includes(status)) {
    const at = Date.parse(activityAt || "");
    if (!Number.isFinite(at)) return "";
    const staleSeconds = Math.floor((Date.now() - at) / 1000);
    if (staleSeconds > 90) return "";
  }
  return adbJobStatusLabel(status);
}

function renderAdbSwipeMeta(job) {
  const meta = el("adbSwipeMeta");
  if (!meta) return;
  const running = (job?.devices || []).filter((device) => ["queued", "running"].includes(device.state || ""));
  if (!job || !running.length) {
    meta.textContent = "ADB側の進捗なし";
    return;
  }
  const labels = running.slice(0, 8).map((device) => device.label || device.serial || "-").join(" / ");
  const more = running.length > 8 ? ` / ほか${running.length - 8}台` : "";
  meta.textContent = `ADBで動作中 ${running.length}台: ${labels}${more}`;
}

function adbJobStatusLabel(status) {
  const labels = {
    running: "実行中",
    stopping: "停止中",
    stopped: "停止",
    done: "完了",
    failed: "失敗",
    queued: "待機中",
    missing: "未接続",
    adb_fallback: "ADBへ切替",
  };
  return labels[status] || status || "-";
}

function formatAdbRemaining(job) {
  if (!job || !["running", "stopping"].includes(job.status || "")) return "-";
  const end = Date.parse(job.endAt || "");
  if (!Number.isFinite(end)) return "-";
  return formatSeconds(Math.max(0, Math.ceil((end - Date.now()) / 1000)));
}

function formatAdbDeviceRemaining(device) {
  if (!device || !["running", "queued"].includes(device.state || "")) return "-";
  const end = Date.parse(device.endAt || "");
  if (!Number.isFinite(end)) return "-";
  return formatSeconds(Math.max(0, Math.ceil((end - Date.now()) / 1000)));
}

function formatSeconds(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}分${String(secs).padStart(2, "0")}秒`;
}

function formatTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:${String(date.getSeconds()).padStart(2, "0")}`;
}

function lastActivityLabel(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "確認 -";
  const seconds = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
  if (seconds < 60) return `確認 ${formatTime(value)} / ${seconds}秒前`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `確認 ${formatTime(value)} / ${minutes}分前`;
  const hours = Math.floor(minutes / 60);
  return `確認 ${formatTime(value)} / ${hours}時間前`;
}

async function runDeviceSettingAction(label, endpoint, button = null) {
  setBusy(true, button);
  logLine(label + " 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJsonResult(endpoint, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    const targetCount = Number.isFinite(Number(result.targeted)) ? Number(result.targeted) : Number(result.connected || 0);
    const failed = result.failed ? ` / 失敗 ${result.failed}台` : "";
    const skippedActive = result.skippedActive ? ` / 稼働中スキップ ${result.skippedActive}台` : "";
    const apkSummary = formatApkInstallSummary(result);
    const needsReview = Number(result.failed || 0) > 0 || Number(result.packageSummary?.failed || 0) > 0;
    logLine(`${label} ${needsReview ? "要確認" : "OK"}: 成功 ${result.succeeded || 0}/${targetCount}台${failed}${skippedActive}${apkSummary}`);
    logApkInstallDetails(result);
    logDeviceSettingFailureDetails(label, result);
    if (needsReview) flash = { message: "要確認", type: "warn" };
  } catch (error) {
    logLine(label + " NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

function logDeviceSettingFailureDetails(label, result = {}) {
  const rows = Array.isArray(result.results) ? result.results : [];
  const failed = rows.filter((row) => row && row.ok === false).slice(0, 8);
  for (const row of failed) {
    const id = row.serial || row.label || "-";
    const reason = row.message || row.code || row.rawResult?.error || row.rawResult?.stderr || "理由不明";
    logLine(`${label} 失敗詳細: ${id} / ${reason}`);
  }
}

async function refreshBaselineSettings(button = null) {
  setBusy(true, button);
  logLine("初期設定 全再読込 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJsonResult("/api/adb/baseline-device-settings/refresh", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    const targetCount = Number.isFinite(Number(result.targeted)) ? Number(result.targeted) : Number(result.connected || 0);
    const failed = result.failed ? ` / 失敗 ${result.failed}台` : "";
    logLine(`初期設定 全再読込 OK: 成功 ${result.succeeded || 0}/${targetCount}台${failed}`);
    if (Number(result.failed || 0) > 0) flash = { message: "要確認", type: "warn" };
    await loadSummary();
  } catch (error) {
    logLine("初期設定 全再読込 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

async function openApkFolder(button = null) {
  setBusy(true, button);
  let flash = { message: "開きました", type: "ok" };
  try {
    const result = await fetchJson("/api/apk-folder/open", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    logLine(`APKフォルダ OK: ${result.path || "data/apk"}`);
  } catch (error) {
    logLine("APKフォルダ NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

function formatApkInstallSummary(result) {
  const summary = result && result.packageSummary;
  if (!summary) return "";
  const missing = summary.missingApk ? ` / APK未配置 ${summary.missingApk}件` : "";
  return ` / APK成功 ${summary.installed}件 / インストール済みスキップ ${summary.skipped}件 / APK失敗 ${summary.failed}件${missing}`;
}

function logApkInstallDetails(result) {
  if (!result || !Array.isArray(result.results) || !result.packageSummary) return;
  const lines = [];
  const missingLabels = new Set();
  const expectedPathsByLabel = new Map();
  for (const device of result.results) {
    for (const pkg of device.packages || []) {
      if (pkg.skipped) {
        lines.push(`${device.serial} ${pkg.label}: インストール済みのためスキップ`);
      } else if (pkg.ok) {
        const mode = pkg.installMode ? ` / ${pkg.installMode}${pkg.reason ? ":" + pkg.reason : ""}` : "";
        const splits = Number(pkg.splitCount || 0) > 1 ? ` / ${pkg.splitCount}分割` : "";
        lines.push(`${device.serial} ${pkg.label}: インストール完了${mode}${splits}`);
      } else {
        if (pkg.code === "APK_NOT_FOUND") {
          missingLabels.add(pkg.label || "APK");
          if (Array.isArray(pkg.expectedPaths) && pkg.expectedPaths.length) {
            expectedPathsByLabel.set(pkg.label || "APK", pkg.expectedPaths.slice(0, 4).join(" / "));
          }
        }
        lines.push(`${device.serial} ${pkg.label}: ${pkg.message || pkg.code || "インストール失敗"}`);
      }
    }
  }
  for (const label of missingLabels) {
    const expected = expectedPathsByLabel.get(label);
    logLine(`APK未配置: ${label}${expected ? " / 探索先 " + expected : ""}`);
  }
  for (const line of lines.slice(0, 30)) logLine(line);
  if (lines.length > 30) logLine(`APK詳細: 残り${lines.length - 30}件は同期ログJSONで確認`);
}

function collectPendingTagChanges() {
  const frame = el("tagBoardFrame");
  const doc = frame && frame.contentDocument;
  if (!doc) return [];
  return [...doc.querySelectorAll('input[type="checkbox"]')]
    .filter((input) => input.checked !== (input.dataset.original === "1"))
    .map((input) => ({
      serial: input.dataset.serial,
      managementId: input.dataset.managementId,
      tag: input.dataset.tag,
      checked: input.checked,
    }));
}

function reloadTagBoardFrame() {
  const frame = el("tagBoardFrame");
  if (frame) frame.src = "/tag-board?ts=" + Date.now();
}

async function saveDbFile(button = null) {
  setBusy(true, button);
  logLine("DB保存 準備中...");
  try {
    const data = await fetchJson("/api/fleet-db/export-json");
    const text = JSON.stringify(data, null, 2);
    const fileName = `android-fleet-db-${new Date().toISOString().slice(0, 10)}.json`;
    if (window.showSaveFilePicker) {
      const handle = await window.showSaveFilePicker({
        suggestedName: fileName,
        types: [{
          description: "Android Fleet DB JSON",
          accept: { "application/json": [".json"] },
        }],
      });
      const writable = await handle.createWritable();
      await writable.write(text);
      await writable.close();
      logLine("DB保存 OK: " + handle.name);
    } else {
      const blob = new Blob([text], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(url);
      logLine("");
    }
  } catch (error) {
    if (error && error.name === "AbortError") {
      logLine("DB保存 キャンセル");
    } else {
      logLine("DB保存 NG: " + error.message);
    }
  } finally {
    setBusy(false);
  }
}

function bindScriptBuilderActions() {
  const deviceSelect = el("scriptDeviceSelect");
  if (!deviceSelect) return;
  setupScriptPackageSelect();
  el("scriptRefreshShotBtn").addEventListener("click", () => refreshScriptScreenshot());
  el("scriptCopyScreenTextBtn").addEventListener("click", copySelectedDeviceScreenText);
  el("scriptCopyDeviceClipboardBtn").addEventListener("click", copySelectedDeviceClipboardText);
  el("scriptAdbChromeTestBtn").addEventListener("click", runAdbChromeTest);
  el("scriptAutoRefreshInput").addEventListener("change", toggleScriptAutoRefresh);
  el("scriptPreviewImage").addEventListener("click", addTapStepFromPreview);
  el("scriptMinimalPresetBtn").addEventListener("click", setMinimalToastPreset);
  el("scriptDebugPresetBtn").addEventListener("click", setDebugScriptPreset);
  el("scriptChromePresetBtn").addEventListener("click", setChromeScriptPreset);
  el("scriptAddLaunchBtn").addEventListener("click", () => {
    const selected = selectedScriptPackageOption();
    addScriptStep({
      type: "launch",
      packageName: selected.packageName,
      appName: selected.appName || "",
      launchUrl: selected.launchUrl || "",
      waitMs: scriptWaitMs(),
    });
  });
  el("scriptAddWaitBtn").addEventListener("click", () => addScriptStep({
    type: "wait",
    waitMs: scriptWaitMs(),
  }));
  el("scriptAddTextBtn").addEventListener("click", () => {
    const text = el("scriptTextInput").value;
    if (!text) return logLine("");
    addScriptStep({ type: "text", text, waitMs: scriptWaitMs() });
  });
  el("scriptAddBackBtn").addEventListener("click", () => addScriptStep({ type: "back", waitMs: scriptWaitMs() }));
  el("scriptAddHomeBtn").addEventListener("click", () => addScriptStep({ type: "home", waitMs: scriptWaitMs() }));
  el("scriptClearBtn").addEventListener("click", clearScriptSteps);
  el("scriptStepList").addEventListener("click", handleScriptStepListClick);
  el("scriptCopyBtn").addEventListener("click", copyScriptOutput);
  el("scriptDownloadBtn").addEventListener("click", downloadScriptOutput);
  el("scriptRunXiaoweiBtn").addEventListener("click", runXiaoweiGeneratedScript);
  el("scriptInstallTestsBtn").addEventListener("click", installXiaoweiTestScripts);
  el("scriptFolderCheckBtn").addEventListener("click", checkXiaoweiScriptFolder);
  el("scriptLogTailBtn").addEventListener("click", checkXiaoweiLogTail);
  el("scriptLogMarkBtn").addEventListener("click", markXiaoweiLogBaseline);
  el("scriptLogDeltaBtn").addEventListener("click", checkXiaoweiLogDelta);
  el("scriptCopyAdminInstallBtn").addEventListener("click", copyAdminInstallCommand);
  el("scriptRepeatInput").addEventListener("input", renderScriptBuilder);
  el("scriptRepeatInput").addEventListener("change", renderScriptBuilder);
  renderScriptBuilder();
}

function setupScriptPackageSelect() {
  const select = el("scriptPackageSelect");
  if (!select) return;
  select.innerHTML = SCRIPT_PACKAGE_OPTIONS.map((option) =>
    `<option value="${esc(option.packageName)}">${esc(option.label)} / ${esc(option.packageName === "custom" ? "": option.packageName)}</option>`
  ).join("");
  select.value = "com.android.chrome";
  select.addEventListener("change", updateScriptPackageCustomVisibility);
  updateScriptPackageCustomVisibility();
}

function updateScriptPackageCustomVisibility() {
  const customInput = el("scriptPackageCustomInput");
  if (!customInput) return;
  customInput.classList.toggle("hidden", el("scriptPackageSelect").value !== "custom");
}

function selectedScriptPackageName() {
  return selectedScriptPackageOption().packageName;
}

function selectedScriptPackageOption() {
  const selected = el("scriptPackageSelect").value;
  if (selected === "custom") {
    const packageName = el("scriptPackageCustomInput").value.trim() || "com.android.chrome";
    return { packageName, appName: "", launchUrl: "" };
  }
  return SCRIPT_PACKAGE_OPTIONS.find((option) => option.packageName === selected) || SCRIPT_PACKAGE_OPTIONS[0];
}

function renderScriptBuilderDevices(rows) {
  const select = el("scriptDeviceSelect");
  if (!select) return;
  const current = select.value;
  const candidates = rows
    .filter((row) => row.serial)
    .slice()
    .sort((a, b) => managementNumber(a) - managementNumber(b));
  select.innerHTML = [
    `<option value="">端末を選択</option>`,
    ...candidates.map((row) => {
      const label = formatXiaoWeiDeviceOptionLabel(row);
      return `<option value="${esc(row.serial)}">${esc(label)}</option>`;
    }),
  ].join("");
  if (current && [...select.options].some((option) => option.value === current)) select.value = current;
}

function renderClipboardDevices(rows) {
  renderClipboardTargets(rows);
}

function renderClipboardTargets(rows) {
  const wrap = el("clipboardTargetGrid");
  if (!wrap) return;
  const candidates = clipboardTargetCandidates(rows);
  pruneClipboardTargets(candidates);
  if (!candidates.length) {
    wrap.innerHTML = `<div class="clipboard-empty compact">ADB接続中の送信先がありません。</div>`;
    return;
  }
  wrap.innerHTML = candidates.map((row) => {
    const checked = state.clipboardTargetSerials.has(row.serial) ? "checked" : "";
    const label = formatXiaoWeiDeviceOptionLabel(row);
    return `
      <label class="clipboard-target-item">
        <input type="checkbox" value="${esc(row.serial)}" ${checked}>
        <span>${esc(label)}</span>
      </label>
    `;
  }).join("");
}

function clipboardTargetCandidates(rows = state.summary?.devices || []) {
  return (rows || [])
    .filter((row) => row.serial)
    .filter((row) => row.adbConnected !== false)
    .filter((row) => !el("clipboardActiveOnlyInput")?.checked || isClipboardTargetActive(row))
    .slice()
    .sort((a, b) => managementNumber(a) - managementNumber(b));
}

function isClipboardTargetActive(row) {
  if (!row || row.excluded) return false;
  const number = Number(row.laixiNumber || row.number || row.managementNumber || 0);
  if (Number.isFinite(number) && number >= 800) return false;
  const tags = Array.isArray(row.tags) ? row.tags : [];
  if (tags.some((tag) => /^STATE_WAITING$|^RESET_DONE$|^NO_CYCLE$|^GROUP_WAIT/i.test(String(tag)))) return false;
  if (row.group === "稼働中" || row.status === "ACTIVE" || row.isActive === true) return true;
  return tags.some((tag) => /^(DAY_\d+|CI_|V180_|V10_)/.test(String(tag)));
}

function pruneClipboardTargets(candidates = clipboardTargetCandidates()) {
  const allowed = new Set(candidates.map((row) => row.serial));
  state.clipboardTargetSerials = new Set([...state.clipboardTargetSerials].filter((serial) => allowed.has(serial)));
}

function handleClipboardTargetChange(event) {
  const input = event.target.closest("#clipboardTargetGrid input[type='checkbox']");
  if (!input) return;
  if (input.checked) {
    state.clipboardTargetSerials.add(input.value);
  } else {
    state.clipboardTargetSerials.delete(input.value);
  }
}

function selectClipboardTargets(mode) {
  if (mode === "clear" || mode === "manual") {
    state.clipboardTargetSerials.clear();
  } else {
    const candidates = clipboardTargetCandidates();
    state.clipboardTargetSerials = new Set(
      candidates
        .filter((row) => mode !== "active" || isClipboardTargetActive(row))
        .map((row) => row.serial)
    );
  }
  renderClipboardTargets(state.summary?.devices || []);
}

function checkedClipboardTargetSerials() {
  const checked = [...document.querySelectorAll("#clipboardTargetGrid input[type='checkbox']:checked")]
    .map((input) => input.value)
    .filter(Boolean);
  if (checked.length) {
    for (const serial of checked) state.clipboardTargetSerials.add(serial);
    return checked;
  }
  return [...state.clipboardTargetSerials];
}

function renderApnPalette() {
  const wrap = el("apnPalette");
  if (!wrap) return;
  wrap.innerHTML = APN_PRESETS.map((preset, index) => {
    const fields = Object.entries(APN_FIELD_LABELS)
      .map(([key, label]) => ({ key, label, value: preset.fields?.[key] || "" }))
      .filter((field) => String(field.value).trim())
      .map((field) => `
        <div class="apn-field-row">
          <div class="apn-field-label">${esc(field.label)}</div>
          <div class="apn-field-value">${esc(field.value)}</div>
          <button class="apn-paste-btn" data-apn-index="${index}" data-apn-field="${esc(field.key)}" type="button">貼付</button>
        </div>
      `).join("");
    return `
      <article class="apn-card">
        <div class="apn-card-head">
          <div>
            <div class="apn-card-title">${esc(preset.carrier)}</div>
            <div class="apn-card-sub">${esc(preset.profile || "")}</div>
          </div>
          <div class="apn-card-note">${esc(preset.note || "")}</div>
        </div>
        <div class="apn-fields">${fields}</div>
      </article>
    `;
  }).join("");
}

async function loadClipboardItems() {
  try {
    const result = await fetchJson("/api/clipboard-items");
    state.clipboardItems = Array.isArray(result.items) ? result.items : [];
    renderClipboardItems();
  } catch (error) {
    logLine("保管リスト読込 NG: " + error.message);
  }
}

function renderClipboardItems() {
  const wrap = el("clipboardItems");
  if (!wrap) return;
  const items = state.clipboardItems || [];
  el("clipboardMeta").textContent = `保管 ${items.length}件 / Chrome起動からURLジャンプまで実行`;
  if (!items.length) {
    wrap.innerHTML = `<div class="clipboard-empty">まだ保存されたURL/本文はありません。</div>`;
    return;
  }
  wrap.innerHTML = items.map((item, index) => {
    const source = clipboardItemSourceLabel(item);
    const upDisabled = index === 0 ? "disabled" : "";
    const downDisabled = index === items.length - 1 ? "disabled" : "";
    const colorButtonLabel = isHoneyClipboardItem(item) ? "黄色押す" : "ピンク押す";
    return `
      <article class="clipboard-item" data-id="${esc(item.id)}">
        <div class="clipboard-item-main">
          <strong>${esc(item.title || "無題")}</strong>
          <time>${esc(formatDateTime(item.updatedAt || item.createdAt))}</time>
        </div>
        <div class="clipboard-item-source">${esc(source || "手動保存")}</div>
        <div class="clipboard-item-text">${esc(item.text || "")}</div>
        ${item.note ? `<div class="clipboard-item-note">${esc(item.note)}</div>` : ""}
        <div class="clipboard-item-foot">
          <button class="clipboard-task-run-btn primary-action" data-id="${esc(item.id)}" type="button">URLへ飛ぶ</button>
          <button class="clipboard-chrome-prepare-btn primary-action" data-id="${esc(item.id)}" type="button">Chrome準備</button>
          <button class="clipboard-send-btn primary-action" data-id="${esc(item.id)}" type="button">UIへ送信</button>
          <button class="clipboard-enter-btn primary-action" data-id="${esc(item.id)}" type="button">Enter</button>
          <button class="clipboard-pink-button-btn primary-action" data-id="${esc(item.id)}" type="button">${colorButtonLabel}</button>
          <button class="clipboard-copy-btn" data-id="${esc(item.id)}" type="button">コピー</button>
          <button class="clipboard-number-step-btn" data-id="${esc(item.id)}" data-delta="1" type="button">数字進む</button>
          <button class="clipboard-number-step-btn" data-id="${esc(item.id)}" data-delta="-1" type="button">数字戻る</button>
          <button class="clipboard-move-up-btn" data-id="${esc(item.id)}" type="button" ${upDisabled}>↑</button>
          <button class="clipboard-move-down-btn" data-id="${esc(item.id)}" type="button" ${downDisabled}>↓</button>
          <button class="clipboard-edit-btn" data-id="${esc(item.id)}" type="button">編集</button>
          <button class="clipboard-delete-btn danger-action" data-id="${esc(item.id)}" type="button">削除</button>
        </div>
      </article>
    `;
  }).join("");
}

function findSummaryDeviceBySerial(serial) {
  const value = String(serial || "");
  if (!value) return null;
  return (state.summary?.devices || []).find((row) => String(row.serial || "") === value) || null;
}

function clipboardItemSourceLabel(item = {}) {
  const current = findSummaryDeviceBySerial(item.sourceSerial);
  if (current) {
    const currentLabel = formatXiaoWeiDeviceOptionLabel(current);
    const savedLabel = [item.sourceNumber, item.sourceLabel].filter(Boolean).join(" ");
    if (savedLabel && savedLabel !== currentLabel) return `取得元: ${currentLabel}（保存時: ${savedLabel}）`;
    return `取得元: ${currentLabel}`;
  }
  const saved = [item.sourceNumber, item.sourceLabel].filter(Boolean).join(" ");
  return saved ? `取得元: ${saved}` : "手動保存";
}

function selectedClipboardDevice() {
  const serial = checkedClipboardTargetSerials()[0] || "";
  return (state.summary?.devices || []).find((row) => row.serial === serial) || null;
}

function clipboardDevicePayload(row = selectedClipboardDevice()) {
  if (!row) return {};
  return {
    sourceSerial: row.serial || "",
    sourceLabel: row.deviceLabel || row.deviceName || row.laixiName || row.modelGroup || "",
    sourceNumber: row.laixiNumber || "",
  };
}

async function saveClipboardForm(event) {
  event.preventDefault();
  const text = el("clipboardTextInput").value.trim();
  if (!text) return logLine("URL/本文が空です");
  const title = clipboardTitleValue();
  setBusy(true, el("clipboardSaveBtn"));
  try {
    const result = await fetchJson("/api/clipboard-items", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        id: state.clipboardEditingId,
        title,
        text,
        note: el("clipboardNoteInput").value.trim(),
        ...clipboardDevicePayload(),
      }),
    });
    state.clipboardItems = result.items || [];
    state.clipboardEditingId = "";
    renderClipboardItems();
    logLine(`保管リスト保存 OK: ${result.item?.title || ""}`);
  } catch (error) {
    logLine("保管リスト保存 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function clipboardTitleValue() {
  const preset = el("clipboardTitlePreset")?.value || "";
  if (preset === "custom") return el("clipboardTitleInput").value.trim();
  return preset || el("clipboardTitleInput").value.trim();
}

function setClipboardTitleValue(value) {
  const title = String(value || "").trim();
  const preset = el("clipboardTitlePreset");
  const input = el("clipboardTitleInput");
  const presetValues = ["QR招待", "ハチミツURL"];
  if (presetValues.includes(title)) {
    preset.value = title;
    input.value = "";
  } else {
    preset.value = "custom";
    input.value = title;
  }
  syncClipboardTitleInputVisibility();
}

function syncClipboardTitleInputVisibility() {
  const input = el("clipboardTitleInput");
  const isCustom = el("clipboardTitlePreset").value === "custom";
  input.classList.toggle("hidden", !isCustom);
  if (!isCustom) input.value = "";
}

async function captureSelectedDeviceClipboardToVault() {
  const row = selectedClipboardDevice();
  if (!row || !row.serial) return logLine("端末クリップ取得: 対象端末を選んでください");
  setBusy(true, el("clipboardCaptureBtn"));
  try {
    logLine(`端末クリップ取得 実行中: ${formatXiaoWeiDeviceOptionLabel(row)}`);
    const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "clipboard_text", timeout: 15000 }),
    });
    const payload = result.result || {};
    const text = String(payload.text || "").trim();
    if (!text) return logLine("端末クリップ取得: 取得できる文字がありません");
    const inferredTitle = inferClipboardTitleClient(text);
    el("clipboardTextInput").value = text;
    setClipboardTitleValue(inferredTitle);
    const saveResult = await fetchJson("/api/clipboard-items", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        title: inferredTitle,
        text,
        note: el("clipboardNoteInput").value.trim(),
        ...clipboardDevicePayload(row),
      }),
    });
    state.clipboardItems = saveResult.items || [];
    renderClipboardItems();
    logLine(`端末クリップ取得 OK: URL欄へ反映 / ${text.length}文字 / ${formatXiaoWeiDeviceOptionLabel(row)}`);
  } catch (error) {
    logLine("端末クリップ取得 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function handleClipboardItemAction(event) {
  const button = event.target.closest("button[data-id]");
  if (!button) return;
  if (state.clipboardUrlTaskRunning) {
    logLine("URLタスク: すでに実行中です");
    flashButtonResult(button, "実行中", "warn");
    return;
  }
  if (state.busy) {
    logLine("タスク操作: 別の処理中です。完了後にもう一度押してください");
    flashButtonResult(button, "処理中", "warn");
    return;
  }
  const item = (state.clipboardItems || []).find((entry) => entry.id === button.dataset.id);
  if (!item) return;
  if (button.classList.contains("clipboard-send-btn")) {
    await sendClipboardItemToDevice(item, button);
    return;
  }
  if (button.classList.contains("clipboard-chrome-prepare-btn")) {
    await prepareChromeSearchForSelectedClipboardTargets(item, button);
    return;
  }
  if (button.classList.contains("clipboard-enter-btn")) {
    await pressEnterForSelectedClipboardTargets(item, button);
    return;
  }
  if (button.classList.contains("clipboard-pink-button-btn")) {
    await tapPinkButtonForSelectedClipboardTargets(item, button);
    return;
  }
  if (button.classList.contains("clipboard-copy-btn")) {
    await copyClipboardItemText(item, button);
    return;
  }
  if (button.classList.contains("clipboard-task-run-btn")) {
    logLine(`URLタスク クリック: ${item.title || "無題"}`);
    await runClipboardUrlTask(item, button);
    return;
  }
  if (button.classList.contains("clipboard-number-step-btn")) {
    const delta = Number(button.dataset.delta || 0);
    await stepClipboardItemNumber(item, delta, button);
    return;
  }
  if (button.classList.contains("clipboard-move-up-btn")) {
    await moveClipboardItem(item.id, -1, button);
    return;
  }
  if (button.classList.contains("clipboard-move-down-btn")) {
    await moveClipboardItem(item.id, 1, button);
    return;
  }
  if (button.classList.contains("clipboard-edit-btn")) {
    state.clipboardEditingId = item.id;
    setClipboardTitleValue(item.title || "");
    el("clipboardTextInput").value = item.text || "";
    el("clipboardNoteInput").value = item.note || "";
    return;
  }
  if (button.classList.contains("clipboard-delete-btn")) {
    const ok = window.confirm("削除しますか？");
    if (!ok) return;
    await deleteClipboardItem(item.id, button);
  }
}

async function copyClipboardItemText(item, button = null) {
  const text = String(item.text || "");
  if (!text.trim()) {
    logLine(`コピー: 本文が空です / ${item.title || "無題"}`);
    return;
  }
  setBusy(true, button);
  try {
    await navigator.clipboard.writeText(text);
    logLine(`コピー OK: ${item.title || "無題"} / ${text.length}文字`);
  } catch (error) {
    logLine(`コピー NG: ${error.message}`);
  } finally {
    setBusy(false);
  }
}

function formatSteppedNumber(rawNumber, delta) {
  const value = Number(rawNumber);
  if (!Number.isFinite(value)) return null;
  const next = Math.max(0, value + delta);
  const nextText = String(next);
  return rawNumber.length > 1 && nextText.length <= rawNumber.length
    ? nextText.padStart(rawNumber.length, "0")
    : nextText;
}

function stepClipboardTextNumber(text, delta) {
  const value = String(text || "");
  const emailNumberPattern = /([A-Za-z0-9._%+-]*?)(\d+)(@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/;
  const emailMatch = value.match(emailNumberPattern);
  if (emailMatch) {
    const nextNumber = formatSteppedNumber(emailMatch[2], delta);
    if (nextNumber === null) return { ok: false };
    return {
      ok: true,
      text: value.replace(emailNumberPattern, `${emailMatch[1]}${nextNumber}${emailMatch[3]}`),
      before: emailMatch[2],
      after: nextNumber,
    };
  }

  const suffixMatch = value.match(/([\s\S]*?)(\d+)(\s*)$/);
  if (!suffixMatch) return { ok: false };
  const nextNumber = formatSteppedNumber(suffixMatch[2], delta);
  if (nextNumber === null) return { ok: false };
  return {
    ok: true,
    text: `${suffixMatch[1]}${nextNumber}${suffixMatch[3]}`,
    before: suffixMatch[2],
    after: nextNumber,
  };
}

async function stepClipboardItemNumber(item, delta, button = null) {
  if (!delta) return;
  const stepped = stepClipboardTextNumber(item.text || "", delta);
  if (!stepped.ok) {
    logLine(`数字${delta > 0 ? "進む" : "戻る"}: 対象の数字が見つかりません / ${item.title || "無題"}`);
    return;
  }
  const originalIds = (state.clipboardItems || []).map((entry) => entry.id);
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/clipboard-items", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        id: item.id,
        title: item.title || "",
        text: stepped.text,
        note: item.note || "",
        sourceSerial: item.sourceSerial || "",
        sourceLabel: item.sourceLabel || "",
        sourceNumber: item.sourceNumber || "",
      }),
    });
    state.clipboardItems = result.items || [];
    if (originalIds.length) {
      const reorderResult = await fetchJson("/api/clipboard-items/reorder", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ids: originalIds }),
      });
      state.clipboardItems = reorderResult.items || state.clipboardItems;
    }
    if (state.clipboardEditingId === item.id) {
      el("clipboardTextInput").value = stepped.text;
    }
    renderClipboardItems();
    logLine(`数字${delta > 0 ? "進む" : "戻る"} OK: ${stepped.before} -> ${stepped.after} / ${item.title || "無題"}`);
  } catch (error) {
    logLine(`数字${delta > 0 ? "進む" : "戻る"} NG: ${error.message}`);
    await loadClipboardItems();
  } finally {
    setBusy(false);
  }
}

async function runClipboardDeviceActionBatch(label, targets, payloadForRow, options = {}) {
  const button = options.button || null;
  const concurrency = Math.max(1, Number(options.concurrency || 8));
  if (!targets.length) {
    logLine(`${label}: 送信先端末を選んでください`);
    return { succeeded: 0, failed: 0 };
  }
  setBusy(true, button);
  let succeeded = 0;
  let failed = 0;
  let cursor = 0;
  async function worker() {
    while (cursor < targets.length) {
      const row = targets[cursor++];
      try {
        const payload = payloadForRow(row);
        const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(payload),
        });
        succeeded += 1;
        if (options.successLog) {
          logLine(options.successLog(row, result));
        } else {
          logLine(`${label} OK: ${formatXiaoWeiDeviceOptionLabel(row)}`);
        }
      } catch (error) {
        failed += 1;
        logLine(`${label} NG: ${formatXiaoWeiDeviceOptionLabel(row)} / ${error.message}`);
      }
    }
  }
  try {
    logLine(`${label} 開始: ${targets.length}台 / 同時${concurrency}台`);
    await Promise.all(Array.from({ length: Math.min(concurrency, targets.length) }, () => worker()));
    logLine(`${label} 完了: 成功 ${succeeded} / 失敗 ${failed}`);
    return { succeeded, failed };
  } finally {
    setBusy(false);
    flashButtonResult(button, failed ? "要確認" : "完了", failed ? "warn" : "ok");
  }
}

async function moveClipboardItem(id, direction, button = null) {
  const items = [...(state.clipboardItems || [])];
  const index = items.findIndex((entry) => entry.id === id);
  const nextIndex = index + direction;
  if (index < 0 || nextIndex < 0 || nextIndex >= items.length) return;
  [items[index], items[nextIndex]] = [items[nextIndex], items[index]];
  state.clipboardItems = items;
  renderClipboardItems();
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/clipboard-items/reorder", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ids: items.map((entry) => entry.id) }),
    });
    state.clipboardItems = result.items || items;
    renderClipboardItems();
    logLine("保管リスト並べ替え OK");
  } catch (error) {
    logLine("保管リスト並べ替え NG: " + error.message);
    await loadClipboardItems();
  } finally {
    setBusy(false);
  }
}

async function sendClipboardItemToDevice(item, button = null) {
  const targets = selectedClipboardTargetsForDeviceAction(item);
  if (!targets.length) return logLine("UIへ送信: 送信先端末を選んでください");
  if (!String(item.text || "").trim()) return logLine("UIへ送信: 送信する本文が空です");
  await runClipboardDeviceActionBatch(
    `UIへ送信 ${item.title || ""}`.trim(),
    targets,
    () => ({ action: "input_text", text: item.text, timeout: 15000 }),
    {
      button,
      concurrency: 8,
      successLog: (row, result) => `UIへ送信 OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${result.result?.length || String(item.text).length}文字`,
    }
  );
}

async function prepareChromeSearchForSelectedClipboardTargets(item, button = null) {
  const targets = selectedClipboardTargetsForDeviceAction(item);
  await runClipboardDeviceActionBatch(
    `Chrome準備 ${item?.title || ""}`.trim(),
    targets,
    () => ({
      action: "chrome_search_prepare",
      afterHomeWaitMs: 700,
      afterLaunchWaitMs: 1400,
      timeout: 12000,
    }),
    {
      button,
      concurrency: 8,
      successLog: (row, result) => `Chrome準備 OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${result.result?.addressFocus?.method || "focus"}`,
    }
  );
}

async function pressEnterForSelectedClipboardTargets(item, button = null) {
  const targets = selectedClipboardTargetsForDeviceAction(item);
  await runClipboardDeviceActionBatch(
    `Enter ${item?.title || ""}`.trim(),
    targets,
    () => ({ action: "press_enter", timeout: 5000 }),
    {
      button,
      concurrency: 12,
      successLog: (row) => `Enter OK: ${formatXiaoWeiDeviceOptionLabel(row)}`,
    }
  );
}

async function tapPinkButtonForSelectedClipboardTargets(item, button = null) {
  const targets = selectedClipboardTargetsForDeviceAction(item);
  const honey = isHoneyClipboardItem(item);
  const label = honey ? "黄色押す" : "ピンク押す";
  await runClipboardDeviceActionBatch(
    `${label} ${item?.title || ""}`.trim(),
    targets,
    () => ({
      action: "tap_landing_button",
      mode: "image",
      fallbackCoordinate: true,
      timeout: 15000,
    }),
    {
      button,
      concurrency: 8,
      successLog: (row, result) => {
        const tap = result.result?.tap || {};
        const method = tap.method || tap.imageTap?.method || "tap";
        const foreground = tap.foreground?.packageName || tap.tap?.foreground?.packageName || "";
        return `${label} OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${method}${foreground ? ` / ${foreground}` : ""}`;
      },
    }
  );
}

function isHoneyClipboardItem(item = {}) {
  const value = `${item.title || ""} ${item.note || ""} ${item.text || ""}`;
  return /ハチミツ|はちみつ|蜂蜜|サッカー|soccer|ranking|challenge/i.test(value);
}

async function runClipboardUrlTask(item, button = null) {
  if (state.clipboardUrlTaskRunning) {
    logLine("URLタスク: すでに実行中です");
    return;
  }
  const targetPlan = clipboardUrlTargetPlan(item);
  const targets = targetPlan.targets;
  const selectedCount = targetPlan.selectedCount;
  logLine(`URLタスク 選択 ${selectedCount}件 / 送信 ${targets.length}件`);
  if (selectedCount !== targets.length) {
    logClipboardTargetFilterReasons(item);
  }
  const text = String(item.text || "").trim();
  if (!text) return logLine("URLタスク: URL/本文が空です");
  const action = preferredUrlAction(item, text);
  const packageName = preferredUrlPackageName(item, text);
  const landingButtonMode = preferredLandingButtonMode(item, text);
  const inviteTaskKind = preferredInviteTaskKind(item, text);
  const onePassInviteTask = action === "chrome_url_task" && ["qr", "soccer"].includes(inviteTaskKind);
  const startedAt = Date.now();
  const failures = targetPlan.failures.slice();
  const excluded = targetPlan.excluded.slice();
  if (!targets.length) {
    if (!selectedCount) return logLine("URLタスク: 送信先端末を選んでください");
    logLine(`URLタスク 完了: 実行対象なし / 事前NG ${failures.length} / 対象外 ${excluded.length}`);
    showClipboardUrlTaskResultDialog({
      title: item.title || "URLタスク",
      selectedCount,
      succeeded: 0,
      failures,
      excluded,
      startedAt,
      finishedAt: Date.now(),
      onePassInviteTask,
    });
    return;
  }
  state.clipboardUrlTaskRunning = true;
  setBusy(true, button);
  let succeeded = 0;
  let fatalError = null;
  try {
    logLine(`URLタスク 開始: ${targets.length}台 / ${item.title || ""}`);
    logLine(`URLタスク 方法: ${action}${packageName ? " / " + packageName : ""} / ${inviteTaskKind}${onePassInviteTask ? " / 1巡のみ" : ""}`);
    for (const row of targets) {
      try {
        const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            action,
            url: text,
            packageName,
            lockPortrait: true,
            forceStopPackage: true,
            landingButtonMode,
            inviteTaskKind,
            skipInviteVerification: onePassInviteTask,
            retryOnUnverified: !onePassInviteTask,
            fastAfterTap: onePassInviteTask,
            timeout: 25000,
          }),
        });
        const resultFailure = clipboardUrlTaskResponseFailure(row, result, { onePassInviteTask, inviteTaskKind });
        if (resultFailure) {
          failures.push(resultFailure);
          logLine(`URLタスク NG: ${resultFailure.label} / ${resultFailure.reason} / 予想: ${resultFailure.prediction}`);
          continue;
        }
        succeeded += 1;
        const foreground = result.result?.foreground?.component || result.result?.foreground?.packageName || "";
        logLine(`URLタスク OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${action}${packageName ? " / " + packageName : ""}${foreground ? " / " + foreground : ""}`);
      } catch (error) {
        const failure = clipboardUrlTaskErrorFailure(row, error);
        failures.push(failure);
        logLine(`URLタスク NG: ${failure.label} / ${failure.reason} / 予想: ${failure.prediction}`);
      }
    }
  } catch (error) {
    fatalError = error;
    failures.push(clipboardUrlTaskErrorFailure(null, error, "タスク全体"));
    logLine(`URLタスク 全体NG: ${error.message}`);
  } finally {
    const failed = failures.length;
    logLine(onePassInviteTask
      ? `URLタスク 1巡完了: 成功 ${succeeded} / 失敗 ${failed} / 対象外 ${excluded.length} / 自動確認・再送なし`
      : `URLタスク 完了: 成功 ${succeeded} / 失敗 ${failed} / 対象外 ${excluded.length}`);
    state.clipboardUrlTaskRunning = false;
    setBusy(false);
    flashButtonResult(button, failed ? "要確認" : "完了", failed ? "warn" : "ok");
    showClipboardUrlTaskResultDialog({
      title: item.title || "URLタスク",
      selectedCount,
      succeeded,
      failures,
      excluded,
      startedAt,
      finishedAt: Date.now(),
      onePassInviteTask,
      fatalError: fatalError?.message || "",
    });
  }
}

function clipboardUrlTaskDeviceInfo(row = null, fallbackSerial = "") {
  const serial = String(row?.serial || fallbackSerial || "");
  return {
    label: row ? formatXiaoWeiDeviceOptionLabel(row) : fallbackSerial || "タスク全体",
    serial,
  };
}

function clipboardUrlTaskFailure(row, reason, prediction, detail = "", fallbackSerial = "") {
  return {
    ...clipboardUrlTaskDeviceInfo(row, fallbackSerial),
    reason: String(reason || "原因不明のエラー"),
    prediction: String(prediction || "ADB接続または端末側の一時的な不調の可能性があります"),
    detail: String(detail || "").trim().slice(0, 600),
  };
}

function clipboardUrlTaskResponseFailure(row, response, options = {}) {
  if (!options.onePassInviteTask) return null;
  const tap = response?.result?.landingFallbackTap;
  const buttonLabel = options.inviteTaskKind === "qr" ? "ピンクの招待ボタン" : "黄色の招待ボタン";
  if (!tap) {
    return clipboardUrlTaskFailure(
      row,
      `${buttonLabel}の押下結果を取得できませんでした`,
      "Fleetの画面とサーバーの版違い、または端末応答の途中切断が考えられます",
      "landingFallbackTap missing"
    );
  }
  const tapReason = String(tap.reason || tap.error || tap.imageTap?.reason || "");
  if (tap.ok === false || tapReason === "yellow-not-detected") {
    return clipboardUrlTaskFailure(
      row,
      `${buttonLabel}を検出・押下できませんでした`,
      "Chromeの読み込み遅延、初回確認画面、URLページ変更、またはボタンの色・位置変更が考えられます",
      tapReason || "button tap failed"
    );
  }
  return null;
}

function clipboardUrlTaskErrorFailure(row, error, fallbackLabel = "") {
  const detail = String(error?.message || error || "原因不明").trim();
  const value = detail.toLowerCase();
  let reason = "端末処理でエラーが発生しました";
  let prediction = "ADBの一時切断、端末の高負荷、またはChromeの読み込み不調が考えられます";
  if (/unauthorized|not authorized|authorization/.test(value)) {
    reason = "ADB接続が許可待ちになりました";
    prediction = "スマホ画面のUSBデバッグ許可が未承認、または承認情報が失効した可能性があります";
  } else if (/\boffline\b/.test(value)) {
    reason = "処理中にADBがオフラインになりました";
    prediction = "USBケーブル、ハブ、端末端子の瞬断、またはADBポートの不調が考えられます";
  } else if (/device[^\n]*(not found|missing)|no devices|connected device not found|unknown serial|not connected/.test(value)) {
    reason = "処理中に端末のADB接続が切れました";
    prediction = "USBケーブル、ハブ、端末端子、USBデバッグ接続を確認してください";
  } else if (/timed out|timeout|etimedout|\b504\b/.test(value)) {
    reason = "端末が制限時間内に応答しませんでした";
    prediction = "端末の高負荷、ADB停止、Chromeの読み込み遅延、USB通信の不安定化が考えられます";
  } else if (/adb_not_available|adb[^\n]*(not found|enoent)|spawn[^\n]*enoent/.test(value)) {
    reason = "ADBを起動できませんでした";
    prediction = "ADB実行ファイル、Fleetの起動場所、またはADBサーバーの状態を確認してください";
  } else if (/chrome|activity[^\n]*(not found|unable)|unable to resolve intent/.test(value)) {
    reason = "Chromeまたは招待URLを開けませんでした";
    prediction = "Chrome未導入、初回起動画面、無効化状態、またはURL形式の問題が考えられます";
  } else if (/screencap|screenshot|png|decode|image/.test(value)) {
    reason = "招待ボタンを探す画面画像を取得できませんでした";
    prediction = "端末画面が消灯中、ADB画面取得の失敗、または端末応答の遅延が考えられます";
  } else if (/failed to fetch|networkerror|econnrefused|socket|unexpected[^\n]*json/.test(value)) {
    reason = "Fleetサーバーとの通信に失敗しました";
    prediction = "Fleetサーバーの再起動、ブラウザとサーバーの接続、またはPC負荷を確認してください";
  }
  const failure = clipboardUrlTaskFailure(row, reason, prediction, detail);
  if (!row && fallbackLabel) failure.label = fallbackLabel;
  return failure;
}

function clipboardUrlTaskResultText(result = {}) {
  const lines = [
    `URLタスク結果: ${result.title || "URLタスク"}`,
    `選択 ${Number(result.selectedCount || 0)}台 / 成功 ${Number(result.succeeded || 0)}台 / 失敗 ${(result.failures || []).length}台 / 対象外 ${(result.excluded || []).length}台`,
  ];
  if (result.onePassInviteTask) lines.push("成功の意味: URL表示と招待ボタン押下まで完了。招待結果画面の再確認は未実施。");
  for (const failure of result.failures || []) {
    lines.push(`失敗: ${failure.label}${failure.serial ? ` [${failure.serial}]` : ""}`);
    lines.push(`理由: ${failure.reason}`);
    lines.push(`予想: ${failure.prediction}`);
    if (failure.detail) lines.push(`詳細: ${failure.detail}`);
  }
  for (const row of result.excluded || []) {
    lines.push(`対象外: ${row.label}${row.serial ? ` [${row.serial}]` : ""} / ${row.reason}`);
  }
  return lines.join("\n");
}

function showClipboardUrlTaskResultDialog(result = {}) {
  document.querySelector(".url-task-result-backdrop")?.remove();
  const failures = Array.isArray(result.failures) ? result.failures : [];
  const excluded = Array.isArray(result.excluded) ? result.excluded : [];
  const succeeded = Number(result.succeeded || 0);
  const selectedCount = Number(result.selectedCount || 0);
  const durationSeconds = Math.max(0, Math.round((Number(result.finishedAt || Date.now()) - Number(result.startedAt || Date.now())) / 1000));
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop url-task-result-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog url-task-result-dialog ${failures.length ? "has-failures" : "all-success"}" role="alertdialog" aria-modal="true" aria-labelledby="urlTaskResultTitle">
      <div class="adb-drop-dialog-head url-task-result-head">
        <div>
          <h3 id="urlTaskResultTitle">URLタスク完了</h3>
          <p>${esc(result.title || "URLタスク")} / 選択 ${selectedCount}台 / ${durationSeconds}秒</p>
        </div>
        <button class="adb-drop-close url-task-result-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="url-task-result-body">
        <div class="url-task-result-counts">
          <div class="success"><span>成功</span><strong>${succeeded}</strong><small>台</small></div>
          <div class="failure"><span>失敗</span><strong>${failures.length}</strong><small>台</small></div>
          <div class="excluded"><span>対象外</span><strong>${excluded.length}</strong><small>台</small></div>
        </div>
        <div class="url-task-result-definition">
          ${result.onePassInviteTask
            ? "成功は、URL表示と招待ボタン押下まで完了した台数です。招待結果画面の再確認はしていません。"
            : "成功は、端末アクションがエラーなく完了した台数です。"}
        </div>
        ${failures.length ? `
          <section class="url-task-result-section failure-list">
            <h4>失敗した端末と予想原因</h4>
            <div class="url-task-result-failure-list">
              ${failures.map((failure) => `
                <article class="url-task-result-failure-row">
                  <div class="url-task-result-device">
                    <strong>${esc(failure.label || failure.serial || "不明な端末")}</strong>
                    ${failure.serial ? `<code>${esc(failure.serial)}</code>` : ""}
                  </div>
                  <div class="url-task-result-reason"><span>失敗理由</span><b>${esc(failure.reason || "原因不明")}</b></div>
                  <div class="url-task-result-prediction"><span>予想原因</span><p>${esc(failure.prediction || "確認できませんでした")}</p></div>
                  ${failure.detail ? `<details><summary>エラー詳細</summary><code>${esc(failure.detail)}</code></details>` : ""}
                </article>
              `).join("")}
            </div>
          </section>
        ` : `<div class="url-task-result-all-clear"><strong>処理エラーはありません</strong><span>${succeeded ? "選択した実行対象を一巡しました。" : "実行対象はありませんでした。対象外の理由を確認してください。"}</span></div>`}
        ${excluded.length ? `
          <section class="url-task-result-section excluded-list">
            <h4>対象外 ${excluded.length}台</h4>
            <div class="url-task-result-excluded-list">
              ${excluded.map((row) => `<span><b>${esc(row.label || row.serial || "不明な端末")}</b> / ${esc(row.reason || "対象外")}</span>`).join("")}
            </div>
          </section>
        ` : ""}
      </div>
      <div class="adb-drop-actions url-task-result-actions">
        <button class="section-head-action url-task-result-copy" type="button">結果をコピー</button>
        <button class="section-head-action url-task-result-close" type="button">閉じる</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".url-task-result-close").forEach((closeButton) => {
    closeButton.addEventListener("click", () => overlay.remove());
  });
  overlay.querySelector(".url-task-result-copy")?.addEventListener("click", async (event) => {
    const copyButton = event.currentTarget;
    const text = clipboardUrlTaskResultText(result);
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const input = document.createElement("textarea");
      input.value = text;
      document.body.appendChild(input);
      input.select();
      document.execCommand("copy");
      input.remove();
    }
    flashButtonResult(copyButton, "コピー済み", "ok");
  });
  overlay.querySelector(".url-task-result-close")?.focus();
}

function logClipboardTargetFilterReasons(item = null) {
  const plan = clipboardUrlTargetPlan(item);
  if (!plan.selectedCount) {
    logLine("URLタスク: チェックされた端末がありません");
    return;
  }
  for (const failure of plan.failures.slice(0, 12)) {
    logLine(`URLタスク 事前NG: ${failure.label} / ${failure.reason} / 予想: ${failure.prediction}`);
  }
  for (const row of plan.excluded.slice(0, 12)) {
    logLine(`URLタスク 対象外: ${row.label} / ${row.reason}`);
  }
}

function preferredUrlPackageName(item, text) {
  const value = `${item?.title || ""} ${item?.note || ""} ${text || ""}`.toLowerCase();
  if (isBrowserUrlTask(item, text)) {
    return "com.android.chrome";
  }
  if (/tiktok|tiktoklite|tik tok|vt\.tiktok|www\.tiktok|m\.tiktok|lite/.test(value)) {
    if (/lite\.tiktok\.com|lite\.tt\./.test(value)) return "com.ss.android.ugc.tiktok.lite";
    return "com.zhiliaoapp.musically.go";
  }
  if (/line\.me|lin\.ee|line/.test(value)) {
    return "jp.naver.line.android";
  }
  return "";
}

function preferredUrlAction(item, text) {
  if (isBrowserUrlTask(item, text)) {
    return "chrome_url_task";
  }
  return "launch_url";
}

function preferredLandingButtonMode(item, text) {
  const value = `${item?.title || ""} ${item?.note || ""} ${text || ""}`.toLowerCase();
  return /qr|qr招待|招待|invite/.test(value) ? "optional" : "required";
}

function preferredInviteTaskKind(item, text) {
  const value = `${item?.title || ""} ${item?.note || ""} ${text || ""}`.toLowerCase();
  if (/qr|qr招待/.test(value)) return "qr";
  if (/ハチミツ|はちみつ|サッカー|soccer|ranking|challenge/.test(value)) return "soccer";
  return /invite|招待/.test(value) ? "qr" : "generic";
}

function isBrowserUrlTask(item, text) {
  const value = `${item?.title || ""} ${item?.note || ""} ${text || ""}`.toLowerCase();
  return /^https?:\/\//i.test(String(text || "").trim()) || /qr招待|招待|invite/.test(value);
}

function selectedClipboardUrlTargets(item = null) {
  return clipboardUrlTargetPlan(item).targets;
}

function clipboardUrlTargetPlan(item = null) {
  const rows = state.summary?.devices || [];
  const serials = checkedClipboardTargetSerials();
  const serialSet = new Set(serials);
  const sourceSerial = String(item?.sourceSerial || "");
  const activeOnly = Boolean(el("clipboardActiveOnlyInput")?.checked);
  const excludeSource = Boolean(el("clipboardExcludeSourceInput")?.checked && sourceSerial);
  const seen = new Set();
  const targets = [];
  const failures = [];
  const excluded = [];
  for (const row of rows) {
    if (!row.serial || !serialSet.has(row.serial)) continue;
    seen.add(row.serial);
    const info = clipboardUrlTaskDeviceInfo(row);
    if (row.adbConnected === false) {
      failures.push(clipboardUrlTaskFailure(
        row,
        "開始時点でADB未接続でした",
        "USBケーブル、ハブ、端末端子、USBデバッグ許可、ADBポートの状態を確認してください",
        row.adbStatus || row.status || "adbConnected=false"
      ));
      continue;
    }
    if (activeOnly && !isClipboardTargetActive(row)) {
      excluded.push({ ...info, reason: "非稼働端末フィルター" });
      continue;
    }
    if (excludeSource && row.serial === sourceSerial) {
      excluded.push({ ...info, reason: "取得元へ送らない設定" });
      continue;
    }
    targets.push(row);
  }
  for (const serial of serials) {
    if (seen.has(serial)) continue;
    failures.push(clipboardUrlTaskFailure(
      null,
      "選択端末が端末DBに見つかりませんでした",
      "端末DB更新後に画面の選択状態が古くなっている可能性があります。画面を更新して再選択してください",
      "selected serial missing from current summary",
      serial
    ));
  }
  return { selectedCount: serials.length, targets, failures, excluded };
}

function selectedClipboardTargetsForDeviceAction(item = null) {
  const rows = state.summary?.devices || [];
  const serialSet = new Set(checkedClipboardTargetSerials());
  const sourceSerial = String(item?.sourceSerial || "");
  return rows
    .filter((row) => row.serial && serialSet.has(row.serial))
    .filter((row) => row.adbConnected !== false)
    .filter((row) => !el("clipboardActiveOnlyInput")?.checked || isClipboardTargetActive(row))
    .filter((row) => !item || !el("clipboardExcludeSourceInput")?.checked || !sourceSerial || row.serial !== sourceSerial);
}

async function closeTtlForSelectedClipboardTargets(button = null) {
  const targets = selectedClipboardTargetsForDeviceAction().map((row) => ({
    serial: row.serial,
    adbPort: row.adbPort || "",
    label: formatXiaoWeiDeviceOptionLabel(row),
  }));
  if (!targets.length) {
    logLine("TTLアプリを閉じる NG: 対象端末が選択されていません");
    return;
  }
  setBusy(true, button);
  logLine(`TTLアプリを閉じる 実行中: ${targets.length}台`);
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson("/api/adb/close-ttl", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ targets }),
    });
    logLine(`TTLアプリを閉じる ${result.ok ? "OK" : "NG"}: 成功 ${result.succeeded || 0} / 失敗 ${result.failed || 0}`);
    if (!result.ok || Number(result.failed || 0) > 0) flash = { message: "要確認", type: "warn" };
    logFailedDeviceRows("TTLアプリを閉じる", result.results || []);
  } catch (error) {
    logLine("TTLアプリを閉じる NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

async function launchAppForSelectedClipboardTargets(app, label, button = null) {
  const actionLabel = label || (app === "ttl" ? "TTL起動" : app === "line" ? "LINE起動" : "アプリ起動");
  const targets = selectedClipboardTargetsForDeviceAction().map((row) => ({
    serial: row.serial,
    adbPort: row.adbPort || "",
    label: formatXiaoWeiDeviceOptionLabel(row),
  }));
  if (!targets.length) {
    logLine(`${actionLabel} NG: 対象端末が選択されていません`);
    return;
  }
  setBusy(true, button);
  logLine(`${actionLabel} 実行中: ${targets.length}台`);
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson("/api/adb/launch-app", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ app, targets }),
    });
    logLine(`${actionLabel} ${result.ok ? "OK" : "NG"}: 成功 ${result.succeeded || 0} / 失敗 ${result.failed || 0}`);
    if (!result.ok || Number(result.failed || 0) > 0) flash = { message: "要確認", type: "warn" };
    logFailedDeviceRows(actionLabel, result.results || []);
  } catch (error) {
    logLine(`${actionLabel} NG: ${error.message}`);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

async function installApksForSelectedClipboardTargets(button = null) {
  const selectedRows = selectedClipboardTargetsForDeviceAction();
  const targets = selectedRows.map((row) => ({
    serial: row.serial,
    adbPort: row.adbPort || "",
    label: formatXiaoWeiDeviceOptionLabel(row),
  }));
  if (!targets.length) {
    logLine("APKインストール NG: 対象端末が選択されていません");
    return;
  }

  let selectedFiles = null;
  while (selectedFiles === null) {
    let library;
    try {
      library = await fetchJson("/api/apk-library");
    } catch (error) {
      logLine("APK一覧 NG: " + error.message);
      flashButtonResult(button, "失敗", "error");
      return;
    }
    const picked = await showApkInstallPickerDialog(library.files || [], {
      targetCount: targets.length,
      path: library.path || "data/apk",
    });
    if (!picked) return;
    if (picked.reload) continue;
    selectedFiles = picked.files;
  }
  if (!selectedFiles.length) return;
  const workCount = targets.length * selectedFiles.length;
  const ok = window.confirm(`${targets.length}台へ${selectedFiles.length}個のAPKをインストールします。\n合計 ${workCount}件の導入処理です。台数やAPK数が多い場合は時間がかかります。\n\n開始しますか？`);
  if (!ok) return;
  setBusy(true, button);
  logLine(`APKインストール 実行中: ${targets.length}台 × ${selectedFiles.length}ファイル`);
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson("/api/adb/install-apks", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ targets, files: selectedFiles }),
    });
    const targetCount = Number.isFinite(Number(result.targeted)) ? Number(result.targeted) : targets.length;
    const failed = result.failed ? ` / 失敗 ${result.failed}台` : "";
    const apkSummary = formatApkInstallSummary(result);
    const needsReview = Number(result.failed || 0) > 0 || Number(result.packageSummary?.failed || 0) > 0;
    logLine(`APKインストール ${needsReview ? "要確認" : "OK"}: 成功 ${result.succeeded || 0}/${targetCount}台${failed}${apkSummary}`);
    if (needsReview) flash = { message: "要確認", type: "warn" };
    logApkInstallDetails(result);
  } catch (error) {
    logLine("APKインストール NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

function showApkInstallPickerDialog(files = [], options = {}) {
  return new Promise((resolve) => {
    closeAdbDropDialog();
    const rows = Array.isArray(files) ? files : [];
    const overlay = document.createElement("div");
    overlay.className = "adb-drop-dialog-backdrop";
    overlay.innerHTML = `
      <div class="adb-drop-dialog app-extract-dialog apk-install-dialog" role="dialog" aria-modal="true" aria-labelledby="apkInstallDialogTitle">
        <div class="adb-drop-dialog-head">
          <div>
            <h3 id="apkInstallDialogTitle">APKインストール</h3>
            <p>対象 ${esc(options.targetCount || 0)}台 / APKフォルダ ${esc(rows.length)}件</p>
          </div>
          <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
        </div>
        <div class="app-extract-toolbar apk-install-toolbar">
          <button class="section-head-action apk-install-select-all" type="button">すべて選択</button>
          <button class="section-head-action apk-install-clear" type="button">解除</button>
          <button class="section-head-action apk-install-refresh" type="button">再読込</button>
          <button class="section-head-action apk-install-open-folder" type="button">APKフォルダ</button>
          <span class="apk-install-selection-count">選択 0件</span>
        </div>
        <div class="apk-install-path" title="${esc(options.path || "data/apk")}">${esc(options.path || "data/apk")}</div>
        <div class="app-extract-list apk-install-list">
          ${rows.length ? rows.map((file) => `
            <label class="app-extract-item apk-install-item ${file.kind === "split APK" ? "split" : ""}">
              <input type="checkbox" value="${esc(file.name)}">
              <span>
                <strong>${esc(file.name)}</strong>
                <small>${esc(file.kind || "APK")} / ${esc(formatApkFileSize(file.sizeBytes))}</small>
                ${file.kind === "split APK" ? "<em>本体と追加APKをまとめて導入</em>" : ""}
              </span>
            </label>
          `).join("") : '<div class="apk-install-empty">APKフォルダにAPK/APKM/XAPKがありません。<br>「APKフォルダ」を開いてファイルを入れてください。</div>'}
        </div>
        <div class="adb-drop-actions">
          <button class="section-head-action apk-install-start primary-action" type="button" disabled>選択したAPKをインストール</button>
          <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    const close = (value) => {
      overlay.remove();
      resolve(value);
    };
    const updateSelection = () => {
      const count = overlay.querySelectorAll(".apk-install-item input:checked").length;
      const countNode = overlay.querySelector(".apk-install-selection-count");
      const startButton = overlay.querySelector(".apk-install-start");
      if (countNode) countNode.textContent = `選択 ${count}件`;
      if (startButton) startButton.disabled = count === 0;
    };
    overlay.querySelector(".adb-drop-close")?.addEventListener("click", () => close(null));
    overlay.querySelector(".adb-drop-close-action")?.addEventListener("click", () => close(null));
    overlay.querySelector(".apk-install-select-all")?.addEventListener("click", () => {
      overlay.querySelectorAll(".apk-install-item input").forEach((input) => { input.checked = true; });
      updateSelection();
    });
    overlay.querySelector(".apk-install-clear")?.addEventListener("click", () => {
      overlay.querySelectorAll(".apk-install-item input").forEach((input) => { input.checked = false; });
      updateSelection();
    });
    overlay.querySelector(".apk-install-refresh")?.addEventListener("click", () => close({ reload: true, files: [] }));
    overlay.querySelector(".apk-install-open-folder")?.addEventListener("click", (event) => openApkFolder(event.currentTarget));
    overlay.querySelector(".apk-install-list")?.addEventListener("change", updateSelection);
    overlay.querySelector(".apk-install-start")?.addEventListener("click", () => {
      const selected = [...overlay.querySelectorAll(".apk-install-item input:checked")].map((input) => input.value);
      close({ reload: false, files: selected });
    });
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) close(null);
    });
    updateSelection();
  });
}

function formatApkFileSize(value) {
  const bytes = Number(value || 0);
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  if (bytes >= 1024 ** 3) return `${(bytes / 1024 ** 3).toFixed(1)} GB`;
  if (bytes >= 1024 ** 2) return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
  if (bytes >= 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${bytes} B`;
}

async function extractAppBundleFromSelectedClipboardTarget(button = null) {
  const targets = selectedClipboardTargetsForDeviceAction();
  if (!targets.length) {
    logLine("スマホアプリ吸い出し NG: 吸い出し元スマホを1台チェックしてください");
    return;
  }
  const row = targets[0];
  if (targets.length > 1) {
    logLine(`スマホアプリ吸い出し: 複数選択のため先頭 ${formatXiaoWeiDeviceOptionLabel(row)} を使います`);
  }

  setBusy(true, button);
  let flash = { message: "完了", type: "ok" };
  try {
    logLine(`スマホアプリ一覧 取得中: ${formatXiaoWeiDeviceOptionLabel(row)}`);
    const listResult = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/packages?limit=300&scope=third_party`);
    const packages = prioritizeExtractablePackages(extractPackageNamesFromListResult(listResult, row.serial));
    if (!packages.length) {
      logLine("スマホアプリ吸い出し NG: アプリ一覧が空です");
      flash = { message: "失敗", type: "error" };
      return;
    }
    const pickedPackages = await showAppExtractPickerDialog(packages, row);
    if (!pickedPackages) {
      flash = { message: "中止", type: "warn" };
      return;
    }
    if (!pickedPackages.length) {
      logLine("スマホアプリ吸い出し NG: アプリが選択されていません");
      flash = { message: "失敗", type: "error" };
      return;
    }
    let okCount = 0;
    let ngCount = 0;
    for (const packageName of pickedPackages) {
      const saveName = defaultAppBundleSaveName(packageName);
      try {
        logLine(`スマホアプリ吸い出し 実行中: ${formatXiaoWeiDeviceOptionLabel(row)} / ${packageDisplayName(packageName)} -> ${saveName}.apkm`);
        const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            action: "extract_app_bundle",
            packageName,
            saveName,
            timeout: 240000,
          }),
        });
        const data = result.result || {};
        const splits = Number(data.splitCount || 0);
        const backup = data.backupPath ? " / 旧ファイルはバックアップ済み" : "";
        okCount += 1;
        logLine(`スマホアプリ吸い出し OK: ${packageDisplayName(packageName)} / ${saveName}.apkm / ${splits}分割${backup}`);
      } catch (error) {
        ngCount += 1;
        logLine(`スマホアプリ吸い出し NG: ${packageDisplayName(packageName)} / ${error.message}`);
      }
    }
    if (ngCount) flash = { message: "要確認", type: "warn" };
    window.alert(`スマホアプリ吸い出し 完了\n成功 ${okCount} / 失敗 ${ngCount}\n保存先: data/apk`);
  } catch (error) {
    logLine("スマホアプリ吸い出し NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

function showAppExtractPickerDialog(packages = [], row = {}) {
  return new Promise((resolve) => {
    closeAdbDropDialog();
    const defaults = new Set([
      "com.ss.android.ugc.tiktok.lite",
      "com.zhiliaoapp.musically.go",
      "com.zhiliaoapp.musically",
      "jp.naver.line.android",
    ].filter((packageName) => packages.includes(packageName)));
    const overlay = document.createElement("div");
    overlay.className = "adb-drop-dialog-backdrop";
    overlay.innerHTML = `
      <div class="adb-drop-dialog app-extract-dialog" role="dialog" aria-modal="true" aria-labelledby="appExtractDialogTitle">
        <div class="adb-drop-dialog-head">
          <div>
            <h3 id="appExtractDialogTitle">スマホアプリ吸い出し</h3>
            <p>${esc(formatXiaoWeiDeviceOptionLabel(row))} / ${esc(packages.length)}件</p>
          </div>
          <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
        </div>
        <div class="app-extract-toolbar">
          <button class="section-head-action app-extract-priority" type="button">TTL・TikTok・LINE選択</button>
          <button class="section-head-action app-extract-clear" type="button">解除</button>
        </div>
        <div class="app-extract-list">
          ${packages.slice(0, 300).map((packageName) => {
            const info = appPackageInfo(packageName);
            return `
              <label class="app-extract-item ${defaults.has(packageName) ? "recommended" : ""}">
                <input type="checkbox" value="${esc(packageName)}" ${defaults.has(packageName) ? "checked" : ""}>
                <span>
                  <strong>${esc(info.name)}</strong>
                  <small>${esc(packageName)}</small>
                  ${info.note ? `<em>${esc(info.note)}</em>` : ""}
                </span>
              </label>
            `;
          }).join("")}
        </div>
        <div class="adb-drop-actions">
          <button class="section-head-action app-extract-start primary-action" type="button">選択したアプリを吸い出し</button>
          <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    const close = (value) => {
      overlay.remove();
      resolve(value);
    };
    overlay.querySelector(".adb-drop-close")?.addEventListener("click", () => close(null));
    overlay.querySelector(".adb-drop-close-action")?.addEventListener("click", () => close(null));
    overlay.querySelector(".app-extract-priority")?.addEventListener("click", () => {
      overlay.querySelectorAll(".app-extract-item input").forEach((input) => {
        input.checked = defaults.has(input.value);
      });
    });
    overlay.querySelector(".app-extract-clear")?.addEventListener("click", () => {
      overlay.querySelectorAll(".app-extract-item input").forEach((input) => {
        input.checked = false;
      });
    });
    overlay.querySelector(".app-extract-start")?.addEventListener("click", () => {
      const selected = [...overlay.querySelectorAll(".app-extract-item input:checked")].map((input) => input.value);
      close(selected);
    });
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) close(null);
    });
  });
}

function prioritizeExtractablePackages(packages = []) {
  const seen = new Set();
  const normalized = packages.map((value) => String(value || "").trim()).filter(Boolean);
  const priority = [
    "com.ss.android.ugc.tiktok.lite",
    "com.zhiliaoapp.musically.go",
    "com.zhiliaoapp.musically",
    "jp.naver.line.android",
  ];
  return [...priority, ...normalized.sort((a, b) => a.localeCompare(b, "en"))]
    .filter((packageName) => {
      if (!normalized.includes(packageName) || seen.has(packageName)) return false;
      seen.add(packageName);
      return true;
    });
}

function extractPackageNamesFromListResult(result, serial = "") {
  const body = result?.result || result || {};
  if (Array.isArray(body.packages)) return body.packages;
  const bySerial = body[String(serial)] || body[serial];
  if (Array.isArray(bySerial)) {
    return bySerial.map((item) => item.apk || item.packageName || item.name || "").filter(Boolean);
  }
  const firstArray = Object.values(body).find((value) => Array.isArray(value));
  if (Array.isArray(firstArray)) {
    return firstArray.map((item) => item.apk || item.packageName || item.name || "").filter(Boolean);
  }
  return [];
}

function packageDisplayName(packageName) {
  const info = appPackageInfo(packageName);
  return `${info.name} / ${packageName}`;
}

function appPackageInfo(packageName) {
  const known = {
    "com.ss.android.ugc.tiktok.lite": ["TikTok Lite", "招待検証の本命"],
    "com.zhiliaoapp.musically.go": ["TikTok Lite", "別パッケージ候補"],
    "com.zhiliaoapp.musically": ["TikTok", "TikTok本家"],
    "jp.naver.line.android": ["LINE", "APKから任意導入"],
    "com.android.chrome": ["Chrome", ""],
    "com.google.android.youtube": ["YouTube", ""],
    "com.android.vending": ["Google Play", ""],
    "com.google.android.gms": ["Google Play開発者サービス", ""],
    "com.google.android.gm": ["Gmail", ""],
    "com.google.android.apps.nbu.files": ["Files", ""],
  };
  if (known[packageName]) return { name: known[packageName][0], note: known[packageName][1] };
  const short = String(packageName || "")
    .replace(/^com\./, "")
    .replace(/^jp\./, "")
    .split(".")
    .filter(Boolean)
    .slice(-3)
    .join(" / ");
  return { name: short || packageName, note: "" };
}

function resolvePickedPackageName(input, packages = []) {
  const value = String(input || "").trim();
  const number = Number(value);
  if (Number.isInteger(number) && number >= 1 && number <= packages.length) return packages[number - 1];
  if (/^[A-Za-z0-9_.]+$/.test(value)) return value;
  return "";
}

function defaultAppBundleSaveName(packageName) {
  if (packageName === "com.ss.android.ugc.tiktok.lite") return "tiktok-lite";
  if (packageName === "com.zhiliaoapp.musically.go") return "tiktok-lite-alt";
  if (packageName === "com.zhiliaoapp.musically") return "tiktok";
  if (packageName === "jp.naver.line.android") return "line";
  return packageName.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/\.+/g, ".").slice(0, 80) || "app";
}

async function diagnoseTtlInviteForSelectedClipboardTargets(button = null) {
  const selectedTargets = selectedClipboardTargetsForDeviceAction();
  if (!selectedTargets.length) {
    const message = "TTL招待診断 NG: 対象端末が選択されていません。端末にチェックを入れてください。";
    logLine(message);
    window.alert(message);
    return;
  }
  const targets = selectedTargets.slice(0, 12);
  if (selectedTargets.length > targets.length) {
    logLine(`TTL招待診断: 選択 ${selectedTargets.length}台中、先頭 ${targets.length}台だけ診断します`);
  }
  const input = window.prompt("診断する招待URLを貼ってください。空欄ならテストURLで確認します。", "");
  if (input === null) return;
  const url = String(input || "").trim() || "https://lite.tiktok.com/t/test";
  setBusy(true, button);
  let okCount = 0;
  let warnCount = 0;
  logLine(`TTL招待診断 開始: ${targets.length}台 / ${url}`);
  let cursor = 0;
  const concurrency = Math.min(4, targets.length);
  async function worker() {
    while (cursor < targets.length) {
      const row = targets[cursor++];
      logLine(`TTL招待診断 実行中: ${formatXiaoWeiDeviceOptionLabel(row)}`);
      await diagnoseOneTtlInviteTarget(row, url).then((ok) => {
        if (ok) okCount += 1;
        else warnCount += 1;
      });
    }
  }
  try {
    await Promise.all(Array.from({ length: concurrency }, () => worker()));
    logLine(`TTL招待診断 完了: OK ${okCount} / 要確認 ${warnCount}`);
    window.alert(`TTL招待診断 完了\nOK ${okCount} / 要確認 ${warnCount}\n詳細はログを見てください。`);
    flashButtonResult(button, warnCount ? "要確認" : "OK", warnCount ? "warn" : "ok");
  } finally {
    setBusy(false);
  }
}

async function diagnoseOneTtlInviteTarget(row, url) {
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "ttl_invite_diagnostics",
        url,
        timeout: 8000,
      }),
    });
    const diagnosis = result.result?.diagnosis || "診断結果なし";
    const installedCount = result.result?.installedCount ?? "-";
    const matches = Array.isArray(result.result?.installedMatches) ? result.result.installedMatches.join(",") : "";
    if (result.result?.ok) {
      logLine(`TTL招待診断 OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${diagnosis}${matches ? " / " + matches : ""}`);
      return true;
    }
    const duplicate = result.result?.duplicateInstalled ? " / TTL複数" : "";
    logLine(`TTL招待診断 要確認: ${formatXiaoWeiDeviceOptionLabel(row)} / TTL ${installedCount}個${duplicate} / ${diagnosis}`);
    return false;
  } catch (error) {
    logLine(`TTL招待診断 NG: ${formatXiaoWeiDeviceOptionLabel(row)} / ${error.message}`);
    return false;
  }
}

async function cleanupTtlInviteForSelectedClipboardTargets(button = null) {
  const selectedTargets = selectedClipboardTargetsForDeviceAction();
  if (!selectedTargets.length) {
    const message = "TTL整理 NG: 対象端末が選択されていません。端末にチェックを入れてください。";
    logLine(message);
    window.alert(message);
    return;
  }
  const targets = selectedTargets.slice(0, 12);
  if (selectedTargets.length > targets.length) {
    logLine(`TTL整理: 選択 ${selectedTargets.length}台中、先頭 ${targets.length}台だけ整理します`);
  }
  const input = window.prompt("整理判定に使う招待URLを貼ってください。空欄ならテストURLで確認します。", "");
  if (input === null) return;
  const url = String(input || "").trim() || "https://lite.tiktok.com/t/test";
  setBusy(true, button);
  const plans = [];
  try {
    logLine(`TTL整理 診断開始: ${targets.length}台 / ${url}`);
    for (const row of targets) {
      try {
        const dryRun = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            action: "ttl_invite_cleanup",
            url,
            execute: false,
            timeout: 12000,
          }),
        });
        const plan = dryRun.result?.plan || {};
        plans.push({ row, plan, dryRun });
        const remove = Array.isArray(plan.removePackageNames) ? plan.removePackageNames.join(",") : "";
        logLine(`TTL整理 予定: ${formatXiaoWeiDeviceOptionLabel(row)} / 残す ${plan.keepPackageName || "-"}${remove ? " / 消す " + remove : " / 整理不要"}`);
      } catch (error) {
        plans.push({ row, error });
        logLine(`TTL整理 診断NG: ${formatXiaoWeiDeviceOptionLabel(row)} / ${error.message}`);
      }
    }
    const executable = plans.filter((item) => item.plan?.needsCleanup && item.plan?.keepPackageName);
    if (!executable.length) {
      logLine("TTL整理 完了: 整理が必要な端末はありません");
      window.alert("TTL整理: 整理が必要な端末はありません。");
      flashButtonResult(button, "整理不要", "ok");
      return;
    }
    const confirmLines = executable.map((item) => {
      const remove = item.plan.removePackageNames.join(", ");
      return `${formatXiaoWeiDeviceOptionLabel(item.row)}\n残す: ${item.plan.keepPackageName}\n消す: ${remove}`;
    });
    const ok = window.confirm(`APK側TTLを残して、重複TTLを削除します。\n\n${confirmLines.join("\n\n")}\n\n実行しますか？`);
    if (!ok) {
      logLine("TTL整理 キャンセル");
      return;
    }
    let okCount = 0;
    let ngCount = 0;
    for (const item of executable) {
      try {
        const result = await fetchJson(`/api/devices/${encodeURIComponent(item.row.serial)}/actions`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            action: "ttl_invite_cleanup",
            url,
            execute: true,
            timeout: 30000,
          }),
        });
        if (result.result?.ok) {
          okCount += 1;
          logLine(`TTL整理 OK: ${formatXiaoWeiDeviceOptionLabel(item.row)} / ${result.result.message || ""}`);
        } else {
          ngCount += 1;
          logLine(`TTL整理 要確認: ${formatXiaoWeiDeviceOptionLabel(item.row)} / ${result.result?.message || "未確認"}`);
        }
      } catch (error) {
        ngCount += 1;
        logLine(`TTL整理 NG: ${formatXiaoWeiDeviceOptionLabel(item.row)} / ${error.message}`);
      }
    }
    logLine(`TTL整理 完了: OK ${okCount} / 要確認 ${ngCount}`);
    window.alert(`TTL整理 完了\nOK ${okCount} / 要確認 ${ngCount}\n続けてTTL招待診断を実行してください。`);
    flashButtonResult(button, ngCount ? "要確認" : "OK", ngCount ? "warn" : "ok");
  } finally {
    setBusy(false);
  }
}

async function openApnSettingsForSelectedDevice(button = null) {
  const row = selectedClipboardDevice();
  if (!row || !row.serial) return logLine("APN設定: 対象端末を選んでください");
  setBusy(true, button);
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "open_apn_settings", timeout: 12000 }),
    });
    const foreground = result.result?.foreground?.component || result.result?.foreground?.packageName || "";
    logLine(`APN設定 OK: ${formatXiaoWeiDeviceOptionLabel(row)}${foreground ? " / " + foreground : ""}`);
  } catch (error) {
    logLine("APN設定 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function handleApnPaletteAction(event) {
  const button = event.target.closest(".apn-paste-btn");
  if (!button) return;
  const preset = APN_PRESETS[Number(button.dataset.apnIndex)];
  const fieldKey = button.dataset.apnField || "";
  const value = preset?.fields?.[fieldKey];
  if (!preset || !String(value || "").trim()) return;
  await pasteApnValueToSelectedDevice(preset, fieldKey, value, button);
}

async function pasteApnValueToSelectedDevice(preset, fieldKey, value, button = null) {
  const row = selectedClipboardDevice();
  if (!row || !row.serial) return logLine("APN貼付: 対象端末を選んでください");
  setBusy(true, button);
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "input_text", text: String(value), clearFirst: true, timeout: 15000 }),
    });
    const label = APN_FIELD_LABELS[fieldKey] || fieldKey;
    logLine(`APN貼付 OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${preset.carrier} / ${label} / ${result.result?.length || String(value).length}文字`);
  } catch (error) {
    logLine("APN貼付 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function deleteClipboardItem(id, button = null) {
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/clipboard-items/delete", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id }),
    });
    state.clipboardItems = result.items || [];
    renderClipboardItems();
    logLine("保管リスト削除 OK");
  } catch (error) {
    logLine("保管リスト削除 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function clearClipboardForm() {
  state.clipboardEditingId = "";
  setClipboardTitleValue("QR招待");
  el("clipboardTextInput").value = "";
  el("clipboardNoteInput").value = "";
}

function inferClipboardTitleClient(text) {
  const value = String(text || "").trim();
  try {
    return new URL(value).hostname;
  } catch {
    return value.replace(/\s+/g, " ").slice(0, 40) || "クリップ";
  }
}

async function refreshScriptScreenshot() {
  const serial = el("scriptDeviceSelect").value;
  if (!serial) return logLine("JSビルダー: 対象端末を選んでください");
  if (state.scriptBuilder.refreshing) return;
  state.scriptBuilder.refreshing = true;
  const button = el("scriptRefreshShotBtn");
  button.disabled = true;
  el("scriptPreviewMeta").textContent = "取得中...";
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "screenshot" }),
    });
    if (!result.screenshotUrl) throw new Error("スクショURLが返りませんでした");
    const url = result.screenshotUrl + "?ts=" + Date.now();
    state.scriptBuilder.latestScreenshotUrl = url;
    setScriptPreviewImage(url);
    logLine("JSビルダー スクショ更新 OK");
  } catch (error) {
    el("scriptPreviewMeta").textContent = "取得NG";
    logLine("JSビルダー スクショ更新 NG: " + error.message);
  } finally {
    state.scriptBuilder.refreshing = false;
    button.disabled = state.busy;
  }
}

async function copySelectedDeviceScreenText() {
  const serial = el("scriptDeviceSelect").value;
  if (!serial) return logLine("画面テキストコピー: 対象端末を選んでください");
  setBusy(true, el("scriptCopyScreenTextBtn"));
  logLine("画面テキストコピー 実行中...");
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "screen_text", timeout: 15000 }),
    });
    const text = result.result?.text || "";
    const count = Number(result.result?.count || 0);
    if (!text.trim()) {
      logLine("画面テキストコピー: 取得できるUIテキストがありません");
      return;
    }
    await writeClipboardText(text);
    logLine(`画面テキストコピー OK: ${count}行`);
  } catch (error) {
    logLine("画面テキストコピー NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function copySelectedDeviceClipboardText() {
  const serial = el("scriptDeviceSelect").value;
  if (!serial) return logLine("端末クリップコピー: 対象端末を選んでください");
  setBusy(true, el("scriptCopyDeviceClipboardBtn"));
  logLine("端末クリップコピー 実行中...");
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "clipboard_text", timeout: 15000 }),
    });
    const payload = result.result || {};
    const text = payload.text || "";
    if (!text.trim()) {
      const detail = [
        payload.message || "",
        payload.nativeError ? `ADB=${payload.nativeError}` : "",
        payload.laixiError ? `XiaoWei=${payload.laixiError}` : "",
      ].filter(Boolean).join(" / ");
      logLine("端末クリップコピー: 取得できるクリップボード文字がありません" + (detail ? ` / ${detail}` : ""));
      return;
    }
    await writeClipboardText(text);
    logLine(`端末クリップコピー OK: ${text.length}文字 / ${payload.method || "unknown"}`);
  } catch (error) {
    logLine("端末クリップコピー NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function runAdbChromeTest() {
  const serial = el("scriptDeviceSelect").value;
  if (!serial) return logLine("ADB Chrome確認: 対象端末を選んでください");
  setBusy(true);
  logLine("ADB Chrome確認 実行中...");
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "launch_url",
        packageName: "com.android.chrome",
        url: "https://www.google.com/",
      }),
    });
    const foreground = result.result?.foreground?.packageName || "unknown";
    const activity = result.result?.foreground?.activity || "";
    const firstRun = /FirstRunActivity/i.test(activity) ? " / Chrome初回画面" : "";
    logLine("ADB Chrome確認 OK: " + (result.result?.packageName || "com.android.chrome") + " / foreground=" + foreground + (activity ? " / activity=" + activity : "") + firstRun);
    await new Promise((resolve) => setTimeout(resolve, 1200));
    await refreshScriptScreenshot();
  } catch (error) {
    logLine("ADB Chrome確認 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function runXiaoweiGeneratedScript() {
  const serial = el("scriptDeviceSelect").value;
  if (!serial) return logLine("XiaoWei実行: 対象端末を選んでください");
  renderScriptBuilder();
  const script = el("scriptOutput").value.trim();
  if (!script) return logLine("XiaoWei実行: 生成JSが空です");
  logScriptCompatibility(script);

  setBusy(true);
  logLine("XiaoWei実行: ログ基準保存...");
  try {
    const baseline = await fetchJson("/api/xiaowei/log-tail?limit=1");
    state.scriptBuilder.logBaseline = {
      file: baseline.file || "",
      lineCount: Number(baseline.lineCount || 0),
      sizeBytes: Number(baseline.sizeBytes || 0),
      markedAt: new Date().toISOString(),
    };

    logLine("XiaoWei実行: 送信中...");
    const result = await fetchJson(`/api/devices/${encodeURIComponent(serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "xiaowei_js",
        script,
      }),
    });
    const foreground = result.result?.foreground?.packageName || "unknown";
    const activity = result.result?.foreground?.activity || "";
    const bytes = result.result?.scriptBytes || script.length;
    logLine(`XiaoWei実行 OK: ${bytes} bytes / foreground=${foreground}${activity ? " / activity=" + activity : ""}`);
    await new Promise((resolve) => setTimeout(resolve, 1200));
    await checkXiaoweiLogDelta();
    await refreshScriptScreenshot();
  } catch (error) {
    logLine("XiaoWei実行 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function checkXiaoweiScriptFolder() {
  setBusy(true);
  logLine("XiaoWei scriptフォルダ確認 実行中...");
  try {
    const result = await fetchJson("/api/xiaowei/scripts");
    const files = (result.files || []).slice(0, 5).map((file) => file.name).join(", ") || "なし";
    const expected = (result.expectedTestScripts || [])
      .map((file) => `${file.name}:${file.present ? "OK" : "不足"}`)
      .join(", ") || "未確認";
    const writable = result.writable ? "書込OK" : "書込NG";
    const extra = result.writeError ? " / " + result.writeError : "";
    logLine(`XiaoWei scriptフォルダ: ${result.exists ? "存在OK" : "未検出"} / ${writable} / テスト=${expected} / JS=${files}${extra}`);
    if (result.exists && !result.writable) {
      logLine("XiaoWei scriptフォルダ: 書込NGのためXiaoWeiのscriptフォルダへ手動配置してください");
    }
  } catch (error) {
    logLine("XiaoWei scriptフォルダ確認 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function installXiaoweiTestScripts() {
  setBusy(true);
  logLine("XiaoWei テストJS配置 実行中...");
  try {
    const result = await fetchJson("/api/xiaowei/scripts/install-tests", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    const copied = (result.copied || []).join(", ") || "なし";
    const failed = (result.failed || []).map((item) => `${item.name}: ${item.error}`).join(" / ");
    const expected = (result.scripts?.expectedTestScripts || [])
      .map((file) => `${file.name}:${file.present ? "OK" : "不足"}`)
      .join(", ") || "未確認";
    logLine(`XiaoWei テストJS配置 ${result.ok ? "OK" : "NG"}: copied=${copied} / テスト=${expected}${failed ? " / " + failed : ""}`);
  } catch (error) {
    logLine("XiaoWei テストJS配置 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function copyAdminInstallCommand() {
  const command = `explorer.exe "C:\\Program Files (x86)\\xiaowei_android\\script"`;
  try {
    await navigator.clipboard.writeText(command);
    logLine("管理者コマンドコピー OK");
  } catch (error) {
    el("scriptOutput").value = command;
    el("scriptOutput").select();
    logLine("管理者コマンドコピー NG: 生成JS欄に出しました");
  }
}

async function checkXiaoweiLogTail() {
  setBusy(true);
  logLine("XiaoWeiログ確認 実行中...");
  try {
    const result = await fetchJson("/api/xiaowei/log-tail?limit=80");
    const keywords = /(script|js|toast|chrome|error|エラー|失敗|launch|autox|app_process)/i;
    const lines = (result.lines || []).filter((line) => keywords.test(line)).slice(-6);
    const summary = lines.length ? lines.join(" | ") : "";
    logLine(`XiaoWeiログ: ${result.file || "なし"} / lines=${result.lineCount || 0} / ${summary}`);
  } catch (error) {
    logLine("XiaoWeiログ確認 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function markXiaoweiLogBaseline() {
  setBusy(true);
  logLine("XiaoWeiログ基準保存 実行中...");
  try {
    const result = await fetchJson("/api/xiaowei/log-tail?limit=1");
    state.scriptBuilder.logBaseline = {
      file: result.file || "",
      lineCount: Number(result.lineCount || 0),
      sizeBytes: Number(result.sizeBytes || 0),
      markedAt: new Date().toISOString(),
    };
    logLine(`XiaoWeiログ基準保存 OK: ${state.scriptBuilder.logBaseline.file} / lines=${state.scriptBuilder.logBaseline.lineCount}`);
  } catch (error) {
    logLine("XiaoWeiログ基準保存 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function checkXiaoweiLogDelta() {
  const baseline = state.scriptBuilder.logBaseline;
  if (!baseline) return logLine("XiaoWeiログ差分確認: 先にログ基準保存を押してください");
  setBusy(true);
  logLine("XiaoWeiログ差分確認 実行中...");
  try {
    const result = await fetchJson("/api/xiaowei/log-tail?limit=500");
    if ((result.file || "") !== baseline.file) {
      logLine(`XiaoWeiログ差分: ログファイル変更 ${baseline.file} -> ${result.file || "なし"}`);
    }
    const allTail = result.lines || [];
    const addedCount = Math.max(0, Number(result.lineCount || 0) - Number(baseline.lineCount || 0));
    const addedLines = addedCount > 0 ? allTail.slice(-Math.min(addedCount, allTail.length)) : [];
    const keywords = /(script|js|toast|chrome|error|エラー|失敗|launch|autox|app_process|open api)/i;
    const relevant = addedLines.filter((line) => keywords.test(line)).slice(-8);
    const summary = relevant.length ? relevant.join(" | ") : (addedLines.length ? addedLines.slice(-3).join(" | ") : "");
    logLine(`XiaoWeiログ差分: +${addedCount}行 / ${summary}`);
  } catch (error) {
    logLine("XiaoWeiログ差分確認 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function setScriptPreviewImage(url) {
  const stage = el("scriptPreviewStage");
  const image = el("scriptPreviewImage");
  const marker = el("scriptTapMarker");
  image.onload = () => {
    stage.classList.add("has-image");
    marker.classList.add("hidden");
    el("scriptPreviewMeta").textContent = `${image.naturalWidth} x ${image.naturalHeight} / ${new Date().toLocaleTimeString("ja-JP")}`;
  };
  image.src = url;
}

function toggleScriptAutoRefresh() {
  if (state.scriptBuilder.autoRefreshTimer) {
    clearInterval(state.scriptBuilder.autoRefreshTimer);
    state.scriptBuilder.autoRefreshTimer = 0;
  }
  if (el("scriptAutoRefreshInput").checked) {
    refreshScriptScreenshot();
    state.scriptBuilder.autoRefreshTimer = setInterval(refreshScriptScreenshot, 3000);
    logLine("JSビルダー: 3秒スクショ更新 ON");
  } else {
    logLine("JSビルダー: 3秒スクショ更新 OFF");
  }
}

function addTapStepFromPreview(event) {
  const image = el("scriptPreviewImage");
  if (!image.naturalWidth || !image.naturalHeight) return;
  const rect = image.getBoundingClientRect();
  const rx = clamp((event.clientX - rect.left) / rect.width, 0, 1);
  const ry = clamp((event.clientY - rect.top) / rect.height, 0, 1);
  const marker = el("scriptTapMarker");
  marker.style.left = `${event.clientX - el("scriptPreviewStage").getBoundingClientRect().left}px`;
  marker.style.top = `${event.clientY - el("scriptPreviewStage").getBoundingClientRect().top}px`;
  marker.classList.remove("hidden");
  addScriptStep({
    type: "tap",
    rx: round(rx, 4),
    ry: round(ry, 4),
    waitMs: scriptWaitMs(),
  });
}

function scriptWaitMs() {
  const waitMs = Number(el("scriptWaitInput").value || 0);
  return Number.isFinite(waitMs) && waitMs >= 0 ? Math.round(waitMs) : 0;
}

function scriptRepeatCount() {
  const repeat = Number(el("scriptRepeatInput").value || 1);
  return Number.isFinite(repeat) && repeat > 0 ? Math.round(repeat) : 1;
}

function addScriptStep(step) {
  state.scriptBuilder.steps.push(step);
  renderScriptBuilder();
}

function setMinimalToastPreset() {
  state.scriptBuilder.steps = [
    { type: "minimal_toast", label: "xiaowei minimal toast", waitMs: 0 },
  ];
  renderScriptBuilder();
  logLine("");
}

function setDebugScriptPreset() {
  state.scriptBuilder.steps = [
    { type: "debug", label: "visible log 1", waitMs: 1000 },
    { type: "debug", label: "visible log 2", waitMs: 1000 },
    { type: "debug", label: "visible log 3", waitMs: 1000 },
  ];
  renderScriptBuilder();
  logLine("JSビルダー: ログテストを生成");
}

function setChromeScriptPreset() {
  const chrome = SCRIPT_PACKAGE_OPTIONS.find((option) => option.packageName === "com.android.chrome") || SCRIPT_PACKAGE_OPTIONS[0];
  state.scriptBuilder.steps = [
    {
      type: "launch",
      packageName: chrome.packageName,
      appName: chrome.appName,
      launchUrl: chrome.launchUrl || "",
      waitMs: 3000,
    },
    {
      type: "chrome_search_focus",
      waitMs: 500,
    },
  ];
  renderScriptBuilder();
  logLine("");
}

function clearScriptSteps() {
  const ok = window.confirm("JSビルダーのステップをクリアします。よろしいですか？");
  if (!ok) return;
  state.scriptBuilder.steps = [];
  renderScriptBuilder();
  logLine("JSビルダー: ステップをクリア");
}

function renderScriptBuilder() {
  const list = el("scriptStepList");
  const output = el("scriptOutput");
  if (!list || !output) return;
  list.innerHTML = state.scriptBuilder.steps.map((step, index) =>
    `<li><span>${esc(scriptStepLabel(step))}</span><button class="script-step-delete" data-step-index="${esc(index)}" type="button" title="この行を削除">削除</button></li>`
  ).join("");
  output.value = buildAutoxScript(state.scriptBuilder.steps, scriptRepeatCount());
}

function handleScriptStepListClick(event) {
  const button = event.target.closest(".script-step-delete");
  if (!button) return;
  const index = Number(button.dataset.stepIndex);
  if (!Number.isInteger(index) || index < 0 || index >= state.scriptBuilder.steps.length) return;
  const [removed] = state.scriptBuilder.steps.splice(index, 1);
  renderScriptBuilder();
  logLine("JSビルダー 行削除: " + scriptStepLabel(removed));
}

function scriptStepLabel(step) {
  if (step.type === "launch") {
    const appName = step.appName ? ` (${step.appName})` : "";
    return `起動 ${step.packageName}${appName} / wait ${step.waitMs}ms`;
  }
  if (step.type === "minimal_toast") return `最小toast ${step.label || ""}`;
  if (step.type === "debug") return `ログ ${step.label || "test"} / wait ${step.waitMs}ms`;
  if (step.type === "chrome_search_focus") return `Chrome検索欄フォーカス / wait ${step.waitMs}ms`;
  if (step.type === "tap") return `tap x=${step.rx} y=${step.ry} / wait ${step.waitMs}ms`;
  if (step.type === "wait") return `wait ${step.waitMs}ms`;
  if (step.type === "text") return `入力 ${step.text} / wait ${step.waitMs}ms`;
  if (step.type === "back") return `戻る / wait ${step.waitMs}ms`;
  if (step.type === "home") return `HOME / wait ${step.waitMs}ms`;
  return step.type || "step";
}

function buildAutoxScript(steps, repeat) {
  if (steps.length === 1 && steps[0].type === "minimal_toast") {
    return `"auto";\ntoast(${JSON.stringify(steps[0].label || "xiaowei minimal toast")});`;
  }

  const lines = [
    "\"auto\";",
    "// Generated by Android Fleet JS Builder",
    "// XiaoWei/AutoJS script test. Test on one device first.",
    "",
    "try {",
    "  if (typeof console !== \"undefined\" && typeof console.hide === \"function\") console.hide();",
    "} catch (error) {}",
    "",
    "function say(message) {",
    "  try {",
    "    if (typeof toast === \"function\") toast(message);",
    "  } catch (error) {}",
    "}",
    "",
    "say(\"script start\");",
    "",
    "function tapRatio(rx, ry) {",
    "  click(Math.round(device.width * rx), Math.round(device.height * ry));",
    "}",
    "",
    "function findOneSafe(selector, timeoutMs) {",
    "  try {",
    "    if (selector && typeof selector.findOne === \"function\") return selector.findOne(timeoutMs || 1000);",
    "  } catch (error) {}",
    "  return null;",
    "}",
    "",
    "function clickNodeSafe(node) {",
    "  if (!node) return false;",
    "  try {",
    "    if (typeof node.click === \"function\" && node.click()) return true;",
    "  } catch (error) {}",
    "  try {",
    "    var b = node.bounds();",
    "    if (b) {",
    "      click(b.centerX(), b.centerY());",
    "      return true;",
    "    }",
    "  } catch (error) {}",
    "  return false;",
    "}",
    "",
    "function focusChromeSearchBox() {",
    "  var target = null;",
    "  try { if (!target && typeof id === \"function\") target = findOneSafe(id(\"search_box_text\"), 1200); } catch (error) {}",
    "  try { if (!target && typeof id === \"function\") target = findOneSafe(id(\"url_bar\"), 1200); } catch (error) {}",
    "  try { if (!target && typeof id === \"function\") target = findOneSafe(id(\"com.android.chrome:id/search_box_text\"), 1200); } catch (error) {}",
    "  try { if (!target && typeof id === \"function\") target = findOneSafe(id(\"com.android.chrome:id/url_bar\"), 1200); } catch (error) {}",
    "  try { if (!target && typeof descMatches === \"function\") target = findOneSafe(descMatches(/検索|Search|URL|アドレス|address/i), 1200); } catch (error) {}",
    "  try { if (!target && typeof textMatches === \"function\") target = findOneSafe(textMatches(/検索|Search|URL|アドレス|address|google/i), 1200); } catch (error) {}",
    "  if (clickNodeSafe(target)) {",
    "    say(\"chrome search focus ok\");",
    "    return true;",
    "  }",
    "  tapRatio(0.24, 0.35);",
    "  say(\"chrome search focus fallback\");",
    "  return false;",
    "}",
    "",
    "function openPackage(packageName, appName, launchUrl) {",
    "  var ok = false;",
    "  try {",
    "    if (launchUrl && typeof app !== \"undefined\" && typeof app.startActivity === \"function\") {",
    "      say(\"try app.startActivity: \" + launchUrl);",
    "      app.startActivity({",
    "        action: \"VIEW\",",
    "        data: launchUrl",
    "      });",
    "      ok = true;",
    "    }",
    "  } catch (error) {",
    "    say(\"startActivity failed\");",
    "  }",
    "  try {",
    "    if (!ok) say(\"try launchPackage: \" + packageName);",
    "    if (typeof launchPackage === \"function\") ok = launchPackage(packageName);",
    "  } catch (error) {}",
    "  try {",
    "    if (!ok) say(\"try app.launchPackage: \" + packageName);",
    "    if (!ok && typeof app !== \"undefined\" && typeof app.launchPackage === \"function\") ok = app.launchPackage(packageName);",
    "  } catch (error) {}",
    "  try {",
    "    if (!ok && appName && typeof launchApp === \"function\") {",
    "      say(\"try launchApp: \" + appName);",
    "      ok = launchApp(appName);",
    "    }",
    "  } catch (error) {}",
    "  say(ok ? \"launch ok\" : \"launch failed: \" + packageName);",
    "  return ok;",
    "}",
    "",
    `for (var run = 0; run < ${Math.max(1, repeat)}; run++) {`,
  ];
  for (const step of steps) {
    if (step.type === "launch") {
      lines.push(`  openPackage(${JSON.stringify(step.packageName || "com.android.chrome")}, ${JSON.stringify(step.appName || "")}, ${JSON.stringify(step.launchUrl || "")});`);
      appendSleep(lines, step.waitMs);
    } else if (step.type === "debug") {
      lines.push(`  say(${JSON.stringify(step.label || "visible log test")});`);
      appendSleep(lines, step.waitMs);
    } else if (step.type === "tap") {
      lines.push(`  tapRatio(${Number(step.rx).toFixed(4)}, ${Number(step.ry).toFixed(4)});`);
      appendSleep(lines, step.waitMs);
    } else if (step.type === "chrome_search_focus") {
      lines.push("  focusChromeSearchBox();");
      appendSleep(lines, step.waitMs);
    } else if (step.type === "wait") {
      appendSleep(lines, step.waitMs);
    } else if (step.type === "text") {
      lines.push(`  setText(${JSON.stringify(step.text || "")});`);
      appendSleep(lines, step.waitMs);
    } else if (step.type === "back") {
      lines.push("  back();");
      appendSleep(lines, step.waitMs);
    } else if (step.type === "home") {
      lines.push("  home();");
      appendSleep(lines, step.waitMs);
    }
  }
  lines.push("}");
  lines.push("");
  lines.push("say(\"script done\");");
  return lines.join("\n");
}

function appendSleep(lines, waitMs) {
  const value = Number(waitMs || 0);
  if (value > 0) lines.push(`  sleep(${Math.round(value)});`);
}

async function copyScriptOutput() {
  const text = el("scriptOutput").value;
  logScriptCompatibility(text);
  await writeClipboardText(text, "JSビルダー コピー");
}

async function writeClipboardText(text, label = "コピー") {
  let browserCopied = false;
  try {
    await navigator.clipboard.writeText(text);
    browserCopied = true;
  } catch (error) {
    browserCopied = false;
  }

  if (browserCopied) {
    logLine(`${label} OK`);
    return;
  }

  try {
    const result = await fetchJson("/api/pc/clipboard", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ text }),
    });
    logLine(`${label} OK: PCクリップボード ${result.length || String(text || "").length}文字`);
    return;
  } catch (error) {
    el("scriptOutput").value = text;
    el("scriptOutput").select();
    const copied = document.execCommand("copy");
    logLine(`${label} ${copied ? "OK" : "NG"}: ブラウザ/PCクリップボード不可${error.message ? " / " + error.message : ""}`);
  }
}

function downloadScriptOutput() {
  const text = el("scriptOutput").value;
  logScriptCompatibility(text);
  const blob = new Blob([text], { type: "text/javascript;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `autox-script-${localTimestampForFile()}.js`;
  link.click();
  URL.revokeObjectURL(url);
  logLine("JSビルダー JS保存 OK");
}

function logScriptCompatibility(text) {
  const issues = [];
  if (/\blet\b/.test(text)) issues.push("let");
  if (/\bconst\b/.test(text)) issues.push("const");
  if (/=>/.test(text)) issues.push("=>");
  if (issues.length) {
    logLine("JSビルダー 互換注意: XiaoWei/AutoJS環境によって落ちる可能性 " + issues.join(", "));
  } else {
    logLine("");
  }
}

async function exportBranchReport() {
  setBusy(true);
  try {
    const summary = state.summary || await fetchJson("/api/fleet-db/summary");
    const siteName = summary.settings?.siteName || "Android Fleet";
    const payload = {
      kind: "android-fleet-branch-report",
      version: 1,
      siteName,
      exportedAt: new Date().toISOString(),
      withdrawals: summary.withdrawals || [],
    };
    const text = JSON.stringify(payload, null, 2);
    const fileName = `android-fleet-report_${siteName}_${localDateInputValue()}_${localTimestampForFile()}.json`.replace(/[\\/:*?"<>|]/g, "_");
    await saveTextFile(fileName, text, "支店日報JSON");
  } catch (error) {
    if (error && error.name === "AbortError") logLine("支店日報出力 キャンセル");
    else logLine("支店日報出力 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function importBranchReportFile() {
  const file = el("branchReportFileInput").files[0];
  el("branchReportFileInput").value = "";
  if (!file) return;
  setBusy(true);
    logLine("日報取込 プレビュー中...");
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    const preview = await fetchJson("/api/fleet-db/preview-branch-report", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(data),
    });
    const message = [
      "日報取込プレビュー",
      "",
      `拠点: ${preview.siteName || data.siteName || "支店"}`,
      `総件数: ${preview.total || 0}件`,
      `追加予定: ${preview.importable || 0}件`,
      `重複スキップ: ${preview.duplicate || 0}件`,
      `要確認: ${preview.invalid || 0}件`,
      "",
      "この内容で取り込みますか？",
    ].join("\n");
    logLine(`日報取込 プレビュー: 追加 ${preview.importable || 0}件 / 重複 ${preview.duplicate || 0}件 / 要確認 ${preview.invalid || 0}件`);
    if (!window.confirm(message)) {
      logLine("日報取込 キャンセル");
      return;
    }
    logLine("日報取込 実行中...");
    const result = await fetchJson("/api/fleet-db/import-branch-report", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(data),
    });
    logLine(`日報取込 OK: 追加 ${result.imported}件 / スキップ ${result.skipped}件`);
    await loadSummary();
  } catch (error) {
    logLine("日報取込 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function saveTextFile(fileName, text, description) {
  if (window.showSaveFilePicker) {
    const handle = await window.showSaveFilePicker({
      suggestedName: fileName,
      types: [{
        description,
        accept: { "application/json": [".json"] },
      }],
    });
    const writable = await handle.createWritable();
    await writable.write(text);
    await writable.close();
    logLine("日報出力 OK: " + handle.name);
    return;
  }
  const blob = new Blob([text], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  link.click();
  URL.revokeObjectURL(url);
  logLine("");
}

async function fetchJson(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok || data.ok === false) {
    const portText = Array.isArray(data.triedAdbPorts)
      ? " / tried: " + data.triedAdbPorts.map((item) => item.adbPort || "default").join(", ")
      : "";
    throw new Error(data.error || data.message || data.result?.stderr || data.result?.stdout || data.code || response.statusText + portText);
  }
  return data;
}

async function fetchJsonResult(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok && !data.results && !data.packageSummary) {
    const portText = Array.isArray(data.triedAdbPorts)
      ? " / tried: " + data.triedAdbPorts.map((item) => item.adbPort || "default").join(", ")
      : "";
    throw new Error(data.error || data.message || data.result?.stderr || data.result?.stdout || data.code || response.statusText + portText);
  }
  return data;
}

function renderAll(data) {
  renderSiteName(data.settings?.siteName || "Android Fleet");
  renderGlobalErrorRate(data.errorStats);
  renderDeviceDbFleetCounts(data.devices || []);
  const license = data.license || {};
  const customerText = license.customerId
    ? `購入ID ${license.customerId}${license.packageId ? ` / ${license.packageId}` : ""}`
    : "";
  el("appMeta").textContent = [
    `登録端末 ${data.counts.devices}台`,
    Number(data.counts.offlineDevices || 0) ? `未接続 ${Number(data.counts.offlineDevices)}台` : "",
    `出金 ${data.counts.withdrawals}件`,
    customerText,
    formatDateTime(data.generatedAt),
  ].filter(Boolean).join(" / ");
  el("retiredDevicesBtn").textContent = Number(data.counts?.retired || 0)
    ? `管理対象外 (${Number(data.counts.retired)})`
    : "管理対象外";
  renderWithdrawalForm([...(data.devices || []), ...(data.offlineDevices || [])]);
  renderDevices(data.devices || []);
  renderOfflineDeviceDb(data.offlineDevices || []);
  renderWithdrawals(data.withdrawals || []);
  renderDeviceRevenue(data.deviceRevenue || []);
  renderMonthlyRevenue(data.monthlyRevenue || [], data.monthlyRevenueBySite || [], data.siteRevenue || []);
  renderScriptBuilderDevices(data.devices || []);
  renderClipboardDevices(data.devices || []);
  renderClipboardItems();
  renderRewardCalculator();
  renderDeviceMaster(state.deviceMaster);
}

function renderDeviceDbFleetCounts(rows = []) {
  const devices = Array.isArray(rows) ? rows : [];
  const active = devices.filter((row) => deviceOrderBand(row) === "active").length;
  el("deviceDbActiveCount").textContent = `稼働 ${active}台`;
  el("deviceDbInactiveCount").textContent = `非稼働 ${devices.length - active}台`;
}

function offlineDeviceById(offlineId) {
  return (state.summary?.offlineDevices || []).find((row) => row.offlineId === offlineId) || null;
}

function offlineCurrentDay(row, now = new Date()) {
  const start = String(row?.operationStartedOn || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(start)) return 0;
  const parse = (value) => {
    const [year, month, day] = value.split("-").map(Number);
    return Date.UTC(year, month - 1, day);
  };
  const elapsed = Math.max(0, Math.floor((parse(localDateInputValue(now)) - parse(start)) / 86400000));
  return Math.min(14, Math.max(1, Number(row.initialDay || 1) + elapsed));
}

function offlineCurrentUptimeMinutes(row, nowMs = Date.now()) {
  let minutes = Number(row?.uptimeBaseMinutes || 0);
  const recordedAt = Date.parse(row?.uptimeRecordedAt || "");
  if (row?.uptimeRunning && row?.status === "active" && Number.isFinite(recordedAt)) {
    minutes += Math.max(0, Math.floor((nowMs - recordedAt) / 60000));
  }
  return Math.max(0, Math.round(minutes));
}

function offlineRestTiming(row, nowMs = Date.now()) {
  if (row?.status !== "resting" || !row?.restStartedAt) return { state: "none", remainingMinutes: 0, endsAt: "" };
  const startedAt = Date.parse(row.restStartedAt);
  const endsAtMs = startedAt + Number(row.restHours || 24) * 3600000;
  const remainingMinutes = Math.max(0, Math.ceil((endsAtMs - nowMs) / 60000));
  return {
    state: remainingMinutes > 0 ? "resting" : "ready",
    remainingMinutes,
    endsAt: Number.isFinite(endsAtMs) ? new Date(endsAtMs).toISOString() : "",
  };
}

function offlineStatusInfo(row, nowMs = Date.now()) {
  if (row?.status === "archived") return { key: "archived", label: "管理終了" };
  if (row?.status === "resting") {
    return offlineRestTiming(row, nowMs).state === "ready"
      ? { key: "ready", label: "寝かせ完了" }
      : { key: "resting", label: "寝かせ中" };
  }
  if (row?.status === "completed") return { key: "complete", label: "完走" };
  if (offlineCurrentDay(row, new Date(nowMs)) >= 14) return { key: "complete", label: "完走待ち" };
  return { key: "active", label: "稼働中" };
}

function offlineDurationLabel(minutes) {
  const value = Math.max(0, Math.round(Number(minutes || 0)));
  const days = Math.floor(value / 1440);
  const hours = Math.floor((value % 1440) / 60);
  const mins = value % 60;
  if (days) return `${days}日 ${hours}時間`;
  if (hours) return `${hours}時間 ${mins}分`;
  return `${mins}分`;
}

function offlineTaskConfigLabel(config = {}) {
  const values = [
    Number(config.ciYen || 0) ? `CI ${yen(config.ciYen)}` : "",
    Number(config.video180PointsPerDay || 0) ? `180分 ${number(config.video180PointsPerDay)}P` : "",
    Number(config.video10Yen || 0) ? `追加 ${yen(config.video10Yen)}` : "",
  ].filter(Boolean);
  return values.length ? values.map((value) => `<span>${esc(value)}</span>`).join("") : `<span class="muted">未設定</span>`;
}

function offlineActionButtons(row, status) {
  const id = esc(row.offlineId || "");
  const buttons = [`<button class="offline-row-action" data-offline-edit="${id}" type="button">編集</button>`];
  if (status.key === "active" || status.key === "complete") {
    buttons.push(`<button class="offline-row-action" data-offline-action="toggle-uptime" data-offline-id="${id}" type="button">${row.uptimeRunning ? "UPTIME停止" : "UPTIME開始"}</button>`);
    buttons.push(`<button class="offline-row-action primary-action" data-offline-action="complete-cycle" data-offline-id="${id}" type="button">完走→寝かせ</button>`);
  } else if (status.key === "ready" || row.status === "completed") {
    buttons.push(`<button class="offline-row-action primary-action" data-offline-action="start-cycle" data-offline-id="${id}" type="button">次周期開始</button>`);
  }
  if (status.key === "archived") {
    buttons.push(`<button class="offline-row-action" data-offline-action="restore" data-offline-id="${id}" type="button">管理再開</button>`);
  } else {
    buttons.push(`<button class="offline-row-action danger-action" data-offline-action="archive" data-offline-id="${id}" type="button">管理終了</button>`);
  }
  return buttons.join("");
}

function renderOfflineDeviceDb(rows = []) {
  const devices = Array.isArray(rows) ? rows : [];
  const nowMs = Date.now();
  const liveRows = devices.filter((row) => row.status !== "archived");
  const statusRows = liveRows.map((row) => ({ row, status: offlineStatusInfo(row, nowMs) }));
  const activeCount = statusRows.filter((item) => ["active", "complete"].includes(item.status.key)).length;
  const restingCount = statusRows.filter((item) => item.status.key === "resting").length;
  const readyRows = statusRows.filter((item) => item.status.key === "ready").map((item) => item.row);
  el("offlineDeviceTotal").textContent = `稼働 ${activeCount}台`;
  el("offlineDeviceResting").textContent = `寝かせ中 ${restingCount}台`;
  el("offlineDeviceReady").textContent = `寝かせ完了 ${readyRows.length}台`;
  el("offlineDeviceTotal").title = `登録 ${liveRows.length}台 / 管理終了 ${devices.length - liveRows.length}台`;
  const alert = el("offlineReadyAlert");
  alert.classList.toggle("hidden", readyRows.length === 0);
  alert.textContent = readyRows.length
    ? `寝かせ完了: ${readyRows.map((row) => `${row.number} ${row.name}`).join(" / ")}`
    : "";
  if (!el("offlineDeviceStartDateInput").value) el("offlineDeviceStartDateInput").value = localDateInputValue();

  const body = el("offlineDeviceRows");
  if (!devices.length) {
    body.innerHTML = `<tr class="offline-empty-row"><td colspan="11">未接続端末はまだ登録されていません</td></tr>`;
    return;
  }
  body.innerHTML = devices.map((row) => {
    const status = offlineStatusInfo(row, nowMs);
    const day = offlineCurrentDay(row, new Date(nowMs));
    const uptimeMinutes = offlineCurrentUptimeMinutes(row, nowMs);
    const uptimeHours = uptimeMinutes / 60;
    const rest = offlineRestTiming(row, nowMs);
    const restText = status.key === "ready"
      ? "完了"
      : status.key === "resting"
        ? `残り ${offlineDurationLabel(rest.remainingMinutes)}`
        : "-";
    const tasks = row.todayTasks || {};
    const taskDisabled = row.status === "archived" ? "disabled" : "";
    const withdrawalText = Number(row.withdrawalCount || 0)
      ? `${Number(row.withdrawalCount)}件 / ${yen(row.withdrawalTotalYen || 0)}`
      : "0件";
    return `
      <tr class="offline-device-row offline-row-${esc(status.key)}" data-offline-id="${esc(row.offlineId || "")}" data-offline-status="${esc(status.key)}">
        <td class="offline-device-identity"><strong>No.${esc(row.number || "-")}</strong><span>${esc(row.name || row.offlineId || "")}</span><small>${esc([row.model, row.carrier, row.simStatus, row.offlineId].filter(Boolean).join(" / "))}</small></td>
        <td><strong class="offline-day-value">${day ? `DAY ${day}` : "-"}</strong><small>${esc(row.operationStartedOn || "")}</small></td>
        <td><span class="offline-status-badge ${esc(status.key)}">${esc(status.label)}</span><small>${Number(row.completedCycles || 0) ? `${Number(row.completedCycles)}周期完了` : ""}</small></td>
        <td><span class="uptime-pill ${uptimeBandClass(uptimeHours)} offline-uptime-value">${esc(uptimeLabel(uptimeHours))}</span><small>${row.uptimeRunning && row.status === "active" ? "カウント中" : "停止中"}</small></td>
        <td><strong class="offline-rest-value">${esc(restText)}</strong><small>${rest.endsAt ? `${formatDateTime(rest.endsAt)}まで` : `${Number(row.restHours || 24)}時間設定`}</small></td>
        <td class="offline-task-cell">
          <label><input class="offline-task-check" data-task="ci" type="checkbox" ${tasks.ci ? "checked" : ""} ${taskDisabled}> CI</label>
          <label><input class="offline-task-check" data-task="video180" type="checkbox" ${tasks.video180 ? "checked" : ""} ${taskDisabled}> 180分</label>
          <label><input class="offline-task-check" data-task="video10" type="checkbox" ${tasks.video10 ? "checked" : ""} ${taskDisabled}> 追加</label>
        </td>
        <td class="offline-task-config">${offlineTaskConfigLabel(row.taskConfig)}</td>
        <td>${esc(row.invitePartner || "-")}</td>
        <td><strong>${esc(withdrawalText)}</strong><small>${esc(row.lastWithdrawalDate || "")}</small></td>
        <td class="offline-notes-cell">${esc(row.notes || "-")}</td>
        <td><span class="offline-row-actions">${offlineActionButtons(row, status)}</span></td>
      </tr>`;
  }).join("");
}

async function saveOfflineDevice(event) {
  event.preventDefault();
  const offlineId = el("offlineDeviceIdInput").value.trim();
  const payload = {
    offlineId,
    number: el("offlineDeviceNumberInput").value,
    name: el("offlineDeviceNameInput").value.trim(),
    model: el("offlineDeviceModelInput").value.trim(),
    carrier: el("offlineDeviceCarrierInput").value.trim(),
    simStatus: el("offlineDeviceSimInput").value,
    operationStartedOn: el("offlineDeviceStartDateInput").value,
    initialDay: Number(el("offlineDeviceInitialDayInput").value || 1),
    uptimeHours: Number(el("offlineDeviceUptimeInput").value || 0),
    uptimeRunning: el("offlineDeviceUptimeRunningInput").checked,
    restHours: Number(el("offlineDeviceRestHoursInput").value || 24),
    invitePartner: el("offlineDeviceInvitePartnerInput").value.trim(),
    notes: el("offlineDeviceNotesInput").value.trim(),
    taskConfig: {
      ciYen: Number(el("offlineDeviceCiInput").value || 0),
      video180PointsPerDay: Number(el("offlineDeviceVideo180Input").value || 0),
      video10Yen: Number(el("offlineDeviceVideo10Input").value || 0),
    },
  };
  setBusy(true, el("offlineDeviceSaveBtn"), offlineId ? "更新中..." : "登録中...");
  try {
    const result = await fetchJson("/api/fleet-db/offline-devices/upsert", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    logLine(`${offlineId ? "未接続端末更新" : "未接続端末登録"} OK: No.${result.device.number} ${result.device.name}`);
    clearOfflineDeviceForm();
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine(`${offlineId ? "未接続端末更新" : "未接続端末登録"} NG: ${error.message}`);
    window.alert(error.message);
  } finally {
    setBusy(false);
  }
}

function clearOfflineDeviceForm() {
  if (!el("offlineDeviceForm")) return;
  state.offlineEditingId = "";
  el("offlineDeviceIdInput").value = "";
  el("offlineDeviceForm").reset();
  el("offlineDeviceStartDateInput").value = localDateInputValue();
  el("offlineDeviceInitialDayInput").value = "1";
  el("offlineDeviceUptimeInput").value = "0";
  el("offlineDeviceUptimeRunningInput").checked = true;
  el("offlineDeviceRestHoursInput").value = "24";
  el("offlineDeviceSaveBtn").textContent = "手動登録";
  el("offlineDeviceCancelBtn").classList.add("hidden");
}

function startOfflineDeviceEdit(offlineId) {
  const row = offlineDeviceById(offlineId);
  if (!row) return logLine("未接続端末編集 NG: 端末が見つかりません");
  state.offlineEditingId = offlineId;
  el("offlineDeviceIdInput").value = offlineId;
  el("offlineDeviceNumberInput").value = row.number || "";
  el("offlineDeviceNameInput").value = row.name || "";
  el("offlineDeviceModelInput").value = row.model || "";
  el("offlineDeviceCarrierInput").value = row.carrier || "";
  el("offlineDeviceSimInput").value = row.simStatus || "";
  el("offlineDeviceStartDateInput").value = row.operationStartedOn || localDateInputValue();
  el("offlineDeviceInitialDayInput").value = row.initialDay || 1;
  el("offlineDeviceUptimeInput").value = (offlineCurrentUptimeMinutes(row) / 60).toFixed(1);
  el("offlineDeviceUptimeRunningInput").checked = row.uptimeRunning === true && row.status === "active";
  el("offlineDeviceRestHoursInput").value = row.restHours || 24;
  el("offlineDeviceCiInput").value = row.taskConfig?.ciYen || "";
  el("offlineDeviceVideo180Input").value = row.taskConfig?.video180PointsPerDay || "";
  el("offlineDeviceVideo10Input").value = row.taskConfig?.video10Yen || "";
  el("offlineDeviceInvitePartnerInput").value = row.invitePartner || "";
  el("offlineDeviceNotesInput").value = row.notes || "";
  el("offlineDeviceSaveBtn").textContent = "登録内容を更新";
  el("offlineDeviceCancelBtn").classList.remove("hidden");
  el("offlineDeviceForm").scrollIntoView({ behavior: "smooth", block: "start" });
  el("offlineDeviceNumberInput").focus({ preventScroll: true });
}

function handleOfflineDeviceRowAction(event) {
  const edit = event.target.closest("[data-offline-edit]");
  if (edit) return startOfflineDeviceEdit(edit.dataset.offlineEdit || "");
  const button = event.target.closest("[data-offline-action]");
  if (!button) return;
  runOfflineDeviceAction(button.dataset.offlineId || "", button.dataset.offlineAction || "", button);
}

async function runOfflineDeviceAction(offlineId, action, button) {
  const row = offlineDeviceById(offlineId);
  if (!row) return logLine("未接続端末操作 NG: 端末が見つかりません");
  const confirmations = {
    "complete-cycle": "完走として記録し、寝かせ時間のカウントを開始します。よろしいですか？",
    "start-cycle": "寝かせ完了としてDAY 1から次周期を開始します。よろしいですか？",
    archive: "この端末を管理終了にします。履歴と出金記録は残ります。よろしいですか？",
    restore: "この端末の管理を再開します。DAY 1、UPTIME停止で再開します。よろしいですか？",
  };
  if (confirmations[action] && !window.confirm(confirmations[action])) return;
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/fleet-db/offline-devices/action", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        offlineId,
        action,
        operationStartedOn: action === "start-cycle" ? localDateInputValue() : undefined,
        initialDay: action === "start-cycle" ? 1 : undefined,
      }),
    });
    logLine(`未接続端末操作 OK: No.${result.device.number} ${result.device.name}`);
    if (state.offlineEditingId === offlineId && action !== "toggle-uptime") clearOfflineDeviceForm();
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine(`未接続端末操作 NG: ${error.message}`);
    window.alert(error.message);
  } finally {
    setBusy(false);
  }
}

async function handleOfflineDeviceTaskChange(event) {
  const checkbox = event.target.closest(".offline-task-check");
  if (!checkbox) return;
  const tableRow = checkbox.closest("tr[data-offline-id]");
  const offlineId = tableRow?.dataset.offlineId || "";
  const checks = Object.fromEntries([...tableRow.querySelectorAll(".offline-task-check")].map((input) => [input.dataset.task, input.checked]));
  for (const input of tableRow.querySelectorAll(".offline-task-check")) input.disabled = true;
  tableRow.classList.add("saving");
  try {
    await fetchJson("/api/fleet-db/offline-devices/task-checks", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ offlineId, date: localDateInputValue(), ...checks }),
    });
    logLine(`未接続タスク保存 OK: ${offlineDeviceById(offlineId)?.number || offlineId} ${Object.values(checks).filter(Boolean).length}/3`);
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine(`未接続タスク保存 NG: ${error.message}`);
    await loadLocalSummaryOnly().catch(() => {});
  }
}

function renderGlobalErrorRate(stats = {}) {
  const target = el("globalErrorRate");
  if (!target) return;
  const rate = stats && stats.rateLabel || "-";
  const noError = Number(stats && stats.noError || 0);
  const day1 = Number(stats && stats.day1 || 0);
  const day2Plus = Number(stats && stats.day2Plus || 0);
  const unclassified = Number(stats && stats.unclassified || 0);
  target.textContent = `ERROR率 ${rate}`;
  target.classList.toggle("empty", !stats || !Number(stats.total || 0));
  target.title = `エラーなし ${noError}件 / 初日 ${day1}件 / 2日目以降 ${day2Plus}件${unclassified ? ` / 判定待ち ${unclassified}件` : ""}`;
}

function renderSiteName(siteName) {
  const name = siteName || "Android Fleet";
  el("appTitle").textContent = name;
  el("siteNameInput").value = name;
  document.title = name;
}

function renderWithdrawalForm(rows) {
  const select = el("withdrawalDeviceSelect");
  const current = select.value;
  const sortedRows = rows.slice().sort(compareWithdrawalDeviceOptions);
  select.innerHTML = [
    `<option value="">端末を選択</option>`,
    ...sortedRows.map((row) => {
      const label = formatWithdrawalDeviceOptionLabel(row);
      const value = row.serial || row.managementId || "";
      return `<option value="${esc(value)}" title="${esc(label)}">${esc(label)}</option>`;
    }),
  ].join("");
  if (current && [...select.options].some((option) => option.value === current)) select.value = current;
  if (!el("withdrawalDateInput").value) el("withdrawalDateInput").value = localDateInputValue();
}

function compareWithdrawalDeviceOptions(a, b) {
  const aNumber = managementNumber(a);
  const bNumber = managementNumber(b);
  if (aNumber !== bNumber) return aNumber - bNumber;
  return String(formatWithdrawalDeviceOptionLabel(a)).localeCompare(String(formatWithdrawalDeviceOptionLabel(b)), "ja");
}

function formatWithdrawalDeviceOptionLabel(row) {
  const number = formatXiaoWeiNumber(row.laixiNumber || row.managementId || row.xiaoweiSort || "");
  const fixed = row.deviceLabel || row.laixiName || row.uiName || "";
  const original = row.deviceName || row.xiaoweiName || "";
  const serial = String(row.serial || "").trim();
  const serialTail = serial ? `ID:${serial.slice(-6)}` : "";
  const status = withdrawalDeviceStatusLabel(row.effectiveStatus || row.status || "");
  const parts = [];
  if (row.isOffline) parts.push("未接続");
  if (number) parts.push(number);
  if (fixed) parts.push(fixed);
  if (original && original !== fixed && !String(original).includes(fixed)) parts.push(`元: ${original}`);
  if (status) parts.push(status);
  if (serialTail) parts.push(serialTail);
  return parts.filter(Boolean).join(" / ") || serial || "端末名なし";
}

function withdrawalDeviceStatusLabel(status) {
  return {
    ONLINE: "稼働中",
    ACTIVE: "稼働中",
    RESTING: "寝かせ中",
    READY: "寝かせ完了",
    COMPLETED: "完走",
    ARCHIVED: "管理終了",
    "NO CYCLE": "",
    WAITING: "",
    INACTIVE: "",
  }[String(status || "").toUpperCase()] || "";
}

function deviceEditorControlKey(control) {
  if (!control) return "";
  const device = control.dataset.device || control.closest("tr")?.dataset.device || "";
  const field = control.dataset.field || control.dataset.kind || "";
  return device && field ? `${device}\u001f${field}` : "";
}

function deviceEditorValueChanged(control) {
  if (!control) return false;
  const value = control.classList.contains("device-edit-input") ? control.value.trim() : control.value;
  return value !== (control.dataset.original || "");
}

function captureDeviceEditorDrafts() {
  const drafts = new Map();
  for (const control of document.querySelectorAll("#deviceRows .device-edit-input, #deviceRows .device-task-select")) {
    if (!deviceEditorValueChanged(control)) continue;
    const key = deviceEditorControlKey(control);
    if (!key) continue;
    drafts.set(key, {
      value: control.value,
      error: control.classList.contains("input-error"),
      title: control.title || "",
    });
  }
  return drafts;
}

function restoreDeviceEditorDrafts(drafts) {
  if (!(drafts instanceof Map) || !drafts.size) return;
  const controls = new Map();
  for (const control of document.querySelectorAll("#deviceRows .device-edit-input, #deviceRows .device-task-select")) {
    const key = deviceEditorControlKey(control);
    if (key) controls.set(key, control);
  }
  for (const [key, draft] of drafts.entries()) {
    const control = controls.get(key);
    if (!control) continue;
    if (control.tagName === "SELECT" && ![...control.options].some((option) => option.value === draft.value)) continue;
    control.value = draft.value;
    const changed = deviceEditorValueChanged(control);
    control.classList.toggle("changed-input", changed);
    control.classList.toggle("input-error", changed && draft.error);
    control.title = changed && draft.error ? draft.title : "";
  }
}

function deviceEditorHasFocus() {
  const active = document.activeElement;
  return Boolean(active && active.closest?.("#deviceRows") && active.matches(".device-edit-input, .device-task-select"));
}

function schedulePendingDeviceRender() {
  if (state.deviceRenderFlushTimer) window.clearTimeout(state.deviceRenderFlushTimer);
  state.deviceRenderFlushTimer = window.setTimeout(() => {
    state.deviceRenderFlushTimer = 0;
    if (deviceEditorHasFocus() || !Array.isArray(state.pendingDeviceRows)) return;
    const pendingRows = state.pendingDeviceRows;
    state.pendingDeviceRows = null;
    renderDevices(pendingRows, { force: true });
  }, 0);
}

function renderXiaoweiDisplayName(value) {
  const fullName = String(value || "").trim();
  const statusMatch = fullName.match(/^(?:(?:DAY\d+|180分[○〇]|追加[○〇])(?:\s+|$))+/i);
  const statusText = String(statusMatch?.[0] || "").trim();
  const deviceName = statusText
    ? fullName.slice(statusMatch[0].length).trim()
    : fullName;
  const firstLine = ["XiaoWei名:", statusText].filter(Boolean).join(" ");

  return `
    <div class="xiaowei-display-name" title="${esc(fullName)}">
      <span class="xiaowei-display-name-line">${esc(firstLine)}</span>
      <span class="xiaowei-display-name-line xiaowei-display-name-device">${esc(deviceName || "-")}</span>
    </div>
  `;
}

function renderDevices(rows, options = {}) {
  const nextRows = Array.isArray(rows) ? rows : [];
  if (!options.force && deviceEditorHasFocus()) {
    state.pendingDeviceRows = nextRows.slice();
    return;
  }
  const drafts = captureDeviceEditorDrafts();
  state.pendingDeviceRows = null;
  const adbRows = state.adbDevices?.devices || [];
  const hasAdbSnapshot = Boolean(state.adbDevices && !state.adbDevices.skipped && Array.isArray(adbRows));
  const adbBySerial = new Map(adbRows
    .filter((device) => device && device.serial)
    .map((device) => [String(device.serial), device]));
  const invitePartnerOptions = buildInvitePartnerSuggestions(nextRows);
  el("invitePartnerOptions").innerHTML = invitePartnerOptions
    .map((label) => `<option value="${esc(label)}"></option>`)
    .join("");
  el("deviceRows").innerHTML = sortDeviceRows(nextRows).map((row) => {
    const adb = adbBySerial.get(String(row.serial || ""));
    const adbConnected = Boolean(adb && (adb.status === "device" || adb.connected === true));
    const inviteVerificationIdle = String(row.status || "").toUpperCase() === "INACTIVE";
    const currentBatteryPercent = hasAdbSnapshot && row.serial && !adbConnected
      ? ""
      : (adb?.batteryPercent ?? row.batteryPercent ?? row.adbLastBatteryPercent ?? "");
    const displayRow = {
      ...row,
      adbConnected: hasAdbSnapshot && row.serial ? adbConnected : null,
      simStatus: inviteVerificationIdle ? "" : row.simStatus || adb?.simStatus || "",
      networkType: inviteVerificationIdle ? "" : row.networkType || adb?.networkType || "",
      osVersion: inviteVerificationIdle ? "" : row.osVersion || adb?.osVersion || "",
      adbUptimeSeconds: adb?.uptimeSeconds ?? row.adbLastUptimeSeconds,
      adbUptimeRaw: adb?.uptimeRaw || row.adbLastUptimeRaw || "",
      adbUptimeFetchedAt: adb?.uptimeFetchedAt || Date.parse(row.adbLastUptimeCheckedAt || "") || 0,
      batteryPercent: currentBatteryPercent,
    };
    const batteryMissing = displayRow.batteryPercent === "" || displayRow.batteryPercent === null || displayRow.batteryPercent === undefined;
    const rowClasses = [
      displayRow.adbConnected === false ? "device-row-offline" : "",
      row.serial && state.adbMissingSerials?.has(String(row.serial)) ? "device-row-dropped" : "",
      displayRow.adbConnected === false && batteryMissing ? "device-row-offline-battery-missing" : "",
    ].filter(Boolean).join(" ");
    const masterNameMarkup = row.masterRegistered === false
      ? `<span class="device-master-name device-master-unregistered" title="型番 ${esc(row.masterLookupModelCode || "不明")} / キャリア ${esc(row.masterLookupCarrierCode || "UNKNOWN")}">マスタ未登録: ${esc(row.masterLookupModelCode || row.deviceName || "機種要確認")}</span>`
      : `<span class="device-master-name">マスタ: ${esc(row.deviceName || "")}</span>`;
    return `
    <tr class="${rowClasses}" data-device="${esc(row.serial || row.managementId || "")}">
      <td class="management-id-cell">${esc(row.laixiNumber || "")}</td>
      <td class="device-day-cell">${formatDeviceDay(displayRow)}</td>
      <td class="baseline-settings-cell">${baselineSettingsStatusDetail(displayRow)}</td>
      <td class="invite-factors-cell">${renderInviteFactorsCell(displayRow)}</td>
      <td class="device-name-cell">
        ${renderXiaoweiDisplayName(row.laixiName)}
        <div class="short-name-editor">
          <label>短縮名編集</label>
          <input class="table-input device-edit-input short-name-input" type="text" value="${esc(row.modelGroup || "")}" data-field="shortName" data-device="${esc(row.serial || row.managementId || "")}" data-original="${esc(row.modelGroup || "")}" placeholder="A25">
          <span>${esc(row.carrierCode || "")}</span>
        </div>
        <div class="device-name-meta">
          ${masterNameMarkup}
          <span class="raw-device-name">${row.serial ? `端末ID: ${esc(row.serial)}` : ""}</span>
        </div>
      </td>
      <td class="history-cell">${renderDeviceHistoryButton(displayRow)}</td>
      <td class="device-tasks-cell">${renderDeviceTasksCell(row)}</td>
      <td class="swipe-method-cell">${renderSwipeMethodCell(row)}</td>
      <td class="status-cell">${statusPill(displayRow.status, displayRow)}</td>
      ${batteryCell(displayRow)}
    </tr>
  `;
  }).join("");
  restoreDeviceEditorDrafts(drafts);
  updateDeviceNameSaveState();
}

function batteryCell(row) {
  if (row && row.adbConnected === false) {
    return `<td class="num battery-cell battery-missing battery-offline-missing" title="ADB未接続のため現在の電池残量は取得できません">OFFLINE</td>`;
  }
  const value = row && row.batteryPercent;
  const missing = value === "" || value === null || value === undefined;
  if (missing) {
    return `<td class="num battery-cell battery-missing" title="電池未取得">未取得</td>`;
  }
  return `<td class="num battery-cell ${Number(value) <= 20 ? "battery-low" : ""}">${esc(value)}%</td>`;
}

function formatDeviceDay(row) {
  const fromRow = Number(row && row.day || 0);
  const fromTags = Array.isArray(row && row.tags)
    ? row.tags.map((tag) => /^DAY_(\d{2})$/.exec(String(tag || ""))).find(Boolean)
    : null;
  const day = fromRow || (fromTags ? Number(fromTags[1]) : 0);
  return day ? `<span class="device-day-chip">DAY${String(day).padStart(2, "0")}</span>` : "";
}

function renderInviteFactorsCell(row) {
  const device = row.serial || row.managementId || "";
  const osValue = formatOsVersion(row.osVersion);
  return `
    <div class="invite-factor-grid">
      ${renderTtlMethodChip(row)}
      ${renderInviteFactorSelect(row, "simStatus")}
      ${renderInviteFactorSelect(row, "networkType")}
      ${renderInviteFactorSelect(row, "ttlRegisterMethod")}
      ${renderInviteUptimeChip(row)}
      <label class="invite-factor-field" title="SIMからWi-Fiなどへ切り替えた日">
        <span>切替</span>
        <input class="table-input device-edit-input invite-small-input" type="number" min="1" max="365" value="${esc(row.networkSwitchedDay || "")}" data-field="networkSwitchedDay" data-device="${esc(device)}" data-original="${esc(row.networkSwitchedDay || "")}" placeholder="日">
      </label>
      <input class="table-input device-edit-input invite-os-input" type="text" value="${esc(osValue)}" data-field="osVersion" data-device="${esc(device)}" data-original="${esc(osValue)}" placeholder="OS">
      ${renderInviteFactorSelect(row, "inviteType")}
      ${renderInviteFactorSelect(row, "inviteRole")}
      ${renderInviteFactorSelect(row, "inviteResult")}
      ${renderInvitePartnerSelect(row)}
      <input class="table-input device-edit-input invite-note-input" type="text" data-field="inviteOpsNote" data-device="${esc(device)}" data-original="${esc(row.inviteOpsNote || "")}" value="${esc(row.inviteOpsNote || "")}" placeholder="備考: 何日目にSIM→Wi-Fi、追加視聴、検索など">
    </div>
  `;
}

function renderTtlMethodChip(row) {
  const method = String(row.ttlRegisterMethod || "").trim();
  const label = method || "導入方法未設定";
  const klass = method === "Google Play" ? "play" : method === "APK自動" ? "apk" : "empty";
  return `<span class="ttl-method-chip ${klass}" title="導入方法">${esc(label)}</span>`;
}

function renderInviteUptimeChip(row) {
  const uptimeSeconds = Number(row.adbUptimeSeconds);
  if (!Number.isFinite(uptimeSeconds) || uptimeSeconds < 0) {
    return `<span class="invite-uptime-chip uptime-unknown" title="ADB稼働時間未取得">UPTIME未取得</span>`;
  }
  const fetchedAt = Number(row.adbUptimeFetchedAt || Date.now());
  const value = currentUptimeValue(uptimeSeconds, fetchedAt);
  return `<span class="invite-uptime-chip ${uptimeBandClass(value.hours)}" data-uptime-base="${esc(uptimeSeconds)}" data-uptime-fetched-at="${esc(fetchedAt)}" data-uptime-prefix="UPTIME " title="${esc(uptimeTitle(value.hours))}">UPTIME ${esc(uptimeLabel(value.hours))}</span>`;
}

function formatOsVersion(value) {
  const text = String(value || "").trim();
  if (!text) return "";
  const release = text
    .replace(/^OS\s*/i, "")
    .replace(/\s*\/\s*SDK\s*\d+\s*$/i, "")
    .trim();
  return release ? `OS ${release}` : "";
}

function renderInviteFactorSelect(row, field) {
  const options = INVITE_FACTOR_OPTIONS[field] || [["", "?"]];
  const value = row[field] || "";
  const device = row.serial || row.managementId || "";
  return `
    <select class="table-input device-edit-input invite-factor-select" data-field="${esc(field)}" data-device="${esc(device)}" data-original="${esc(value)}">
      ${options.map(([optionValue, label]) => `<option value="${esc(optionValue)}" ${optionValue === value ? "selected" : ""}>${esc(label)}</option>`).join("")}
    </select>
  `;
}

function renderInvitePartnerSelect(row) {
  const device = row.serial || row.managementId || "";
  const value = invitePartnerLabel(row.invitePartner || "");
  return `
    <input class="table-input device-edit-input invite-factor-select invite-partner-select" type="text" maxlength="80"
      list="invitePartnerOptions" value="${esc(value)}" data-field="invitePartner" data-device="${esc(device)}"
      data-original="${esc(value)}" placeholder="親・相手を選択／iPhone名を入力" autocomplete="off">
  `;
}

function buildInvitePartnerSuggestions(rows = []) {
  const suggestions = new Set();
  const add = (value) => {
    const label = invitePartnerLabel(value);
    if (label) suggestions.add(label);
  };
  for (const item of sortDeviceRows(rows)) {
    add(invitePartnerOptionLabel(item));
    add(item?.invitePartner);
    for (const entry of Array.isArray(item?.inviteHistory) ? item.inviteHistory : []) add(entry?.partner);
  }
  return [...suggestions].sort((left, right) => left.localeCompare(right, "ja"));
}

function invitePartnerOptionLabel(row) {
  if (!row) return "";
  const number = row.laixiNumber || row.managementId || "";
  const shortName = row.deviceLabel || row.laixiName || row.uiName || "";
  return [number, shortName].filter(Boolean).join(" / ");
}

function renderDeviceTaskSelect(row, kind) {
  const config = DEVICE_TASK_SELECTS[kind];
  if (!config) return "";
  const checked = deviceTaskCheckedTags(row, kind);
  const labels = checked.length ? checked.map((tag) => deviceTaskTagLabel(kind, tag)) : ["未設定"];
  const note = deviceTaskNote(row, kind);
  return `<div class="device-task-cell">${labels.map((label) => `<span class="device-task-chip ${checked.length ? "" : "empty"}">${esc(label)}</span>`).join("")}${note}</div>`;
}

function renderDeviceTasksCell(row) {
  const items = [
    ["チェックイン", "ci", "円"],
    ["動画180分", "video180", ""],
    ["追加視聴", "video10", "円"],
  ].map(([label, kind, suffix]) => renderDeviceTaskLine(row, kind, label, suffix));
  return `<div class="device-task-stack">${items.join("")}${renderDeviceTaskErrorStatus(row)}</div>`;
}

function renderDeviceTaskLine(row, kind, label, suffix = "") {
  const checked = deviceTaskCheckedTags(row, kind);
  const value = checked.length ? checked.map((tag) => deviceTaskTagLabel(kind, tag)).join(" / ") : "-";
  const note = deviceTaskPlainNote(row, kind);
  const valueText = value === "-" || !suffix || value.endsWith(suffix) ? value : `${value}${suffix}`;
  return `
    <div class="device-task-line ${checked.length ? "" : "empty"}">
      <span>${esc(label)}</span>
      <b>${esc(valueText)}</b>
      ${note ? `<em>${esc(note)}</em>` : ""}
    </div>
  `;
}

function deviceTaskPlainNote(row, kind) {
  const tags = Array.isArray(row.tags) ? row.tags : [];
  if (kind === "video180" && tags.includes("V180_DONE")) return "完了";
  if (kind === "video10" && tags.includes("V10_DONE")) return "完了";
  return "";
}

function renderDeviceTaskErrorStatus(row) {
  const tags = Array.isArray(row?.tags) ? row.tags : [];
  const errorCount = Number(row?.taskHistory?.errorStats?.error || 0);
  if (tags.includes("STATE_ERROR")) {
    return `<div class="device-task-error-status current">ERROR中</div>`;
  }
  if (tags.includes("STATE_ERROR_HISTORY") || row?.hasErrorHistory || errorCount > 0) {
    return `<div class="device-task-error-status history">ERROR歴あり</div>`;
  }
  return "";
}

function deviceTaskCheckedTags(row, kind) {
  const tags = Array.isArray(row.tags) ? row.tags : [];
  const config = DEVICE_TASK_SELECTS[kind];
  if (!config) return [];
  return config.tags.filter((tag) => tags.includes(tag));
}

function deviceTaskTagLabel(kind, tag) {
  const options = DEVICE_TASK_SELECTS[kind]?.options || [];
  const found = options.find(([value]) => value === tag);
  return found ? found[1] : tag;
}

function deviceTaskNote(row, kind) {
  const tags = Array.isArray(row.tags) ? row.tags : [];
  if (kind === "ci") {
    if (tags.includes("STATE_ERROR")) return `<div class="device-task-note error">ERROR中</div>`;
    if (tags.includes("STATE_ERROR_HISTORY")) return `<div class="device-task-note error-history">ERROR歴あり</div>`;
  }
  if (kind === "video180" && tags.includes("V180_DONE")) {
    return `<div class="device-task-note done">完了</div>`;
  }
  if (kind === "video10" && tags.includes("V10_DONE")) {
    return `<div class="device-task-note done">完了</div>`;
  }
  return "";
}

function renderDeviceHistoryButton(row) {
  const taskCount = Number(row?.taskHistory?.completedCount ?? row?.taskHistory?.count ?? 0);
  const withdrawalCount = deviceWithdrawals(row).length;
  const inviteCount = inviteHistoryEntries(row).length;
  const errorCount = Number(row?.taskHistory?.errorStats?.error || 0);
  const disconnectCount = Number(row?.connectionIncidentStats?.total || 0);
  const recoveryCount = Number(row?.recoveryAttemptStats?.total || 0);
  const count = taskCount + withdrawalCount + inviteCount + errorCount + disconnectCount + recoveryCount;
  const device = row.serial || row.managementId || "";
  if (!count) {
    return `<button class="history-link-btn empty" data-device="${esc(device)}" type="button" disabled><span>完走0件</span><span>招待0件</span><span>切断0件 / 復旧0回</span></button>`;
  }
  const disconnectClass = disconnectCount ? " disconnect" : "";
  return `<button class="history-link-btn${disconnectClass}" data-device="${esc(device)}" type="button" title="履歴を表示"><span>完走${esc(taskCount)}件</span><span>招待${esc(inviteCount)}件</span><span>切断${esc(disconnectCount)}件 / 復旧${esc(recoveryCount)}回</span></button>`;
}

function renderTaskHistoryCell(row) {
  const history = row.taskHistory || {};
  const count = Number(history.count || 0);
  if (!count) return `<span class="task-history-pill empty" title="">-</span>`;
  const items = Array.isArray(history.items) ? history.items : [];
  const title = items.length
    ? items.flatMap((item) => {
        const resetLines = Array.isArray(item.resetHistory)
          ? item.resetHistory.map((entry) => [
              "リセット",
              entry.at || "",
              entry.reason || "",
              entry.amountYen ? `${Number(entry.amountYen).toLocaleString("ja-JP")}円` : "",
              entry.summary || "",
            ].filter(Boolean).join(" / "))
          : [];
        return [item.text || item.cycleId || "", ...resetLines].filter(Boolean);
      }).join("\n")
    : "";
  const latest = history.latest?.text || "";
  const latestShort = latest
    .replace(/^#\d+\s*\/\s*/, "")
    .replace(/\s*\/\s*/g, " ");
  return `<span class="task-history-pill" title="${esc(title)}"><b>履歴${esc(count)}</b><small>${esc(latestShort || "詳細")}</small></span>`;
}

function deviceWithdrawals(row) {
  const matcher = globalThis.AndroidFleetWithdrawalMatching?.withdrawalBelongsToDevice;
  return (state.summary?.withdrawals || [])
    .filter((item) => matcher ? matcher(item, row) : false)
    .slice()
    .sort((a, b) => String(b.withdrawalDate || b.recordedAt || "").localeCompare(String(a.withdrawalDate || a.recordedAt || "")));
}

function inviteHistoryLines(row) {
  return String(row?.inviteOpsNote || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
}

function inviteHistoryEntries(row) {
  const structured = Array.isArray(row?.inviteHistory) ? row.inviteHistory.filter((entry) => entry && (entry.at || entry.result)) : [];
  if (structured.length) return structured;
  return inviteHistoryLines(row).map((text) => ({ legacy: true, text }));
}

let deviceHistoryRestoreFocus = null;

function showDeviceHistoryDialog(row) {
  if (!row) return;
  closeDeviceHistoryDialog();
  deviceHistoryRestoreFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  const taskItems = Array.isArray(row.taskHistory?.items) ? row.taskHistory.items : [];
  const completedTaskCount = Number(row.taskHistory?.completedCount ?? taskItems.length);
  const withdrawals = deviceWithdrawals(row);
  const inviteEntries = inviteHistoryEntries(row);
  const inviteStats = inviteHistoryStats(row, inviteEntries);
  const errorOutcomes = Array.isArray(row.taskHistory?.errorOutcomes) ? row.taskHistory.errorOutcomes : [];
  const errorStats = row.taskHistory?.errorStats || {};
  const connectionIncidents = Array.isArray(row.connectionIncidents) ? row.connectionIncidents : [];
  const connectionStats = row.connectionIncidentStats || {};
  const recoveryAttempts = Array.isArray(row.recoveryAttempts) ? row.recoveryAttempts : [];
  const recoveryStats = row.recoveryAttemptStats || {};
  const adbState = currentHistoryAdbState(row);
  const uptimeText = historyUptimeText(row, adbState);
  const batteryText = historyBatteryText(row, adbState);
  const adbText = adbState.connected === false ? "ADB OFFLINE" : adbState.connected === true ? "ADB OK" : "ADB未確認";
  const notes = [row.notes, row.inviteOpsNote].map((value) => String(value || "").trim()).filter(Boolean);
  const numberLabel = row.laixiNumber || row.xiaoweiNumber || "-";
  const nameLabel = row.deviceLabel || row.laixiName || row.xiaoweiName || row.deviceName || row.serial || "端末名なし";
  const cumulativeRevenue = withdrawals.reduce((sum, item) => sum + Number(item.amountYen || 0), 0);
  const overlay = document.createElement("div");
  overlay.className = "device-history-dialog-backdrop";
  overlay.innerHTML = `
    <div class="device-history-dialog" role="dialog" aria-modal="true" aria-labelledby="deviceHistoryDialogTitle">
      <div class="device-history-dialog-head">
        <div class="device-history-title">
          <h3 id="deviceHistoryDialogTitle">端末履歴</h3>
          <p>${esc(numberLabel)} / ${esc(nameLabel)}</p>
        </div>
        <div class="device-history-head-actions">
          <button class="section-head-action retire-device-action" type="button">管理対象から外す</button>
          <button class="device-history-close" type="button" aria-label="閉じる">×</button>
        </div>
        ${historyKpiStrip([
          { label: "稼働", value: `${taskItems.length}回` },
          { label: "完走", value: `${completedTaskCount}件` },
          { label: "招待", value: `${inviteEntries.length}件` },
          { label: "ERROR率", value: errorStats.rateLabel || "-", tone: Number(errorStats.error || 0) ? "error" : "good" },
          { label: "切断", value: `${Number(connectionStats.total || 0)}件`, tone: connectionStats.chronic || Number(connectionStats.open || 0) ? "error" : Number(connectionStats.total || 0) ? "warn" : "good" },
          { label: "復旧実行", value: `${Number(recoveryStats.total || 0)}回`, tone: recoveryStats.repeated ? "error" : Number(recoveryStats.total || 0) ? "warn" : "good" },
          { label: "累計収益", value: yen(cumulativeRevenue), tone: "money" },
        ])}
      </div>
      <div class="device-history-body">
        ${historyConnectionTable(connectionIncidents, connectionStats, recoveryAttempts, recoveryStats)}
        ${historyTaskTable(taskItems, errorOutcomes, errorStats, withdrawals)}
        ${historyInviteTable(inviteEntries, inviteStats)}
        ${historyWithdrawalTable(withdrawals)}
        <div class="device-history-current-panels">
          ${historyInfoSheet("端末情報・現在値", historyDeviceCurrentCards(row, { uptimeText, batteryText, adbText }), "device")}
          ${historyInfoSheet("招待検証・現在値", historyInviteCurrentCards(row, inviteStats), "invite")}
        </div>
        <div class="device-history-note"><b>備考</b><span>${esc(notes.join("\n") || "記録なし")}</span></div>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelector(".retire-device-action")?.addEventListener("click", (event) => retireDeviceFromHistory(row, event.currentTarget));
  overlay.querySelector(".device-history-close")?.addEventListener("click", closeDeviceHistoryDialog);
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeDeviceHistoryDialog();
  });
  document.addEventListener("keydown", handleDeviceHistoryDialogKeydown);
  requestAnimationFrame(() => overlay.querySelector(".device-history-close")?.focus());
}

function closeDeviceHistoryDialog() {
  const overlay = document.querySelector(".device-history-dialog-backdrop");
  if (!overlay) return;
  overlay.remove();
  document.removeEventListener("keydown", handleDeviceHistoryDialogKeydown);
  if (deviceHistoryRestoreFocus?.isConnected) deviceHistoryRestoreFocus.focus();
  deviceHistoryRestoreFocus = null;
}

function handleDeviceHistoryDialogKeydown(event) {
  if (event.key !== "Escape") return;
  event.preventDefault();
  closeDeviceHistoryDialog();
}

function historyKpiStrip(cards) {
  return `<div class="device-history-kpis">${cards.map((card) => `
    <div class="device-history-kpi ${esc(card.tone || "")}">
      <span>${esc(card.label)}</span>
      <strong>${esc(card.value || "-")}</strong>
    </div>
  `).join("")}</div>`;
}

function historyRateStrip(items, label) {
  return `<div class="history-rate-strip" aria-label="${esc(label)}">${items.map((item) => `
    <span class="history-rate-item ${esc(item.tone || "")}"><small>${esc(item.label)}</small><b>${esc(item.value)}</b></span>
  `).join("")}</div>`;
}

function historyConnectionTable(incidents, stats = {}, recoveryAttempts = [], recoveryStats = {}) {
  const rows = (Array.isArray(incidents) ? incidents.slice() : [])
    .sort((a, b) => String(b?.startedAt || "").localeCompare(String(a?.startedAt || "")));
  const repairRows = (Array.isArray(recoveryAttempts) ? recoveryAttempts.slice() : [])
    .sort((a, b) => String(b?.at || "").localeCompare(String(a?.at || "")));
  const summaryItems = [
    { label: "切断", value: `${Number(stats.total || 0)}件`, tone: Number(stats.total || 0) ? "error" : "good" },
    { label: "30日", value: `${Number(stats.last30Days || 0)}件`, tone: stats.chronic ? "error" : "" },
    { label: "未復旧", value: `${Number(stats.open || 0)}件`, tone: Number(stats.open || 0) ? "error" : "good" },
    { label: "復旧実行", value: `${Number(recoveryStats.total || 0)}回`, tone: recoveryStats.repeated ? "error" : Number(recoveryStats.total || 0) ? "pending" : "good" },
    { label: "停止合計", value: historyConnectionDuration(stats.totalDurationSeconds), tone: "" },
    ...(Number(stats.ignored || 0) ? [{ label: "集計外", value: `${Number(stats.ignored)}件`, tone: "pending" }] : []),
    { label: "判定", value: stats.chronic ? "多発" : "通常", tone: stats.chronic ? "error" : "good" },
  ];
  return `
    <section class="device-history-sheet connection">
      <div class="device-history-sheet-head">
        <h4>ADB切断・復旧履歴</h4>
        ${historyRateStrip(summaryItems, "ADB切断・復旧集計")}
      </div>
      <div class="device-history-table-wrap connection-history-scroll" tabindex="0">
        <table class="device-history-table connection-history-table">
          <colgroup><col class="col-start"><col class="col-recovered"><col class="col-duration"><col class="col-status"><col class="col-reason"></colgroup>
          <thead><tr><th>検知</th><th>復旧</th><th>停止時間</th><th>状態</th><th>内容</th></tr></thead>
          <tbody>${rows.length ? rows.map(renderConnectionHistoryTableRow).join("") : historyEmptyTableRow(5)}</tbody>
        </table>
      </div>
      ${repairRows.length ? `
        <div class="device-history-subhead">復旧ボタン実行履歴</div>
        <div class="device-history-table-wrap recovery-attempt-scroll" tabindex="0">
          <table class="device-history-table recovery-attempt-table">
            <thead><tr><th>実行日時</th><th>処理</th><th>強力復旧</th><th>実行ID</th></tr></thead>
            <tbody>${repairRows.map(renderRecoveryAttemptTableRow).join("")}</tbody>
          </table>
        </div>
      ` : ""}
    </section>
  `;
}

function renderRecoveryAttemptTableRow(attempt) {
  return `<tr>
    <td>${esc(historyDateTimeLabel(attempt?.at) || "-")}</td>
    <td class="history-table-tone pending">自動復旧を実行</td>
    <td>${attempt?.deepRepair === false ? "通常" : "あり"}</td>
    <td class="history-table-memo" title="${esc(attempt?.requestId || "-")}">${esc(attempt?.requestId || "-")}</td>
  </tr>`;
}

function renderConnectionHistoryTableRow(incident) {
  const status = incident?.status === "open" ? "未復旧" : incident?.status === "ignored" ? "集計外" : "復旧済";
  const tone = incident?.status === "open" ? "error" : incident?.status === "ignored" ? "pending" : "good";
  const endAt = incident?.status === "ignored" ? incident?.ignoredAt : incident?.recoveredAt;
  return `<tr>
    <td>${esc(historyDateTimeLabel(incident?.startedAt) || "-")}</td>
    <td>${esc(historyDateTimeLabel(endAt) || (incident?.status === "open" ? "未復旧" : "-"))}</td>
    <td>${esc(historyConnectionDuration(incident?.durationSeconds, incident?.startedAt, incident?.status))}</td>
    <td class="history-table-tone ${esc(tone)}">${esc(status)}</td>
    <td class="history-table-memo" title="${esc(incident?.reason || "ADBから消失（原因不明）")}">${esc(incident?.reason || "ADBから消失（原因不明）")}</td>
  </tr>`;
}

function historyConnectionDuration(seconds, startedAt = "", status = "") {
  let value = Number(seconds || 0);
  if (status === "open" && startedAt) {
    const startedMs = Date.parse(startedAt);
    if (Number.isFinite(startedMs)) value = Math.max(value, Math.floor((Date.now() - startedMs) / 1000));
  }
  if (!Number.isFinite(value) || value <= 0) return status === "ignored" ? "集計外" : "0分";
  const days = Math.floor(value / 86400);
  const hours = Math.floor((value % 86400) / 3600);
  const rawMinutes = Math.floor((value % 3600) / 60);
  const minutes = days || hours ? rawMinutes : Math.max(1, rawMinutes);
  return [days ? `${days}日` : "", hours ? `${hours}時間` : "", minutes ? `${minutes}分` : ""].filter(Boolean).join(" ");
}

function historyTaskTable(taskItems, errorOutcomes, errorStats, withdrawals) {
  const usedOutcomes = new Set();
  const rows = taskItems.map((item) => {
    const outcome = historyTaskOutcome(item, errorOutcomes);
    if (outcome) usedOutcomes.add(historyOutcomeKey(outcome));
    return renderTaskHistoryTableRow(item, outcome, withdrawals);
  });
  for (const outcome of errorOutcomes) {
    if (!usedOutcomes.has(historyOutcomeKey(outcome))) rows.push(renderOrphanErrorHistoryTableRow(outcome));
  }
  const unclassified = Number(errorStats.unclassified || 0);
  const summaryItems = [
    { label: "エラーなし", value: `${Number(errorStats.noError || 0)}件`, tone: "good" },
    { label: "初日", value: `${Number(errorStats.day1 || 0)}件`, tone: "error" },
    { label: "2日目以降", value: `${Number(errorStats.day2Plus || 0)}件`, tone: "error" },
    ...(unclassified ? [{ label: "判定待ち", value: `${unclassified}件`, tone: "pending" }] : []),
    { label: "ERROR率", value: errorStats.rateLabel || "-", tone: Number(errorStats.error || 0) ? "error" : "good" },
  ];
  return `
    <section class="device-history-sheet task">
      <div class="device-history-sheet-head">
        <h4>稼働・タスク履歴</h4>
        ${historyRateStrip(summaryItems, "ERROR集計")}
      </div>
      <div class="device-history-table-wrap task-history-scroll" tabindex="0">
        <table class="device-history-table task-history-table">
          <colgroup>
            <col class="col-start"><col class="col-end"><col class="col-sequence"><col class="col-status"><col class="col-day">
            <col class="col-ci"><col class="col-video"><col class="col-video10"><col class="col-error"><col class="col-money"><col class="col-memo">
          </colgroup>
          <thead><tr><th>開始</th><th>終了</th><th>回</th><th>状態</th><th>DAY</th><th>チェックイン</th><th>動画180分</th><th>追加視聴</th><th>ERROR</th><th>収益</th><th>メモ</th></tr></thead>
          <tbody>${rows.length ? rows.join("") : historyEmptyTableRow(11)}</tbody>
        </table>
      </div>
    </section>
  `;
}

function renderTaskHistoryTableRow(item, outcome, withdrawals) {
  const range = taskHistoryDateRangeParts(item);
  const status = item.status === "active" ? "実行中" : item.status === "completed" ? "完了" : item.status || "記録";
  const statusTone = item.status === "completed" ? "good" : item.status === "active" ? "active" : "";
  const payout = historyTaskPayout(item, withdrawals);
  const memo = historyTaskMemo(item, payout);
  return `<tr>
    <td>${esc(range.started || "-")}</td>
    <td>${esc(range.ended || "-")}</td>
    <td>${item.sequence ? `#${esc(item.sequence)}` : "-"}</td>
    <td class="history-table-tone ${esc(statusTone)}">${esc(status)}</td>
    <td class="history-table-tone day">${item.day ? `DAY${esc(String(item.day).padStart(2, "0"))}` : "-"}</td>
    <td>${historyTaskValueCell(item, "ci", "チェックイン")}</td>
    <td>${historyTaskValueCell(item, "video180", "動画180分", "V180_DONE")}</td>
    <td>${historyTaskValueCell(item, "video10", "追加視聴", "V10_DONE")}</td>
    ${historyTaskErrorCell(outcome, item.status)}
    <td class="history-table-tone money">${payout ? esc(yen(payout.amount)) : "-"}</td>
    <td class="history-table-memo" title="${esc(memo)}">${esc(memo)}</td>
  </tr>`;
}

function renderOrphanErrorHistoryTableRow(outcome) {
  const range = taskHistoryDateRangeParts(outcome);
  return `<tr class="history-orphan-error-row">
    <td>${esc(range.started || monthDayLabel(outcome.firstErrorAt || outcome.at || "") || "-")}</td>
    <td>${esc(range.ended || (outcome.provisional ? "進行中" : "-"))}</td>
    <td>${outcome.sequence ? `#${esc(outcome.sequence)}` : "-"}</td>
    <td>判定記録</td><td>-</td><td>-</td><td>-</td><td>-</td>
    ${historyTaskErrorCell(outcome, outcome.provisional ? "active" : "completed")}
    <td>-</td><td class="history-table-memo">ERROR判定履歴のみ</td>
  </tr>`;
}

function historyTaskOutcome(item, outcomes) {
  const own = Array.isArray(item?.errorOutcomes) ? item.errorOutcomes : [];
  const matches = own.length ? own : (Array.isArray(outcomes) ? outcomes : []).filter((outcome) =>
    (item?.cycleId && outcome?.cycleId === item.cycleId) ||
    (item?.sequence && outcome?.sequence && Number(outcome.sequence) === Number(item.sequence))
  );
  return matches.find((outcome) => ["day1", "day2plus"].includes(outcome?.category)) || matches[0] || null;
}

function historyOutcomeKey(outcome) {
  return String(outcome?.id || `${outcome?.cycleId || ""}:${outcome?.sequence || ""}:${outcome?.category || ""}:${outcome?.at || ""}`);
}

function historyTaskErrorCell(outcome, status) {
  if (!outcome) {
    const active = status === "active";
    return `<td class="history-error-cell pending"><strong>${active ? "判定中" : "判定待ち"}</strong></td>`;
  }
  const tone = outcome.category === "none" ? "good" : outcome.category === "unknown" ? "pending" : "error";
  const details = [
    outcome.firstErrorDay ? `DAY${String(outcome.firstErrorDay).padStart(2, "0")}` : "",
    outcome.firstErrorAt ? historyDateTimeLabel(outcome.firstErrorAt) : "",
    outcome.provisional ? "進行中" : "",
  ].filter(Boolean).join("  ");
  return `<td class="history-error-cell ${esc(tone)}"><strong>${esc(historyCompactErrorLabel(outcome))}</strong>${details ? `<small>${esc(details)}</small>` : ""}</td>`;
}

function historyCompactErrorLabel(outcome) {
  if (outcome?.category === "none") return "エラーなし";
  if (outcome?.category === "day1") return "初日ERROR";
  if (outcome?.category === "day2plus") return "2日目以降ERROR";
  return "判定待ち";
}

function historyTaskValueCell(item, field, label, doneTag = "") {
  const value = historyTaskValue(item?.[field], label);
  if (!value) return '<span class="history-table-empty">-</span>';
  const tags = Array.isArray(item?.tags) ? item.tags : [];
  const done = doneTag && tags.includes(doneTag);
  return `<strong>${esc(value)}</strong>${done ? '<small class="history-table-done">完了</small>' : ""}`;
}

function historyTaskPayout(item, withdrawals) {
  const matches = (Array.isArray(withdrawals) ? withdrawals : []).filter((withdrawal) =>
    (item?.cycleId && withdrawal?.cycleId === item.cycleId) ||
    (item?.sequence && withdrawal?.sequence && Number(withdrawal.sequence) === Number(item.sequence))
  );
  const amount = matches.reduce((sum, withdrawal) => sum + Number(withdrawal.amountYen || 0), 0);
  return amount > 0 ? { amount, count: matches.length } : null;
}

function historyTaskMemo(item, payout) {
  const parts = [];
  if (Number(item?.finalYen || 0) > 0) parts.push(`最終記録 ${yen(item.finalYen)}`);
  if (payout?.count > 1) parts.push(`出金 ${payout.count}件`);
  for (const reset of Array.isArray(item?.resetHistory) ? item.resetHistory : []) {
    const resetDetails = [
      monthDayLabel(reset.at || "") ? `リセット ${monthDayLabel(reset.at)}` : "リセット",
      reset.reason || "",
      Number(reset.amountYen || 0) > 0 ? yen(reset.amountYen) : "",
      ...historyTextParts(reset.summary),
    ].filter(Boolean);
    parts.push(resetDetails.join(" "));
  }
  return parts.join(" / ") || "-";
}

function historyInviteTable(entries, stats) {
  const rows = (Array.isArray(entries) ? entries.slice() : []).sort((a, b) => String(b?.at || "").localeCompare(String(a?.at || "")));
  return `
    <section class="device-history-sheet invite">
      <div class="device-history-sheet-head">
        <h4>招待検証</h4>
        ${historyRateStrip([
          { label: "成功", value: `${stats.success}件`, tone: "good" },
          { label: "失敗", value: `${stats.fail}件`, tone: "error" },
          { label: "成功率", value: stats.rateLabel, tone: stats.fail ? "" : "good" },
        ], "招待成功率")}
      </div>
      <div class="device-history-table-wrap invite-history-scroll" tabindex="0">
        <table class="device-history-table invite-history-table">
          <colgroup><col class="col-date"><col class="col-type"><col class="col-role"><col class="col-result"><col class="col-partner"><col class="col-sim"><col class="col-network"><col class="col-switch-day"><col class="col-method"><col class="col-os"><col class="col-uptime"><col class="col-note"></colgroup>
          <thead><tr><th>日付</th><th>招待</th><th>親 or 子</th><th>結果</th><th>相手</th><th>SIM</th><th>通信</th><th>切替DAY</th><th>導入方法</th><th>OS</th><th>UPTIME</th><th>備考</th></tr></thead>
          <tbody>${rows.length ? rows.map(renderInviteHistoryTableRow).join("") : historyEmptyTableRow(12)}</tbody>
        </table>
      </div>
    </section>
  `;
}

function renderInviteHistoryTableRow(entry) {
  if (entry?.legacy) {
    return `<tr><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td class="history-table-memo">${esc(entry.text || "記録なし")}</td></tr>`;
  }
  const partner = invitePartnerLabel(entry?.partner) || entry?.partner || "-";
  const result = entry?.result || "-";
  const resultTone = /成功|OK/i.test(result) ? "good" : /失敗|NG/i.test(result) ? "error" : "";
  return `<tr>
    <td>${esc(monthDayLabel(entry?.at || "") || "-")}</td>
    <td>${esc(entry?.type || "-")}</td>
    <td>${esc(entry?.role || "-")}</td>
    <td class="history-table-tone ${esc(resultTone)}">${esc(result)}</td>
    <td class="history-table-partner" title="${esc(partner)}">${esc(partner)}</td>
    <td>${esc(entry?.simStatus || "-")}</td>
    <td>${esc(entry?.networkType || "-")}</td>
    <td>${entry?.networkSwitchedDay ? `DAY${esc(String(entry.networkSwitchedDay).padStart(2, "0"))}` : "-"}</td>
    <td>${esc(entry?.ttlRegisterMethod || "-")}</td>
    <td>${esc(formatOsVersion(entry?.osVersion) || "-")}</td>
    <td>${esc(historyRecordedUptime(entry?.uptimeSeconds))}</td>
    <td class="history-table-memo" title="${esc(entry?.note || "-")}">${esc(entry?.note || "-")}</td>
  </tr>`;
}

function historyRecordedUptime(seconds) {
  if (seconds === null || seconds === undefined || seconds === "") return "-";
  const value = Number(seconds);
  if (!Number.isFinite(value) || value < 0) return "-";
  return `UPTIME ${uptimeLabel(value / 3600)}`;
}

function historyWithdrawalTable(withdrawals) {
  const rows = Array.isArray(withdrawals) ? withdrawals : [];
  return `
    <section class="device-history-sheet money">
      <div class="device-history-sheet-head"><h4>出金・個別収益</h4><span class="history-sheet-count">${esc(rows.length)}件</span></div>
      <div class="device-history-table-wrap withdrawal-history-scroll" tabindex="0">
        <table class="device-history-table withdrawal-history-table">
          <colgroup><col class="col-date"><col class="col-money"><col class="col-site"><col class="col-day"><col class="col-reflect"><col class="col-cycle"><col class="col-note"></colgroup>
          <thead><tr><th>日付</th><th>金額</th><th>拠点</th><th>DAY</th><th>反映</th><th>稼働回</th><th>内容</th></tr></thead>
          <tbody>${rows.length ? rows.map(renderWithdrawalHistoryTableRow).join("") : historyEmptyTableRow(7)}</tbody>
        </table>
      </div>
    </section>
  `;
}

function renderWithdrawalHistoryTableRow(row) {
  const reflected = row.resetDone || row.resetDoneAt ? "非稼働反映済" : "記録のみ";
  return `<tr>
    <td>${esc(monthDayLabel(row.withdrawalDate || row.recordedAt || "") || "-")}</td>
    <td class="history-table-tone money">${esc(yen(row.amountYen))}</td>
    <td>${esc(row.siteName || "-")}</td>
    <td class="history-table-tone day">${row.day ? `DAY${esc(String(row.day).padStart(2, "0"))}` : "-"}</td>
    <td class="history-table-tone ${row.resetDone || row.resetDoneAt ? "good" : ""}">${esc(reflected)}</td>
    <td>${row.sequence ? `#${esc(row.sequence)}` : esc(row.cycleId || "-")}</td>
    <td class="history-table-memo" title="${esc(toJapaneseMemo(row.memo) || "-")}">${esc(toJapaneseMemo(row.memo) || "-")}</td>
  </tr>`;
}

function historyEmptyTableRow(columns) {
  return `<tr class="history-table-empty-row"><td colspan="${Number(columns)}">記録なし</td></tr>`;
}

function historyInfoSheet(title, cards, kind = "") {
  const chunks = [];
  for (let index = 0; index < cards.length; index += 6) chunks.push(cards.slice(index, index + 6));
  const body = chunks.map((chunk) => `
    <tr class="history-info-labels">${chunk.map((card) => `<th>${esc(card.label)}</th>`).join("")}${"<th></th>".repeat(6 - chunk.length)}</tr>
    <tr class="history-info-values">${chunk.map((card) => `<td class="${esc(card.tone || "")}" title="${esc(`${card.label}: ${card.value || "-"}`)}">${esc(card.value || "-")}</td>`).join("")}${"<td></td>".repeat(6 - chunk.length)}</tr>
  `).join("");
  return `
    <section class="device-history-sheet info ${esc(kind)}">
      <div class="device-history-sheet-head"><h4>${esc(title)}</h4></div>
      <div class="device-history-table-wrap history-info-scroll" tabindex="0">
        <table class="device-history-info-table"><tbody>${body}</tbody></table>
      </div>
    </section>
  `;
}

function historyDeviceCurrentCards(row, live) {
  const install = historyDeviceInstallSnapshot(row);
  const connectionStats = row.connectionIncidentStats || {};
  const recoveryStats = row.recoveryAttemptStats || {};
  return [
    { label: "番号", value: row.laixiNumber || row.xiaoweiNumber || "-" },
    { label: "XiaoWei名", value: row.laixiName || row.xiaoweiName || "-" },
    { label: "マスタ", value: row.deviceName || "-" },
    { label: "短縮名", value: row.modelGroup || row.shortNameOverride || "-" },
    { label: "端末ID", value: row.serial || "-" },
    { label: "XiaoWei番号", value: row.xiaoweiNumber || row.laixiNumber || "-" },
    { label: "キャリア", value: row.carrierCode || "未設定" },
    { label: "状態", value: historyStatusLabel(row.status), tone: String(row.status || "").toLowerCase() },
    { label: "OS", value: formatOsVersion(row.deviceOsVersion || row.osVersion) || "未取得" },
    { label: "SIM", value: row.deviceSimStatus || row.simStatus || "未設定" },
    { label: "通信", value: row.deviceNetworkType || row.networkType || "未設定" },
    { label: "切替日", value: row.networkSwitchedDay ? `DAY${row.networkSwitchedDay}` : "記録なし" },
    { label: "UPTIME", value: live.uptimeText || "未取得" },
    { label: "電池", value: live.batteryText || "未取得" },
    { label: "ADB", value: live.adbText || "未確認", tone: live.adbText === "ADB OFFLINE" ? "error" : "good" },
    { label: "切断履歴", value: `${Number(connectionStats.total || 0)}件`, tone: connectionStats.chronic ? "error" : "" },
    { label: "30日以内", value: `${Number(connectionStats.last30Days || 0)}件`, tone: connectionStats.chronic ? "error" : "" },
    { label: "直近切断", value: connectionStats.latestAt ? historyDateTimeLabel(connectionStats.latestAt) : "記録なし" },
    { label: "復旧実行", value: `${Number(recoveryStats.total || 0)}回`, tone: recoveryStats.repeated ? "error" : "" },
    { label: "直近復旧操作", value: recoveryStats.latestAt ? historyDateTimeLabel(recoveryStats.latestAt) : "記録なし" },
    { label: "初期設定", value: install.initialSettings },
    { label: "アプリ", value: install.appState },
    { label: "Agent", value: install.agent },
    { label: "初回登録", value: row.firstSeenAt ? formatDateTime(row.firstSeenAt) : "記録なし" },
    { label: "最終認識", value: row.lastSeenAt ? formatDateTime(row.lastSeenAt) : "記録なし" },
    { label: "元の名前", value: row.originalName || "記録なし" },
  ];
}

function historyDeviceInstallSnapshot(row) {
  const settings = row.deviceSettings && typeof row.deviceSettings === "object" ? row.deviceSettings : {};
  const baselineChecks = [
    settings.emergencyAlertsOff?.observed,
    settings.autoRotateOff?.observed,
    settings.dataSaverOn?.observed,
    settings.nfcOff?.observed,
    settings.silentOn?.observed,
  ];
  const completedSettings = baselineChecks.filter((value) => value === true).length;
  const checkedSettings = baselineChecks.filter((value) => value === true || value === false).length;
  const initialSettings = completedSettings === baselineChecks.length
    ? "完了"
    : checkedSettings ? `${completedSettings}/${baselineChecks.length}` : "未確認";
  const agent = row.swipeAgentInstalled === true
    ? row.swipeAgentAccessibilityEnabled === false ? "導入済・権限OFF" : "導入済"
    : row.swipeAgentInstalled === false ? "未導入" : "未確認";
  const appState = [
    row.ttlInstalled === true ? "TTL導入済" : row.ttlInstalled === false ? "TTLなし" : "TTL未確認",
    row.lineInstalled === true ? "LINE導入済" : row.lineInstalled === false ? "LINEなし" : "LINE未確認",
  ].join("  ");
  return { initialSettings, agent, appState };
}

function historyInviteCurrentCards(row, stats) {
  const result = row.inviteResult || "結果未設定";
  return [
    { label: "招待", value: row.inviteType || "招待未設定" },
    { label: "親 or 子", value: row.inviteRole || "親子未設定" },
    { label: "結果", value: result, tone: /成功|OK/i.test(result) ? "good" : /失敗|NG/i.test(result) ? "error" : "" },
    { label: "相手", value: invitePartnerLabel(row.invitePartner) || "相手未設定" },
    { label: "SIM", value: row.simStatus || "未設定" },
    { label: "通信", value: row.networkType || "未設定" },
    { label: "導入方法", value: row.ttlRegisterMethod || "未設定" },
    { label: "OS", value: formatOsVersion(row.osVersion) || "未取得" },
    { label: "成功", value: `${stats.success}件`, tone: "good" },
    { label: "失敗", value: `${stats.fail}件`, tone: stats.fail ? "error" : "" },
    { label: "成功率", value: stats.rateLabel, tone: stats.fail ? "" : "good" },
    { label: "Wi-Fi切替DAY", value: row.networkSwitchedDay ? `DAY${row.networkSwitchedDay}` : "記録なし" },
  ];
}

async function retireDeviceFromHistory(row, button = null) {
  const number = row?.laixiNumber || row?.xiaoweiNumber || "-";
  const name = row?.deviceLabel || row?.laixiName || row?.deviceName || row?.serial || "端末";
  if (!window.confirm(`${number} / ${name} を管理対象から外しますか？\n履歴を残したまま、空いている9000番台へ移します。`)) return;
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/fleet-db/devices/retire", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ device: row.serial || row.managementId, reason: "管理画面から手動で除外" }),
    });
    logLine(`管理対象外: ${number} → ${result.device?.xiaoweiNumber || "9000番台"} / ${name} / 履歴保存済 / バックアップ ${result.backup || "-"}`);
    closeDeviceHistoryDialog();
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine("管理対象外 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function showRetiredDevicesDialog(button = null) {
  setBusy(true, button);
  let result = null;
  try {
    result = await fetchJson("/api/fleet-db/retired-devices");
  } catch (error) {
    logLine("管理対象外一覧 NG: " + error.message);
    result = { ok: false, devices: [], error: error.message };
  } finally {
    setBusy(false);
  }
  closeAdbDropDialog();
  const rows = Array.isArray(result.devices) ? result.devices : [];
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog retired-devices-dialog" role="dialog" aria-modal="true" aria-labelledby="retiredDevicesDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="retiredDevicesDialogTitle">管理対象外（9000番台）</h3>
          <p>${esc(rows.length)}台 / 履歴はDBに保存されています</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      ${rows.length ? `
        <div class="adb-missing-table-wrap">
          <table class="adb-missing-table retired-devices-table">
            <thead><tr><th>番号</th><th>端末名</th><th>外した日時</th><th>理由</th><th>端末ID</th><th></th></tr></thead>
            <tbody>${rows.map((row) => `
              <tr>
                <td><strong>${esc(row.xiaoweiNumber || "-")}</strong>${row.retiredFromXiaoweiNumber ? `<span>元 ${esc(row.retiredFromXiaoweiNumber)}</span>` : ""}</td>
                <td><strong>${esc(row.deviceLabel || row.deviceName || "端末名なし")}</strong><span>履歴 ${esc(row.historyCount || 0)}件</span></td>
                <td>${esc(formatDateTime(row.retiredAt || ""))}</td>
                <td>${esc(row.retiredReason || "-")}</td>
                <td><code>${esc(row.serial || "")}</code></td>
                <td><button class="section-head-action restore-retired-device-action" data-device="${esc(row.serial || row.managementId || "")}" type="button">一覧へ戻す</button></td>
              </tr>
            `).join("")}</tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">管理対象外の端末はありません。</div>`}
      <div class="adb-drop-actions"><button class="section-head-action adb-drop-close-action" type="button">閉じる</button></div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".restore-retired-device-action").forEach((restoreButton) => {
    restoreButton.addEventListener("click", () => restoreRetiredDevice(restoreButton.dataset.device, restoreButton));
  });
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((closeButton) => {
    closeButton.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

async function restoreRetiredDevice(device, button = null) {
  if (!window.confirm("この端末を管理一覧へ戻しますか？")) return;
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/fleet-db/devices/restore", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ device }),
    });
    logLine(`管理対象へ復帰: ${result.device?.xiaoweiNumber || "-"} / ${device}`);
    await loadLocalSummaryOnly();
    await showRetiredDevicesDialog();
  } catch (error) {
    logLine("管理対象への復帰 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function historySection(title, count, lines, kind = "") {
  const body = lines.length
    ? lines.map((line) => `<li>${line}</li>`).join("")
    : `<li class="empty"><span>記録なし</span></li>`;
  return `
    <section class="device-history-section ${esc(kind)}">
      <h4>${esc(title)}<span>${esc(count)}件</span></h4>
      <ul>${body}</ul>
    </section>
  `;
}

function historyIdentityLine(row) {
  const chips = [
    ["番号", row.laixiNumber || row.xiaoweiNumber || "-", "number"],
    ["XiaoWei名", row.laixiName || row.xiaoweiName || "-", "xiaowei"],
    ["マスタ", row.deviceName || "-", "master"],
    ["端末ID", row.serial || "-", "serial"],
  ];
  return `<div class="device-history-identity">${chips.map(([label, value, tone]) => `
    <span class="${esc(tone)}"><small>${esc(label)}</small><b>${esc(value)}</b></span>
  `).join("")}</div>`;
}

function historySummaryBlock(title, cards, kind = "") {
  return `
    <section class="device-history-summary-block ${esc(kind)}">
      <h4>${esc(title)}</h4>
      <div class="device-history-summary">
        ${cards.map((card) => {
          const value = card.value || "-";
          const classes = [card.tone || "", card.className || ""].filter(Boolean).join(" ");
          return `<div class="${esc(classes)}" title="${esc(`${card.label}: ${value}`)}"><span>${esc(card.label)}</span><strong>${esc(value)}</strong></div>`;
        }).join("")}
      </div>
    </section>
  `;
}

function historyDeviceSummary(row, live) {
  const settings = row.deviceSettings && typeof row.deviceSettings === "object" ? row.deviceSettings : {};
  const baselineChecks = [
    settings.emergencyAlertsOff?.observed,
    settings.autoRotateOff?.observed,
    settings.dataSaverOn?.observed,
    settings.nfcOff?.observed,
    settings.silentOn?.observed,
  ];
  const completedSettings = baselineChecks.filter((value) => value === true).length;
  const checkedSettings = baselineChecks.filter((value) => value === true || value === false).length;
  const initialSettings = completedSettings === baselineChecks.length
    ? "完了"
    : checkedSettings ? `${completedSettings}/${baselineChecks.length}` : "未確認";
  const agent = row.swipeAgentInstalled === true
    ? row.swipeAgentAccessibilityEnabled === false ? "導入済・権限OFF" : "導入済"
    : row.swipeAgentInstalled === false ? "未導入" : "未確認";
  const appState = [
    row.ttlInstalled === true ? "TTL導入済" : row.ttlInstalled === false ? "TTLなし" : "TTL未確認",
    row.lineInstalled === true ? "LINE導入済" : row.lineInstalled === false ? "LINEなし" : "LINE未確認",
  ].join("  ");
  return historySummaryBlock("端末情報", [
    { label: "状態", value: historyStatusLabel(row.status), tone: String(row.status || "").toLowerCase() },
    { label: "OS", value: formatOsVersion(row.deviceOsVersion || row.osVersion) || "未取得" },
    { label: "SIM", value: row.deviceSimStatus || row.simStatus || "未設定" },
    { label: "通信", value: row.deviceNetworkType || row.networkType || "未設定" },
    { label: "UPTIME", value: live.uptimeText || "未取得" },
    { label: "電池", value: live.batteryText || "未取得" },
    { label: "ADB", value: live.adbText || "未確認", tone: live.adbText === "ADB OFFLINE" ? "warn" : "" },
    { label: "初期設定", value: initialSettings },
    { label: "アプリ", value: appState },
    { label: "Agent", value: agent },
    { label: "初回登録", value: row.firstSeenAt ? formatDateTime(row.firstSeenAt) : "記録なし" },
    { label: "最終認識", value: row.lastSeenAt ? formatDateTime(row.lastSeenAt) : "記録なし" },
  ], "device");
}

function historyStatusLabel(status) {
  const value = String(status || "UNKNOWN").toUpperCase();
  if (["WAITING", "INACTIVE", "NO CYCLE"].includes(value)) return "非稼働";
  if (value === "ONLINE") return "ONLINE";
  if (value === "ACTIVE") return "稼働中";
  return value;
}

function historyErrorSummary(stats = {}) {
  return historySummaryBlock("ERROR集計", [
    { label: "ERROR率", value: stats.rateLabel || "-", tone: Number(stats.error || 0) ? "warn" : "good" },
    { label: "集計対象", value: `${Number(stats.total || 0)}件` },
    { label: "エラーなし", value: `${Number(stats.noError || 0)}件`, tone: "good" },
    { label: "初日にエラー", value: `${Number(stats.day1 || 0)}件`, tone: "warn" },
    { label: "2日目以降", value: `${Number(stats.day2Plus || 0)}件`, tone: "warn" },
    { label: "旧履歴・判定待ち", value: `${Number(stats.unclassified || 0)}件`, tone: Number(stats.unclassified || 0) ? "pending" : "" },
  ], "error");
}

function historyInviteSummary(row, stats) {
  const type = row.inviteType || "招待未設定";
  const result = row.inviteResult || "結果未設定";
  const role = row.inviteRole || "親子未設定";
  const partner = invitePartnerLabel(row.invitePartner) || "相手未設定";
  return historySummaryBlock("招待検証・現在値", [
    { label: "招待", value: type },
    { label: "親or子", value: role },
    { label: "結果", value: result, tone: /成功|OK/i.test(result) ? "good" : /失敗|NG/i.test(result) ? "warn" : "" },
    { label: "相手", value: partner, className: "history-partner-card" },
    { label: "SIM", value: row.simStatus || "未設定" },
    { label: "通信", value: row.networkType || "未設定" },
    { label: "導入方法", value: row.ttlRegisterMethod || "未設定" },
    { label: "OS", value: formatOsVersion(row.osVersion) || "未取得" },
    { label: "成功率", value: stats.rateLabel },
    { label: "成功", value: `${stats.success}件`, tone: "good" },
    { label: "失敗", value: `${stats.fail}件`, tone: stats.fail ? "warn" : "" },
    { label: "Wi-Fi切替DAY", value: row.networkSwitchedDay ? `DAY${row.networkSwitchedDay}` : "記録なし" },
  ], "invite");
}

function inviteHistoryStats(row, entries = []) {
  let success = 0;
  let fail = 0;
  for (const entry of entries) {
    const result = String(entry?.result || entry?.text || "");
    if (/成功|OK/i.test(result)) success += 1;
    if (/失敗|NG/i.test(result)) fail += 1;
  }
  if (!entries.length) {
    if (["成功", "OK"].includes(row.inviteResult)) success = 1;
    if (["失敗", "NG"].includes(row.inviteResult)) fail = 1;
  }
  const total = success + fail;
  const rateLabel = total ? `${Math.round((success / total) * 100)}%` : "-";
  return { success, fail, rateLabel };
}

function invitePartnerLabel(value) {
  const target = String(value || "");
  if (!target) return "";
  const row = (state.summary?.devices || []).find((item) =>
    String(item.serial || "") === target || String(item.managementId || "") === target || String(item.laixiNumber || "") === target
  );
  if (!row) return target;
  return invitePartnerOptionLabel(row) || target;
}

function currentHistoryAdbState(row) {
  const devices = Array.isArray(state.adbDevices?.devices) ? state.adbDevices.devices : [];
  const hasSnapshot = Boolean(state.adbDevices && !state.adbDevices.skipped && Array.isArray(state.adbDevices.devices));
  const serial = String(row?.serial || "");
  const adb = devices.find((device) => String(device?.serial || "") === serial);
  const connected = hasSnapshot && serial
    ? Boolean(adb && (adb.status === "device" || adb.connected === true))
    : row?.adbConnected === true ? true : row?.adbConnected === false ? false : null;
  return {
    connected,
    uptimeSeconds: adb?.uptimeSeconds ?? row?.adbUptimeSeconds ?? row?.adbLastUptimeSeconds,
    uptimeFetchedAt: adb?.uptimeFetchedAt ?? row?.adbUptimeFetchedAt ?? (Date.parse(row?.adbLastUptimeCheckedAt || "") || 0),
    batteryPercent: connected === false ? null : (adb?.batteryPercent ?? row?.batteryPercent ?? row?.adbLastBatteryPercent),
  };
}

function historyUptimeText(row, adbState = currentHistoryAdbState(row)) {
  const seconds = Number(adbState.uptimeSeconds);
  if (!Number.isFinite(seconds) || seconds < 0) return "UPTIME未取得";
  const value = currentUptimeValue(seconds, adbState.uptimeFetchedAt || Date.now());
  return `UPTIME ${uptimeLabel(value.hours)}`;
}

function historyBatteryText(row, adbState = currentHistoryAdbState(row)) {
  const value = adbState.batteryPercent;
  if (adbState.connected === false) return "電池 OFFLINE";
  if (value === "" || value === null || value === undefined) return "電池未取得";
  return `電池 ${value}%`;
}

function renderTaskHistoryLine(item) {
  const range = taskHistoryDateRangeParts(item);
  const dateText = [
    range.started ? `開始 ${range.started}` : "",
    range.ended ? `終了 ${range.ended}` : "",
  ].filter(Boolean).join("\n") || "-";
  const status = item.status === "active" ? "実行中" : item.status === "completed" ? "完了" : item.status || "記録";
  const details = [
    item.sequence ? { label: "回", value: `#${item.sequence}` } : null,
    { label: "状態", value: status, tone: item.status === "completed" ? "good" : "" },
    item.day ? { label: "DAY", value: `DAY${String(item.day).padStart(2, "0")}`, tone: "day" } : null,
    item.ci ? { label: "チェックイン", value: historyTaskValue(item.ci, "チェックイン") } : null,
    item.video180 ? { label: "動画180分", value: historyTaskValue(item.video180, "動画180分") } : null,
    item.video10 ? { label: "追加視聴", value: historyTaskValue(item.video10, "追加視聴") } : null,
  ].filter(Boolean);
  const resets = Array.isArray(item.resetHistory) ? item.resetHistory : [];
  for (const entry of resets) {
    details.push({
      label: `リセット ${monthDayLabel(entry.at || "") || ""}`.trim(),
      value: [
        entry.reason || "",
        entry.amountYen ? `${Number(entry.amountYen).toLocaleString("ja-JP")}円` : "",
      ].filter(Boolean).join("  ") || "実施",
      tone: "reset",
    });
    for (const part of historyTextParts(entry.summary)) {
      details.push({ label: "リセット内容", value: part, tone: "reset" });
    }
  }
  if (!details.length) details.push({ label: "記録", value: item.text || item.cycleId || "記録なし", wide: true });
  return historyTimelineRow(dateText, details);
}

function historyTaskValue(value, label) {
  return String(value || "").replace(new RegExp(`^${label}\\s*`), "") || String(value || "");
}

function renderErrorHistoryLine(outcome) {
  const range = taskHistoryDateRangeParts(outcome);
  const dateText = [
    range.started ? `開始 ${range.started}` : "",
    range.ended ? `終了 ${range.ended}` : outcome.provisional ? "進行中" : "",
  ].filter(Boolean).join("\n") || monthDayLabel(outcome.firstErrorAt || outcome.at || "") || "-";
  const label = errorOutcomeLabel(outcome);
  const details = [
    { label: "判定", value: label, tone: outcome.category === "none" ? "good" : outcome.category === "unknown" ? "pending" : "error" },
    outcome.firstErrorDay ? { label: "初回発生DAY", value: `DAY${String(outcome.firstErrorDay).padStart(2, "0")}`, tone: "day" } : null,
    outcome.firstErrorAt ? { label: "初回発生", value: historyDateTimeLabel(outcome.firstErrorAt), tone: "error" } : null,
    { label: "記録状態", value: outcome.provisional ? "進行中" : "確定", tone: outcome.provisional ? "pending" : "" },
    outcome.sequence ? { label: "回", value: `#${outcome.sequence}` } : null,
  ].filter(Boolean);
  return historyTimelineRow(dateText, details);
}

function errorOutcomeLabel(outcome) {
  if (outcome?.category === "none") return "エラー出なかった";
  if (outcome?.category === "day1") return "初日にエラー発生";
  if (outcome?.category === "day2plus") return "2日目以降にエラー発生";
  return "旧履歴・初回DAY判定待ち";
}

function taskHistoryDateRangeParts(item) {
  const started = monthDayLabel(item?.operationStartedAt || item?.startedAt || "");
  const ended = monthDayLabel(item?.operationEndedAt || item?.endedAt || "");
  return { started, ended };
}

function monthDayLabel(value) {
  const text = String(value || "").trim();
  if (!text) return "";
  const direct = /^(\d{4})-(\d{2})-(\d{2})/.exec(text);
  if (direct) return `${direct[2]}/${direct[3]}`;
  const date = new Date(text);
  if (Number.isNaN(date.getTime())) return "";
  const pad = (number) => String(number).padStart(2, "0");
  return `${pad(date.getMonth() + 1)}/${pad(date.getDate())}`;
}

function historyDateTimeLabel(value) {
  const date = new Date(String(value || ""));
  if (Number.isNaN(date.getTime())) return monthDayLabel(value) || "記録なし";
  const pad = (number) => String(number).padStart(2, "0");
  return `${pad(date.getMonth() + 1)}/${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function renderWithdrawalHistoryLine(row) {
  const dateText = monthDayLabel(row.withdrawalDate || row.recordedAt || "") || "-";
  const details = [
    row.siteName ? { label: "拠点", value: row.siteName } : null,
    row.amountYen ? { label: "金額", value: yen(row.amountYen), tone: "money" } : null,
    row.day ? { label: "DAY", value: `DAY${String(row.day).padStart(2, "0")}`, tone: "day" } : null,
    row.resetDone || row.resetDoneAt ? { label: "反映", value: "非稼働反映済", tone: "good" } : null,
    row.memo ? { label: "内容", value: toJapaneseMemo(row.memo), wide: true } : null,
  ].filter(Boolean);
  return historyTimelineRow(dateText, details);
}

function renderInviteHistoryLine(entry) {
  if (entry && !entry.legacy) {
    const dateText = monthDayLabel(entry.at || "") || "-";
    const partner = invitePartnerLabel(entry.partner) || entry.partner || "";
    return historyTimelineRow(dateText, [
      entry.type ? { label: "招待", value: entry.type } : null,
      entry.role ? { label: "親or子", value: entry.role } : null,
      entry.result ? { label: "結果", value: entry.result, tone: /成功|OK/i.test(entry.result) ? "good" : /失敗|NG/i.test(entry.result) ? "error" : "" } : null,
      partner ? { label: "相手", value: partner, wide: true } : null,
      entry.simStatus ? { label: "SIM", value: entry.simStatus } : null,
      entry.networkType ? { label: "通信", value: entry.networkType } : null,
      entry.networkSwitchedDay ? { label: "切替DAY", value: `DAY${String(entry.networkSwitchedDay).padStart(2, "0")}` } : null,
      entry.ttlRegisterMethod ? { label: "導入方法", value: entry.ttlRegisterMethod } : null,
      entry.osVersion ? { label: "OS", value: formatOsVersion(entry.osVersion) } : null,
      entry.note ? { label: "備考", value: entry.note, wide: true } : null,
    ].filter(Boolean));
  }
  const text = String(entry?.text || entry || "").trim();
  const match = /^(\d{4}-\d{2}-\d{2}|\d{1,2}\/\d{1,2})\s*(.*)$/.exec(text);
  const details = historyTextParts(match ? match[2] || text : text).map((value) => ({ label: "記録", value, wide: true }));
  if (match) return historyTimelineRow(monthDayLabel(match[1]) || match[1], details);
  return historyTimelineRow("-", details);
}

function historyTextParts(value) {
  return String(value || "")
    .split(/\s+\/\s+|\s*・\s*/)
    .map((part) => part.trim())
    .filter(Boolean);
}

function historyTimelineRow(dateText, details) {
  const rows = (Array.isArray(details) ? details : [{ label: "記録", value: details }]).filter((item) => item && (item.value || item.label));
  const body = rows.length ? rows.map(historyDetailChip).join("") : historyDetailChip({ label: "記録", value: "記録なし" });
  return `<div class="history-timeline-row"><div class="history-timeline-date">${esc(dateText)}</div><div class="history-timeline-detail">${body}</div></div>`;
}

function historyDetailChip(item) {
  const value = typeof item === "string" ? item : item.value;
  const label = typeof item === "string" ? "" : item.label;
  const classes = ["history-detail-chip", item?.tone || "", item?.wide ? "wide" : ""].filter(Boolean).join(" ");
  return `<span class="${esc(classes)}">${label ? `<small>${esc(label)}</small>` : ""}<b>${esc(value || "-")}</b></span>`;
}

function handleDeviceTaskSelectChange(event) {
  const select = event.target.closest(".device-task-select");
  if (!select) {
    handleDeviceNameInput(event);
    return;
  }
  const device = select.dataset.device || "";
  const kind = select.dataset.kind || "";
  const config = DEVICE_TASK_SELECTS[kind];
  if (!device || !config) return;
  const nextTag = select.value;
  const previous = select.dataset.original || "";
  const changed = nextTag !== previous;
  select.classList.toggle("changed-input", changed);
  select.classList.remove("input-error");
  select.title = changed ? "": "";
  updateDeviceNameSaveState();
}

function renderSwipeModeSelect(row) {
  const device = row.serial || row.managementId || "";
  const current = row.swipeModePreference || "auto";
  const recommendation = normalizeSwipeModeRecommendation(row);
  const options = [
    ["auto", ""],
    ["agent", "Agent推奨"],
    ["adb", "ADB推奨"],
    ["disabled", "無効"],
  ].map(([value, label]) =>
    `<option value="${esc(value)}" ${value === current ? "selected" : ""}>${esc(label)}</option>`
  ).join("");
  return `
    <div class="swipe-mode-cell">
      <select class="table-input device-edit-input swipe-mode-select" data-field="swipeModePreference" data-device="${esc(device)}" data-original="${esc(current)}">
        ${options}
      </select>
      ${swipeModeChip({ swipeModePreference: current, swipeModeRecommendation: recommendation })}
    </div>
  `;
}

function renderSwipeMethodCell(row) {
  return `
    <div class="swipe-method-stack">
      ${swipeAgentPill(row)}
      ${renderSwipeModeSelect(row)}
    </div>
  `;
}

function renderDeviceMaster(master) {
  const data = master && master.ok !== false ? master : { entries: [], counts: {} };
  const entries = Array.isArray(data.entries) ? data.entries : [];
  const query = (el("deviceMasterSearchInput")?.value || "").trim().toLowerCase();
  const filtered = entries.filter((entry) => {
    if (!query) return true;
    return [
      entry.shortName,
      entry.modelCode,
      entry.salesName,
      entry.maker,
      entry.carrierCode,
      entry.route,
    ].join(" ").toLowerCase().includes(query);
  });
  const excluded = data.counts?.excluded ?? (Array.isArray(data.excluded) ? data.excluded.length : 0);
  el("deviceMasterMeta").textContent = `${entries.length}件 / 表示 ${filtered.length}件 / 除外 ${excluded}件`;
  el("deviceMasterRows").innerHTML = filtered.slice(0, 800).map((entry) => `
    <tr data-master-id="${esc(entry.id || "")}">
      <td class="master-short-name">
        <input class="master-short-input" type="text" value="${esc(entry.shortName || "")}" data-id="${esc(entry.id || "")}" data-original="${esc(entry.shortName || "")}">
      </td>
      <td>${esc(entry.modelCode || "")}</td>
      <td>${esc(entry.salesName || "")}</td>
      <td>${esc(entry.maker || "")}</td>
      <td><span class="carrier-chip">${esc(entry.carrierCode || "UNKNOWN")}</span></td>
      <td>${esc(entry.route || "")}</td>
      <td>
        <span class="row-actions">
          <button class="icon-action edit-master-btn" data-id="${esc(entry.id || "")}" type="button">編集</button>
          <button class="icon-action danger-action delete-master-btn" data-id="${esc(entry.id || "")}" type="button">削除</button>
        </span>
      </td>
    </tr>
  `).join("");
}

async function loadDeviceMaster() {
  setBusy(true);
  logLine("端末マスタ再読込 実行中...");
  try {
    const result = await fetchJson("/api/device-master");
    state.deviceMaster = result;
    renderDeviceMaster(result);
    logLine(`端末マスタ再読込 OK: ${result.counts?.entries || 0}件`);
  } catch (error) {
    logLine("端末マスタ再読込 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function saveDeviceMasterEntry(event) {
  event.preventDefault();
  const entry = {
    id: el("deviceMasterIdInput").value,
    shortName: el("deviceMasterShortInput").value,
    modelCode: el("deviceMasterModelInput").value,
    salesName: el("deviceMasterSalesInput").value,
    maker: el("deviceMasterMakerInput").value,
    carrierCode: el("deviceMasterCarrierInput").value,
    route: el("deviceMasterRouteInput").value,
    source: el("deviceMasterIdInput").value ? "manual edit" : "manual",
  };
  if (!entry.shortName.trim() || !entry.salesName.trim()) {
    logLine("端末マスタ保存 NG: 短縮名と販売名を入力してください");
    return;
  }
  setBusy(true);
  logLine("端末マスタ保存 実行中...");
  try {
    const result = await fetchJson("/api/device-master/entries", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ entry }),
    });
    clearDeviceMasterForm();
    await refreshDeviceMasterAndLocalSummary();
    logLine(`端末マスタ保存 OK: ${result.entry?.shortName || ""} ${result.entry?.salesName || ""}${formatMasterRefreshLog(result.refresh)}`);
  } catch (error) {
    logLine("端末マスタ保存 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function handleDeviceMasterRowAction(event) {
  const editButton = event.target.closest(".edit-master-btn");
  const deleteButton = event.target.closest(".delete-master-btn");
  if (editButton) return startDeviceMasterEdit(editButton.dataset.id);
  if (deleteButton) return deleteDeviceMasterEntry(deleteButton.dataset.id);
}

function handleDeviceMasterInlineKeydown(event) {
  const input = event.target.closest(".master-short-input");
  if (!input) return;
  if (event.key === "Enter") {
    event.preventDefault();
    input.blur();
  }
  if (event.key === "Escape") {
    input.value = input.dataset.original || "";
    input.blur();
  }
}

async function handleDeviceMasterInlineChange(event) {
  const input = event.target.closest(".master-short-input");
  if (!input) return;
  const id = input.dataset.id || "";
  const entry = (state.deviceMaster?.entries || []).find((item) => item.id === id);
  if (!entry) return;
  const nextShort = input.value
    .trim()
    .replace(/[^ A-Za-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .slice(0, 24)
    .trim();
  input.value = nextShort;
  if (!nextShort) {
    input.value = input.dataset.original || "";
    logLine("端末マスタ保存 NG: 短縮名は空にできません");
    return;
  }
  if (nextShort === (input.dataset.original || "")) return;

  input.disabled = true;
  input.classList.add("saving");
  try {
    const result = await fetchJson("/api/device-master/entries", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ entry: { ...entry, shortName: nextShort, source: "inline shortName edit" } }),
    });
    await refreshDeviceMasterAndLocalSummary();
    logLine(`端末マスタ短縮名保存 OK: ${result.entry?.shortName || nextShort} ${entry.salesName || ""}${formatMasterRefreshLog(result.refresh)}`);
  } catch (error) {
    input.disabled = false;
    input.classList.remove("saving");
    input.classList.add("error");
    logLine("端末マスタ短縮名保存 NG: " + error.message);
  }
}

function startDeviceMasterEdit(id) {
  const entry = (state.deviceMaster?.entries || []).find((item) => item.id === id);
  if (!entry) return;
  el("deviceMasterIdInput").value = entry.id || "";
  el("deviceMasterShortInput").value = entry.shortName || "";
  el("deviceMasterModelInput").value = entry.modelCode || "";
  el("deviceMasterSalesInput").value = entry.salesName || "";
  el("deviceMasterMakerInput").value = entry.maker || "";
  el("deviceMasterCarrierInput").value = entry.carrierCode || "UNKNOWN";
  el("deviceMasterRouteInput").value = entry.route || "";
  el("deviceMasterCancelBtn").classList.remove("hidden");
  el("deviceMasterSaveBtn").textContent = "編集保存";
}

function clearDeviceMasterForm() {
  el("deviceMasterIdInput").value = "";
  el("deviceMasterShortInput").value = "";
  el("deviceMasterModelInput").value = "";
  el("deviceMasterSalesInput").value = "";
  el("deviceMasterMakerInput").value = "";
  el("deviceMasterCarrierInput").value = "UNKNOWN";
  el("deviceMasterRouteInput").value = "";
  el("deviceMasterCancelBtn").classList.add("hidden");
  el("deviceMasterSaveBtn").textContent = "マスタ保存";
}

async function deleteDeviceMasterEntry(id) {
  if (!id || !confirm("この端末マスタ行を削除しますか？")) return;
  setBusy(true);
  logLine("端末マスタ削除 実行中...");
  try {
    await fetchJson("/api/device-master/entries/delete", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id }),
    });
    await refreshDeviceMasterAndLocalSummary();
    logLine("端末マスタ削除 OK");
  } catch (error) {
    logLine("端末マスタ削除 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function importDeviceMasterCsv() {
  const csv = el("deviceMasterCsvInput").value.trim();
  if (!csv) {
    logLine("CSV取込 NG: CSVを貼り付けてください");
    return;
  }
  setBusy(true);
  logLine("CSV取込 実行中...");
  try {
    const result = await fetchJson("/api/device-master/import-csv", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ csv }),
    });
    el("deviceMasterCsvInput").value = "";
    await refreshDeviceMasterAndLocalSummary();
    logLine(`CSV取込 OK: ${result.imported || 0}件 / 除外 ${result.excluded || 0}件${formatMasterRefreshLog(result.refresh)}`);
  } catch (error) {
    logLine("CSV取込 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function formatMasterRefreshLog(refresh) {
  const sync = refresh?.codeSync;
  if (!sync) return "";
  const changedDevices = Number(sync.changedDevices || 0);
  const changedWithdrawals = Number(sync.changedWithdrawals || 0);
  if (!changedDevices && !changedWithdrawals) return " / 端末名変更なし";
  return ` / 端末名再取得 ${changedDevices}件`;
}

function sortDeviceRows(rows) {
  return rows.slice().sort(compareDeviceDayRows);
}

async function runDeviceNumberResequence(button = null, mode = "model") {
  const rows = state.summary?.devices || [];
  if (!rows.length) {
    window.alert("再採番する端末がありません。");
    return;
  }
  const dayMode = mode === "day";
  const label = dayMode ? "DAY順再採番" : "機種順再採番";
  const source = dayMode ? "day-order-resequence" : "model-order-resequence";
  const activeCount = rows.filter((row) => deviceOrderBand(row) === "active").length;
  const inactiveCount = rows.length - activeCount;
  const ok = window.confirm([
    dayMode
      ? "元の方式でメイン番号を振り直してXiaoWeiへ反映します。"
      : "メイン番号を機種順に振り直してXiaoWeiへ反映します。",
    dayMode
      ? `稼働 ${activeCount}台はDAYが大きい順に1番から、非稼働 ${inactiveCount}台は機種・キャリア順に1000番から再採番します。`
      : `稼働 ${activeCount}台は1番から、非稼働 ${inactiveCount}台は1000番から再採番します。`,
    "既存のメイン番号は変わる場合があります。",
    "名前連番（サブ番号）、DAY順、チェック状態は変更しません。",
    "続けますか？",
  ].join("\n"));
  if (!ok) return;

  setBusy(true, button);
  let dbUpdated = false;
  let flash = { message: "完了", type: "ok" };
  try {
    await applyPendingTagBoardChangesBeforeXiaoweiSync();
    const result = await fetchJson("/api/fleet-db/device-order", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ order: [], source, numberingMode: mode }),
    });
    dbUpdated = true;
    logLine(`${label} DB OK: メイン番号変更 ${(result.numberChanges || []).length}台 / 名前連番・DAY順維持`);

    try {
      const syncResult = await fetchJson("/api/xiaowei/numbers/sync", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ apply: true }),
      });
      logLine(`${label} XiaoWei反映 OK: 対象 ${syncResult.logicalRequested ?? syncResult.requested ?? 0}件 / 成功 ${syncResult.succeeded || 0} / 失敗 ${syncResult.failed || 0}`);
      if (Number(syncResult.failed || 0) > 0) flash = { message: "要確認", type: "warn" };
    } catch (syncError) {
      flash = { message: "同期待ち", type: "warn" };
      logLine(`${label} XiaoWei反映 NG: ${syncError.message}`);
      window.alert(`メイン番号はDBへ${dayMode ? "元のDAY順方式" : "機種順"}で保存しましたが、XiaoWeiへの反映に失敗しました。\n${syncError.message}\n接続確認後に「XiaoWei番号反映」を実行してください。`);
    }
    await loadLocalSummaryOnly();
    reloadTagBoardFrame();
  } catch (error) {
    logLine(`${label} ${dbUpdated ? "確認" : "NG"}: ${error.message}`);
    flash = { message: "失敗", type: "error" };
    if (!dbUpdated) window.alert(`${label}に失敗しました。\n${error.message}`);
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

function compareDeviceDayRows(a, b) {
  const band = deviceOrderBandRank(a) - deviceOrderBandRank(b);
  if (band) return band;
  if (deviceOrderBand(a) === "active") {
    const day = Number(b?.day || 0) - Number(a?.day || 0);
    if (day) return day;
  } else {
    const number = managementNumber(a) - managementNumber(b);
    if (number) return number;
  }
  return naturalDeviceRowCompare(a, b);
}

function deviceOrderBand(row) {
  const tags = Array.isArray(row?.tags) ? row.tags.map((tag) => String(tag).toUpperCase()) : [];
  const status = String(row?.status || "").toUpperCase();
  if (tags.includes("WAITING") || tags.includes("GROUP_REST") || tags.includes("GROUP_INACTIVE") || status === "WAITING" || status === "INACTIVE") {
    return "inactive";
  }
  if (tags.includes("GROUP_ACTIVE") || Number(row?.day || 0) > 0) {
    return "active";
  }
  return "inactive";
}

function deviceOrderBandRank(row) {
  return deviceOrderBand(row) === "active" ? 0 : 1;
}

function naturalDeviceRowCompare(a, b) {
  const keyA = String(a.modelGroup || a.deviceDisplayCode || a.deviceLabel || a.laixiName || a.deviceName || a.serial || "").trim();
  const keyB = String(b.modelGroup || b.deviceDisplayCode || b.deviceLabel || b.laixiName || b.deviceName || b.serial || "").trim();
  const rank = naturalDeviceNameRank(keyA) - naturalDeviceNameRank(keyB);
  if (rank) return rank;
  return keyA.localeCompare(keyB, "en", { numeric: true, sensitivity: "base" })
    || String(a.carrierCode || "").localeCompare(String(b.carrierCode || ""), "en", { numeric: true })
    || managementNumber(a) - managementNumber(b)
    || String(a.serial || "").localeCompare(String(b.serial || ""), "en", { numeric: true });
}

function naturalDeviceNameRank(value) {
  const first = String(value || "").trim().charAt(0);
  if (/\d/.test(first)) return 0;
  if (/[A-Za-z]/.test(first)) return 1;
  return 2;
}

function managementNumber(row) {
  const id = String(row.laixiNumber || row.managementId || row.xiaoweiSort || "");
  const match = /(\d+)/.exec(id);
  return match ? Number(match[1]) : 9999;
}

function openDeviceNameSequenceDialog() {
  closeDeviceNameSequenceDialog();
  const rows = sortDeviceRows(state.summary?.devices || []).filter((row) => deviceNameSequence(row));
  const sequenceById = new Map(rows.map((row) => [
    String(row.serial || row.managementId || ""),
    String(deviceNameSequence(row)).padStart(2, "0"),
  ]).filter(([id]) => id));
  const originalById = new Map(sequenceById);
  const overlay = document.createElement("div");
  overlay.className = "custom-order-backdrop";
  overlay.innerHTML = `
    <div class="custom-order-dialog" role="dialog" aria-modal="true" aria-labelledby="deviceNameSequenceTitle">
      <div class="custom-order-head">
        <div><h3 id="deviceNameSequenceTitle">XiaoWei名の連番変更</h3><p>A25-01などの末尾連番を01〜999で変更します。メイン番号とXiaoWeiの機種順は変わりません。</p></div>
        <button class="custom-order-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="custom-order-tools">
        <input class="custom-order-search" type="search" placeholder="メイン番号・機種名・端末IDで検索">
        <span class="custom-order-count"></span>
      </div>
      <div class="custom-order-selected"></div>
      <div class="custom-order-list"></div>
      <div class="custom-order-actions">
        <span class="spacer"></span>
        <button class="custom-order-cancel" type="button">キャンセル</button>
        <button class="custom-order-save primary-action" type="button">連番を保存・同期</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const search = overlay.querySelector(".custom-order-search");
  const list = overlay.querySelector(".custom-order-list");
  const selectedPanel = overlay.querySelector(".custom-order-selected");
  const count = overlay.querySelector(".custom-order-count");

  const labelFor = (row) => [
    `No.${row.laixiNumber || row.xiaoweiNumber || row.xiaoweiSort || "-"}`,
    row.deviceLabel || row.deviceDisplayCode || row.laixiName || row.deviceName,
    row.serial ? `ID:${row.serial}` : "",
  ].filter(Boolean).join(" / ");
  function render() {
    const activeCount = rows.filter((row) => deviceOrderBand(row) === "active").length;
    const inactiveCount = rows.length - activeCount;
    count.textContent = `全 ${rows.length}台`;
    selectedPanel.innerHTML = `<div class="custom-order-band-summary"><strong>表示名だけ変更</strong><span>稼働 ${activeCount}台</span><span>非稼働 ${inactiveCount}台</span><span>メイン番号・機種順を維持</span><span>DB・チェック一覧はDAY順</span></div>`;
    const query = String(search.value || "").trim().toLowerCase();
    const visibleRows = rows.filter((row) => {
      const id = String(row.serial || row.managementId || "");
      const searchable = `${sequenceById.get(id) || ""} ${row.managementId || ""} ${labelFor(row)}`.toLowerCase();
      return !query || searchable.includes(query);
    });
    list.innerHTML = [
      { key: "active", label: "稼働端末", range: "DAY順" },
      { key: "inactive", label: "非稼働端末", range: "メイン番号順" },
    ].map((group) => {
      const groupRows = visibleRows.filter((row) => deviceOrderBand(row) === group.key);
      if (!groupRows.length) return "";
      return `<section class="custom-order-list-band" data-order-band="${group.key}"><h4>${group.label} <span>${group.range} / ${groupRows.length}台</span></h4>${groupRows.map((row) => {
        const id = String(row.serial || row.managementId || "");
        const dayLabel = group.key === "active" ? `DAY${String(Number(row.day || 0)).padStart(2, "0")}` : "非稼働";
        const mainNumber = row.laixiNumber || row.xiaoweiNumber || row.xiaoweiSort || "-";
        const base = row.modelGroup || String(row.deviceDisplayCode || "").replace(/-\d{2,3}$/, "") || "端末";
        const carrier = row.carrierCode && row.carrierCode !== "UNKNOWN" ? row.carrierCode : "";
        return `<label class="device-name-sequence-row" data-order-band="${group.key}"><span class="device-main-number">No.${esc(mainNumber)}</span><b>${esc(dayLabel)}</b><span class="device-name-sequence-editor"><span>${esc(base)}-</span><input class="device-name-sequence-input" type="text" inputmode="numeric" pattern="[0-9]{1,3}" maxlength="3" value="${esc(sequenceById.get(id) || "")}" data-device-name-sequence="${esc(id)}" aria-label="${esc(labelFor(row))}の表示名連番"><em>${esc(carrier)}</em><small>${esc(row.serial || row.managementId || "")}</small></span></label>`;
      }).join("")}</section>`;
    }).join("");
  }
  list.addEventListener("input", (event) => {
    const input = event.target.closest("[data-device-name-sequence]");
    if (!input) return;
    const cleanValue = String(input.value || "").replace(/\D/g, "").slice(0, 3);
    if (input.value !== cleanValue) input.value = cleanValue;
    sequenceById.set(input.dataset.deviceNameSequence || "", cleanValue);
  });
  search.addEventListener("input", render);
  overlay.querySelector(".custom-order-close").addEventListener("click", closeDeviceNameSequenceDialog);
  overlay.querySelector(".custom-order-cancel").addEventListener("click", closeDeviceNameSequenceDialog);
  overlay.querySelector(".custom-order-save").addEventListener("click", (event) => saveDeviceNameSequences(rows, sequenceById, originalById, event.currentTarget));
  overlay.addEventListener("click", (event) => { if (event.target === overlay) closeDeviceNameSequenceDialog(); });
  overlay.addEventListener("keydown", (event) => { if (event.key === "Escape") closeDeviceNameSequenceDialog(); });
  render();
  search.focus();
}

function closeDeviceNameSequenceDialog() {
  document.querySelector(".custom-order-backdrop")?.remove();
}

function deviceNameSequence(row) {
  const direct = Number(row?.deviceNameSequence || 0);
  if (Number.isInteger(direct) && direct >= 1 && direct <= MAX_DEVICE_NAME_SEQUENCE) return direct;
  const match = /-(\d{1,3})$/.exec(String(row?.deviceDisplayCode || ""));
  return match ? Number(match[1]) : 0;
}

function deviceNameSequencePayload(rows, sequenceById, originalById) {
  const changes = [];
  const owners = new Map();
  for (const row of rows) {
    const id = String(row.serial || row.managementId || "");
    const rawSequence = String(sequenceById.get(id) || "").trim();
    if (!rawSequence) throw new Error(`${id} の表示名連番を入力してください`);
    const sequence = Number(rawSequence);
    if (!Number.isInteger(sequence) || sequence < 1 || sequence > MAX_DEVICE_NAME_SEQUENCE) {
      throw new Error(`${id} の表示名連番は1〜${MAX_DEVICE_NAME_SEQUENCE}で入力してください`);
    }
    const group = `${row.modelGroup || ""}::${row.carrierCode || "UNKNOWN"}`;
    const ownerKey = `${group}::${sequence}`;
    if (owners.has(ownerKey) && owners.get(ownerKey) !== id) {
      throw new Error(`${row.modelGroup || "同一機種"} ${row.carrierCode || ""} の連番 ${String(sequence).padStart(2, "0")} が重複しています`);
    }
    owners.set(ownerKey, id);
    if (sequence !== Number(originalById.get(id) || 0)) changes.push({ device: id, sequence });
  }
  return changes;
}

async function saveDeviceNameSequences(rows, sequenceById, originalById, button) {
  let changes = [];
  try {
    changes = deviceNameSequencePayload(rows, sequenceById, originalById);
  } catch (error) {
    window.alert(error.message);
    return;
  }
  if (!changes.length) {
    window.alert("表示名連番の変更はありません。");
    return;
  }
  if (!window.confirm(`${changes.length}台のXiaoWei名連番を保存して同期しますか？\nメイン番号、機種順、DAY順は変更しません。`)) return;
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/fleet-db/device-name-sequences", {
      method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ changes }),
    });
    closeDeviceNameSequenceDialog();
    await loadLocalSummaryOnly();
    reloadTagBoardFrame();
    logLine(`XiaoWei名連番 保存 OK: ${result.changedDevices || 0}台 / メイン番号変更 0台 / DAY順維持`);
    try {
      const syncResult = await fetchJson("/api/xiaowei/display-names/sync", {
        method: "POST", headers: { "content-type": "application/json" }, body: "{}",
      });
      logLine(`XiaoWei名連番 同期 OK: 失敗 ${(syncResult.failedSteps || []).length}件`);
      await loadLocalSummaryOnly();
      reloadTagBoardFrame();
    } catch (syncError) {
      logLine(`XiaoWei名連番 同期 NG: ${syncError.message}`);
      window.alert(`連番はDBへ保存しましたが、XiaoWei名への同期に失敗しました。\n${syncError.message}\n接続後に「XiaoWei名/番号同期」を実行してください。`);
    }
  } catch (error) {
    window.alert("XiaoWei名連番の保存に失敗しました。\n" + error.message);
  } finally {
    setBusy(false);
  }
}

function formatManagementName(row) {
  const number = formatXiaoWeiNumber(row.laixiNumber || row.managementId || row.xiaoweiSort || "");
  const name = row.deviceLabel || row.laixiName || row.deviceName || row.uiName || "";
  return [number, name].filter(Boolean).join(" ");
}

function formatManagementId(value) {
  const text = String(value || "").trim();
  const numberMatch = /^(?:A-)?(\d+)$/.exec(text);
  if (numberMatch) return numberMatch[1].padStart(2, "0");
  return text.replace(/^A-/i, "");
}

function formatXiaoWeiNumber(value) {
  const text = String(value || "").trim();
  const match = /^(?:A-)?(\d+)$/.exec(text);
  if (!match) return text.replace(/^A-/i, "");
  const raw = match[1];
  return String(Number(raw)).padStart(raw.length >= 3 ? 3 : 2, "0");
}

function formatXiaoWeiDeviceOptionLabel(row) {
  const number = formatXiaoWeiNumber(row.laixiNumber || row.managementId || row.xiaoweiSort || "");
  const label = row.deviceLabel || row.laixiName || row.deviceName || row.uiName || row.serial || "";
  return [number, label].filter(Boolean).join(" ");
}

function renderWithdrawals(rows) {
  const total = rows.reduce((sum, row) => sum + Number(row.amountYen || 0), 0);
  el("withdrawalTotal").textContent = `${rows.length}件 / ${yen(total)}`;
  el("withdrawalRows").innerHTML = rows.slice().reverse().map((row) => `
    <tr class="site-row ${siteClass(row.siteName)}">
      <td>${esc(row.withdrawalDate || "")}</td>
      <td>${siteBadge(row.siteName)}</td>
      <td>${esc(row.deviceName || "")}</td>
      <td class="num yen">${yen(row.amountYen || 0)}</td>
      <td>
        <span class="row-actions">
          <button class="icon-action edit-withdrawal-btn" data-id="${esc(row.withdrawalId || "")}" type="button">訂正</button>
          <button class="icon-action danger-action delete-withdrawal-btn" data-id="${esc(row.withdrawalId || "")}" type="button" title="削除">削除</button>
        </span>
      </td>
      <td>${row.resetDone || row.resetDoneAt ? `<span class="done-label">非稼働反映済</span>` : `<span class="muted">記録のみ</span>`}</td>
      <td>${esc(toJapaneseMemo(row.memo || ""))}</td>
    </tr>
  `).join("");
}

async function handleWithdrawalRowAction(event) {
  const editButton = event.target.closest(".edit-withdrawal-btn");
  const deleteButton = event.target.closest(".delete-withdrawal-btn");
  if (editButton) return startWithdrawalEdit(editButton.dataset.id);
  if (deleteButton) return deleteWithdrawal(deleteButton.dataset.id);
}

function startWithdrawalEdit(withdrawalId) {
  const row = findWithdrawalInState(withdrawalId);
  if (!row) {
    logLine("出金編集 NG: 履歴が見つかりません");
    return;
  }
  el("withdrawalIdInput").value = row.withdrawalId || "";
  el("withdrawalDateInput").value = row.withdrawalDate || localDateInputValue();
  el("withdrawalDeviceSelect").value = row.serial || row.managementId || "";
  el("withdrawalAmountInput").value = row.amountYen || "";
  el("withdrawalMemoInput").value = toJapaneseMemo(row.memo || "");
  el("addWithdrawalBtn").textContent = "出金更新";
  el("cancelWithdrawalEditBtn").classList.remove("hidden");
  el("withdrawalAmountInput").focus();
}

async function deleteWithdrawal(withdrawalId) {
  const row = findWithdrawalInState(withdrawalId);
  if (!row) return logLine("出金削除 NG: 履歴が見つかりません");
  const ok = window.confirm("この出金履歴を削除します。よろしいですか？");
  if (!ok) return;
  setBusy(true);
  try {
    const result = await fetchJson("/api/fleet-db/withdrawals/delete", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ withdrawalId }),
    });
    logLine("出金削除 OK: " + (result.deleted?.managementId || ""));
    clearWithdrawalForm();
    await loadSummary();
  } catch (error) {
    logLine("出金削除 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function markWithdrawalResetDone(withdrawalId) {
  const row = findWithdrawalInState(withdrawalId);
  if (!row) return logLine("リセット NG: 履歴が見つかりません");
  const ok = window.confirm("この出金履歴をリセット扱いにします。よろしいですか？");
  if (!ok) return;
  setBusy(true);
  try {
    const result = await fetchJson("/api/fleet-db/withdrawals/reset-done", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ withdrawalId }),
    });
    logLine("リセット OK: " + (result.withdrawal?.managementId || ""));
    logRefreshWarnings("リセット更新", result.refresh);
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("リセット NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function handleDeviceRowAction(event) {
  const historyButton = event.target.closest(".history-link-btn");
  if (historyButton) {
    const device = historyButton.dataset.device || historyButton.closest("tr")?.dataset.device || "";
    const row = (state.summary?.devices || []).find((item) => item && (item.serial === device || item.managementId === device || item.laixiNumber === device));
    showDeviceHistoryDialog(row);
    return;
  }
  const resetButton = event.target.closest(".device-reset-btn");
  if (!resetButton) return;
  const device = resetButton.dataset.device;
  const ok = window.confirm("この端末をリセットします。よろしいですか？");
  if (!ok) return;
  setBusy(true);
  try {
    const result = await fetchJson("/api/fleet-db/devices/reset", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ device, reason: "manual_error_reset" }),
    });
    logLine("端末リセット OK: " + (result.device?.managementId || ""));
    logRefreshWarnings("端末リセット更新", result.refresh);
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("端末リセット NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function handleDeviceNameInput(event) {
  const input = event.target.closest(".device-edit-input");
  if (!input) return;
  const changed = input.value.trim() !== (input.dataset.original || "");
  input.classList.toggle("changed-input", changed);
  input.classList.remove("input-error");
  input.title = changed ? "": "";
  updateDeviceNameSaveState();
}

function changedDeviceNameInputs() {
  return [...document.querySelectorAll(".device-edit-input")]
    .filter((input) => input.value.trim() !== (input.dataset.original || ""));
}

function changedDeviceTaskSelects() {
  return [...document.querySelectorAll(".device-task-select")]
    .filter((select) => select.value !== (select.dataset.original || ""));
}

function changedInviteInputs() {
  return changedDeviceNameInputs().filter((input) => INVITE_EDIT_FIELDS.has(input.dataset.field || ""));
}

function updateDeviceNameSaveState() {
  const button = el("saveDeviceNamesBtn");
  const status = el("deviceNameSaveStatus");
  if (!button || !status) return;
  const count = changedDeviceNameInputs().length + changedDeviceTaskSelects().length;
  const errorCount = document.querySelectorAll(".device-edit-input.input-error, .device-task-select.input-error").length;
  button.disabled = state.busy || count === 0;
  status.textContent = errorCount ? `${errorCount}件失敗` : count ? `${count}件未保存` : "";
  status.className = ["mini-status", errorCount ? "error" : count ? "warn" : ""].filter(Boolean).join(" ");

  const inviteButton = el("saveInviteFactorsBtn");
  const inviteStatus = el("inviteFactorsSaveStatus");
  if (inviteButton && inviteStatus) {
    const inviteInputs = changedInviteInputs();
    const inviteErrors = inviteInputs.filter((input) => input.classList.contains("input-error")).length;
    inviteButton.disabled = state.busy || inviteInputs.length === 0;
    inviteStatus.textContent = inviteErrors ? `${inviteErrors}件失敗` : inviteInputs.length ? `${inviteInputs.length}件未保存` : "";
    inviteStatus.className = ["mini-status", "invite-save-status", inviteErrors ? "error" : inviteInputs.length ? "warn" : ""].filter(Boolean).join(" ");
  }
}

async function saveChangedDeviceNames() {
  const inputs = changedDeviceNameInputs();
  const taskSelects = changedDeviceTaskSelects();
  const inviteInputCount = inputs.filter((input) => INVITE_EDIT_FIELDS.has(input.dataset.field || "")).length;
  const total = inputs.length + taskSelects.length;
  if (!total) return;
  setBusy(true);
  el("deviceNameSaveStatus").textContent = `${total}件保存中...`;
  if (inviteInputCount) el("inviteFactorsSaveStatus").textContent = `${inviteInputCount}件保存中...`;
  let failed = 0;
  try {
    const groups = new Map();
    for (const input of inputs) {
      const device = input.dataset.device || input.closest("tr")?.dataset.device || "";
      if (!device) continue;
      if (!groups.has(device)) groups.set(device, []);
      groups.get(device).push(input);
    }
    for (const [device, groupInputs] of groups.entries()) {
      const body = { device, syncName: false };
      for (const input of groupInputs) body[input.dataset.field || "name"] = input.value.trim();
      try {
        const result = await fetchJson("/api/fleet-db/devices/update", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(body),
        });
        for (const input of groupInputs) {
          input.dataset.original = input.value.trim();
          input.classList.remove("changed-input", "input-error");
          input.title = "";
        }
        logLine(`端末名保存 OK: ${result.device?.managementId || device}`);
      } catch (error) {
        failed += 1;
        for (const input of groupInputs) {
          input.classList.add("input-error");
          input.title = error.message;
        }
        logLine("端末名保存 NG: " + error.message);
      }
    }
    if (taskSelects.length) {
      const changes = [];
      for (const select of taskSelects) {
        const device = select.dataset.device || select.closest("tr")?.dataset.device || "";
        const kind = select.dataset.kind || "";
        const config = DEVICE_TASK_SELECTS[kind];
        if (!device || !config) continue;
        const nextTag = select.value;
        for (const tag of config.tags) {
          changes.push({
            serial: device,
            managementId: device,
            tag,
            checked: tag === nextTag,
          });
        }
      }
      if (changes.length) {
        try {
          const result = await fetchJson("/api/tag-board/tags/apply", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ changes }),
          });
          for (const select of taskSelects) {
            select.dataset.original = select.value;
            select.classList.remove("changed-input", "input-error");
            select.title = "";
          }
          logLine(`DBタスク反映 OK: ${taskSelects.length}件 / チェック ${result.applied || 0}件`);
          reloadTagBoardFrame();
        } catch (error) {
          failed += 1;
          for (const select of taskSelects) {
            select.classList.add("input-error");
            select.title = error.message;
          }
          logLine("DBタスク反映 NG: " + error.message);
        }
      }
    }
    if (!failed) await loadSummary();
    else {
      el("deviceNameSaveStatus").textContent = `${failed}件失敗`;
      el("deviceNameSaveStatus").className = "mini-status error";
    }
  } finally {
    setBusy(false);
    updateDeviceNameSaveState();
    if (!failed && inviteInputCount) {
      const inviteStatus = el("inviteFactorsSaveStatus");
      inviteStatus.textContent = "保存済";
      inviteStatus.className = "mini-status invite-save-status success";
      window.setTimeout(() => {
        if (!changedInviteInputs().length) updateDeviceNameSaveState();
      }, 2000);
    }
  }
}

function logRefreshWarnings(label, refresh) {
  if (!refresh) return;
  const failed = Object.entries(refresh)
    .filter(([, result]) => result && result.ok === false)
    .map(([name]) => name);
  if (failed.length) logLine(`${label} 注意: ${failed.join(", ")}`);
}

function findWithdrawalInState(withdrawalId) {
  return (state.summary?.withdrawals || []).find((row) => row.withdrawalId === withdrawalId);
}

function renderDeviceRevenue(rows) {
  el("deviceRevenueRows").innerHTML = rows.map((row) => `
    <tr class="site-row ${siteClass(row.siteName)}">
      <td>${siteBadge(row.siteName)}</td>
      <td class="num">${esc(row.deviceNumber || row.managementId || "")}</td>
      <td>${esc(row.deviceName)}</td>
      <td class="num">${esc(row.count)}</td>
      <td class="num yen">${yen(row.totalYen)}</td>
      <td class="num yen">${yen(row.monthYen)}</td>
      <td class="num">${yen(row.averageYen)}</td>
      <td>${esc(row.lastWithdrawalDate)}</td>
    </tr>
  `).join("");
}

function renderMonthlyRevenue(rows, siteRows, siteTotals) {
  const currentMonth = localDateInputValue().slice(0, 7);
  const latest = rows.find((row) => row.month === currentMonth) || { month: currentMonth, totalYen: 0, count: 0, yen3000: 0, over5000: 0 };
  const allTotal = rows.reduce((sum, row) => sum + Number(row.totalYen || 0), 0);
  el("monthlyCards").innerHTML = [
    card("今月", currentMonth, yen(latest.totalYen || 0)),
    card("今月件数", "出金", `${latest.count || 0}件`),
    card("3000～4999円", "今月", `${latest.yen3000 || 0}件`),
    card("5000円以上", "今月", `${latest.over5000 || 0}件`),
    card("累計", "DB全体", yen(allTotal)),
  ].join("");
  el("siteRevenueRows").innerHTML = siteTotals.map((row) => `
    <tr class="site-row ${siteClass(row.siteName)}">
      <td>${siteBadge(row.siteName)}</td>
      <td class="num">${esc(row.count)}</td>
      <td class="num yen">${yen(row.monthYen)}</td>
      <td class="num yen">${yen(row.totalYen)}</td>
    </tr>
  `).join("");
  el("monthlyRows").innerHTML = rows.slice().reverse().map((row) => `
    <tr>
      <td>${esc(row.month)}</td>
      <td class="num">${esc(row.count)}</td>
      <td class="num">${esc(row.yen3000)}</td>
      <td class="num">${esc(row.over5000)}</td>
      <td class="num yen">${yen(row.totalYen)}</td>
    </tr>
  `).join("");
  el("monthlySiteRows").innerHTML = siteRows.slice().reverse().map((row) => `
    <tr class="site-row ${siteClass(row.siteName)}">
      <td>${esc(row.month)}</td>
      <td>${siteBadge(row.siteName)}</td>
      <td class="num">${esc(row.count)}</td>
      <td class="num">${esc(row.yen3000)}</td>
      <td class="num">${esc(row.over5000)}</td>
      <td class="num yen">${yen(row.totalYen)}</td>
    </tr>
  `).join("");
}

function renderRewardCalculator() {
  if (!el("calcCiSelect")) return;
  const ciYen = Number(el("calcCiSelect").value || 0);
  const video180Points = Number(el("calc180Select").value || 0);
  const selected10 = el("calc10Select").value;
  const custom10 = Number(el("calc10CustomInput").value || 0);
  const video10Yen = selected10 === "custom" ? Math.max(0, custom10) : Number(selected10 || 0);
  el("calc10CustomInput").disabled = selected10 !== "custom";

  const projection = buildRewardProjection({
    ciTotalYen: ciYen,
    video180DailyPoints: video180Points,
    video10TotalYen: video10Yen,
  });
  const day3000 = projection.day3000 ? `${projection.day3000}日目` : "";
  const day5000 = projection.day5000 ? `${projection.day5000}日目` : "";
  el("calcFormulaLine").textContent = `チェックイン ${yen(ciYen)} + 動画180分 ${number(video180Points)}P/日 x ${VIDEO_TASK_DAYS}日 + 追加視聴 ${yen(video10Yen)} / ${VIDEO_TASK_DAYS}日`;
  el("calcSummaryCards").innerHTML = [
    calcCard("最終見込み", yen(projection.finalYen), projection.finalYen >= 5000 ? "good" : projection.finalYen >= 3000 ? "warn" : "bad"),
    calcCard("3000円到達", day3000, projection.day3000 ? "good" : "bad"),
    calcCard("5000円到達", day5000, projection.day5000 ? "good" : "warn"),
  ].join("");
  el("calcRows").innerHTML = projection.rows.map((row) => {
    const reached5000 = row.totalYen >= 5000;
    const reached3000 = row.totalYen >= 3000;
    const klass = reached5000 ? "reach-row-5000" : reached3000 ? "reach-row-3000" : "";
    const badges = [
      reached3000 ? `<span class="reach-pill ok3000">3000</span>` : "",
      reached5000 ? `<span class="reach-pill ok5000">5000</span>` : "",
    ].filter(Boolean).join(" ");
    return `<tr class="${klass}">
      <td>${row.day}日目</td>
      <td class="num">${row.ciMultiplier}</td>
      <td class="num">${number(row.ciPoints)}</td>
      <td class="num">${number(row.video180Points)}</td>
      <td class="num">${yen(row.video10Yen)}</td>
      <td class="num">${yen(row.dayPoints / 100)}</td>
      <td class="num yen">${yen(row.totalYen)}</td>
      <td>${badges || `<span class="reach-pill">-</span>`}</td>
    </tr>`;
  }).join("");
  el("calcCiRows").innerHTML = projection.rows.map((row) => `
    <tr>
      <td>${row.day}日目</td>
      <td class="num">${row.ciMultiplier} / 45</td>
      <td class="num">${number(row.ciPoints)}</td>
      <td class="num yen">${yen(row.ciPoints / 100)}</td>
    </tr>
  `).join("");
  el("calcUnitExplanation").innerHTML = renderCiUnitExplanation(ciYen, projection.rows);
}

function renderCiUnitExplanation(ciYen, rows) {
  const unitYen = ciYen / CI_MULTIPLIER_TOTAL;
  const first = rows[0] || { ciMultiplier: 0, ciPoints: 0 };
  const last = rows[13] || rows[rows.length - 1] || { ciMultiplier: 0, ciPoints: 0 };
  return `
    <div class="calc-unit-title">口数の説明</div>
    <div class="calc-unit-formula">報酬総額 ${yen(ciYen)} ÷ 45口 = 1口あたり ${yen(round(unitYen, 2))}</div>
    <div class="calc-unit-grid">
      <div><b>1日目</b><span>${yen(round(unitYen, 2))} x ${first.ciMultiplier}口 = ${yen(first.ciPoints / 100)}</span></div>
      <div><b>14日目</b><span>${yen(round(unitYen, 2))} x ${last.ciMultiplier}口 = ${yen(last.ciPoints / 100)}</span></div>
    </div>
    <div class="calc-unit-caption">日ごとの45口配分は、3,3,3,1,1,1,5,1,1,2,3,5,6,10口です。</div>
  `;
}

function buildRewardProjection(options) {
  const ciTotalYen = Number(options.ciTotalYen || 0);
  const video180DailyPoints = Number(options.video180DailyPoints || 0);
  const video10TotalYen = Number(options.video10TotalYen || 0);
  const ciTotalPoints = Math.round(ciTotalYen * 100);
  const ciUnit = ciTotalPoints / CI_MULTIPLIER_TOTAL;
  const video10DailyYen = video10TotalYen / VIDEO_TASK_DAYS;
  const rows = [];
  let totalPoints = 0;
  let ciAllocatedPoints = 0;
  for (let day = 1; day <= 14; day += 1) {
    const ciMultiplier = CI_MULTIPLIERS[day - 1] || 0;
    const ciPoints = day === CI_MULTIPLIERS.length
      ? ciTotalPoints - ciAllocatedPoints
      : Math.round(ciUnit * ciMultiplier);
    ciAllocatedPoints += ciPoints;
    const video180Points = day <= VIDEO_TASK_DAYS ? video180DailyPoints : 0;
    const video10Yen = day <= VIDEO_TASK_DAYS ? video10DailyYen : 0;
    const video10Points = Math.round(video10Yen * 100);
    const dayPoints = ciPoints + video180Points + video10Points;
    totalPoints += dayPoints;
    rows.push({
      day,
      ciMultiplier,
      ciPoints,
      video180Points,
      video10Yen: round(video10Yen, 2),
      dayPoints,
      totalYen: round(totalPoints / 100, 2),
    });
  }
  return {
    rows,
    finalYen: rows.length ? rows[rows.length - 1].totalYen : 0,
    day3000: firstReachDay(rows, 3000),
    day5000: firstReachDay(rows, 5000),
  };
}

function firstReachDay(rows, targetYen) {
  const row = rows.find((item) => item.totalYen >= targetYen);
  return row ? row.day : null;
}

function calcCard(label, value, klass) {
  return `<div class="calc-card ${esc(klass || "")}"><div class="label">${esc(label)}</div><div class="value">${esc(value)}</div></div>`;
}

function card(label, sub, value) {
  return `<div class="revenue-card"><div class="label">${esc(label)} / ${esc(sub)}</div><div class="value">${esc(value)}</div></div>`;
}

function statusPill(status, row = {}) {
  if (row.adbConnected === false) {
    return `<span class="status-pill status-offline">OFFLINE</span>`;
  }
  const value = status || "UNKNOWN";
  const klass = value === "ONLINE" ? "status-online" : (value === "WAITING" || value === "INACTIVE") ? "status-waiting" : value === "ACTIVE" ? "status-active" : "status-unknown";
  const label = value === "WAITING" || value === "INACTIVE" || value === "NO CYCLE" ? "非稼働" : value;
  return `<span class="status-pill ${klass}">${esc(label)}</span>`;
}

function swipeAgentPill(row) {
  if (row.swipeAgentInstalled === true) {
    const version = [row.swipeAgentVersionName, row.swipeAgentVersionCode].filter(Boolean).join("/");
    if (row.swipeAgentAccessibilityEnabled === false) {
      return `<span class="status-pill status-waiting" title="">Agent権限なし</span>`;
    }
    return `<span class="status-pill status-online" title="${esc(row.swipeAgentCheckedAt || "")}">導入済${version ? ` ${esc(version)}` : ""}</span>`;
  }
  if (row.swipeAgentInstalled === false) {
    const title = row.swipeAgentLastError || row.swipeAgentCheckedAt || "";
    return `<span class="status-pill status-waiting" title="${esc(title)}">未導入</span>`;
  }
  return `<span class="status-pill status-unknown">未確認</span>`;
}

function normalizeSwipeModeRecommendation(row) {
  const manual = row.swipeModePreference || "auto";
  if (manual === "agent") return { mode: "agent", source: "manual", label: "Agent推奨" };
  if (manual === "adb") return { mode: "adb", source: "manual", label: "ADB推奨" };
  if (manual === "disabled") return { mode: "disabled", source: "manual", label: "無効" };
  const recommendation = row.swipeModeRecommendation || {};
  if (recommendation.mode) return recommendation;
  const lastError = String(row.swipeAgentLastError || "");
  if (row.swipeAgentInstalled === false || row.swipeAgentAccessibilityEnabled === false || /WRITE_SECURE_SETTINGS|Permission denial|accessibility/i.test(lastError)) {
    return { mode: "adb", source: "auto", label: "ADB推奨" };
  }
  return { mode: "agent", source: "auto", label: "Agent推奨" };
}

function swipeModeChip(row) {
  const recommendation = normalizeSwipeModeRecommendation(row || {});
  const mode = recommendation.mode || "agent";
  const source = recommendation.source === "manual" ? "手動固定" : "自動判定";
  const label = recommendation.label || (mode === "adb" ? "ADB推奨" : mode === "disabled" ? "無効" : "Agent推奨");
  return `<span class="swipe-mode-chip ${esc(mode)}" title="${esc(source)}">${esc(label)}</span>`;
}

function swipeModeCardClass(row) {
  const recommendation = normalizeSwipeModeRecommendation(row || {});
  return `swipe-mode-card-${recommendation.mode || "agent"}`;
}

function uptimePill(row, adbDevice) {
  const seconds = Number(adbDevice?.uptimeSeconds);
  if (!Number.isFinite(seconds) || seconds < 0) {
    const title = adbDevice?.uptimeError || (row.serial ? "ADB未接続または稼働時間未取得" : "端末IDなし");
    return `<span class="uptime-pill uptime-unknown" title="${esc(title)}">-</span>`;
  }
  const fetchedAt = Number(adbDevice?.uptimeFetchedAt || state.adbDevices?.uptimeFetchedAt || Date.now());
  const value = currentUptimeValue(seconds, fetchedAt);
  const title = uptimeTitle(value.hours, adbDevice?.uptimeRaw);
  return `<span class="uptime-pill ${uptimeBandClass(value.hours)}" data-uptime-base="${esc(seconds)}" data-uptime-fetched-at="${esc(fetchedAt)}" data-uptime-raw="${esc(adbDevice?.uptimeRaw || "")}" title="${esc(title)}">${esc(uptimeLabel(value.hours))}</span>`;
}

function uptimeBandClass(hours) {
  if (hours >= 500) return "uptime-500";
  if (hours >= 400) return "uptime-400";
  if (hours >= 300) return "uptime-300";
  if (hours >= 200) return "uptime-200";
  if (hours >= 100) return "uptime-100";
  return "uptime-000";
}

function currentUptimeValue(baseSeconds, fetchedAt) {
  const elapsedSeconds = Math.max(0, Math.floor((Date.now() - Number(fetchedAt || Date.now())) / 1000));
  const seconds = Math.max(0, Number(baseSeconds || 0) + elapsedSeconds);
  return { seconds, hours: seconds / 3600 };
}

function uptimeLabel(hours) {
  return hours >= 100 ? `${Math.floor(hours)}h` : `${hours.toFixed(1)}h`;
}

function uptimeTitle(hours, raw = "") {
  const days = hours / 24;
  return `${hours.toFixed(1)}時間 / ${days.toFixed(1)}日${raw ? ` / ${raw}` : ""}`;
}

function startUptimeTicker() {
  if (state.uptimeTickTimer) return;
  state.uptimeTickTimer = window.setInterval(tickUptimePills, 30000);
}

function tickUptimePills() {
  for (const pill of document.querySelectorAll(".uptime-pill[data-uptime-base], .invite-uptime-chip[data-uptime-base]")) {
    const baseSeconds = Number(pill.dataset.uptimeBase);
    const fetchedAt = Number(pill.dataset.uptimeFetchedAt);
    if (!Number.isFinite(baseSeconds) || !Number.isFinite(fetchedAt)) continue;
    const value = currentUptimeValue(baseSeconds, fetchedAt);
    const prefix = pill.dataset.uptimePrefix || "";
    pill.textContent = `${prefix}${uptimeLabel(value.hours)}`;
    pill.title = uptimeTitle(value.hours, pill.dataset.uptimeRaw || "");
    pill.classList.remove("uptime-000", "uptime-100", "uptime-200", "uptime-300", "uptime-400", "uptime-500");
    pill.classList.add(uptimeBandClass(value.hours));
  }
  tickOfflineDeviceRows();
}

function tickOfflineDeviceRows() {
  const rows = state.summary?.offlineDevices || [];
  let statusChanged = false;
  for (const element of document.querySelectorAll("#offlineDeviceRows tr[data-offline-id]")) {
    const row = rows.find((item) => item.offlineId === element.dataset.offlineId);
    if (!row) continue;
    const nowMs = Date.now();
    const status = offlineStatusInfo(row, nowMs);
    if (status.key !== element.dataset.offlineStatus) {
      statusChanged = true;
      break;
    }
    const day = offlineCurrentDay(row, new Date(nowMs));
    const uptimeMinutes = offlineCurrentUptimeMinutes(row, nowMs);
    const uptimeHours = uptimeMinutes / 60;
    const rest = offlineRestTiming(row, nowMs);
    const dayElement = element.querySelector(".offline-day-value");
    const uptimeElement = element.querySelector(".offline-uptime-value");
    const restElement = element.querySelector(".offline-rest-value");
    if (dayElement) dayElement.textContent = day ? `DAY ${day}` : "-";
    if (uptimeElement) {
      uptimeElement.textContent = uptimeLabel(uptimeHours);
      uptimeElement.classList.remove("uptime-000", "uptime-100", "uptime-200", "uptime-300", "uptime-400", "uptime-500");
      uptimeElement.classList.add(uptimeBandClass(uptimeHours));
    }
    if (restElement && status.key === "resting") restElement.textContent = `残り ${offlineDurationLabel(rest.remainingMinutes)}`;
  }
  if (statusChanged) renderOfflineDeviceDb(rows);
}

function siteName(value) {
  return String(value || state.summary?.settings?.siteName || "本店");
}

function siteClass(value) {
  const name = siteName(value);
  let hash = 0;
  for (const char of name) hash = (hash * 31 + char.charCodeAt(0)) >>> 0;
  return `site-${hash % 8}`;
}

function siteBadge(value) {
  const name = siteName(value);
  return `<span class="site-badge ${siteClass(name)}" title="${esc(name)}">${esc(name)}</span>`;
}

function toJapaneseMemo(memo) {
  return String(memo || "")
    .replace(/3000 yen withdrawn,\s*reset,\s*then moved to waiting\.?/gi, "3,000円出金後、リセットして非稼働へ移動")
    .replace(/yen withdrawn,\s*reset,\s*then moved to waiting\.?/gi, "円出金後、リセットして非稼働へ移動")
    .replace(/withdrawn/gi, "出金")
    .replace(/reset done/gi, "リセット済み")
    .replace(/reset/gi, "リセット")
    .replace(/moved to waiting/gi, "非稼働へ移動")
    .replace(/individual revenue memo/gi, "個別収益メモ")
    .trim();
}

function looksCorruptedText(value) {
  const text = String(value || "");
  for (const char of text) {
    const code = char.charCodeAt(0);
    if (code === 0xfffd) return true;
    if (code >= 0x8340 && code <= 0x9fff) return true;
    if (code >= 0xe000 && code <= 0xf8ff) return true;
    if (code >= 0xff61 && code <= 0xff9f) return true;
  }
  return false;
}

function setBusy(busy, activeButton = null, loadingText = "処理中...") {
  const safeLoadingText = looksCorruptedText(loadingText) ? "処理中..." : String(loadingText || "処理中...");
  state.busy = busy;
  for (const button of document.querySelectorAll("button")) button.disabled = busy;
  if (busy && activeButton) {
    activeButton.dataset.originalText = activeButton.dataset.originalText || activeButton.textContent;
    activeButton.textContent = safeLoadingText;
    activeButton.classList.add("is-loading");
  }
  if (!busy) {
    for (const button of document.querySelectorAll("button.is-loading")) {
      button.textContent = button.dataset.originalText || button.textContent;
      delete button.dataset.originalText;
      button.classList.remove("is-loading");
    }
    updateDeviceNameSaveState();
  }
}

function flashButtonResult(button, message = "完了", type = "ok", ms = 1800) {
  if (!button || !button.isConnected) return;
  const klass = type === "error" ? "flash-error" : type === "warn" ? "flash-warn" : "flash-ok";
  const original = button.dataset.flashOriginal || button.dataset.originalText || button.textContent;
  if (button.dataset.flashTimer) window.clearTimeout(Number(button.dataset.flashTimer));
  button.dataset.flashOriginal = original;
  button.textContent = message;
  button.classList.remove("flash-ok", "flash-warn", "flash-error");
  button.classList.add(klass);
  button.dataset.flashTimer = String(window.setTimeout(() => {
    if (!button.isConnected) return;
    button.textContent = button.dataset.flashOriginal || original;
    delete button.dataset.flashOriginal;
    delete button.dataset.flashTimer;
    button.classList.remove("flash-ok", "flash-warn", "flash-error");
  }, ms));
}

function setSwipeStopControlsLocked(locked) {
  const ids = [
    "swipeAgentStartBtn",
    "swipeAgentStopBtn",
    "adbSwipeStopBtn",
    "swipeRecoveryTestBtn",
    "swipeLiveRecoveryTestBtn",
    "swipeAgentApplyBulkBtn",
    "swipeAgentSelectAllBtn",
    "swipeAgentSelectActiveBtn",
    "swipeAgentClearSelectionBtn",
    "swipeAgentRefreshBtn",
    "swipeAgentStatusBtn",
    "swipeAgentInstallBtn",
  ];
  for (const id of ids) {
    const button = el(id);
    if (button) button.disabled = Boolean(locked);
  }
}

function logLine(message) {
  const text = String(message ?? "");
  const entry = createSyncLogEntry(text);
  state.syncLogs.unshift(entry);
  state.syncLogs = state.syncLogs.slice(0, 5000);
  state.syncLogPending.push(entry);
  renderSyncLogs();
  persistLogLines(state.syncLogs.slice(0, LOG_STORAGE_LIMIT).map(formatSyncLogEntry).join("\n"));
  scheduleSyncLogFlush();
}

function restoreLogLines() {
  if (!el("logBox")) return;
  try {
    const lines = JSON.parse(localStorage.getItem(LOG_STORAGE_KEY) || "[]");
    if (Array.isArray(lines) && lines.length) {
      state.syncLogs = lines.map((line, index) => parseLegacySyncLogLine(line, index));
      renderSyncLogs();
    }
  } catch (_) {
    localStorage.removeItem(LOG_STORAGE_KEY);
  }
}

function persistLogLines(text) {
  try {
    const lines = String(text || "").split("\n").filter(Boolean).slice(0, LOG_STORAGE_LIMIT);
    localStorage.setItem(LOG_STORAGE_KEY, JSON.stringify(lines));
  } catch (_) {
    // Logging must never break the operation being logged.
  }
}

function createSyncLogEntry(message) {
  const at = new Date().toISOString();
  const failureProbe = String(message || "")
    .replace(/(?:失敗|エラー)\s*[:：=]?\s*0(?:件|台)?(?=\s*(?:\/|$))/gi, "")
    .replace(/\b(?:failed|failures?|errors?)\s*[:=]?\s*0\b/gi, "");
  const failure = /(?:NG|失敗|ERROR|エラー|未認識|接続できません|見つかりません)/i.test(failureProbe);
  const success = !failure && /(?:OK|完了|保存|反映|取得成功|変更なし)/i.test(message);
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
    at,
    level: failure ? "failure" : success ? "success" : "info",
    category: /同期|反映|DB再読込|DAY更新|端末名再取得/i.test(message) ? "sync" : "operation",
    message,
  };
}

function parseLegacySyncLogLine(line, index) {
  const text = String(line || "");
  const message = text.replace(/^\[[^\]]+\]\s*/, "");
  return { ...createSyncLogEntry(message), id: `legacy-${index}-${message.slice(0, 20)}` };
}

function formatSyncLogEntry(entry) {
  const date = new Date(entry.at || Date.now());
  const stamp = Number.isNaN(date.getTime()) ? String(entry.at || "") : date.toLocaleString("ja-JP", { hour12: false });
  return `[${stamp}] ${entry.message || ""}`;
}

function renderSyncLogs() {
  const box = el("logBox");
  if (!box) return;
  const filter = el("syncLogFilter")?.value || "all";
  const query = (el("syncLogSearch")?.value || "").trim().toLowerCase();
  const filtered = state.syncLogs.filter((entry) => {
    if (filter === "success" && entry.level !== "success") return false;
    if (filter === "failure" && entry.level !== "failure") return false;
    if (filter === "sync" && entry.category !== "sync") return false;
    return !query || `${entry.message} ${entry.at}`.toLowerCase().includes(query);
  });
  box.textContent = filtered.map(formatSyncLogEntry).join("\n");
  const meta = el("syncLogMeta");
  if (meta) meta.textContent = `保存 ${state.syncLogs.length}件 / 表示 ${filtered.length}件 / 最大5000件`;
}

async function loadPersistentSyncLogs() {
  try {
    const result = await fetchJson("/api/fleet-db/sync-log");
    const serverEntries = Array.isArray(result.entries) ? result.entries.slice().reverse() : [];
    const byId = new Map(serverEntries.map((entry) => [entry.id, entry]));
    for (const entry of state.syncLogs) if (!byId.has(entry.id)) byId.set(entry.id, entry);
    state.syncLogs = [...byId.values()]
      .sort((a, b) => String(b.at).localeCompare(String(a.at)))
      .slice(0, Number(result.limit || 5000));
    renderSyncLogs();
  } catch (_) {
    renderSyncLogs();
  }
}

function scheduleSyncLogFlush() {
  if (state.syncLogFlushTimer) return;
  state.syncLogFlushTimer = window.setTimeout(flushSyncLogs, 400);
}

async function flushSyncLogs() {
  window.clearTimeout(state.syncLogFlushTimer);
  state.syncLogFlushTimer = 0;
  const entries = state.syncLogPending.splice(0, 100);
  if (!entries.length) return;
  try {
    await fetchJson("/api/fleet-db/sync-log", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ entries }),
    });
  } catch (_) {
    state.syncLogPending.unshift(...entries);
  }
  if (state.syncLogPending.length) scheduleSyncLogFlush();
}

function downloadSyncLogs() {
  const content = state.syncLogs.map(formatSyncLogEntry).join("\r\n");
  const blob = new Blob(["\uFEFF", content], { type: "text/plain;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `AndroidFleet-同期ログ-${new Date().toISOString().slice(0, 10)}.txt`;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}

async function clearSyncLogs() {
  if (!window.confirm("同期ログをすべて消去しますか？この操作は元に戻せません。")) return;
  try {
    await fetchJson("/api/fleet-db/sync-log/clear", { method: "POST" });
    state.syncLogs = [];
    state.syncLogPending = [];
    localStorage.removeItem(LOG_STORAGE_KEY);
    renderSyncLogs();
  } catch (error) {
    window.alert("同期ログの消去に失敗しました。\n" + error.message);
  }
}

function summarizeActionResult(result) {
  if (result.failedSteps && result.failedSteps.length) return "失敗 " + result.failedSteps.join(", ");
  if (result.file) return result.file;
  if (result.result && result.result.json) {
    const json = result.result.json;
    if (json.synced) return "同期済 " + JSON.stringify(json.counts || {});
    if (json.queued) return "保留: " + (json.reason || "");
  }
  return "";
}

function summarizeSyncStepDurations(refresh) {
  const labels = {
    backupBeforeRefresh: "DBバックアップ",
    deviceCodeSync: "端末名再取得",
    tagBoard: "チェック表生成",
    displayNames: "表示名",
    numbers: "番号",
    tagBoardAfterDisplayNames: "チェック表更新",
    sheets: "Sheets",
  };
  return Object.entries(refresh || {})
    .filter(([, result]) => Boolean(result) && Number.isFinite(Number(result.durationMs)))
    .map(([name, result]) => `${labels[name] || name} ${(Number(result.durationMs) / 1000).toFixed(1)}秒`)
    .join(" / ");
}

function yen(value) {
  return "\u00a5" + Number(value || 0).toLocaleString("ja-JP");
}

function number(value) {
  return Number(value || 0).toLocaleString("ja-JP");
}

function round(value, digits) {
  const scale = 10 ** digits;
  return Math.round(Number(value || 0) * scale) / scale;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, Number(value || 0)));
}

function formatDate(value) {
  if (!value) return "";
  return String(value).slice(0, 10);
}

function formatDateTime(value) {
  if (!value) return "";
  return new Date(value).toLocaleString("ja-JP");
}

function localDateInputValue(date = new Date()) {
  const parts = new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date).reduce((map, part) => {
    map[part.type] = part.value;
    return map;
  }, {});
  return `${parts.year}-${parts.month}-${parts.day}`;
}

function localTimestampForFile() {
  const date = new Date();
  const parts = new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(date).reduce((map, part) => {
    map[part.type] = part.value;
    return map;
  }, {});
  return `${parts.year}${parts.month}${parts.day}-${parts.hour}${parts.minute}${parts.second}`;
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  }[char]));
}
