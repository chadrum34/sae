"use strict";

const fs = require("fs");
const path = require("path");
const { createConfigPaths, ensureConfigPaths } = require("./lib/config-paths");
const { readJson, writeJson } = require("./lib/monitor-state");
const { CANONICAL_TAGS, canonicalizeTags, sortTags, tagLabel, tagDescriptionJa } = require("./lib/tag-schema");

const rootDir = __dirname;
const paths = ensureConfigPaths(createConfigPaths({ rootDir }));
const dbDir = path.join(paths.dataDir, "fleet-db");
const dbPath = path.join(dbDir, "fleet-db.json");
const boardPath = path.join(dbDir, "device-tag-board.md");
const csvPath = path.join(dbDir, "device-tag-board.csv");
const jsonPath = path.join(dbDir, "device-tag-board.json");
const matrixMdPath = path.join(dbDir, "device-tag-matrix.md");
const matrixCsvPath = path.join(dbDir, "device-tag-matrix.csv");
const matrixHtmlPath = path.join(dbDir, "device-tag-matrix.html");
const matrixJsonPath = path.join(dbDir, "device-tag-matrix.json");
const transposedHtmlPath = path.join(dbDir, "device-tag-transposed.html");
const INACTIVE_NUMBER_START = 1000;

const preferredTags = CANONICAL_TAGS;
const boardVisibleTags = [
  "GROUP_ACTIVE",
  "GROUP_INACTIVE",
  "STATE_ERROR",
  "STATE_ERROR_HISTORY",
  "CI_1350",
  "CI_1971",
  "CI_2565",
  "CI_2700",
  "CI_3847",
  "V180_7500",
  "V180_15000",
  "V180_22500",
  "V180_DONE",
  "V10_1190",
  "V10_1438",
  "V10_2262",
  "V10_DONE",
  "DAY_01",
  "DAY_02",
  "DAY_03",
  "DAY_04",
  "DAY_05",
  "DAY_06",
  "DAY_07",
  "DAY_08",
  "DAY_09",
  "DAY_10",
  "DAY_11",
  "DAY_12",
  "DAY_13",
  "DAY_14",
  "STATE_CI_KEEP",
];

if (require.main === module) main();

module.exports = {
  findTagBoardDeviceMatches,
  normalizeTagBoardDeviceNumber,
};

function main() {
  const db = readJson(dbPath, null);
  if (!db) {
    throw new Error("fleet-db.json not found. Run update-fleet-db.js first.");
  }

  const rows = buildRows(db);
  const matrix = buildMatrix(rows);
  fs.mkdirSync(dbDir, { recursive: true });
  writeJson(jsonPath, rows);
  writeCsv(csvPath, rows);
  writeMarkdown(boardPath, rows, db);
  writeJson(matrixJsonPath, matrix);
  writeMatrixCsv(matrixCsvPath, matrix);
  writeMatrixMarkdown(matrixMdPath, matrix, db);
  writeMatrixHtml(matrixHtmlPath, matrix, db);
  writeTransposedHtml(transposedHtmlPath, matrix, db);

  console.log(JSON.stringify({
    ok: true,
    rows: rows.length,
    boardPath,
    csvPath,
    jsonPath,
    matrixMdPath,
    matrixCsvPath,
    matrixHtmlPath,
    matrixJsonPath,
    transposedHtmlPath,
  }, null, 2));
}

function normalizeTagBoardDeviceNumber(rawValue) {
  const compact = String(rawValue === undefined || rawValue === null ? "" : rawValue)
    .normalize("NFKC")
    .trim()
    .toUpperCase()
    .replace(/[‐‑‒–—―ー−ｰ－]/g, "-")
    .replace(/\s+/g, "");
  if (!compact) return { ok: false, number: "", error: "empty" };

  const match = compact.match(/^(?:(?:A|NO\.?)?-?)?0*(\d{1,4})$/);
  if (!match) return { ok: false, number: "", error: "invalid" };

  const value = Number(match[1]);
  if (!Number.isInteger(value) || value < 1 || value >= 9000) {
    return { ok: false, number: "", error: "range" };
  }
  return { ok: true, number: String(value), value, error: "" };
}

function findTagBoardDeviceMatches(devices, rawQuery) {
  const normalized = normalizeTagBoardDeviceNumber(rawQuery);
  if (!normalized.ok) {
    return { ok: false, number: "", indexes: [], error: normalized.error };
  }

  const rows = Array.isArray(devices) ? devices : [];
  const indexes = [];
  for (let index = 0; index < rows.length; index += 1) {
    const displayNumber = normalizeTagBoardDeviceNumber(rows[index] && rows[index].displayId);
    if (displayNumber.ok && displayNumber.number === normalized.number) indexes.push(index);
  }
  return {
    ok: indexes.length > 0,
    number: normalized.number,
    indexes,
    error: indexes.length > 0 ? "" : "not_found",
  };
}

function buildRows(db) {
  const devices = db.physicalDevices || {};
  const activeSerials = new Set();
  const rows = Object.values(db.cycles || {})
    .filter((cycle) => cycle.status === "active")
    .map((cycle) => {
      const device = devices[cycle.physicalSerial] || {};
      const deviceNumber = tagBoardDeviceNumber(device);
      if (cycle.physicalSerial) activeSerials.add(String(cycle.physicalSerial));
      const tags = withFleetGroupTag(canonicalizeTags(Array.isArray(cycle.tags) ? cycle.tags : []));
      return {
        managementId: cycle.managementId || device.managementId || "",
        displayId: "",
        name: tagBoardDeviceName(device),
        sortLabel: device.uiNameOverride || device.name || device.xiaoweiName || "",
        deviceCode: device.deviceCode || "",
        deviceDisplayCode: tagBoardDisplayCode(device),
        uiNameOverride: device.uiNameOverride || "",
        xiaoweiName: device.xiaoweiName || "",
        serial: cycle.physicalSerial,
        status: firstTag(tags, /^STATE_/),
        ci: firstTag(tags, /^CI_/),
        video180: taskTagSummary(tags, /^V180_(?!DONE$)/, "V180_DONE"),
        video10: taskTagSummary(tags, /^V10_(?!DONE$)/, "V10_DONE"),
        day: firstTag(tags, /^DAY_/),
        decision: firstTag(tags, /^DEC_/),
        network: firstTag(tags, /^NET_/),
        can3000: tags.includes("OK_3000") ? "OK_3000" : tags.includes("NG_3000") ? "NG_3000" : "",
        currentPoints: value(cycle.currentPoints),
        currentYen: value(cycle.currentYen),
        pointScreenType: cycle.lastPointScreenType || "",
        projectedGrossYen: value(cycle.economics && cycle.economics.projectedGrossYen),
        dayYieldYenWith200hWait: value(cycle.economics && cycle.economics.dayYieldYenWith200hWait),
        adbStatus: cycle.lastAdbStatus || "",
        xiaoweiStatus: cycle.lastXiaoweiStatus || "",
        xiaoweiSort: value(deviceNumber),
        laixiNumber: value(deviceNumber),
        allTags: tags.join(" / "),
      };
    });
  for (const device of Object.values(devices)) {
    const serial = String(device.serial || "");
    if (!serial || activeSerials.has(serial)) continue;
    const tags = withFleetGroupTag([]);
    const deviceNumber = tagBoardDeviceNumber(device);
    rows.push({
      managementId: device.managementId || "",
      displayId: "",
      name: tagBoardDeviceName(device),
      sortLabel: device.uiNameOverride || device.name || device.xiaoweiName || "",
      deviceCode: device.deviceCode || "",
      deviceDisplayCode: tagBoardDisplayCode(device),
      uiNameOverride: device.uiNameOverride || "",
      xiaoweiName: device.xiaoweiName || "",
      serial,
      status: "",
      ci: "",
      video180: "",
      video10: "",
      day: "",
      decision: "",
      network: "",
      can3000: "",
      currentPoints: "",
      currentYen: "",
      pointScreenType: "",
      projectedGrossYen: "",
      dayYieldYenWith200hWait: "",
      adbStatus: "",
      xiaoweiStatus: "",
      xiaoweiSort: value(deviceNumber),
      laixiNumber: value(deviceNumber),
      allTags: tags.join(" / "),
    });
  }
  annotateTagBoardDisplayIds(rows);
  return rows.sort(compareBoardRows);
}

function compareBoardRows(a, b) {
  const groupA = boardSortGroup(a);
  const groupB = boardSortGroup(b);
  if (groupA !== groupB) return groupA - groupB;

  if (groupA === 0) return compareTagBoardNumberRows(a, b);

  const numberA = managementNumber(a.displayId || a.managementId);
  const numberB = managementNumber(b.displayId || b.managementId);
  if (numberA !== numberB) return numberA - numberB;

  return String(a.displayId || a.managementId).localeCompare(String(b.displayId || b.managementId), "en");
}

function boardSortGroup(row) {
  const tags = String(row.allTags || "");
  const xiaoweiSort = Number(row.xiaoweiSort || 0);
  if (tags.includes("GROUP_INACTIVE") || tags.includes("GROUP_REST") || tags.includes("WAITING")) return 9;
  return 0;
}

function withFleetGroupTag(tags) {
  const result = tags.filter((tag) => !/^GROUP_/.test(tag));
  const groupTag = fleetGroupTag(tags);
  if (groupTag) result.unshift(groupTag);
  return sortTags(result);
}

function fleetGroupTag(tags) {
  if (tags.includes("GROUP_REST") || tags.includes("WAITING")) return "GROUP_INACTIVE";
  if (tags.includes("GROUP_INACTIVE")) return "GROUP_INACTIVE";
  if (tags.includes("GROUP_ACTIVE")) return "GROUP_ACTIVE";
  if (!tags.some((tag) => /^DAY_\d{2}$/.test(tag))) return "GROUP_INACTIVE";
  return "GROUP_ACTIVE";
}

function managementNumber(value) {
  const match = String(value || "").match(/(\d+)/);
  return match ? Number(match[1]) : Number.MAX_SAFE_INTEGER;
}

function annotateTagBoardDisplayIds(rows) {
  const bands = [
    { key: "active", start: 1, end: INACTIVE_NUMBER_START },
    { key: "inactive", start: INACTIVE_NUMBER_START, end: 9000 },
  ];
  for (const band of bands) {
    const bandRows = rows.filter((row) => tagBoardNumberBand(row) === band.key);
    const used = new Set();
    const pending = [];
    for (const row of bandRows) {
      const storedNumber = tagBoardStoredNumber(row);
      if (storedNumber >= band.start && storedNumber < band.end && !used.has(storedNumber)) {
        assignTagBoardNumber(row, storedNumber, "db_canonical");
        used.add(storedNumber);
      } else {
        pending.push(row);
      }
    }
    pending.sort(compareTagBoardNumberRows);
    let next = band.start;
    for (const row of pending) {
      while (next < band.end && used.has(next)) next += 1;
      if (next >= band.end) throw new Error(`Tag board ${band.key} number range is full`);
      assignTagBoardNumber(row, next, "db_projection");
      used.add(next);
      next += 1;
    }
  }
  assertTagBoardNumberSync(rows);
}

function tagBoardDeviceNumber(device) {
  for (const input of [
    device && device.laixiNumberOverride,
    device && device.xiaoweiSort,
    device && device.laixiNumber,
    device && device.number,
  ]) {
    const number = Number(input);
    if (Number.isInteger(number) && number > 0) return number;
  }
  return "";
}

function tagBoardStoredNumber(row) {
  for (const input of [row && row.laixiNumber, row && row.xiaoweiSort]) {
    const number = Number(input);
    if (Number.isInteger(number) && number > 0) return number;
  }
  return 0;
}

function assignTagBoardNumber(row, number, source) {
  row.displayId = String(number);
  row.laixiNumber = String(number);
  row.xiaoweiSort = number;
  row.numberSource = source;
}

function assertTagBoardNumberSync(rows) {
  const seen = new Map();
  const errors = [];
  for (const row of rows) {
    const displayId = String(row.displayId || "");
    const laixiNumber = String(row.laixiNumber || "");
    if (!displayId) errors.push(`${row.serial}: missing displayId`);
    if (displayId !== laixiNumber) errors.push(`${row.serial}: displayId ${displayId} != laixiNumber ${laixiNumber}`);
    if (displayId) {
      const previous = seen.get(displayId);
      if (previous) errors.push(`${row.serial}: duplicate displayId ${displayId} with ${previous}`);
      else seen.set(displayId, row.serial);
    }
  }
  if (errors.length) {
    throw new Error(`Tag board number sync failed: ${errors.slice(0, 10).join("; ")}`);
  }
}

function compareTagBoardNumberRows(a, b) {
  const dayA = Number(String(a.day || "").replace(/^DAY_/, "") || 0);
  const dayB = Number(String(b.day || "").replace(/^DAY_/, "") || 0);
  if (dayA !== dayB) return dayB - dayA;
  const partsA = parseSortLabel(a.sortLabel || a.name);
  const partsB = parseSortLabel(b.sortLabel || b.name);
  const model = String(partsA.modelGroup || "").localeCompare(String(partsB.modelGroup || ""), "en", { numeric: true });
  if (model !== 0) return model;
  const carrier = carrierSortValue(partsA.carrierCode) - carrierSortValue(partsB.carrierCode)
    || String(partsA.carrierCode || "").localeCompare(String(partsB.carrierCode || ""), "en", { numeric: true });
  if (carrier !== 0) return carrier;
  const label = String(partsA.deviceCode || a.sortLabel || a.name || "").localeCompare(String(partsB.deviceCode || b.sortLabel || b.name || ""), "en", { numeric: true });
  if (label !== 0) return label;
  return String(a.managementId || a.serial).localeCompare(String(b.managementId || b.serial), "en", { numeric: true });
}

function parseSortLabel(value) {
  const text = String(value || "").trim();
  const match = /^([A-Za-z0-9]+)(?:-\d+)?(?:\s+([A-Z]+))?/.exec(text);
  return {
    modelGroup: match ? match[1].toUpperCase() : text.toUpperCase(),
    carrierCode: match && match[2] ? match[2].toUpperCase() : "UNKNOWN",
    deviceCode: text,
  };
}

function carrierSortValue(value) {
  return {
    DOCOMO: 10,
    KDDI: 20,
    SBM: 30,
    RAKUTEN: 40,
    SIMFREE: 50,
    UNKNOWN: 90,
  }[String(value || "UNKNOWN").toUpperCase()] || 80;
}

function tagBoardNumberBand(row) {
  const tags = String(row.allTags || "");
  if (tags.includes("GROUP_REST") || tags.includes("WAITING")) return "inactive";
  if (tags.includes("GROUP_INACTIVE")) return "inactive";
  if (tags.includes("GROUP_ACTIVE")) return "active";
  return row.day ? "active" : "inactive";
}

function firstTag(tags, pattern) {
  return tags.find((tag) => pattern.test(tag)) || "";
}

function taskTagSummary(tags, amountPattern, doneTag) {
  const amount = firstTag(tags, amountPattern);
  const done = tags.includes(doneTag) ? doneTag : "";
  return [amount, done].filter(Boolean).join(" + ");
}

function value(input) {
  return input === undefined || input === null ? "" : input;
}

function writeCsv(filePath, rows) {
  const headers = [
    "managementId",
    "displayId",
    "name",
    "xiaoweiName",
    "serial",
    "status",
    "ci",
    "video180",
    "video10",
    "day",
    "decision",
    "network",
    "can3000",
    "currentPoints",
    "currentYen",
    "pointScreenType",
    "projectedGrossYen",
    "dayYieldYenWith200hWait",
    "xiaoweiSort",
    "laixiNumber",
    "allTags",
  ];
  const lines = [headers.join(",")];
  for (const row of rows) {
    lines.push(headers.map((header) => csvCell(row[header])).join(","));
  }
  fs.writeFileSync(filePath, `${lines.join("\n")}\n`, "utf8");
}

function writeMarkdown(filePath, rows, db) {
  const now = new Date().toISOString();
  const tagIndex = buildTagIndex(rows);
  const headers = ["??", "??", "??", "CI", "180?", "10?", "DAY", "??", "3000?", "??"];
  const lines = [
    "# Device Tag Board",
    "",
    `Generated: ${now}`,
    "",
    "Tags are managed only in the local DB. XiaoWei receives device names and numbers only.",
    "",
    "## Device View",
    "",
    `| ${headers.join(" | ")} |`,
    `| ${headers.map(() => "---").join(" | ")} |`,
    ...rows.map((row) => `| ${[
      row.displayId || row.managementId,
      row.name,
      row.status,
      row.ci,
      row.video180,
      row.video10,
      row.day,
      row.decision,
      row.can3000,
      row.currentYen || row.projectedGrossYen,
    ].map(mdCell).join(" | ")} |`),
    "",
    "## Tag View",
    "",
    ...Object.entries(tagIndex).map(([tag, ids]) => `- ${tag}: ${ids.join(", ")}`),
    "",
    "## Tag Translation",
    "",
    ...matrixLikeTags(rows).map((tag) => `- ${tag}: ${tagDescriptionJa(tag) || tagLabel(tag)}`),
    "",
    "## Source",
    "",
    `- DB updatedAt: ${db.updatedAt || ""}`,
    `- Active rows: ${rows.length}`,
    "",
  ];
  fs.writeFileSync(filePath, lines.join("\n"), "utf8");
}

function buildTagIndex(rows) {
  const result = {};
  for (const row of rows) {
    for (const tag of row.allTags.split(" / ").filter(Boolean)) {
      result[tag] = result[tag] || [];
      result[tag].push(row.displayId || row.managementId || row.serial);
    }
  }
  return Object.fromEntries(Object.entries(result).sort(([a], [b]) => sortTags([a, b])[0] === a ? -1 : 1));
}

function matrixLikeTags(rows) {
  const discovered = new Set();
  for (const row of rows) {
    for (const tag of row.allTags.split(" / ").filter(Boolean)) {
      discovered.add(tag);
    }
  }
  const ordered = [];
  for (const tag of preferredTags) {
    if (discovered.has(tag)) ordered.push(tag);
  }
  for (const tag of sortTags([...discovered])) {
    if (!ordered.includes(tag)) ordered.push(tag);
  }
  return ordered;
}

function buildMatrix(rows) {
  const discovered = new Set();
  for (const row of rows) {
    for (const tag of row.allTags.split(" / ").filter(Boolean)) {
      discovered.add(tag);
    }
  }

  const ordered = [];
  for (const tag of boardVisibleTags) {
    if (!ordered.includes(tag)) ordered.push(tag);
  }
  for (const tag of sortTags([...discovered]).filter((tag) => boardVisibleTags.includes(tag))) {
    if (tag === "STATE_ACTIVE") continue;
    if (!ordered.includes(tag)) ordered.push(tag);
  }

  return {
    generatedAt: new Date().toISOString(),
    tags: ordered,
    devices: rows.map((row) => {
      const tagSet = new Set(row.allTags.split(" / ").filter(Boolean));
      return {
        managementId: row.managementId,
        displayId: row.displayId || row.managementId,
        name: row.name,
        xiaoweiName: row.xiaoweiName,
        serial: row.serial,
        currentPoints: row.currentPoints,
        currentYen: row.currentYen,
        pointScreenType: row.pointScreenType,
        projectedGrossYen: row.projectedGrossYen,
        dayYieldYenWith200hWait: row.dayYieldYenWith200hWait,
        adbStatus: row.adbStatus,
        xiaoweiStatus: row.xiaoweiStatus,
        xiaoweiSort: row.xiaoweiSort,
        laixiNumber: row.laixiNumber,
        tags: Object.fromEntries(ordered.map((tag) => [tag, tagSet.has(tag)])),
      };
    }),
  };
}

function writeMatrixCsv(filePath, matrix) {
  const headers = ["端末", "名前", "見込み円", ...matrix.tags];
  const lines = [headers.join(",")];
  for (const device of matrix.devices) {
    const row = [
      device.managementId,
      device.displayId,
      device.name,
      device.xiaoweiName,
      device.serial,
      device.currentPoints,
      device.currentYen,
      device.pointScreenType,
      device.currentYen || device.projectedGrossYen,
      device.dayYieldYenWith200hWait,
      device.xiaoweiSort,
      device.laixiNumber,
      ...matrix.tags.map((tag) => device.tags[tag] ? "1" : ""),
    ];
    lines.push(row.map(csvCell).join(","));
  }
  fs.writeFileSync(filePath, `${lines.join("\n")}\n`, "utf8");
}

function writeMatrixMarkdown(filePath, matrix, db) {
  const headers = ["端末", "名前", "見込み円", ...matrix.tags];
  const lines = [
    "# Device Tag Matrix",
    "",
    `Generated: ${matrix.generatedAt}`,
    "",
    "Tags are managed only in the local DB. XiaoWei receives device names and numbers only.",
    "",
    `| ${headers.map(mdCell).join(" | ")} |`,
    `| ${headers.map(() => "---").join(" | ")} |`,
    ...matrix.devices.map((device) => `| ${[
      device.displayId || device.managementId,
      device.name,
      device.projectedGrossYen,
      ...matrix.tags.map((tag) => device.tags[tag] ? "checked" : ""),
    ].map(mdCell).join(" | ")} |`),
    "",
    "## Source",
    "",
    `- DB updatedAt: ${db.updatedAt || ""}`,
    `- Active rows: ${matrix.devices.length}`,
    `- Tag columns: ${matrix.tags.length}`,
    "",
  ];
  fs.writeFileSync(filePath, lines.join("\n"), "utf8");
}

function writeMatrixHtml(filePath, matrix, db) {
  const styles = `
    :root { color-scheme: light dark; font-family: "Segoe UI", Meiryo, sans-serif; }
    body { margin: 0; padding: 16px; background: #111827; color: #e5e7eb; }
    h1 { margin: 0 0 8px; font-size: 20px; }
    .meta { color: #9ca3af; margin-bottom: 12px; font-size: 13px; }
    .hint { color: #cbd5e1; margin-bottom: 12px; font-size: 13px; }
    .top-scroll { overflow-x: auto; overflow-y: hidden; height: 20px; border: 1px solid #374151; border-radius: 8px; margin-bottom: 8px; background: #0f172a; }
    .top-scroll-inner { height: 1px; }
    .wrap { overflow: auto; border: 1px solid #374151; border-radius: 8px; height: calc(100vh - 116px); background: #0f172a; scrollbar-gutter: stable both-edges; }
    .top-scroll::-webkit-scrollbar,
    .wrap::-webkit-scrollbar { width: 18px; height: 18px; }
    .top-scroll::-webkit-scrollbar-thumb,
    .wrap::-webkit-scrollbar-thumb { background: #64748b; border: 4px solid #0f172a; border-radius: 999px; }
    .top-scroll::-webkit-scrollbar-track,
    .wrap::-webkit-scrollbar-track { background: #1f2937; }
    table { border-collapse: separate; border-spacing: 0; font-size: 13px; min-width: max-content; }
    th, td { border-right: 1px solid #273244; border-bottom: 1px solid #273244; padding: 7px 8px; white-space: nowrap; text-align: center; }
    th { position: sticky; top: 0; z-index: 2; background: #1f2937; color: #f9fafb; }
    th.device, td.device { position: sticky; left: 0; z-index: 3; background: #172033; text-align: left; min-width: 74px; }
    th.name, td.name { position: sticky; left: 90px; z-index: 3; background: #172033; text-align: left; min-width: 150px; }
    th.name { z-index: 4; }
    th.device { z-index: 4; }
    .tag-head { min-width: 44px; max-width: 58px; height: 62px; line-height: 1.12; white-space: normal; word-break: keep-all; vertical-align: bottom; font-size: 11px; padding: 5px 4px; }
    .tag-head.day { min-width: 34px; max-width: 38px; }
    .tag-head.short { min-width: 46px; max-width: 52px; }
    .tag-head .line { display: block; }
    .tag-head .sub { color: #cbd5e1; font-size: 10px; }
    input[type="checkbox"] { width: 17px; height: 17px; accent-color: #22c55e; }
    .empty input[type="checkbox"] { opacity: .45; }
    .yen { color: #fbbf24; font-variant-numeric: tabular-nums; }
    .error { background: #3b1722; }
    .ci { background: #263247; }
    .task { background: #17343f; }
    .day { background: #25223c; }
    .invite { background: #3a2a15; }
    .profit { background: #173422; }
    .cycle { background: #2b2d42; }
  `;
  const html = `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>チェック一覧</title>
${faviconLinks()}
<style>${styles}</style>
</head>
<body>
<h1>チェック一覧</h1>
<div class="meta">表示端末 ${matrix.devices.length}台 / チェック項目 ${matrix.tags.length}件 / ${escapeHtml(matrix.generatedAt)}</div>
<div class="hint">チェックはローカルDBで管理します。XiaoWeiへは端末名と番号だけ同期します。</div>
<div class="top-scroll"><div class="top-scroll-inner"></div></div>
<div class="wrap">
<table>
<thead>
<tr>
<th class="device">端末</th>
<th class="name">名前</th>
<th>見込み円</th>
${matrix.tags.map((tag) => `<th class="tag-head ${tagClass(tag)}">${tagLabelHtml(tag)}</th>`).join("")}
</tr>
</thead>
<tbody>
${matrix.devices.map((device) => `<tr>
<td class="device">${escapeHtml(device.displayId || device.managementId)}</td>
<td class="name">${escapeHtml(device.name)}</td>
<td class="yen">${escapeHtml(device.projectedGrossYen)}</td>
${matrix.tags.map((tag) => `<td class="${device.tags[tag] ? "checked" : "empty"} ${tagClass(tag)}"><input type="checkbox" ${device.tags[tag] ? "checked" : ""} disabled></td>`).join("")}
</tr>`).join("\n")}
</tbody>
</table>
</div>
<script>
(() => {
  const wrap = document.querySelector('.wrap');
  const topScroll = document.querySelector('.top-scroll');
  const topInner = document.querySelector('.top-scroll-inner');
  const table = document.querySelector('table');
  if (!wrap || !topScroll || !topInner || !table) return;
  const syncWidth = () => {
    topInner.style.width = table.scrollWidth + 'px';
  };
  syncWidth();
  window.addEventListener('resize', syncWidth);
  topScroll.addEventListener('scroll', () => {
    if (wrap.scrollLeft !== topScroll.scrollLeft) wrap.scrollLeft = topScroll.scrollLeft;
  });
  wrap.addEventListener('scroll', () => {
    if (topScroll.scrollLeft !== wrap.scrollLeft) topScroll.scrollLeft = wrap.scrollLeft;
  });
})();
</script>
</body>
</html>`;
  fs.writeFileSync(filePath, html, "utf8");
}

function writeTransposedHtml(filePath, matrix, db) {
  const fleetCounts = fleetCountSummary(matrix);
  const styles = `
    :root {
      color-scheme: dark;
      --bg: #05070d;
      --panel: #0a0f18;
      --panel-2: #101720;
      --line: #2a313d;
      --line-soft: #202734;
      --text: #f8fafc;
      --muted: #8b98aa;
      --green: #22c55e;
      --cyan: #22d3ee;
      --pink: #fb7185;
      --yellow: #facc15;
      --ink: #080a0f;
      font-family: "Segoe UI", Meiryo, sans-serif;
    }
    html, body { width: 100%; height: 100%; min-height: 100vh; min-height: 100dvh; }
    body { box-sizing: border-box; margin: 0; padding: 0; background: var(--bg); color: var(--text); overflow: hidden; display: grid; grid-template-rows: 42px auto minmax(0, 1fr); gap: 0; }
    *, *::before, *::after { box-sizing: border-box; }
    .topbar { display: flex; align-items: center; gap: 8px; min-height: 0; padding: 0 10px 0 0; border-bottom: 1px solid #2c3340; background: #0b0f17; overflow: hidden; }
    .brand-lockup { display: none; }
    .brand-mark { width: 24px; height: 24px; border-radius: 5px; background: var(--ink); box-shadow: 5px 0 0 var(--cyan), 10px 0 0 var(--pink); flex: 0 0 auto; }
    h1 { align-self: stretch; display: flex; align-items: center; margin: 0 8px 0 0; padding: 0 12px; min-width: 120px; background: #0b0f17; color: #f8fafc; border-right: 1px solid #2c3340; font-size: 17px; letter-spacing: 0; line-height: 1; }
    h1::after { content: none; }
    .brand-sub { display: block; margin-top: 3px; color: #3f3505; font-size: 10px; font-weight: 800; }
    .command-strip { display: contents; }
    .stats-strip { display: contents; }
    button { min-height: 32px; border: 1px solid #303846; background: #121923; color: #f8fafc; border-radius: 4px; padding: 5px 11px; font-weight: 900; cursor: pointer; }
    button:hover { border-color: var(--yellow); }
    button.secondary { border-color: #1f8a4c; background: #0f3f28; }
    button.utility { border-color: #0e7490; background: #123142; }
    button:disabled { opacity: .45; cursor: not-allowed; }
    .button-help-popover {
      position: fixed;
      z-index: 10000;
      min-width: 220px;
      max-width: 360px;
      border: 1px solid #475569;
      border-radius: 7px;
      padding: 9px 10px;
      background: #020617;
      color: #e5e7eb;
      box-shadow: 0 14px 34px rgba(0,0,0,.42);
      font-size: 12px;
      font-weight: 800;
      line-height: 1.55;
      pointer-events: none;
    }
    .button-help-popover::before {
      content: "";
      position: absolute;
      left: 18px;
      top: -6px;
      width: 10px;
      height: 10px;
      border-left: 1px solid #475569;
      border-top: 1px solid #475569;
      background: #020617;
      transform: rotate(45deg);
    }
    .button-help-popover[hidden] { display: none; }
    #restartAdb { display: none; }
    body.embedded #syncXiaowei { display: none; }
    #applyChanges { border-color: #155e75; background: #164e63; color: #e0f2fe; }
    #applyChanges:not(:disabled) { border-color: #0891b2; background: #0e7490; box-shadow: inset 0 0 0 1px rgba(34,211,238,.18); }
    #applyChanges:disabled { opacity: .64; }
    .status { display: inline-flex; align-items: center; min-height: 28px; border: 1px solid #475569; background: #1e293b; color: #e2e8f0; border-radius: 4px; padding: 3px 9px; font-size: 12px; font-weight: 900; white-space: nowrap; }
    .status.warn { border-color: #a16207; background: #422006; color: var(--yellow); }
    .status.ok { color: #86efac; }
    .status.error { border-color: #991b1b; background: #3b121f; color: #fca5a5; }
    .confirm-overlay {
      position: fixed;
      inset: 0;
      z-index: 20000;
      display: grid;
      place-items: center;
      padding: 24px;
      background: rgba(2, 6, 23, .74);
    }
    .confirm-dialog {
      width: min(560px, 100%);
      border: 1px solid #475569;
      border-radius: 8px;
      background: #0b1220;
      color: #e5e7eb;
      box-shadow: 0 24px 70px rgba(0,0,0,.55);
      padding: 18px;
    }
    .confirm-dialog h2 { margin: 0 0 12px; font-size: 18px; }
    .confirm-dialog p { margin: 0 0 10px; line-height: 1.65; }
    .confirm-dialog ul { max-height: 120px; overflow: auto; margin: 8px 0 14px; padding: 8px 10px 8px 24px; border: 1px solid #1f2937; border-radius: 6px; background: #020617; }
    .confirm-dialog label { display: grid; gap: 5px; margin: 10px 0; font-size: 12px; color: #cbd5e1; font-weight: 800; }
    .confirm-dialog select,
    .confirm-dialog input { min-height: 34px; border: 1px solid #334155; border-radius: 6px; background: #020617; color: #e5e7eb; padding: 5px 9px; font-weight: 800; }
    .confirm-actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 16px; }
    .confirm-actions .yes { border-color: #15803d; background: #14532d; }
    .confirm-actions .no { border-color: #64748b; background: #1e293b; }
    .tag-note { color: #a9b9ce; font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 330px; }
    .flow-note { display: flex; align-items: center; gap: 8px 14px; flex-wrap: wrap; overflow: visible; color: #a9b9ce; font-size: 11px; border-bottom: 1px solid #202734; background: #080c12; padding: 5px 10px; line-height: 1.45; white-space: normal; }
    .flow-note-text { flex: 1 1 360px; min-width: 180px; }
    .flow-note-text::before { content: ">"; color: var(--yellow); margin-right: 6px; font-size: 9px; }
    body.embedded .flow-note { max-height: none; overflow: visible; }
    .device-search { display: flex; align-items: center; gap: 6px; flex: 0 1 auto; min-width: 0; margin-left: auto; }
    .device-search label { color: #e2e8f0; font-size: 12px; font-weight: 900; white-space: nowrap; }
    .device-search input { width: 118px; min-width: 76px; height: 30px; border: 1px solid #475569; border-radius: 4px; background: #020617; color: #f8fafc; padding: 4px 8px; font-size: 14px; font-weight: 900; font-variant-numeric: tabular-nums; }
    .device-search input:focus { border-color: var(--yellow); outline: 2px solid rgba(250,204,21,.24); outline-offset: 1px; }
    .device-search.not-found input { border-color: #ef4444; outline-color: rgba(239,68,68,.25); }
    .device-search button { min-height: 30px; height: 30px; padding: 3px 9px; }
    .device-search-result { min-width: 78px; color: #86efac; font-size: 11px; font-weight: 900; white-space: nowrap; }
    .device-search-result.error { color: #fca5a5; }
    .fleet-counts { display: inline-flex; align-items: center; gap: 5px; font-size: 11px; color: #cbd5e1; }
    .fleet-count { display: inline-flex; align-items: center; min-height: 28px; padding: 2px 9px; border: 1px solid #303846; border-radius: 4px; background: #101720; font-variant-numeric: tabular-nums; font-weight: 900; white-space: nowrap; }
    .fleet-count.active { color: #bbf7d0; border-color: #166534; background: #0d2c1c; }
    .fleet-count.inactive { color: #fde68a; border-color: #92400e; background: #2a1d0b; }
    .fleet-count.sleeping { color: #ddd6fe; border-color: #5b21b6; background: #211b35; }
    .meta { color: var(--muted); margin-left: auto; font-size: 10px; white-space: nowrap; }
    .hint { display: none; }
    .wrap { overflow-x: hidden; overflow-y: auto; border: 0; min-height: 0; height: 100%; background: var(--panel); scrollbar-gutter: stable both-edges; }
    .wrap::-webkit-scrollbar { width: 18px; height: 18px; }
    .wrap::-webkit-scrollbar-thumb { background: #64748b; border: 4px solid var(--panel); border-radius: 999px; }
    .wrap::-webkit-scrollbar-track { background: #05070d; }
    .matrix-grid { display: flex; flex-direction: column; gap: 0; padding: 0; }
    .matrix-section { width: 100%; overflow: hidden; border-bottom: 2px solid #05070d; background: #0a0f18; }
    table { border-collapse: separate; border-spacing: 0; font-size: 13px; width: 100%; table-layout: fixed; }
    th, td { border-right: 1px solid #1b212c; border-bottom: 1px solid #1b212c; padding: 3px 3px; white-space: nowrap; text-align: center; }
    th { position: sticky; top: 0; z-index: 2; background: #111827; color: #f9fafb; border-bottom: 2px solid var(--yellow); }
    tbody tr:nth-child(2n) td { box-shadow: inset 0 1px 0 rgba(255,255,255,.015); }
    tbody tr:hover td { filter: brightness(1.18); }
    col.tag-col { width: 118px; }
    th.tag, td.tag { position: sticky; left: 0; z-index: 3; background: #101720; text-align: left; width: 118px; min-width: 118px; max-width: 118px; overflow: visible; white-space: normal; line-height: 1.08; box-shadow: 2px 0 0 #05070d; font-weight: 900; vertical-align: middle; }
    th.tag { z-index: 4; }
    td.tag { padding: 4px 6px 4px 8px; }
    .tag-label { display: block; white-space: normal; word-break: keep-all; }
    .tag-label .line { display: block; }
    .tag-label .sub { display: block; color: #dbeafe; font-size: 11px; font-variant-numeric: tabular-nums; margin-top: 1px; }
    .device-head { width: 76px; min-width: 76px; max-width: 76px; white-space: normal; line-height: 1.06; font-size: 10px; vertical-align: bottom; padding: 5px 3px 5px; overflow: hidden; background: #141b26; }
    .device-head .id { display: block; color: #f8fafc; font-weight: 900; font-size: 13px; }
    .device-head .park { display: block; color: var(--yellow); font-weight: 900; font-size: 11px; font-variant-numeric: tabular-nums; }
    .device-head .name { display: block; color: #e5e7eb; overflow: hidden; text-overflow: ellipsis; }
    .device-head .conn { display: block; color: var(--muted); font-size: 9px; font-weight: 800; letter-spacing: .02em; }
    .device-head.offline-device { background: #3a1820; box-shadow: inset 0 3px 0 #ef4444; }
    .device-head.offline-device .id,
    .device-head.offline-device .conn { color: #fca5a5; }
    .device-head.sleeping-device { background: #24213d; box-shadow: inset 0 3px 0 #a78bfa; }
    .device-head.sleeping-device .id,
    .device-head.sleeping-device .conn { color: #c4b5fd; }
    .tag.group { background: #1f2937; color: #fde68a; border-left: 4px solid var(--yellow); }
    .tag.error { background: #3b121f; color: #fecaca; border-left: 4px solid #fb7185; }
    .tag.ci { background: #151f32; color: #bfdbfe; border-left: 4px solid #60a5fa; }
    .tag.task { background: #102a30; color: #99f6e4; border-left: 4px solid var(--cyan); }
    .tag.day { background: #211d37; color: #ddd6fe; border-left: 4px solid #a78bfa; }
    .tag.invite { background: #2c220f; color: #fde68a; border-left: 4px solid var(--yellow); }
    .tag.profit { background: #102617; color: #bbf7d0; border-left: 4px solid var(--green); }
    .tag.cycle { background: #1e2338; color: #c7d2fe; border-left: 4px solid #818cf8; }
    .checked { background: #1f2937; color: #e5e7eb; font-weight: 700; }
    .empty { color: #4b5563; }
    td.ci.empty { background: #172238; }
    td.ci.checked { background: #1e3a5f; color: #bfdbfe; }
    td.task.empty { background: #102a30; }
    td.task.checked { background: #12514b; color: #99f6e4; }
    td.day.empty { background: #1c1b31; }
    td.day.checked { background: #342d63; color: #ddd6fe; }
    td.invite.empty { background: #241c12; }
    td.invite.checked { background: #6b4b12; color: #fde68a; }
    td.profit.empty { background: #102617; }
    td.profit.checked { background: #166534; color: #bbf7d0; }
    td.cycle.empty { background: #1f2235; }
    td.cycle.checked { background: #3730a3; color: #c7d2fe; }
    td.error.empty { background: #2b151d; }
    td.error.checked { background: #4a1f2b; color: #fecaca; }
    td.group.empty { background: #1b2231; }
    td.group.checked { background: #5a4314; color: #fde68a; }
    td.group input[type="checkbox"] { accent-color: var(--yellow); }
    td.ci input[type="checkbox"] { accent-color: #60a5fa; }
    td.task input[type="checkbox"] { accent-color: var(--cyan); }
    td.day input[type="checkbox"] { accent-color: #a78bfa; }
    td.error input[type="checkbox"] { accent-color: #fb7185; }
    td.profit input[type="checkbox"] { accent-color: var(--green); }
    td.cycle input[type="checkbox"] { accent-color: #818cf8; }
    td.offline-device,
    td.offline-device.empty { background: #2b151d; }
    td.offline-device.checked { background: #3f2022; color: #fecaca; }
    td.sleeping-device,
    td.sleeping-device.empty { background: #1e1b34; }
    td.sleeping-device.checked { background: #2c2854; color: #ddd6fe; }
    input[type="checkbox"] { width: 18px; height: 18px; accent-color: var(--yellow); cursor: pointer; filter: drop-shadow(0 1px 1px rgba(0,0,0,.45)); }
    td.empty input[type="checkbox"] { opacity: .42; }
    td.changed { outline: 2px solid var(--yellow); outline-offset: -2px; box-shadow: inset 0 0 0 1px rgba(250,204,21,.35); }
    body.changes-settled td.changed { outline: none !important; }
    th.device-search-match, td.device-search-match { position: relative; }
    th.device-search-match::after, td.device-search-match::after { content: ""; position: absolute; inset: 0; z-index: 1; pointer-events: none; background: rgba(250,204,21,.12); box-shadow: inset 3px 0 0 var(--yellow), inset -3px 0 0 var(--yellow); }
    th.device-search-match::after { background: rgba(250,204,21,.2); box-shadow: inset 0 0 0 3px var(--yellow); }
  `;
  const clientMatrix = {
    tags: matrix.tags.map((tag) => ({
      tag,
      label: displayTagName(tag),
      klass: tagClass(tag),
      kind: tag.startsWith('GROUP_') ? 'group' : 'tag',
    })),
    devices: matrix.devices.map((device) => ({
      managementId: device.managementId,
      displayId: device.displayId || device.managementId,
      name: shortDeviceName(device.deviceDisplayCode || device.name),
      serial: device.serial,
      park: parkingLabel(device),
      yen: formatCurrentYen(device),
      conn: connectionLabel(device),
      connectionClass: connectionClass(device),
      tags: device.tags,
    })),
  };
  const html = `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>チェック一覧</title>
${faviconLinks()}
<style>${styles}</style>
</head>
<body>
<div class="topbar">
<h1>チェック一覧</h1>
<button id="syncXiaowei" class="secondary">XiaoWei同期</button>
<button id="applyChanges" disabled>DBへ反映</button>
<span id="changeStatus" class="status">変更なし</span>
<span class="tag-note">チェック変更はDBへ反映してから、必要に応じてXiaoWeiへ同期します。</span>
<span class="fleet-counts" title="チェック一覧の表示台数">
<span class="fleet-count active">稼働 ${fleetCounts.active}台</span>
<span class="fleet-count inactive">非稼働 ${fleetCounts.inactive}台</span>
</span>
<div class="meta">表示端末 ${matrix.devices.length}台 / チェック項目 ${matrix.tags.length}件 / ${escapeHtml(matrix.generatedAt)}</div>
</div>
<div class="flow-note">
<div class="flow-note-text">流れ: チェック変更 → DBへ反映 → XiaoWei同期。古い情報が残る時は画面更新してください。</div>
<form id="deviceSearchForm" class="device-search" role="search">
<label for="deviceSearchInput">端末番号</label>
<input id="deviceSearchInput" type="search" inputmode="text" autocomplete="off" placeholder="例: 25 / A-25" aria-describedby="deviceSearchResult">
<button id="deviceSearchSubmit" class="utility" type="submit">移動</button>
<button id="deviceSearchClear" type="button" disabled>解除</button>
<span id="deviceSearchResult" class="device-search-result" aria-live="polite"></span>
</form>
</div>
<div class="wrap">
<div id="matrixGrid" class="matrix-grid"></div>
</div>
<script>
(() => {
  if (window.self !== window.top) document.body.classList.add('embedded');
  if (new URL(window.location.href).searchParams.get('generated') === '1') {
    window.history.replaceState(null, '', window.location.pathname);
  }
  const matrixData = ${scriptJson(clientMatrix)};
  const normalizeTagBoardDeviceNumber = ${normalizeTagBoardDeviceNumber.toString()};
  const findTagBoardDeviceMatches = ${findTagBoardDeviceMatches.toString()};
  const wrap = document.querySelector('.wrap');
  const matrixGrid = document.querySelector('#matrixGrid');
  const syncButton = document.querySelector('#syncXiaowei');
  const applyButton = document.querySelector('#applyChanges');
  const status = document.querySelector('#changeStatus');
  const deviceSearchForm = document.querySelector('#deviceSearchForm');
  const deviceSearchInput = document.querySelector('#deviceSearchInput');
  const deviceSearchClear = document.querySelector('#deviceSearchClear');
  const deviceSearchResult = document.querySelector('#deviceSearchResult');
  const applyEndpoint = '/api/tag-board/tags/apply';
  const syncEndpoint = '/api/xiaowei/sync';
  const tagWidth = 118;
  const deviceWidth = 76;
  const buttonHelpTexts = {
    syncXiaowei: 'DBへ反映してからXiaoWeiへ同期します。',
    applyChanges: 'チェック変更だけをローカルDBへ保存します。',
    deviceSearchSubmit: '表示中の端末番号へ移動して、列全体を強調します。',
    deviceSearchClear: '番号検索の強調を解除します。',
  };
  const checkboxState = new Map();
  let busy = false;
  let suppressChanged = false;

  function cellKey(serial, tag) {
    return serial + '::' + tag;
  }

  function initButtonHelp() {
    const popup = document.createElement('div');
    popup.id = 'buttonHelpPopup';
    popup.className = 'button-help-popover';
    popup.setAttribute('role', 'tooltip');
    popup.hidden = true;
    document.body.appendChild(popup);
    let activeButton = null;

    function show(button) {
      const text = button && buttonHelpTexts[button.id];
      if (!text) return;
      activeButton = button;
      popup.textContent = text;
      popup.hidden = false;
      positionButtonHelp(button, popup);
    }

    function hide() {
      activeButton = null;
      popup.hidden = true;
    }

    document.addEventListener('pointerover', (event) => {
      const button = event.target.closest('button');
      if (button) show(button);
    });
    document.addEventListener('pointerout', (event) => {
      if (!activeButton) return;
      const next = event.relatedTarget;
      if (next && activeButton.contains(next)) return;
      hide();
    });
    document.addEventListener('focusin', (event) => {
      const button = event.target.closest('button');
      if (button) show(button);
    });
    document.addEventListener('focusout', hide);
    document.addEventListener('click', hide);
    window.addEventListener('scroll', hide, true);
    window.addEventListener('resize', hide);
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') hide();
    });
  }

  function positionButtonHelp(button, popup) {
    const rect = button.getBoundingClientRect();
    const gap = 8;
    const maxWidth = Math.min(360, window.innerWidth - 18);
    popup.style.maxWidth = maxWidth + 'px';
    popup.style.left = '0px';
    popup.style.top = '0px';
    const width = popup.offsetWidth;
    const height = popup.offsetHeight;
    let left = rect.left + rect.width / 2 - width / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
    let top = rect.bottom + gap;
    if (top + height > window.innerHeight - 8) top = rect.top - height - gap;
    popup.style.left = left + 'px';
    popup.style.top = Math.max(8, top) + 'px';
  }

  function changedInputs() {
    return [...document.querySelectorAll('input[type="checkbox"]')]
      .filter(input => input.checked !== (input.dataset.original === '1'));
  }

  function escapeText(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    }[char]));
  }

  function tagLabelTextHtml(value) {
    const parts = String(value ?? '').trim().split(/\s+/).filter(Boolean);
    if (parts.length >= 2) {
      return '<span class="tag-label"><span class="line">' + escapeText(parts[0]) + '</span><span class="sub">' + escapeText(parts.slice(1).join(' ')) + '</span></span>';
    }
    return '<span class="tag-label"><span class="line">' + escapeText(value) + '</span></span>';
  }

  function currentChecked(device, tag) {
    const key = cellKey(device.serial, tag.tag);
    if (checkboxState.has(key)) return checkboxState.get(key);
    return Boolean(device.tags && device.tags[tag.tag]);
  }

  function clearDeviceSearchHighlight() {
    for (const element of document.querySelectorAll('.device-search-match')) {
      element.classList.remove('device-search-match');
    }
  }

  function applyDeviceSearch(options = {}) {
    const shouldScroll = Boolean(options.scroll);
    const behavior = options.behavior === 'auto' ? 'auto' : 'smooth';
    const rawQuery = deviceSearchInput.value;
    clearDeviceSearchHighlight();
    deviceSearchForm.classList.remove('not-found');
    deviceSearchInput.removeAttribute('aria-invalid');
    deviceSearchClear.disabled = !rawQuery.trim();

    if (!rawQuery.trim()) {
      deviceSearchResult.textContent = '';
      deviceSearchResult.className = 'device-search-result';
      return;
    }

    const result = findTagBoardDeviceMatches(matrixData.devices, rawQuery);
    if (!result.ok) {
      deviceSearchForm.classList.add('not-found');
      deviceSearchInput.setAttribute('aria-invalid', 'true');
      deviceSearchResult.textContent = result.error === 'not_found'
        ? result.number + '番はありません'
        : '番号を確認';
      deviceSearchResult.className = 'device-search-result error';
      return;
    }

    const selector = '[data-device-number="' + result.number + '"]';
    for (const element of document.querySelectorAll(selector)) {
      element.classList.add('device-search-match');
    }
    deviceSearchResult.textContent = result.number + '番を表示';
    deviceSearchResult.className = 'device-search-result';

    if (!shouldScroll) return;
    const header = document.querySelector('.device-head' + selector);
    const section = header && header.closest('.matrix-section');
    if (!section) return;
    const wrapRect = wrap.getBoundingClientRect();
    const sectionRect = section.getBoundingClientRect();
    const top = Math.max(0, wrap.scrollTop + sectionRect.top - wrapRect.top);
    if (typeof wrap.scrollTo === 'function') {
      wrap.scrollTo({ top, behavior });
    } else {
      wrap.scrollTop = top;
    }
  }

  function bindDeviceSearch() {
    deviceSearchForm.addEventListener('submit', (event) => {
      event.preventDefault();
      applyDeviceSearch({ scroll: true });
    });
    deviceSearchInput.addEventListener('input', () => {
      applyDeviceSearch({ scroll: false });
    });
    deviceSearchInput.addEventListener('keydown', (event) => {
      if (event.key !== 'Escape') return;
      event.preventDefault();
      deviceSearchInput.value = '';
      applyDeviceSearch({ scroll: false });
    });
    deviceSearchClear.addEventListener('click', () => {
      deviceSearchInput.value = '';
      applyDeviceSearch({ scroll: false });
      deviceSearchInput.focus();
    });
  }

  function renderMatrix() {
    if (!wrap || !matrixGrid) return;
    const available = Math.max(180, wrap.clientWidth - 18);
    const columns = Math.max(1, Math.floor((available - tagWidth) / deviceWidth));
    const chunks = [];
    for (let i = 0; i < matrixData.devices.length; i += columns) {
      chunks.push(matrixData.devices.slice(i, i + columns));
    }

    matrixGrid.innerHTML = chunks.map((devices) => {
      const colgroup = '<col class="tag-col">' + devices.map(() => '<col>').join('');
      const head = '<tr><th class="tag">チェック</th>' + devices.map((device) =>
        '<th class="device-head ' + escapeText(device.connectionClass) + '" data-device-number="' + escapeText(device.displayId) + '">' +
        '<span class="id">' + escapeText(device.displayId || device.managementId) + '</span>' +
        '<span class="park">' + escapeText(device.park) + '</span>' +
        '<span class="name">' + escapeText(device.name) + '</span>' +
        '<span class="conn">' + escapeText(device.conn) + '</span>' +
        '</th>'
      ).join('') + '</tr>';
      const body = matrixData.tags.map((tag) => '<tr>' +
        '<td class="tag ' + escapeText(tag.klass) + '">' + tagLabelTextHtml(tag.label) + '</td>' +
        devices.map((device) => {
          const checked = currentChecked(device, tag);
          const original = Boolean(device.tags && device.tags[tag.tag]);
          const changed = !suppressChanged && checked !== original;
          return '<td class="' + (checked ? 'checked' : 'empty') + ' ' + escapeText(tag.klass) + ' ' + escapeText(device.connectionClass) + (changed ? ' changed' : '') + '" data-device-number="' + escapeText(device.displayId) + '">' +
            '<input type="checkbox" data-serial="' + escapeText(device.serial) + '" data-management-id="' + escapeText(device.managementId) + '" data-tag="' + escapeText(tag.tag) + '" data-kind="' + escapeText(tag.kind) + '" data-original="' + (original ? '1' : '0') + '" ' + (checked ? 'checked' : '') + '>' +
            '</td>';
        }).join('') +
      '</tr>').join('');
      return '<section class="matrix-section"><table><colgroup>' + colgroup + '</colgroup><thead>' + head + '</thead><tbody>' + body + '</tbody></table></section>';
    }).join('');

    bindCheckboxes();
    refreshChangeCount();
    applyDeviceSearch({ scroll: Boolean(deviceSearchInput.value.trim()), behavior: 'auto' });
  }

  function updateStatus(message, klass = '') {
    status.textContent = message;
    status.className = ['status', klass].filter(Boolean).join(' ');
  }

  function refreshStatusText(result) {
    const refresh = result && result.refresh;
    const sheets = refresh && refresh.sheets;
    const names = refresh && refresh.displayNames;
    const numbers = refresh && refresh.numbers;
    const sheetsJson = sheets && sheets.json;
    if (!refresh) return 'DB反映OK';
    const nameText = names && names.ok ? ' / 名前同期OK' : names ? ' / 名前同期NG' : '';
    const disconnectedText = numbers && Number(numbers.disconnectedMatched || 0) > 0
      ? ' / 未接続' + numbers.disconnectedMatched + '台も強制確認（変更' + (numbers.disconnectedRequested || 0) + '・成功' + (numbers.disconnectedSucceeded || 0) + '）' + (numbers.xiaoweiRestartRecommended ? '・XiaoWei再起動で表示反映' : '')
      : '';
    if (!sheets) return 'DB反映OK' + nameText + disconnectedText + ' / Sheets未実行';
    if (!sheets.ok) return 'DB反映OK' + nameText + disconnectedText + ' / Sheets失敗';
    if (sheetsJson && sheetsJson.synced) return 'DB反映OK' + nameText + disconnectedText + ' / Sheets同期OK';
    if (sheetsJson && sheetsJson.queued) return 'DB反映OK' + nameText + disconnectedText + ' / Sheets待機: ' + (sheetsJson.reason || 'queued');
    if (sheetsJson && sheetsJson.skipped) return 'DB反映OK' + nameText + disconnectedText + ' / Sheetsスキップ: ' + (sheetsJson.reason || 'skipped');
    return 'DB反映OK' + nameText + disconnectedText + ' / Sheets状態不明';
  }

  function refreshChangeCount() {
    if (suppressChanged) clearChangedCells();
    const count = changedInputs().length;
    applyButton.disabled = busy || count === 0;
    syncButton.disabled = busy;
    updateStatus(count ? count + '件の変更あり' : '変更なし', count ? 'warn' : '');
  }

  function findDeviceForChange(change) {
    return matrixData.devices.find((device) =>
      String(device.serial || '') === String(change.serial || '') ||
      String(device.managementId || '') === String(change.managementId || '')
    ) || null;
  }

  function resetCandidatesFromChanges(changes) {
    const seen = new Set();
    const candidates = [];
    for (const change of changes) {
      if (change.tag !== 'GROUP_INACTIVE' || !change.checked) continue;
      const key = change.serial || change.managementId;
      if (!key || seen.has(key)) continue;
      seen.add(key);
      const device = findDeviceForChange(change);
      candidates.push({
        serial: change.serial || '',
        managementId: change.managementId || '',
        label: device
          ? [device.displayId || device.managementId, device.name, device.conn].filter(Boolean).join(' ')
          : key,
      });
    }
    return candidates;
  }

  function showInactiveResetConfirm(candidates) {
    if (!candidates.length) return Promise.resolve([]);
    return new Promise((resolve) => {
      let closed = false;
      const overlay = document.createElement('div');
      overlay.className = 'confirm-overlay';
      overlay.innerHTML =
        '<div class="confirm-dialog" role="dialog" aria-modal="true">' +
        '<h2>リセット履歴を保存します</h2>' +
        '<p>現在のチェック状態を端末DBの履歴に保存してから、非稼働だけ残します。</p>' +
        '<p>ERROR歴ありは外します。タスクのチェックを自分で先に外すと、履歴には残りません。</p>' +
        '<ul>' + candidates.map((item) => '<li>' + escapeText(item.label) + '</li>').join('') + '</ul>' +
        '<label>理由<select id="resetReasonSelect">' +
        '<option value="出金後リセット">出金後リセット</option>' +
        '<option value="エラーが出たのでリセット">エラーが出たのでリセット</option>' +
        '</select></label>' +
        '<label>出金額<input id="resetAmountInput" type="number" min="0" step="1" placeholder="任意"></label>' +
        '<p>実行しますか？</p>' +
        '<div class="confirm-actions">' +
        '<button class="no" type="button">いいえ</button>' +
        '<button class="yes" type="button">はい</button>' +
        '</div>' +
        '</div>';
      document.body.appendChild(overlay);
      const reasonSelect = overlay.querySelector('#resetReasonSelect');
      const amountInput = overlay.querySelector('#resetAmountInput');
      function onKeyDown(event) {
        if (event.key === 'Escape') close(null);
      }
      function close(value) {
        if (closed) return;
        closed = true;
        document.removeEventListener('keydown', onKeyDown);
        overlay.remove();
        resolve(value);
      }
      document.addEventListener('keydown', onKeyDown);
      overlay.querySelector('.no').addEventListener('click', () => close(null));
      overlay.querySelector('.yes').addEventListener('click', () => {
        const reason = reasonSelect.value || '出金後リセット';
        const amountYen = Math.max(0, Math.floor(Number(amountInput.value || 0) || 0));
        close(candidates.map((item) => ({
          serial: item.serial,
          managementId: item.managementId,
          reason,
          amountYen,
        })));
      });
      overlay.addEventListener('click', (event) => {
        if (event.target === overlay) close(null);
      });
      overlay.querySelector('.no').focus();
    });
  }

  function discardPendingChanges() {
    suppressChanged = true;
    checkboxState.clear();
    for (const input of document.querySelectorAll('input[type="checkbox"]')) {
      input.checked = input.dataset.original === '1';
      const td = input.closest('td');
      if (!td) continue;
      td.classList.toggle('checked', input.checked);
      td.classList.toggle('empty', !input.checked);
      td.classList.remove('changed');
    }
    applyButton.disabled = true;
  }

  async function applyPendingChanges() {
    const changes = changedInputs().map(input => ({
      serial: input.dataset.serial,
      managementId: input.dataset.managementId,
      tag: input.dataset.tag,
      checked: input.checked,
    }));
    if (!changes.length) {
      settleSuccessfulChanges();
      return { ok: true, applied: 0 };
    }

    const resetConfirmations = await showInactiveResetConfirm(resetCandidatesFromChanges(changes));
    if (resetConfirmations === null) {
      discardPendingChanges();
      updateStatus('キャンセルしました（変更は破棄しました）', '');
      return { ok: true, applied: 0, cancelled: true };
    }

    updateStatus('DBへ反映中...', 'warn');
    const response = await fetch(applyEndpoint, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ changes, resetConfirmations }),
    });
    const result = await response.json();
    if (!response.ok || !result.ok) {
      if (result.dbApplied) {
        settleSuccessfulChanges();
        notifyParentDbUpdated();
        return {
          ...result,
          needsRegeneration: true,
          applyWarning: result.error || 'DB反映後の一覧更新に失敗しました',
        };
      }
      throw new Error(result.error || result.failed + '件の反映に失敗しました');
    }
    settleSuccessfulChanges();
    notifyParentDbUpdated();
    return result;
  }

  function notifyParentDbUpdated() {
    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: 'tag-board-db-updated', at: Date.now() }, '*');
      }
    } catch (_) {
      // Parent notification is best effort.
    }
  }

  function clearChangedCells() {
    for (const td of document.querySelectorAll('td.changed')) {
      td.classList.remove('changed');
    }
    for (const input of document.querySelectorAll('input[type="checkbox"]')) {
      input.dataset.original = input.checked ? '1' : '0';
    }
  }

  function commitCurrentCheckboxState() {
    for (const input of document.querySelectorAll('input[type="checkbox"]')) {
      const key = cellKey(input.dataset.serial, input.dataset.tag);
      checkboxState.set(key, input.checked);
      input.dataset.original = input.checked ? '1' : '0';
      const td = input.closest('td');
      if (td) {
        td.classList.toggle('checked', input.checked);
        td.classList.toggle('empty', !input.checked);
        td.classList.remove('changed');
      }
    }
    for (const device of matrixData.devices) {
      for (const tag of matrixData.tags) {
        const key = cellKey(device.serial, tag.tag);
        if (checkboxState.has(key)) device.tags[tag.tag] = checkboxState.get(key);
      }
    }
  }

  function settleSuccessfulChanges() {
    suppressChanged = true;
    document.body.classList.add('changes-settled');
    if (document.activeElement && typeof document.activeElement.blur === 'function') {
      document.activeElement.blur();
    }
    commitCurrentCheckboxState();
    checkboxState.clear();
    clearChangedCells();
    renderMatrix();
    refreshChangeCount();
    forceClearChangedCells();
  }

  function forceClearChangedCells() {
    for (let i = 0; i < 8; i++) {
      setTimeout(clearChangedCells, i * 80);
    }
  }

  function setBusy(nextBusy) {
    busy = nextBusy;
    syncButton.disabled = busy;
    applyButton.disabled = busy || changedInputs().length === 0;
  }

  function reloadAfterSuccess() {
    settleSuccessfulChanges();
    const url = new URL(window.location.href);
    url.searchParams.set('generated', '1');
    url.searchParams.set('ts', Date.now().toString());
    setTimeout(() => window.location.assign(url.toString()), 150);
  }

  function retryRegenerationAfterApplied(result) {
    settleSuccessfulChanges();
    const url = new URL(window.location.href);
    url.searchParams.delete('generated');
    url.searchParams.set('ts', Date.now().toString());
    updateStatus('DB反映済み / 一覧の再生成を再試行します: ' + (result.applyWarning || '一覧更新失敗'), 'warn');
    setTimeout(() => window.location.assign(url.toString()), 350);
  }

  function bindCheckboxes() {
    for (const input of document.querySelectorAll('input[type="checkbox"]')) {
      input.addEventListener('change', () => {
        suppressChanged = false;
        document.body.classList.remove('changes-settled');
        const exclusiveGroup = input.checked ? exclusiveCheckboxGroup(input.dataset.tag, input.dataset.kind) : '';
        if (exclusiveGroup) {
          for (const other of document.querySelectorAll('input[type="checkbox"][data-serial="' + CSS.escape(input.dataset.serial) + '"]')) {
            if (exclusiveCheckboxGroup(other.dataset.tag, other.dataset.kind) !== exclusiveGroup) continue;
            if (other === input || !other.checked) continue;
            other.checked = false;
            checkboxState.set(cellKey(other.dataset.serial, other.dataset.tag), false);
            const otherTd = other.closest('td');
            const otherOriginal = other.dataset.original === '1';
            if (otherTd) {
              otherTd.classList.toggle('checked', false);
              otherTd.classList.toggle('empty', true);
              otherTd.classList.toggle('changed', other.checked !== otherOriginal);
            }
          }
        }
        checkboxState.set(cellKey(input.dataset.serial, input.dataset.tag), input.checked);
        const td = input.closest('td');
        const original = input.dataset.original === '1';
        td.classList.toggle('checked', input.checked);
        td.classList.toggle('empty', !input.checked);
        td.classList.toggle('changed', input.checked !== original);
        refreshChangeCount();
      });
    }
  }

  function exclusiveCheckboxGroup(tag, kind) {
    const value = String(tag || '');
    if (kind === 'group') return 'group';
    if (/^CI_\d+$/.test(value)) return 'ci';
    if (/^V180_(7500|15000|22500)$/.test(value)) return 'v180_amount';
    if (/^V10_(1190|1438|2262)$/.test(value)) return 'v10_amount';
    if (/^DAY_\d{2}$/.test(value)) return 'day';
    return '';
  }

  applyButton.addEventListener('click', async () => {
    setBusy(true);
    try {
      const result = await applyPendingChanges();
      if (result.cancelled) {
        setBusy(false);
        return;
      }
      if (result.needsRegeneration) {
        retryRegenerationAfterApplied(result);
        return;
      }
      const refreshText = refreshStatusText(result);
      const isQueued = refreshText.includes('queued');
      const isFailed = refreshText.includes('failed');
      updateStatus('DBへ反映: ' + result.applied + '件 / ' + refreshText, isFailed ? 'error' : isQueued ? 'warn' : 'ok');
      if (!isFailed) reloadAfterSuccess();
    } catch (error) {
      setBusy(false);
      updateStatus('DB反映NG: ' + error.message, 'error');
      console.error(error);
    }
  });

  syncButton.addEventListener('click', async () => {
    setBusy(true);
    updateStatus('XiaoWei同期中...', 'warn');
    try {
      const applyResult = await applyPendingChanges();
      if (applyResult.cancelled) {
        setBusy(false);
        return;
      }
      if (applyResult.needsRegeneration) {
        retryRegenerationAfterApplied(applyResult);
        return;
      }
      const response = await fetch(syncEndpoint, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: '{}',
      });
      const result = await response.json();
      const refreshText = refreshStatusText(result);
      if (!response.ok || !result.ok) {
        const message = (result.failedSteps && result.failedSteps.join(', ')) || refreshText;
        if (applyResult.applied) {
          updateStatus('DB反映: ' + applyResult.applied + '件 / XiaoWei同期NG: ' + message, 'warn');
          reloadAfterSuccess();
        } else {
          setBusy(false);
          updateStatus('XiaoWei同期NG: ' + message, 'error');
        }
        console.warn('sync failed', result);
        return;
      }
      const prefix = applyResult.applied ? 'DB反映: ' + applyResult.applied + '件 / ' : '';
      updateStatus(prefix + 'XiaoWei同期OK / ' + refreshText, 'ok');
      reloadAfterSuccess();
    } catch (error) {
      setBusy(false);
      updateStatus('XiaoWei同期NG: ' + error.message, 'error');
      console.error(error);
    }
  });

  let resizeTimer = 0;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(renderMatrix, 120);
  });
  bindDeviceSearch();
  initButtonHelp();
  renderMatrix();
})();
</script>
</body>
</html>`;
  fs.writeFileSync(filePath, html, "utf8");
}

function csvCell(value) {
  const text = String(value === undefined || value === null ? "" : value);
  if (!/[",\n]/.test(text)) return text;
  return `"${text.replace(/"/g, '""')}"`;
}

function mdCell(value) {
  return String(value === undefined || value === null || value === "" ? " " : value).replace(/\|/g, "\\|");
}

function escapeHtml(value) {
  return String(value === undefined || value === null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function scriptJson(value) {
  return JSON.stringify(value).replace(/</g, "\\u003c");
}

function shortTagLabel(tag) {
  return tagLabel(String(tag));
}

function faviconLinks() {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
  <rect width="64" height="64" rx="14" fill="#050816"/>
  <path d="M41 11v24.5c0 9.7-6.5 16.5-15.5 16.5C18 52 12 47.2 12 40.8c0-6.7 5.7-11.4 13.1-11.4 1.8 0 3.5.3 5 .9V11h10.9z" fill="#25f4ee"/>
  <path d="M46 15v24.5C46 49.2 39.5 56 30.5 56 23 56 17 51.2 17 44.8c0-6.7 5.7-11.4 13.1-11.4 1.8 0 3.5.3 5 .9V15H46z" fill="#fe2c55" opacity=".9"/>
  <path d="M42 13v24.5C42 47.2 35.5 54 26.5 54 19 54 13 49.2 13 42.8c0-6.7 5.7-11.4 13.1-11.4 1.8 0 3.5.3 5 .9V13H42z" fill="#ffffff"/>
</svg>`;
  const data = Buffer.from(svg).toString("base64");
  return `<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,${data}">
<link rel="shortcut icon" href="data:image/svg+xml;base64,${data}">`;
}

function tagLabelHtml(tag) {
  return tagLabelLines(tag).map((line, index) => {
    const klass = index === 0 ? "line" : "line sub";
    return `<span class="${klass}">${escapeHtml(line)}</span>`;
  }).join("");
}

function tagLabelLines(tag) {
  const text = String(tag);
  if (text === "GROUP_ACTIVE") return ["稼働中", ""];
  if (text === "GROUP_INACTIVE") return ["非稼働", ""];
  if (text === "GROUP_REST") return ["非稼働", ""];
  if (text === "STATE_CI_KEEP") return ["DAY", "KEEP"];
  if (text === "STATE_ERROR") return ["ERROR", "中"];
  if (text === "STATE_ERROR_HISTORY") return ["ERROR", "歴"];
  if (/^DAY_\d{2}$/.test(text)) return ["DAY", text.slice(4)];
  if (text === "DAY_UNK") return ["DAY", "UNK"];
  if (/^CI_\d+$/.test(text)) return ["チェック", `${text.slice(3)}円`];
  if (text === "CI_ERR") return ["チェック", "ERR"];
  if (/^V180_(\d+)$/.test(text)) return ["180分", `${text.slice(5)}P`];
  if (text === "V180_DONE") return ["180分", "完了"];
  if (text === "V10_DONE") return ["追加", "完了"];
  if (/^V10_(\d+)$/.test(text)) return ["追加", `${text.slice(4)}円`];
  if (/^INV_OK_/.test(text)) return ["INV", `OK${text.slice(7)}`];
  if (/^INV_NG_/.test(text)) return ["INV", `NG${text.slice(7)}`];
  if (text === "WITHDRAW_3000") return ["WD", "3000"];
  if (text === "RESET_DONE") return ["RESET", "完了"];
  if (text === "CYCLE_CLOSED") return ["CYCLE", "CLOSED"];
  if (/^OK_/.test(text)) return ["OK", text.replace(/^OK_/, "")];
  if (/^NG_/.test(text)) return ["NG", text.replace(/^NG_/, "")];
  if (/^DEC_/.test(text)) return ["DEC", text.replace(/^DEC_/, "")];
  if (/^STATE_/.test(text)) return ["ST", text.replace(/^STATE_/, "")];
  if (/^NET_/.test(text)) return ["NET", text.replace(/^NET_/, "")];
  if (/^WAIT_/.test(text)) return ["WAIT", text.replace(/^WAIT_/, "")];
  if (/^P[12]_/.test(text)) return text.split("_");
  return tagLabel(text).split(/\s+/).filter(Boolean);
}

function displayTagName(tag) {
  if (tag === "GROUP_ACTIVE") return "稼働中";
  if (tag === "GROUP_INACTIVE") return "非稼働";
  if (tag === "GROUP_REST") return "非稼働";
  if (tag === "STATE_CI_KEEP") return "DAY KEEP";
  if (tag === "STATE_ERROR") return "ERROR 中";
  if (tag === "STATE_ERROR_HISTORY") return "ERROR 歴";
  return tagLabelLines(tag).join(" ").trim() || tag;
}

function tagClass(tag) {
  if (/^GROUP_/.test(tag)) return "group";
  if (/ERR|ERROR|RESET/.test(tag)) return "error";
  if (/^CI_/.test(tag)) return "ci";
  if (/^INV_/.test(tag)) return "invite";
  if (/^DAY_/.test(tag)) return "day";
  if (/^V180_|^V10_/.test(tag)) return "task";
  if (/^OK_|^NG_|^WITHDRAW_/.test(tag)) return "profit";
  if (/^RESET_|^CYCLE_/.test(tag)) return "cycle";
  return "";
}

function tagLegendHtml(tags) {
  const items = tags.map((tag) => {
    const description = tagDescriptionJa(tag) || tagLabel(tag);
    return `<div class="legend-item"><span class="legend-code">${escapeHtml(displayTagName(tag))}</span><span class="legend-text">${escapeHtml(description)}</span></div>`;
  }).join("");
  return `<section class="legend"><h2>Tag Translation</h2><div class="legend-grid">${items}</div></section>`;
}

function fleetCountSummary(matrix) {
  const devices = Array.isArray(matrix.devices) ? matrix.devices : [];
  const inactive = devices.filter((device) => {
    return Boolean(device.tags && (device.tags.GROUP_INACTIVE || device.tags.GROUP_REST || device.tags.WAITING));
  }).length;
  return {
    active: devices.length - inactive,
    inactive,
    sleeping: 0,
    total: devices.length,
  };
}

function connectionClass(device) {
  if (device.tags && (device.tags.GROUP_INACTIVE || device.tags.GROUP_REST || device.tags.WAITING)) return "offline-device";
  const status = String(device.adbStatus || "").toLowerCase();
  if (status && status !== "device") return "offline-device";
  return "";
}

function connectionLabel(device) {
  if (device.tags && (device.tags.GROUP_INACTIVE || device.tags.GROUP_REST || device.tags.WAITING)) return "INACTIVE";
  const status = String(device.adbStatus || "").toLowerCase();
  if (!status) return "";
  if (status === "missing") return "OFF";
  if (status === "offline") return "ADB OFF";
  if (status === "unauthorized") return "AUTH";
  return "";
}

function parkingLabel(device) {
  return "";
}

function formatCurrentYen(device) {
  if (device.currentYen !== undefined && device.currentYen !== null && device.currentYen !== "") {
    return `¥${device.currentYen}`;
  }
  if (device.projectedGrossYen !== undefined && device.projectedGrossYen !== null && device.projectedGrossYen !== "") {
    return `E${Math.round(Number(device.projectedGrossYen || 0))}`;
  }
  return "";
}

function formatCurrentPoints(device) {
  if (device.currentPoints !== undefined && device.currentPoints !== null && device.currentPoints !== "") {
    return `P${compactNumber(device.currentPoints)}`;
  }
  if (device.pointScreenType) return device.pointScreenType;
  return "";
}

function compactNumber(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return String(value);
  if (Math.abs(number) >= 10000) return `${Math.round(number / 1000) / 10}k`;
  return String(number);
}

function shortDeviceName(name) {
  const text = String(name || "").trim();
  const replacements = [
    [/^Galaxy A25 5G$/i, "A25"],
    [/^Galaxy S20 5G$/i, "S20"],
    [/^Galaxy A06$/i, "A06"],
    [/^Pixel\s+/i, ""],
    [/^Redmi Note\s+/i, "RN "],
    [/^Redmi\s+/i, ""],
    [/^HUAWEI\s+/i, ""],
    [/^OPPO Reno\s*/i, "Reno "],
    [/^arrows\s+/i, ""],
    [/^A402FC$/i, "We2"],
    [/^M07$/i, "We2"],
  ];
  let out = text;
  for (const [pattern, replacement] of replacements) {
    out = out.replace(pattern, replacement);
  }
  return out;
}

function tagBoardDeviceName(device) {
  return tagBoardDisplayCode(device) || device.name || device.xiaoweiName || "";
}

function tagBoardDisplayCode(device) {
  const code = String(device && (device.uiNameOverride || device.deviceCode) || "").trim();
  if (!code) return "";
  const match = /^(.+?)-([A-Z]+)-(\d+)$/i.exec(code);
  if (match) return `${match[1]}-${String(Number(match[3])).padStart(2, "0")}`;
  return code.replace(/-([A-Z]+)-(\d+)$/i, (_, carrier, seq) => `-${String(Number(seq)).padStart(2, "0")}`);
}
