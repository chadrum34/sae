﻿const http = require("http");
const net = require("net");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const zlib = require("zlib");
const { spawn, spawnSync } = require("child_process");
const { performance } = require("perf_hooks");

const { createConfigPaths, ensureConfigPaths } = require("./lib/config-paths");
const { readFleetAppVersion } = require("./lib/app-version");
const { createDeviceStore } = require("./lib/device-store");
const { scanAdbDevices, scanAdbDevicePorts, parseAdbDevices } = require("./lib/adb-scanner");
const { resolveSingleAdbPort, runSinglePortAdbMutation } = require("./lib/adb-single-port-action");
const {
  listSafeAdbActions,
  normalizeApnFormPayload,
  runGuardedApnAction,
  runSafeAdbAction,
} = require("./lib/adb-actions");
const {
  createApnSaveGuard,
  profileRevisionForApnFields,
  resetScopeForAndroidId,
} = require("./lib/apn-save-guard");
const { createRootPseudoResetManager, validateLocalPseudoResetRequest } = require("./lib/root-pseudo-reset");
const { listApkLibrary, resolveApkSelection } = require("./lib/apk-library");
const { createTargetOperationLock, normalizeTargetKeys } = require("./lib/target-operation-lock");
const { buildDeviceSimInfo, parseSubscriptionDump } = require("./lib/adb-sim-info");
const {
  validateLiveApnTarget,
  validateRequestedApnFields,
} = require("./lib/apn-target-validation");
const { classifyNavigationLayout, navigationWritePlan } = require("./lib/adb-navigation-layout");
const { PRIVATE_API_SESSION_HEADER, createPrivateApiGuard } = require("./lib/private-api-guard");
const { buildSupportDiagnostics } = require("./lib/support-diagnostics");
const {
  SUPPORT_DIAGNOSTICS_RECEIVER_LOCAL_PORT,
  createSupportDiagnosticsReceiverServer,
  sendSupportDiagnosticsReport,
  validateSupportDiagnosticsSendRequest,
} = require("./lib/support-diagnostics-transport");
const { createXiaoweiApi } = require("./lib/xiaowei-api");
const { createXiaoweiIntegration } = require("./lib/xiaowei-integration");
const {
  buildXiaoweiNumberUpdatePlan,
  buildXiaoweiNumberSyncStrategy,
  verifyXiaoweiNumberUpdates,
} = require("./lib/xiaowei-number-plan");
const { createLegacyMirrorWsapi } = require("./lib/legacy-mirror-wsapi");
const { createMarkdownLogger } = require("./lib/markdown-log");
const { createDiscordNotifier } = require("./lib/discord-webhook");
const { advanceDayTagsOnce } = require("./lib/day-tags");
const { selectNewDeviceImportCandidates } = require("./lib/device-import-candidates");
const {
  bestDeviceMasterMatch,
  normalizeCarrierCode,
  serialKey,
} = require("./lib/device-master-matcher");
const {
  mergeDeviceMasters,
  mergeDeviceNameMaps,
} = require("./lib/migration-merge");
const { canonicalizeTag, canonicalizeTags } = require("./lib/tag-schema");
const {
  VIDEO_180_TAG_POINTS_PER_DAY,
  VIDEO_10_TAG_YEN,
  estimateCycleEconomics,
} = require("./lib/fleet-economics");
const {
  MAX_CHECKIN_YEN,
  checkinTagFromYen,
  checkinYenFromTag,
  findCheckinAmountTag,
  isCheckinAmountTag,
} = require("./lib/checkin-amount");
const {
  MAX_VIDEO_180_POINTS,
  MAX_VIDEO_10_YEN,
  findVideo180AmountTag,
  findVideo10AmountTag,
  isVideo180AmountTag,
  isVideo10AmountTag,
  video180PointsFromTag,
  video180TagFromPoints,
  video10YenFromTag,
  video10TagFromYen,
} = require("./lib/task-amounts");
const {
  effectiveDeviceUptimeSeconds,
  normalizeInactiveResetConfirmations,
} = require("./lib/inactive-reset");
const { createCustomWithdrawalSubject } = require("./lib/manual-withdrawal-subject");
const {
  beginCycleErrorOperation,
  recordCycleErrorOccurrence,
  backfillCycleErrorDay,
  finalizeCycleErrorOperation,
  collectCycleErrorOutcomes,
  collectDeviceErrorOutcomes,
  collectFleetErrorOutcomes,
  summarizeErrorOutcomes,
} = require("./lib/error-history");
const {
  connectionIncidentStats,
  ignoreConnectionIncidents,
  normalizeConnectionHistory,
  normalizeConnectionIncidents,
  normalizeRecoveryAttempts,
  observeAdbConnectionSnapshot,
  recordRecoveryAttempts,
  recoveryAttemptStats,
} = require("./lib/connection-history");
const { hasStableWithdrawalIdentity, stableWithdrawalSubjectId } = require("./public/withdrawal-matching");
const { DEFAULT_HTTPS_PORT, createTailscaleRemoteAccess } = require("./lib/tailscale-remote-access");
const {
  MAX_OPERATION_DAY,
  archiveOfflineInviteVerification,
  appendOfflineHistory,
  effectiveOfflineUptimeMinutes,
  nextOfflineDeviceId,
  normalizeOfflineDevice,
  normalizeOfflineDevices,
  offlineDeviceSummary,
  offlineRestState,
  updateOfflineInviteProfile,
} = require("./lib/offline-devices");
const {
  deleteOperationGroup,
  normalizeOperationGroups,
  operationGroupIdsForSerial,
  operationGroupList,
  upsertOperationGroup,
} = require("./lib/operation-groups");
const {
  UNRESOLVED_MODEL_NAME,
  resolveModelName,
  resolveHardwareModelName,
  shortModelName,
  isGenericModelName,
  parseManagedDisplayName,
  clearModelNameCache,
} = require("./lib/model-names");

const PORT = Number(process.env.PORT || 8787);
const BROWSER_AGENT_MODE = process.env.ANDROID_FLEET_BROWSER_AGENT === "1";
const DAY_ROLLOVER_XIAOWEI_SYNC_ENABLED = PORT !== 8788
  && process.env.ANDROID_FLEET_DISABLE_DAY_XIAOWEI_SYNC !== "1";
const XIAOWEI_WRITE_SYNC_ENABLED = DAY_ROLLOVER_XIAOWEI_SYNC_ENABLED;
const REMOTE_ACCESS_HTTPS_PORT = Number(process.env.ANDROID_FLEET_REMOTE_HTTPS_PORT || DEFAULT_HTTPS_PORT);
const PUBLIC_DIR = path.join(__dirname, "public");
const DEVICE_NAME_MAP_PATH = path.join(__dirname, "config", "device-name-map.json");
const CUSTOMER_LICENSE_PATH = path.join(__dirname, "config", "customer-license.json");
const LICENSE_ACTIVATION_PATH = path.join(__dirname, "config", "license-activation.json");
const PACKAGE_MANIFEST_PATH = path.join(__dirname, "config", "package-manifest.json");
const MIGRATION_DIR = path.join(__dirname, "AndroidFleet-移行データ");
const MIGRATION_CONFIG_FILES = Object.freeze([
  "device-name-map.json",
  "fleet-monitor.json",
  "sheets-sync.json",
  "xiaowei-tag-taxonomy.json",
]);
const XIAOWEI_DEFAULT_ROOT = "C:\\Program Files (x86)\\xiaowei_android";
const XIAOWEI_ADB_PORT = 5038;
const ENABLE_LEGACY_MIRROR = process.env.ENABLE_LEGACY_MIRROR === "1";
const LEGACY_MIRROR_SCRIPT_DIR = "C:\\Program Files\\LegacyMirror\\Scripts";
const LEGACY_MIRROR_LOG_DIR = "C:\\Program Files\\LegacyMirror\\Logs";
const LEGACY_MIRROR_EXE_PATH = "C:\\Program Files\\LegacyMirror\\LegacyMirror.exe";
const LEGACY_MIRROR_PACKAGE_NAME = "youhu.laixijs";
const TIKTOK_LITE_PACKAGE_NAME = "com.ss.android.ugc.tiktok.lite";
const TIKTOK_LITE_PACKAGE_NAMES = Object.freeze([
  TIKTOK_LITE_PACKAGE_NAME,
  "com.zhiliaoapp.musically.go",
]);
const LINE_PACKAGE_NAME = "jp.naver.line.android";
const SWIPE_AGENT_PACKAGE_NAME = "app.androidfleet.swipeagent";
const SWIPE_AGENT_ACCESSIBILITY_SERVICE = "app.androidfleet.swipeagent/app.androidfleet.swipeagent.SwipeAccessibilityService";
const SWIPE_AGENT_ACTION_START = "app.androidfleet.swipeagent.START";
const SWIPE_AGENT_ACTION_STOP = "app.androidfleet.swipeagent.STOP";
const SWIPE_AGENT_STATUS_PATH = "/sdcard/Android/data/app.androidfleet.swipeagent/files/swipe-agent/status.json";
const SWIPE_AGENT_APK_PATH = path.join(__dirname, "android-swipe-agent", "app", "build", "outputs", "apk", "debug", "app-debug.apk");
const SWIPE_AGENT_MAX_ZERO_SWIPE_RESTARTS = 2;
const TTL_DEEP_RECOVERY_AFTER_STALLS = 2;
const TTL_DEEP_RECOVERY_AFTER_AGENT_RESTARTS = 2;
const SWIPE_JOB_MERGE_GRACE_MS = 60 * 60 * 1000;
const INACTIVE_NUMBER_START = 1000;
const MAX_DEVICE_NAME_SEQUENCE = 999;
const RETIRED_NUMBER_START = 9000;
const BASELINE_DEVICE_SETTINGS = Object.freeze([
  { key: "emergencyAlertsOff", action: "earthquake_alerts_off", label: "緊急メールOFF" },
  { key: "autoRotateOff", action: "auto_rotate_off", label: "画面回転OFF" },
  { key: "dataSaverOn", action: "data_saver_on", label: "データセーバーON" },
  { key: "nfcOff", action: "nfc_off", label: "NFC OFF" },
  { key: "silentOn", action: "sound_off", label: "サイレントON" },
  {
    key: "userAppNotificationsOff",
    action: "user_app_notifications_off",
    label: "ユーザーアプリ通知を非表示",
    alwaysReapply: true,
  },
]);
const BASELINE_APP_SETTINGS = Object.freeze([
  { key: "ttlInstalled", packageKey: "ttl", label: "TTL", packageName: TIKTOK_LITE_PACKAGE_NAME, packageNames: TIKTOK_LITE_PACKAGE_NAMES },
  { key: "lineInstalled", packageKey: "line", label: "LINE", packageName: LINE_PACKAGE_NAME },
]);
const XIAOWEI_TEST_SCRIPT_FILES = Object.freeze([
  "xiaowei-minimal-toast.js",
  "xiaowei-log-test.js",
  "xiaowei-chrome-test.js",
]);
const DEFAULT_OBSIDIAN_VAULT_DIR = discoverObsidianVaultDir();
const paths = ensureConfigPaths(createConfigPaths({ rootDir: __dirname }));
const apnSaveGuard = createApnSaveGuard({
  filePath: path.join(paths.dataDir, "fleet-db", "apn-save-guard.json"),
});
const adbSwipeJobs = new Map();
const swipeAgentJobs = new Map();
const fleetDbSummaryCache = {
  key: "",
  summary: null,
};
const deviceMasterCache = {
  key: "",
  master: null,
};
const deviceMasterMatchCache = new WeakMap();
const store = createDeviceStore({
  filePath: paths.devicesFile,
  allowedPatchKeys: [
    "name",
    "role",
    "state",
    "notes",
    "tags",
    "lastSeenAt",
    "lastCheckinAt",
    "checkinDay",
    "lastInviteAt",
    "taskReward",
    "successCount",
    "failureCount",
    "successRate",
    "fatigueScore",
    "recommendedAction",
    "model",
    "product",
    "transportId",
    "adbStatus",
    "lastScreenshotUrl",
    "lastScreenshotAt",
  ],
});
const markdownLogger = createMarkdownLogger({ logDir: paths.logDir });
const discord = createDiscordNotifier();
const xiaoweiIntegration = createXiaoweiIntegration({ rootDir: resolveXiaoweiRoot() });
const xiaoweiApi = createXiaoweiApi();
const legacyMirrorWsapi = createLegacyMirrorWsapi();
const remoteAccess = createTailscaleRemoteAccess({
  enabled: BROWSER_AGENT_MODE,
  localPort: PORT,
  httpsPort: REMOTE_ACCESS_HTTPS_PORT,
});
const rootPseudoResetManager = createRootPseudoResetManager({ resolveAdbPath });
const deviceMutationTargetLock = createTargetOperationLock();
const apkInstallTargetLock = deviceMutationTargetLock;
const navigationLayoutTargetLock = deviceMutationTargetLock;
const batteryProtectionTargetLock = deviceMutationTargetLock;
const apnDraftTargetLock = deviceMutationTargetLock;
const privateApiGuard = createPrivateApiGuard({
  localPort: PORT,
  remoteHttpsPort: REMOTE_ACCESS_HTTPS_PORT,
  browserAgentMode: BROWSER_AGENT_MODE,
});
const PRIVATE_API_PATHS = new Set([
  "/api/local-session-token",
  "/api/support/diagnostics",
  "/api/support/diagnostics/send",
  "/api/adb/sim-info",
  "/api/adb/navigation-layout",
  "/api/adb/battery-protection",
  "/api/adb/apn-draft",
  "/api/adb/apn-save-guard/release",
]);
const SIM_INFO_CACHE_MS = 4000;
let adbSimInfoFlight = null;
let adbSimInfoCache = null;
const DAY_ROLLOVER_INTERVAL_MS = 60 * 60 * 1000;
let lastSuccessfulXiaoweiDaySyncDate = "";
const USB_TOPOLOGY_REFRESH_INTERVAL_MS = 10 * 60 * 1000;
let usbTopologyRefreshRunning = false;
const SUPPORT_DIAGNOSTICS_LIVE_CACHE_MS = 30 * 1000;
const SUPPORT_DIAGNOSTICS_MAX_SOURCE_BYTES = 512 * 1024;
let supportDiagnosticsLiveCache = { key: "", at: 0, value: null };
let supportDiagnosticsLiveFlight = null;
let supportInstallationStateCache = null;
const supportDiagnosticsConsentReceipts = new Map();
const SUPPORT_DIAGNOSTICS_CONSENT_TTL_MS = 15 * 60 * 1000;
const SUPPORT_DIAGNOSTICS_SEND_REQUEST_MAX_BYTES = 16 * 1024;

store.ensure();

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (req.method === "OPTIONS" && PRIVATE_API_PATHS.has(url.pathname)) {
      return sendPrivateJson(res, {
        ok: false,
        code: "PRIVATE_API_PREFLIGHT_BLOCKED",
        error: "このAPIはAndroid Fleet画面の同一オリジン通信だけを受け付けます。",
      }, 403);
    }

    if (req.method === "OPTIONS") {
      return sendNoContent(res);
    }

    if (!ENABLE_LEGACY_MIRROR && (url.pathname.startsWith("/api/legacy-mirror") || url.pathname === "/api/adb/legacy-mirror-setup")) {
      return sendJson(res, {
        ok: false,
        code: "LEGACY_MIRROR_DISABLED",
        error: "Legacy mirror API is disabled. Start with ENABLE_LEGACY_MIRROR=1 only if needed.",
      }, 410);
    }

    if (req.method === "GET" && url.pathname === "/api/local-session-token") {
      const requestGuard = privateApiGuard.bootstrap(req);
      if (!requestGuard.ok) return sendPrivateJson(res, requestGuard, requestGuard.status);
      return sendPrivateJson(res, {
        ok: true,
        token: privateApiGuard.sessionToken,
        header: PRIVATE_API_SESSION_HEADER,
      });
    }

    if (url.pathname === "/api/support/diagnostics") {
      if (req.method !== "POST") {
        return sendPrivateJson(res, {
          ok: false,
          code: "SUPPORT_DIAGNOSTICS_METHOD_NOT_ALLOWED",
          error: "診断情報はAndroid Fleet画面の生成ボタンから作成してください。",
        }, 405);
      }
      try {
        const requestGuard = privateApiGuard.validate(req, { requireOrigin: true, requireJson: true });
        if (!requestGuard.ok) return sendPrivateJson(res, requestGuard, requestGuard.status);
        const body = await readJson(req);
        const report = await createSupportDiagnosticsReport(body);
        return sendPrivateJson(res, report);
      } catch {
        return sendPrivateJson(res, {
          ok: false,
          code: "SUPPORT_DIAGNOSTICS_FAILED",
          error: "診断情報を生成できませんでした。画面を再読み込みして、もう一度お試しください。",
        }, 500);
      }
    }

    if (url.pathname === "/api/support/diagnostics/send") {
      if (req.method !== "POST") {
        return sendPrivateJson(res, {
          ok: false,
          code: "SUPPORT_DIAGNOSTICS_SEND_METHOD_NOT_ALLOWED",
          error: "診断情報はAndroid Fleet画面の送信ボタンから送ってください。",
        }, 405);
      }
      try {
        const requestGuard = privateApiGuard.validate(req, { requireOrigin: true, requireJson: true });
        if (!requestGuard.ok) return sendPrivateJson(res, requestGuard, requestGuard.status);
        const body = await readJson(req, SUPPORT_DIAGNOSTICS_SEND_REQUEST_MAX_BYTES);
        const sendRequest = validateSupportDiagnosticsSendRequest(body);
        pruneSupportDiagnosticsConsentReceipts();
        let entry = supportDiagnosticsConsentReceipts.get(sendRequest.consentNonce);
        if (!entry) {
          entry = {
            createdAt: Date.now(),
            promise: (async () => {
              const report = await createSupportDiagnosticsReport({ clientAssets: sendRequest.clientAssets });
              return sendSupportDiagnosticsReport(report, { stateDir: supportDiagnosticsStateRoot() });
            })(),
          };
          supportDiagnosticsConsentReceipts.set(sendRequest.consentNonce, entry);
        }
        return sendPrivateJson(res, await entry.promise);
      } catch (error) {
        const code = safeSupportDiagnosticsSendErrorCode(error);
        const status = Number.isInteger(error && error.status) && error.status >= 400 && error.status <= 599
          ? error.status
          : 502;
        return sendPrivateJson(res, {
          ok: false,
          code,
          error: "診断情報を自動送信できませんでした。安全な診断JSONをこのPCへ保存します。",
        }, status);
      }
    }

    const licenseGate = checkLicenseGate(url.pathname);
    if (!licenseGate.ok) {
      return sendJson(res, {
        ok: false,
        code: licenseGate.code,
        error: licenseGate.message,
        license: licenseGate.license,
      }, 403);
    }

    if (req.method === "GET" && url.pathname === "/api/devices") {
      return sendJson(res, await getDevices());
    }

    if (req.method === "GET" && url.pathname === "/api/xiaowei") {
      const xiaowei = await readXiaoweiSources();
      return sendJson(res, summarizeXiaoweiRead(xiaowei));
    }

    if (req.method === "GET" && url.pathname === "/api/xiaowei/missing-from-xiaowei") {
      const result = await findFleetDevicesMissingFromXiaowei();
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "GET" && url.pathname === "/api/xiaowei/projection-issues") {
      const result = await findXiaoweiProjectionIssues();
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "GET" && url.pathname === "/api/adb/usb-diagnosis") {
      const result = await diagnoseUsbAdbDevices({
        includeOk: url.searchParams.get("all") === "1" || url.searchParams.get("all") === "true",
        includeXiaoweiOnly: url.searchParams.get("xiaoweiOnly") === "1" || url.searchParams.get("xiaoweiOnly") === "true",
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/usb-repair") {
      const body = await readJson(req);
      const result = await launchUsbPnpRepair(body);
      appendAuditLog({
        type: "adb_usb_pnp_repair",
        title: "USB/ADB automatic repair launched",
        level: result.ok ? "info" : "warn",
        details: result,
      });
      return sendJson(res, result, result.ok ? 200 : 400);
    }

    if (req.method === "GET" && url.pathname === "/api/fleet-db/device-code-audit") {
      const result = auditFleetDeviceCodes();
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/device-code-repair") {
      const result = repairFleetDeviceCodeGaps();
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "GET" && url.pathname === "/api/legacy-mirror") {
      const legacyMirror = await legacyMirrorWsapi.listDevices();
      return sendJson(res, summarizeLegacyMirrorRead(legacyMirror), legacyMirror.ok ? 200 : 500);
    }

    if (req.method === "GET" && url.pathname === "/api/legacy-mirror/detail") {
      const deviceIds = url.searchParams.get("deviceIds") || "all";
      const legacyMirror = await legacyMirrorWsapi.detailDevices(deviceIds);
      return sendJson(res, summarizeLegacyMirrorRead(legacyMirror), legacyMirror.ok ? 200 : 500);
    }

    if (req.method === "GET" && url.pathname === "/api/legacy-mirror/groups") {
      const legacyMirror = await legacyMirrorWsapi.getGroups();
      return sendJson(res, summarizeLegacyMirrorGroupsRead(legacyMirror), legacyMirror.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/legacy-mirror/devices/number") {
      const body = await readJson(req);
      const result = await legacyMirrorWsapi.editDeviceNo(body.deviceIds, body.deviceNo);
      return sendJson(res, summarizeLegacyMirrorMutation(result), result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/legacy-mirror/devices/name") {
      const body = await readJson(req);
      const result = await legacyMirrorWsapi.editDeviceName(body.deviceIds, body.deviceName);
      return sendJson(res, summarizeLegacyMirrorMutation(result), result.ok ? 200 : 500);
    }

    if (req.method === "GET" && url.pathname === "/api/legacy-mirror/names/preview") {
      const result = await buildLegacyMirrorNameSyncPlan();
      return sendJson(res, result, 200);
    }

    if (req.method === "POST" && url.pathname === "/api/legacy-mirror/names/sync") {
      const result = await syncLegacyMirrorNamesFromFleetDb();
      appendAuditLog({
        type: "laixi_name_sync",
        title: "Legacy device names synced from fleet DB",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          requested: result.requested,
          succeeded: result.succeeded,
          failed: result.failed,
          unmatched: result.unmatched,
        },
      });
      return sendJson(res, result, 200);
    }

    if (req.method === "POST" && url.pathname === "/api/legacy-mirror/numbers/sync") {
      const body = await readJson(req);
      const result = await syncLegacyMirrorNumbersFromFleetDb({ apply: body.apply !== false });
      appendAuditLog({
        type: "laixi_number_sync",
        title: "Legacy device numbers synced from fleet DB",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          requested: result.requested,
          succeeded: result.succeeded,
          failed: result.failed,
        },
      });
      return sendJson(res, result, 200);
    }

    if (req.method === "POST" && url.pathname === "/api/legacy-mirror/sync") {
      const result = await syncLegacyMirrorFromFleetDb();
      appendAuditLog({
        type: "laixi_full_sync",
        title: "Legacy names, numbers, and groups synced from fleet DB",
        level: result.ok ? "info" : "warn",
        details: {
          ok: result.ok,
          names: result.names && { succeeded: result.names.succeeded, failed: result.names.failed },
          numbers: result.numbers && { succeeded: result.numbers.succeeded, failed: result.numbers.failed },
          groups: result.groups && { succeeded: result.groups.succeeded, failed: result.groups.failed },
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/legacy-mirror/groups/sync") {
      const result = await syncLegacyMirrorGroupsFromFleetDb();
      appendAuditLog({
        type: "laixi_group_sync",
        title: "Legacy device groups synced from fleet DB",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          requested: result.requested,
          succeeded: result.succeeded,
          failed: result.failed,
          unchanged: result.unchanged,
          duplicateGroups: result.duplicateGroups,
        },
      });
      return sendJson(res, result, 200);
    }

    if (req.method === "POST" && url.pathname === "/api/legacy-mirror/groups/create") {
      const body = await readJson(req);
      const result = await legacyMirrorWsapi.createGroup(body.groupName);
      return sendJson(res, summarizeLegacyMirrorMutation(result), result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/legacy-mirror/groups/update") {
      const body = await readJson(req);
      const result = await legacyMirrorWsapi.updateGroup(body.groupId, body.groupName);
      return sendJson(res, summarizeLegacyMirrorMutation(result), result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/legacy-mirror/groups/move") {
      const body = await readJson(req);
      const result = await legacyMirrorWsapi.moveToGroup(body);
      return sendJson(res, summarizeLegacyMirrorMutation(result), result.ok ? 200 : 500);
    }

    if (req.method === "GET" && url.pathname === "/api/xiaowei/scripts") {
      return sendJson(res, inspectXiaoweiScriptDir());
    }

    if (req.method === "GET" && url.pathname === "/api/legacy-mirror/scripts") {
      return sendJson(res, inspectLegacyMirrorScriptDir());
    }

    if (req.method === "POST" && url.pathname === "/api/xiaowei/scripts/install-tests") {
      return sendJson(res, installXiaoweiTestScripts());
    }

    if (req.method === "POST" && url.pathname === "/api/legacy-mirror/scripts/install-tests") {
      return sendJson(res, installLegacyMirrorTestScripts());
    }

    if (req.method === "GET" && url.pathname === "/api/xiaowei/log-tail") {
      const limit = Number(url.searchParams.get("limit") || 120);
      return sendJson(res, readXiaoweiLogTail(limit));
    }

    if (req.method === "GET" && url.pathname === "/api/legacy-mirror/log-tail") {
      const limit = Number(url.searchParams.get("limit") || 120);
      return sendJson(res, readLegacyMirrorLogTail(limit));
    }

    if (req.method === "GET" && ["/tag-board", "/device-tag-transposed.html"].includes(url.pathname)) {
      const generatedPath = path.join(paths.dataDir, "fleet-db", "device-tag-transposed.html");
      const serveGenerated = url.searchParams.get("generated") === "1" && fs.existsSync(generatedPath);
      if (!serveGenerated) {
        await maybeAdvanceDayTags();
        const tagBoard = regenerateTagBoard();
        if (!tagBoard.ok) {
          return sendJson(res, {
            ok: false,
            error: "Failed to regenerate tag board",
            tagBoard,
          }, 500);
        }
      }
      return serveDataFile(generatedPath, res);
    }

    if (req.method === "GET" && ["/app", "/fleet-app"].includes(url.pathname)) {
      return serveStatic("/fleet-app.html", res);
    }

    if (req.method === "GET" && url.pathname === "/device-tag-matrix.html") {
      const tagBoard = regenerateTagBoard();
      if (!tagBoard.ok) {
        return sendJson(res, {
          ok: false,
          error: "Failed to regenerate tag board",
          tagBoard,
        }, 500);
      }
      return serveDataFile(path.join(paths.dataDir, "fleet-db", "device-tag-matrix.html"), res);
    }

    if (req.method === "GET" && url.pathname === "/api/fleet-db/summary") {
      return sendJson(res, buildFleetDbSummaryCached());
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/operation-groups/upsert") {
      const body = await readJson(req);
      const result = upsertFleetOperationGroup(body);
      return sendJson(res, result, result.ok ? 200 : result.statusCode || 500);
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/operation-groups/delete") {
      const body = await readJson(req);
      const result = deleteFleetOperationGroup(body);
      return sendJson(res, result, result.ok ? 200 : 404);
    }

    if (req.method === "GET" && url.pathname === "/api/fleet-db/offline-devices") {
      return sendJson(res, listOfflineFleetDevices());
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/offline-devices/upsert") {
      const body = await readJson(req);
      return sendJson(res, upsertOfflineFleetDevice(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/offline-devices/task-checks") {
      const body = await readJson(req);
      return sendJson(res, updateOfflineFleetTaskChecks(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/offline-devices/action") {
      const body = await readJson(req);
      return sendJson(res, runOfflineFleetDeviceAction(body));
    }

    if (req.method === "GET" && url.pathname === "/api/fleet-db/recovery-status") {
      return sendJson(res, buildFleetDbRecoveryStatus());
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/recover") {
      const body = await readJson(req);
      return sendJson(res, recoverFleetDbFromBackup(body));
    }

    if (req.method === "GET" && url.pathname === "/api/fleet-db/sync-log") {
      return sendJson(res, readFleetSyncLog());
    }

    if (req.method === "GET" && url.pathname === "/api/fleet-db/retired-devices") {
      return sendJson(res, listRetiredFleetDevices());
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/devices/retire") {
      const body = await readJson(req);
      return sendJson(res, retireFleetDbDevice(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/devices/restore") {
      const body = await readJson(req);
      return sendJson(res, restoreFleetDbDevice(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/connection-incidents/ignore") {
      const body = await readJson(req);
      return sendJson(res, ignoreFleetConnectionIncidents(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/sync-log") {
      const body = await readJson(req);
      return sendJson(res, appendFleetSyncLog(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/sync-log/clear") {
      return sendJson(res, clearFleetSyncLog());
    }

    if (req.method === "GET" && url.pathname === "/api/fleet-db/export-json") {
      return sendJson(res, buildFleetDbExport());
    }

    if (req.method === "GET" && url.pathname === "/api/device-master") {
      return sendJson(res, readDeviceMasterSummary());
    }

    if (req.method === "POST" && url.pathname === "/api/pc/clipboard") {
      const body = await readJson(req);
      const result = setPcClipboardText(body && body.text);
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "GET" && url.pathname === "/api/clipboard-items") {
      return sendJson(res, readClipboardItems());
    }

    if (req.method === "POST" && url.pathname === "/api/clipboard-items") {
      const body = await readJson(req);
      return sendJson(res, upsertClipboardItem(body));
    }

    if (req.method === "POST" && url.pathname === "/api/clipboard-items/delete") {
      const body = await readJson(req);
      return sendJson(res, deleteClipboardItem(body));
    }

    if (req.method === "POST" && url.pathname === "/api/clipboard-items/reorder") {
      const body = await readJson(req);
      return sendJson(res, reorderClipboardItems(body));
    }

    if (req.method === "POST" && url.pathname === "/api/device-master/entries") {
      const body = await readJson(req);
      return sendJson(res, upsertDeviceMasterEntry(body));
    }

    if (req.method === "POST" && url.pathname === "/api/device-master/entries/delete") {
      const body = await readJson(req);
      return sendJson(res, deleteDeviceMasterEntry(body));
    }

    if (req.method === "POST" && url.pathname === "/api/device-master/import-csv") {
      const body = await readJson(req);
      return sendJson(res, importDeviceMasterCsv(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/settings") {
      const body = await readJson(req);
      return sendJson(res, updateFleetDbSettings(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/device-order") {
      const body = await readJson(req);
      return sendJson(res, updateFleetDbDeviceOrder(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/device-numbers") {
      const body = await readJson(req);
      return sendJson(res, updateFleetDbDeviceNumbers(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/device-name-sequences") {
      const body = await readJson(req);
      return sendJson(res, updateFleetDbDeviceNameSequences(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/withdrawals") {
      const body = await readJson(req);
      return sendJson(res, addManualWithdrawal(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/withdrawals/update") {
      const body = await readJson(req);
      return sendJson(res, updateWithdrawal(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/withdrawals/delete") {
      const body = await readJson(req);
      return sendJson(res, deleteWithdrawal(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/withdrawals/reset-done") {
      const body = await readJson(req);
      return sendJson(res, markWithdrawalResetDone(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/devices/reset") {
      const body = await readJson(req);
      return sendJson(res, resetDeviceToWaiting(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/devices/update") {
      const body = await readJson(req);
      if (body.syncName && rejectXiaoweiWriteWhenIsolated(res, "fleet_device_name_sync")) return;
      return sendJson(res, updateFleetDbDevice(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/import-adb-new") {
      const result = await importNewAdbDevicesToFleetDb();
      appendAuditLog({
        type: "fleet_db_adb_new_devices_imported",
        title: "New ADB devices imported to Fleet DB",
        level: result.ok ? "info" : "warn",
        details: {
          scanned: result.scanned,
          imported: result.imported,
          skipped: result.skipped,
          masterUnregistered: result.masterUnregisteredCount || 0,
          xiaoweiHistorySkipped: result.xiaoweiHistorySkipped || 0,
          xiaoweiUsbConfirmed: result.xiaoweiUsbConfirmed || 0,
          error: result.error || "",
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/device-codes/sync") {
      const body = await readJson(req);
      const identityRefresh = body.refreshIdentity === true
        ? await refreshExistingDeviceIdentitiesFromSources()
        : null;
      const result = syncFleetDeviceCodes({ force: body.force !== false });
      appendAuditLog({
        type: "fleet_db_device_codes_synced",
        title: "Fleet DB fixed device codes synced",
        level: result.ok ? "info" : "warn",
        details: {
          ok: result.ok,
          changedDevices: result.changedDevices,
          changedWithdrawals: result.changedWithdrawals,
          identityCorrections: identityRefresh && identityRefresh.correctedDevices || 0,
        },
      });
      return sendJson(res, { ...result, identityRefresh }, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/import-branch-report") {
      const body = await readJson(req);
      return sendJson(res, importBranchReport(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/preview-branch-report") {
      const body = await readJson(req);
      return sendJson(res, previewBranchReport(body));
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/export-sheets") {
      const result = runNodeScript("sync-google-sheets.js");
      appendAuditLog({
        type: "sheets_export_requested",
        title: "Fleet DB exported to Google Sheets",
        level: result.ok ? "info" : "warn",
        details: result,
      });
      return sendJson(res, { ok: result.ok, result }, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/fleet-db/backup") {
      const result = backupFleetDb();
      appendAuditLog({
        type: "fleet_db_backup",
        title: "Fleet DB backup created",
        level: result.ok ? "info" : "warn",
        details: result,
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/migration/export") {
      const result = exportMigrationData();
      appendAuditLog({
        type: "migration_export",
        title: "Migration data exported",
        level: result.ok ? "info" : "warn",
        details: result,
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/migration/open") {
      const result = openMigrationFolder();
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/migration/import") {
      const result = importMigrationData();
      appendAuditLog({
        type: "migration_import",
        title: "Migration data imported",
        level: result.ok ? "info" : "warn",
        details: result,
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/xiaowei/sync") {
      if (rejectXiaoweiWriteWhenIsolated(res, "name_number_sync")) return;
      const result = await syncXiaoweiTagBoard({ forceDisplayNames: true });
      appendAuditLog({
        type: "xiaowei_name_number_sync",
        title: "XiaoWei name and number sync requested",
        level: result.ok ? "info" : "warn",
        details: {
          ok: result.ok,
          failedSteps: result.failedSteps,
          disconnectedRequested: result.refresh && result.refresh.numbers && result.refresh.numbers.disconnectedRequested || 0,
          disconnectedSucceeded: result.refresh && result.refresh.numbers && result.refresh.numbers.disconnectedSucceeded || 0,
          disconnectedFailed: result.refresh && result.refresh.numbers && result.refresh.numbers.disconnectedFailed || 0,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/xiaowei/numbers/sync") {
      if (rejectXiaoweiWriteWhenIsolated(res, "number_sync")) return;
      const body = await readJson(req);
      const result = await syncXiaoweiNumbersFromFleetDb({ apply: body.apply !== false });
      appendAuditLog({
        type: "xiaowei_number_sync",
        title: "XiaoWei device numbers synced from fleet DB",
        level: result.ok ? "info" : "warn",
        details: {
          ok: result.ok,
          requested: result.requested,
          succeeded: result.succeeded,
          failed: result.failed,
          unmatched: result.unmatched,
          disconnectedMatched: result.disconnectedMatched,
          disconnectedRequested: result.disconnectedRequested,
          disconnectedSucceeded: result.disconnectedSucceeded,
          disconnectedFailed: result.disconnectedFailed,
          apply: body.apply !== false,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/xiaowei/display-names/sync") {
      if (rejectXiaoweiWriteWhenIsolated(res, "display_name_sync")) return;
      const result = refreshDisplayNamesOnly({ forceUpdate: true });
      const failedSteps = criticalFleetRefreshFailures(result);
      appendAuditLog({
        type: "xiaowei_display_name_sync",
        title: "XiaoWei display names refreshed from fleet DB",
        level: failedSteps.length ? "warn" : "info",
        details: {
          ok: failedSteps.length === 0,
          failedSteps,
        },
      });
      return sendJson(res, {
        ok: failedSteps.length === 0,
        refresh: result,
        failedSteps,
        warningSteps: Object.entries(result).filter(([, step]) => !step.ok).map(([name]) => name),
      }, failedSteps.length ? 500 : 200);
    }

    if (req.method === "POST" && url.pathname === "/api/xiaowei/tags/apply") {
      if (rejectXiaoweiWriteWhenIsolated(res, "tag_apply")) return;
      await readJson(req);
      const result = {
        ok: true,
        disabled: true,
        requested: 0,
        applied: 0,
        failed: 0,
        message: "XiaoWei tag sync is disabled. Tags stay in the local DB only.",
      };
      appendAuditLog({
        type: "xiaowei_tag_apply_skipped",
        title: "XiaoWei tag apply skipped",
        level: "info",
        details: {
          ok: result.ok,
          disabled: result.disabled,
        },
      });
      return sendJson(res, result);
    }

    if (req.method === "POST" && url.pathname === "/api/tag-board/tags/apply") {
      const body = await readJson(req);
      const result = await applyTagBoardTagChanges(body);
      const failedChanges = (result.results || [])
        .filter((item) => item && !item.ok)
        .slice(0, 50)
        .map((item) => ({
          serial: item.serial || "",
          managementId: item.managementId || "",
          tag: item.tag || "",
          error: item.error || "unknown error",
        }));
      appendAuditLog({
        type: "tag_board_local_apply",
        title: "Tag board changes applied to fleet DB",
        level: result.ok ? "info" : "warn",
        details: {
          ok: result.ok,
          requested: result.requested,
          applied: result.applied,
          failed: result.failed,
          repairedMissingCycles: result.repairedMissingCycles || 0,
          withdrawalsCreated: result.withdrawalsCreated || 0,
          withdrawalsReused: result.withdrawalsReused || 0,
          failedChanges,
          groupFailed: result.groupSync && result.groupSync.failed,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/day-tags/advance") {
      const body = await readJson(req);
      const result = await runDayRollover({
        force: body.force === true,
        syncXiaowei: body.syncXiaowei !== false,
        syncLegacyMirror: body.syncLegacyMirror === true || body.syncLegacyMirror === true,
        source: "manual",
      });
      appendAuditLog({
        type: "day_tags_advance_manual",
        title: "DAY tags advanced manually",
        level: result.ok ? "info" : "warn",
        details: {
          ok: result.ok,
          skipped: result.skipped,
          changed: result.changed,
          failed: result.failed,
          xiaoweiNames: result.xiaoweiNames && result.xiaoweiNames.ok,
          laixiNames: result.laixiNames && result.laixiNames.succeeded,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/restart-server") {
      const result = restartAdbServer();
      appendAuditLog({
        type: "adb_server_restart",
        title: "ADB server restart requested",
        level: result.ok ? "info" : "warn",
        details: result,
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/setup/first-run") {
      const result = runFirstSetup();
      appendAuditLog({
        type: "first_run_setup",
        title: "First-run setup requested",
        level: result.ok ? "info" : "warn",
        details: result,
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/baseline-device-settings") {
      const result = await applyBaselineDeviceSettingsForConnectedDevices();
      appendAuditLog({
        type: "adb_baseline_device_settings",
        title: "ADB baseline device settings applied for connected devices",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          actions: result.actions,
          connected: result.connected,
          targeted: result.targeted,
          skippedAlreadyApplied: result.skippedAlreadyApplied,
          skippedActive: result.skippedActive,
          succeeded: result.succeeded,
          failed: result.failed,
          warning: result.warning,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/baseline-device-settings/refresh") {
      const result = await refreshBaselineDeviceSettingsForConnectedDevices();
      appendAuditLog({
        type: "adb_baseline_device_settings_refresh",
        title: "ADB baseline device settings refreshed for connected devices",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          connected: result.connected,
          targeted: result.targeted,
          succeeded: result.succeeded,
          failed: result.failed,
          updated: result.updated,
          warning: result.warning,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/xiaomi-miui-optimize") {
      const result = await optimizeXiaomiMiuiForConnectedDevices();
      appendAuditLog({
        type: "adb_xiaomi_miui_optimize",
        title: "ADB Xiaomi MIUI optimization requested",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          scanned: result.scanned,
          connected: result.connected,
          targeted: result.targeted,
          skipped: result.skipped,
          succeeded: result.succeeded,
          failed: result.failed,
          warning: result.warning,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/auto-rotate-off") {
      const result = await setAutoRotateOffForConnectedDevices();
      appendAuditLog({
        type: "adb_auto_rotate_off",
        title: "ADB auto-rotation disabled for connected devices",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          scanned: result.scanned,
          connected: result.connected,
          succeeded: result.succeeded,
          failed: result.failed,
          warning: result.warning,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/earthquake-alerts-off") {
      const result = await setEarthquakeAlertsOffForConnectedDevices();
      appendAuditLog({
        type: "adb_earthquake_alerts_off",
        title: "ADB earthquake/emergency alerts disabled for connected devices",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          scanned: result.scanned,
          connected: result.connected,
          succeeded: result.succeeded,
          failed: result.failed,
          warning: result.warning,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/data-saver") {
      const result = await setDataSaverForConnectedDevices();
      appendAuditLog({
        type: "adb_data_saver_on",
        title: "ADB Data Saver enabled for connected devices",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          scanned: result.scanned,
          connected: result.connected,
          succeeded: result.succeeded,
          failed: result.failed,
          warning: result.warning,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/nfc-off") {
      const result = await setNfcOffForConnectedDevices();
      appendAuditLog({
        type: "adb_nfc_off",
        title: "ADB NFC disabled for connected devices",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          scanned: result.scanned,
          connected: result.connected,
          succeeded: result.succeeded,
          failed: result.failed,
          warning: result.warning,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/sound-off") {
      const result = await setSoundOffForConnectedDevices();
      appendAuditLog({
        type: "adb_sound_off",
        title: "ADB sound disabled for connected devices",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          scanned: result.scanned,
          connected: result.connected,
          succeeded: result.succeeded,
          failed: result.failed,
          warning: result.warning,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/legacy-mirror-setup") {
      const result = await setLegacyMirrorPermissionsForConnectedDevices();
      appendAuditLog({
        type: "adb_laixi_setup",
        title: "ADB legacy helper permissions enabled for connected devices",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          scanned: result.scanned,
          connected: result.connected,
          succeeded: result.succeeded,
          failed: result.failed,
          warning: result.warning,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/install-ttl-line") {
      const body = await readJson(req);
      const result = await installTtlLineApksForTargets(body);
      appendAuditLog({
        type: "adb_install_ttl_line_apks",
        title: "ADB TikTok Lite and LINE APK install requested",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          scanned: result.scanned,
          connected: result.connected,
          succeeded: result.succeeded,
          failed: result.failed,
          warning: result.warning,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/restart-ttl") {
      const body = await readJson(req);
      const result = await restartTtlForTargets(body);
      appendAuditLog({
        type: "adb_restart_ttl",
        title: "ADB TikTok Lite restart requested",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          requested: result.requested,
          succeeded: result.succeeded,
          failed: result.failed,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/close-ttl") {
      const body = await readJson(req);
      const result = await closeTtlForTargets(body);
      appendAuditLog({
        type: "adb_close_ttl",
        title: "ADB TikTok Lite close requested",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          requested: result.requested,
          succeeded: result.succeeded,
          failed: result.failed,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/swipe-agent/recovery-test") {
      const body = await readJson(req);
      const result = await runSwipeRecoveryTestForTargets(body);
      appendAuditLog({
        type: "swipe_agent_recovery_test",
        title: "Swipe Agent recovery test requested",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          requested: result.requested,
          succeeded: result.succeeded,
          failed: result.failed,
        },
      });
      return sendJson(res, result, 200);
    }

    if (req.method === "POST" && url.pathname === "/api/swipe-agent/install-status") {
      const result = await refreshSwipeAgentInstallStatusForConnectedDevices();
      appendAuditLog({
        type: "swipe_agent_install_status",
        title: "Android Swipe Agent install status refreshed",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          connected: result.connected,
          installed: result.installed,
          missing: result.missing,
          failed: result.failed,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/swipe-agent/install") {
      const result = await installSwipeAgentForConnectedDevices();
      appendAuditLog({
        type: "swipe_agent_install",
        title: "Android Swipe Agent installed to missing devices",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          connected: result.connected,
          installed: result.installed,
          skipped: result.skipped,
          failed: result.failed,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/swipe-runner") {
      const body = await readJson(req);
      const result = startAdbSwipeRunner(body);
      appendAuditLog({
        type: "adb_swipe_runner_started",
        title: "ADB swipe runner started",
        level: result.ok ? "info" : "warn",
        details: result,
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/swipe-jobs") {
      const body = await readJson(req);
      const result = await startAdbSwipeJob(body);
      appendAuditLog({
        type: "adb_swipe_job_started",
        title: "ADB swipe job started",
        level: result.ok ? "info" : "warn",
        details: {
          ok: result.ok,
          jobId: result.job && result.job.jobId,
          devices: result.job && result.job.totals && result.job.totals.devices,
          error: result.error || "",
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/swipe-agent/jobs") {
      const body = await readJson(req);
      const result = await startSwipeAgentJob(body);
      appendAuditLog({
        type: "swipe_agent_job_started",
        title: "Android Swipe Agent job started",
        level: result.ok ? "info" : "warn",
        details: {
          ok: result.ok,
          jobId: result.job && result.job.jobId,
          devices: result.job && result.job.totals && result.job.totals.devices,
          error: result.error || "",
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/swipe/stop-all") {
      const body = await readJson(req);
      const result = await stopAllSwipeWork(body);
      appendAuditLog({
        type: "swipe_stop_all",
        title: "Swipe stop requested",
        level: result.ok ? "info" : "warn",
        details: result,
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/apk-folder/open") {
      return sendJson(res, openApkFolder());
    }

    if (req.method === "POST" && url.pathname === "/api/legacy-mirror/restart") {
      const result = restartLegacyMirrorApp();
      appendAuditLog({
        type: "laixi_app_restart",
        title: "Legacy helper app restarted",
        level: result.ok ? "info" : "warn",
        details: result,
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/launch-app") {
      const body = await readJson(req);
      const result = await launchAppForTargets(body);
      appendAuditLog({
        type: "adb_launch_app",
        title: "ADB app launch requested",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          packageName: result.packageName,
          requested: result.requested,
          succeeded: result.succeeded,
          failed: result.failed,
        },
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "GET" && url.pathname === "/api/swipe-agent/jobs") {
      return sendJson(res, listSwipeAgentJobs());
    }

    const swipeAgentJobMatch = url.pathname.match(/^\/api\/swipe-agent\/jobs\/([^/]+)$/);
    if (req.method === "GET" && swipeAgentJobMatch) {
      const result = getSwipeAgentJobStatus(decodeURIComponent(swipeAgentJobMatch[1]));
      return sendJson(res, result, result.ok ? 200 : 404);
    }

    const swipeAgentStopMatch = url.pathname.match(/^\/api\/swipe-agent\/jobs\/([^/]+)\/stop$/);
    if (req.method === "POST" && swipeAgentStopMatch) {
      const result = stopSwipeAgentJob(decodeURIComponent(swipeAgentStopMatch[1]));
      appendAuditLog({
        type: "swipe_agent_job_stop",
        title: "Android Swipe Agent stop requested",
        level: result.ok ? "info" : "warn",
        details: result,
      });
      return sendJson(res, result, result.ok ? 200 : 404);
    }

    if (req.method === "GET" && url.pathname === "/api/adb/swipe-jobs") {
      return sendJson(res, listAdbSwipeJobs());
    }

    const swipeJobMatch = url.pathname.match(/^\/api\/adb\/swipe-jobs\/([^/]+)$/);
    if (req.method === "GET" && swipeJobMatch) {
      const result = getAdbSwipeJobStatus(decodeURIComponent(swipeJobMatch[1]));
      return sendJson(res, result, result.ok ? 200 : 404);
    }

    const swipeJobStopMatch = url.pathname.match(/^\/api\/adb\/swipe-jobs\/([^/]+)\/stop$/);
    if (req.method === "POST" && swipeJobStopMatch) {
      const result = stopAdbSwipeJob(decodeURIComponent(swipeJobStopMatch[1]));
      appendAuditLog({
        type: "adb_swipe_job_stop",
        title: "ADB swipe job stop requested",
        level: result.ok ? "info" : "warn",
        details: result,
      });
      return sendJson(res, result.ok ? result : result, result.ok ? 200 : 404);
    }

    if (req.method === "GET" && url.pathname === "/api/adb/devices") {
      const result = await listAdbDevicesForUi({
        includeUptime: url.searchParams.get("uptime") !== "0",
        includeFacts: url.searchParams.get("facts") === "1" || url.searchParams.get("facts") === "true",
        persistFacts: url.searchParams.get("persist") === "1" || url.searchParams.get("persist") === "true",
      });
      return sendJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "GET" && url.pathname === "/api/adb/sim-info") {
      const requestGuard = privateApiGuard.validate(req);
      if (!requestGuard.ok) return sendPrivateJson(res, requestGuard, requestGuard.status);
      const result = await listAdbSimInfoForUiSingleFlight({
        fresh: url.searchParams.get("fresh") === "1",
      });
      return sendPrivateJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "GET" && url.pathname === "/api/adb/navigation-layout") {
      const requestGuard = privateApiGuard.validate(req);
      if (!requestGuard.ok) return sendPrivateJson(res, requestGuard, requestGuard.status);
      const result = await listAdbNavigationLayoutsForUi();
      return sendPrivateJson(res, result, result.ok ? 200 : 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/navigation-layout") {
      const requestGuard = privateApiGuard.validate(req, { requireOrigin: true, requireJson: true });
      if (!requestGuard.ok) return sendPrivateJson(res, requestGuard, requestGuard.status);
      const body = await readJson(req);
      const result = await applyAdbNavigationLayouts(body);
      appendAuditLog({
        type: "adb_navigation_layout",
        title: "ADB navigation button layout requested",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          backPosition: result.backPosition || "",
          scope: result.scope || "",
          forceReapply: result.forceReapply === true,
          requested: result.requested || 0,
          targeted: result.targeted || 0,
          succeeded: result.succeeded || 0,
          settingVerified: result.settingVerified || 0,
          written: result.written || 0,
          reapplied: result.reapplied || 0,
          screenVerified: result.screenVerified || 0,
          visualCheckRequired: result.visualCheckRequired || 0,
          blocked: result.blocked || 0,
          failed: result.failed || 0,
          duplicateBlocked: result.code === "NAVIGATION_LAYOUT_ALREADY_RUNNING",
          results: Array.isArray(result.results) ? result.results.map((row) => ({
            serial: row.serial || "",
            model: row.model || "",
            oem: row.oem || "",
            code: row.code || "",
            changed: row.changed === null ? null : row.changed === true,
            reapplied: row.reapplied === true,
            settingVerified: row.settingVerified === true,
            screenVerified: row.screenVerified === true,
            stateUncertain: row.stateUncertain === true,
            rollbackOk: row.rollbackOk === true,
            rollbackFailedSettings: Array.isArray(row.rollbackFailedSettings) ? row.rollbackFailedSettings : [],
            settingPaths: Array.isArray(row.settingPaths) ? row.settingPaths : [],
          })) : [],
        },
      });
      return sendPrivateJson(res, result, result.ok ? 200 : result.status || 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/battery-protection") {
      const requestGuard = privateApiGuard.validate(req, { requireOrigin: true, requireJson: true });
      if (!requestGuard.ok) return sendPrivateJson(res, requestGuard, requestGuard.status);
      const body = await readJson(req);
      const result = await runBatteryProtectionForTargets(body);
      appendAuditLog({
        type: "adb_battery_protection",
        title: result.mode === "open"
          ? "ADB battery protection screen requested"
          : "ADB battery protection status requested",
        level: result.failed ? "warn" : "info",
        details: {
          ok: result.ok,
          mode: result.mode || "",
          requested: result.requested || 0,
          targeted: result.targeted || 0,
          succeeded: result.succeeded || 0,
          manualRequired: result.manualRequired || 0,
          failed: result.failed || 0,
          duplicateBlocked: result.code === "BATTERY_PROTECTION_ALREADY_RUNNING",
          results: Array.isArray(result.results) ? result.results.map((row) => ({
            serial: row.serial || "",
            model: row.model || "",
            manufacturer: row.identity?.manufacturer || "",
            code: row.code || "",
            opened: row.opened || "",
            fallbackUsed: row.fallbackUsed === true,
            manualOnly: row.manualOnly !== false,
            batteryPercent: row.battery?.percent !== null
              && row.battery?.percent !== undefined
              && Number.isFinite(Number(row.battery.percent))
              ? Number(row.battery.percent)
              : null,
          })) : [],
        },
      });
      return sendPrivateJson(res, result, result.ok ? 200 : result.status || 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/apn-draft") {
      const requestGuard = privateApiGuard.validate(req, { requireOrigin: true, requireJson: true });
      if (!requestGuard.ok) return sendPrivateJson(res, requestGuard, requestGuard.status);
      const body = await readJson(req);
      const result = await prepareAdbApnDraft(body);
      const draft = result.result || {};
      appendAuditLog({
        type: "adb_apn_draft",
        serial: cleanText(body.serial, 80),
        title: body.dryRun === true
          ? "ADB APN dry run requested"
          : body.saveAfterFill === true
            ? "ADB APN save requested"
            : "ADB APN draft requested",
        level: result.ok && (
          body.dryRun === true
            ? draft.planned === true && result.mutationStarted === false
            : draft.prepared && (body.saveAfterFill !== true || draft.saved === true)
        ) ? "info" : "warn",
        details: {
          ok: result.ok,
          dryRun: body.dryRun === true,
          mutationStarted: result.mutationStarted === true,
          prepared: draft.prepared === true,
          planned: draft.planned === true,
          profileId: cleanText(body.profileId, 64),
          stage: cleanText(draft.stage, 64),
          attemptedFields: Array.isArray(draft.attemptedFields) ? draft.attemptedFields : [],
          verifiedFields: Array.isArray(draft.verifiedFields) ? draft.verifiedFields : [],
          stoppedAt: cleanText(draft.stoppedAt, 40),
          saveRequired: draft.saveRequired === true,
          saveAttempted: draft.saveAttempted === true,
          saveVerified: draft.saveVerified === true,
          saved: draft.saved === true,
          saveState: cleanText(draft.saveState, 24),
          saveMethod: cleanText(draft.saveMethod, 40),
          saveVerifiedBy: cleanText(draft.saveVerifiedBy, 20),
          reason: cleanText(draft.reason, 80),
          code: result.code || "",
        },
      });
      return sendPrivateJson(res, result, result.ok ? 200 : result.status || 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/apn-save-guard/release") {
      const requestGuard = privateApiGuard.validate(req, { requireOrigin: true, requireJson: true });
      if (!requestGuard.ok) return sendPrivateJson(res, requestGuard, requestGuard.status);
      const body = await readJson(req);
      const result = releaseAdbApnSaveGuard(body);
      appendAuditLog({
        type: "adb_apn_save_guard_released",
        serial: cleanText(body.serial, 80),
        title: "ADB APN save guard release requested",
        level: result.ok ? "warn" : "error",
        details: {
          ok: result.ok,
          released: result.released === true,
          profileId: cleanText(body.profileId, 64),
          previousState: cleanText(result.previousState, 24),
          code: result.code || "",
        },
      });
      return sendPrivateJson(res, result, result.ok ? 200 : result.status || 500);
    }

    if (req.method === "GET" && url.pathname === "/api/apk-library") {
      return sendJson(res, readApkLibrary());
    }

    if (req.method === "POST" && url.pathname === "/api/adb/root-pseudo-reset/preview") {
      const requestGuard = validateLocalPseudoResetRequest(req, "preview");
      if (!requestGuard.ok) return sendJson(res, { ok: false, error: requestGuard.error }, requestGuard.status);
      const body = await readJson(req);
      const result = await rootPseudoResetManager.preview({
        serial: body.serial,
        adbPort: body.adbPort,
        label: body.label,
        packages: body.packages,
      });
      appendAuditLog({
        type: result.ready ? "root_pseudo_reset_prepared" : "root_pseudo_reset_rejected",
        serial: result.target && result.target.serial || cleanText(body.serial, 80),
        title: result.ready ? "Root app-data reset prepared" : "Root app-data reset preflight blocked",
        level: result.ready ? "info" : "warn",
        details: {
          ok: result.ok,
          ready: result.ready,
          model: result.preflight && result.preflight.model || "",
          rootAvailable: result.preflight && result.preflight.rootAvailable === true,
          adbEnabled: result.preflight && result.preflight.adbEnabled === true,
          adbKeyPresent: result.preflight && result.preflight.adbKeyPresent === true,
          magiskPresent: result.preflight && result.preflight.magiskPresent === true,
          installedPackages: (result.packages || []).filter((item) => item.installed).map((item) => item.packageName),
          blockers: result.preflight && result.preflight.blockers || [],
          code: result.code || "",
        },
      });
      return sendJson(res, result, result.ok ? 200 : result.status || 500);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/root-pseudo-reset/execute") {
      const requestGuard = validateLocalPseudoResetRequest(req, "execute");
      if (!requestGuard.ok) return sendJson(res, { ok: false, error: requestGuard.error }, requestGuard.status);
      const body = await readJson(req);
      const result = await rootPseudoResetManager.apply({
        serial: body.serial,
        adbPort: body.adbPort,
        label: body.label,
        packages: body.packages,
        confirmationToken: body.confirmationToken,
        confirmation: body.confirmation,
      });
      appendAuditLog({
        type: result.ok ? "root_pseudo_reset_completed" : "root_pseudo_reset_failed",
        serial: result.target && result.target.serial || cleanText(body.serial, 80),
        title: result.ok ? "Root app-data reset completed" : "Root app-data reset failed",
        level: result.ok ? "info" : "warn",
        details: {
          ok: result.ok,
          operationId: result.operationId || "",
          requested: result.requested || 0,
          succeeded: result.succeeded || 0,
          failed: result.failed || 0,
          stoppedEarly: result.stoppedEarly === true,
          packages: (result.results || []).map((item) => ({ packageName: item.packageName, ok: item.ok })),
          preservation: result.preservation || null,
          code: result.code || "",
        },
      });
      return sendJson(res, result, result.ok ? 200 : result.status || 409);
    }

    if (req.method === "POST" && url.pathname === "/api/adb/install-apks") {
      const body = await readJson(req);
      const result = await installSelectedApksForTargets(body);
      const duplicateBlocked = result.code === "APK_INSTALL_ALREADY_RUNNING";
      appendAuditLog({
        type: duplicateBlocked ? "adb_install_duplicate_blocked" : "adb_install_selected_apks",
        title: duplicateBlocked ? "Duplicate ADB APK install blocked" : "ADB selected APK install requested",
        level: result.failed || !result.ok ? "warn" : "info",
        details: {
          ok: result.ok,
          code: result.code || "",
          duplicateBlocked,
          files: result.files,
          targeted: result.targeted,
          succeeded: result.succeeded,
          failed: result.failed,
          warning: result.warning,
        },
      });
      return sendJson(res, result, result.ok ? 200 : result.status || 500);
    }

    if (req.method === "GET" && url.pathname === "/api/events") {
      return sendJson(res, {
        ok: true,
        events: readEvents({
          limit: Number(url.searchParams.get("limit") || 80),
          serial: url.searchParams.get("serial") || "",
          includeScans: url.searchParams.get("includeScans") === "true",
        }),
      });
    }

    if (req.method === "POST" && url.pathname === "/api/adb/actions") {
      const body = await readJson(req);
      const result = await runSafeAdbAction({
        ...body,
        rootDir: paths.root,
        screenshotsDir: paths.screenshotsDir,
      });
      decorateAdbActionResult(result);

      appendAuditLog({
        type: "adb_action",
        serial: result.serial,
        title: `ADB action: ${result.action || body.action || "unknown"}`,
        level: result.ok ? "info" : "warn",
        details: summarizeAdbActionResult(result),
      });

      return sendJson(res, result, result.ok ? 200 : result.status || 500);
    }

    if (req.method === "POST" && /^\/api\/devices\/[^/]+\/actions$/.test(url.pathname)) {
      const serial = decodeURIComponent(url.pathname.split("/")[3]);
      const body = await readJson(req);
      const result = await runPreferredDeviceAction({
        serial,
        action: body.action,
        payload: body,
      });
      decorateAdbActionResult(result);
      const inviteHistory = persistInviteVerificationFromAction(serial, body, result);
      if (inviteHistory) result.inviteHistory = inviteHistory;

      if (result.ok && result.action === "screenshot" && result.screenshotUrl) {
        store.upsertDevice(serial, {
          lastScreenshotUrl: result.screenshotUrl,
          lastScreenshotAt: new Date().toISOString(),
        });
      }

      appendAuditLog({
        type: "adb_action",
        serial,
        title: `ADB action: ${result.action || body.action || "unknown"}`,
        level: result.ok ? "info" : "warn",
        details: summarizeAdbActionResult(result),
      });

      return sendJson(res, result, result.ok ? 200 : result.status || 500);
    }

    if (req.method === "GET" && /^\/api\/devices\/[^/]+\/packages$/.test(url.pathname)) {
      const serial = decodeURIComponent(url.pathname.split("/")[3]);
      const result = await runPreferredDeviceAction({
        serial,
        action: "packages",
        payload: {
          action: "packages",
          limit: Number(url.searchParams.get("limit") || 80),
          scope: url.searchParams.get("scope") || "third_party",
          adbPort: Number(url.searchParams.get("adbPort") || 0) || null,
          includeLabels: url.searchParams.get("includeLabels") === "1",
          timeout: 20000,
        },
      });

      appendAuditLog({
        type: "adb_action",
        serial,
        title: "ADB action: packages",
        level: result.ok ? "info" : "warn",
        details: summarizeAdbActionResult(result),
      });

      return sendJson(res, result, result.ok ? 200 : result.status || 500);
    }

    if (req.method === "GET" && /^\/api\/devices\/[^/]+\/history$/.test(url.pathname)) {
      const serial = decodeURIComponent(url.pathname.split("/")[3]);
      return sendJson(res, {
        ok: true,
        serial,
        events: readEvents({ serial, limit: Number(url.searchParams.get("limit") || 30) }),
      });
    }

    if (req.method === "POST" && url.pathname.startsWith("/api/devices/")) {
      const serial = decodeURIComponent(url.pathname.replace("/api/devices/", ""));
      const body = await readJson(req);
      const before = store.getDevice(serial);
      const saved = store.upsertDevice(serial, body);
      appendAuditLog({
        type: "state_change",
        serial,
        title: `Device saved: ${saved.name || serial}`,
        details: { before, after: saved },
      });
      return sendJson(res, { ok: true, device: saved });
    }

    if (req.method === "POST" && url.pathname === "/api/logs") {
      const body = await readJson(req);
      const entry = {
        type: body.type || "manual_note",
        serial: body.serial || "",
        title: body.title || "Log",
        content: body.content || "",
        actor: body.actor || "operator",
        level: body.level || "info",
      };
      const markdownFile = markdownLogger.appendLog(entry);
      appendAuditLog({ ...entry, markdownFile });
      return sendJson(res, { ok: true, file: markdownFile });
    }

    if (req.method === "POST" && url.pathname === "/api/notify") {
      const body = await readJson(req);
      const result = await discord.notify(body.message || "Android Fleet OS notification", body.fields || {});
      return sendJson(res, { ok: true, discord: result });
    }

    if (req.method === "POST" && url.pathname === "/api/export/obsidian") {
      const body = await readJson(req);
      return sendJson(res, await exportObsidianSummary(body));
    }

    if (req.method === "GET" && url.pathname === "/api/remote-access/status") {
      if (!BROWSER_AGENT_MODE) return sendJson(res, { ok: false, code: "REMOTE_ACCESS_UNAVAILABLE" }, 404);
      return sendJson(res, {
        ...remoteAccess.status(),
        viewer: readTailscaleViewer(req),
      });
    }

    if (req.method === "POST" && url.pathname === "/api/remote-access/start") {
      if (!BROWSER_AGENT_MODE) return sendJson(res, { ok: false, code: "REMOTE_ACCESS_UNAVAILABLE" }, 404);
      const result = remoteAccess.enable();
      appendAuditLog({
        at: new Date().toISOString(),
        operation: "remote_access_start",
        ok: Boolean(result.enabled),
        code: result.code || "",
      });
      return sendJson(res, {
        ...result,
        viewer: readTailscaleViewer(req),
      }, result.enabled || result.consentUrl ? 200 : 400);
    }

    if (req.method === "POST" && url.pathname === "/api/remote-access/stop") {
      if (!BROWSER_AGENT_MODE) return sendJson(res, { ok: false, code: "REMOTE_ACCESS_UNAVAILABLE" }, 404);
      const result = remoteAccess.disable();
      appendAuditLog({
        at: new Date().toISOString(),
        operation: "remote_access_stop",
        ok: !result.enabled,
        code: result.code || "",
      });
      return sendJson(res, {
        ...result,
        viewer: readTailscaleViewer(req),
      }, result.enabled ? 400 : 200);
    }

    if (req.method === "GET" && url.pathname === "/api/config") {
      return sendJson(res, {
        ok: true,
        appVersion: readFleetAppVersion({ appDir: __dirname }),
        browserAgentMode: BROWSER_AGENT_MODE,
        remoteAccessAvailable: BROWSER_AGENT_MODE,
        discordEnabled: discord.enabled,
        dataDir: paths.dataDir,
        logDir: paths.logDir,
        screenshotsDir: paths.screenshotsDir,
        license: readCustomerLicense(),
        adbActions: listSafeAdbActions(),
        xiaowei: {
          dbPath: xiaoweiIntegration.dbPath,
          sqlitePath: xiaoweiIntegration.sqlitePath,
          apiUrl: xiaoweiApi.url,
        },
        obsidian: {
          defaultVaultDir: DEFAULT_OBSIDIAN_VAULT_DIR,
          envVaultDir: process.env.OBSIDIAN_VAULT_DIR || "",
          fallbackDir: path.join(paths.dataDir, "obsidian-export", "android_fleet"),
        },
      });
    }

    if (req.method === "GET" && url.pathname === "/api/monitor") {
      const latest = readJsonFile(paths.monitorLatestFile, null);
      const state = readJsonFile(paths.monitorStateFile, {});
      const monitorConfig = readJsonFile(path.join(paths.root, "config", "fleet-monitor.json"), {});
      return sendJson(res, {
        ok: true,
        latest,
        lastRunAt: state.lastRunAt || "",
        localLlm: {
          enabled: Boolean(monitorConfig.ollama && monitorConfig.ollama.enabled),
          model: monitorConfig.ollama && monitorConfig.ollama.model || "",
          fallbackModel: monitorConfig.ollama && monitorConfig.ollama.fallbackModel || "",
        },
        sheetsQueueCount: countJsonl(paths.anomalyQueueFile),
      });
    }

    if (url.pathname.startsWith("/screenshots/")) {
      return serveScreenshot(url.pathname, res);
    }

    return serveStatic(url.pathname, res);
  } catch (error) {
    return sendJson(res, { ok: false, error: error.message }, 500);
  }
});

server.listen(PORT, "127.0.0.1", () => {
  ensureAdbServerStarted();
  restoreSwipeAgentJobs();
  startDayRolloverScheduler();
  startUsbTopologyCacheScheduler();
  console.log(`Android Fleet OS running at http://127.0.0.1:${PORT}`);
  startSupportDiagnosticsReceiver();
});

function startSupportDiagnosticsReceiver() {
  if (
    PORT !== 8787
    || process.env.ANDROID_FLEET_DISABLE_SUPPORT_RECEIVER === "1"
    || !supportDiagnosticsReceiverEnabled()
  ) return;
  let receiver;
  try {
    receiver = createSupportDiagnosticsReceiverServer({
      inboxDir: path.join(supportDiagnosticsStateRoot(), "receiver", "inbox"),
      enrollmentRegistryPath: path.join(supportDiagnosticsStateRoot(), "receiver", "support-upload-enrollments.json"),
    });
  } catch {
    console.error("Support diagnostics receiver configuration is unavailable.");
    return;
  }
  receiver.once("error", () => {
    console.error("Support diagnostics receiver could not start.");
  });
  receiver.listen(SUPPORT_DIAGNOSTICS_RECEIVER_LOCAL_PORT, "127.0.0.1", () => {
    console.log(`Support diagnostics receiver ready on loopback port ${SUPPORT_DIAGNOSTICS_RECEIVER_LOCAL_PORT}.`);
  });
}

function supportDiagnosticsReceiverEnabled() {
  if (process.env.ANDROID_FLEET_SUPPORT_RECEIVER === "1") return true;
  const enabledPath = path.join(supportDiagnosticsStateRoot(), "receiver", "receiver-enabled.json");
  try {
    const stat = fs.lstatSync(enabledPath);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size <= 0 || stat.size > 1024) return false;
    const config = JSON.parse(fs.readFileSync(enabledPath, "utf8"));
    return Boolean(
      config
      && typeof config === "object"
      && !Array.isArray(config)
      && Object.keys(config).sort().join(",") === "enabled,schemaVersion"
      && config.schemaVersion === 1
      && config.enabled === true
    );
  } catch {
    return false;
  }
}

function readTailscaleViewer(req) {
  const login = String(req.headers["tailscale-user-login"] || "").trim();
  const name = String(req.headers["tailscale-user-name"] || "").trim();
  return {
    remote: Boolean(login || name),
    login,
    name,
  };
}

function discoverObsidianVaultDir() {
  try {
    const configPath = path.join(process.env.APPDATA || "", "obsidian", "obsidian.json");
    const config = JSON.parse(fs.readFileSync(configPath, "utf8").replace(/^\uFEFF/, ""));
    const vaults = Object.values(config.vaults || {});
    const selected = vaults.find((entry) => entry && entry.open && entry.path && fs.existsSync(entry.path))
      || vaults.find((entry) => entry && entry.path && fs.existsSync(entry.path));
    if (selected) return selected.path;
  } catch {
    // Fall back to the local export directory when Obsidian is unavailable.
  }
  return "";
}

function openApkFolder() {
  const apkDir = path.join(paths.root, "data", "apk");
  fs.mkdirSync(apkDir, { recursive: true });
  const child = spawn("explorer.exe", [apkDir], {
    detached: true,
    stdio: "ignore",
    windowsHide: false,
  });
  child.unref();
  return {
    ok: true,
    path: apkDir,
    pid: child.pid,
  };
}

function restartLegacyMirrorApp() {
  if (!fs.existsSync(LEGACY_MIRROR_EXE_PATH)) {
    return { ok: false, error: `Legacy helper exe was not found: ${LEGACY_MIRROR_EXE_PATH}` };
  }
  const stopped = stopProcessesByName("LegacyMirror");
  spawnSync("powershell.exe", ["-NoProfile", "-Command", "Start-Sleep -Milliseconds 800"], {
    windowsHide: true,
    encoding: "utf8",
  });
  const child = spawn(LEGACY_MIRROR_EXE_PATH, [], {
    detached: true,
    stdio: "ignore",
    windowsHide: false,
  });
  child.unref();
  return {
    ok: true,
    stopped,
    pid: child.pid,
    path: LEGACY_MIRROR_EXE_PATH,
    note: "If the group list still looks stale, wait a few seconds for the legacy WebView to reload.",
  };
}

function stopProcessesByName(processName) {
  const result = spawnSync("powershell.exe", [
    "-NoProfile",
    "-Command",
    `$items = Get-Process -Name ${JSON.stringify(processName)} -ErrorAction SilentlyContinue; $count = @($items).Count; if ($count -gt 0) { $items | Stop-Process -Force }; Write-Output $count`,
  ], {
    windowsHide: true,
    encoding: "utf8",
  });
  const count = Number(String(result.stdout || "").trim().split(/\s+/).pop() || 0);
  return Number.isFinite(count) ? count : 0;
}

function readJsonFile(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8").replace(/^\uFEFF/, ""));
  } catch {
    return fallback;
  }
}

function writeJsonFile(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tempPath = `${filePath}.tmp`;
  fs.writeFileSync(tempPath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  fs.renameSync(tempPath, filePath);
  const normalized = path.resolve(filePath);
  const fleetDbPath = path.resolve(paths.dataDir, "fleet-db", "fleet-db.json");
  const masterPath = path.resolve(paths.dataDir, "fleet-db", "device-master.json");
  const connectionPath = path.resolve(paths.dataDir, "fleet-db", "connection-history.json");
  if (normalized === fleetDbPath || normalized === masterPath || normalized === connectionPath) {
    fleetDbSummaryCache.key = "";
    fleetDbSummaryCache.summary = null;
  }
  if (normalized === masterPath) {
    deviceMasterCache.key = "";
    deviceMasterCache.master = null;
  }
}

function readApkLibrary() {
  const apkDir = path.join(paths.root, "data", "apk");
  const result = listApkLibrary(apkDir);
  return {
    ok: true,
    path: result.apkDir,
    files: result.files,
  };
}

function clipboardItemsPath() {
  return path.join(paths.dataDir, "clipboard-items.json");
}

function readClipboardItems() {
  const data = readJsonFile(clipboardItemsPath(), { items: [] });
  const items = Array.isArray(data.items) ? data.items : [];
  return {
    ok: true,
    items: items.filter((item) => item && item.id),
  };
}

function upsertClipboardItem(body = {}) {
  const now = new Date().toISOString();
  const text = cleanText(body.text, 4000);
  if (!text.trim()) return { ok: false, error: "text is empty" };
  const data = readJsonFile(clipboardItemsPath(), { items: [] });
  const items = Array.isArray(data.items) ? data.items : [];
  const id = cleanText(body.id, 80) || `clip-${Date.now().toString(36)}-${Math.random().toString(16).slice(2, 8)}`;
  const existing = items.find((item) => item.id === id) || {};
  const item = {
    ...existing,
    id,
    title: cleanText(body.title || existing.title || inferClipboardTitle(text), 120),
    note: cleanText(body.note || "", 800),
    text,
    sourceSerial: cleanText(body.sourceSerial || existing.sourceSerial || "", 120),
    sourceLabel: cleanText(body.sourceLabel || existing.sourceLabel || "", 160),
    sourceNumber: cleanText(body.sourceNumber || existing.sourceNumber || "", 40),
    createdAt: existing.createdAt || now,
    updatedAt: now,
  };
  const next = [item, ...items.filter((entry) => entry.id !== id)].slice(0, 300);
  writeJsonFile(clipboardItemsPath(), { schemaVersion: 1, updatedAt: now, items: next });
  appendAuditLog({
    type: "clipboard_item_saved",
    serial: item.sourceSerial,
    title: `Clipboard saved: ${item.title}`,
    details: { id: item.id, sourceLabel: item.sourceLabel, length: item.text.length },
  });
  return { ok: true, item, items: next };
}

function deleteClipboardItem(body = {}) {
  const id = cleanText(body.id, 80);
  const data = readJsonFile(clipboardItemsPath(), { items: [] });
  const items = Array.isArray(data.items) ? data.items : [];
  const next = items.filter((item) => item && item.id !== id);
  writeJsonFile(clipboardItemsPath(), { schemaVersion: 1, updatedAt: new Date().toISOString(), items: next });
  appendAuditLog({
    type: "clipboard_item_deleted",
    title: "Clipboard item deleted",
    details: { id, deleted: next.length !== items.length },
  });
  return { ok: true, deleted: next.length !== items.length, items: next };
}

function reorderClipboardItems(body = {}) {
  const ids = Array.isArray(body.ids) ? body.ids.map((id) => cleanText(id, 80)).filter(Boolean) : [];
  const data = readJsonFile(clipboardItemsPath(), { items: [] });
  const items = Array.isArray(data.items) ? data.items.filter((item) => item && item.id) : [];
  const byId = new Map(items.map((item) => [String(item.id), item]));
  const seen = new Set();
  const ordered = [];
  for (const id of ids) {
    if (seen.has(id) || !byId.has(id)) continue;
    seen.add(id);
    ordered.push(byId.get(id));
  }
  for (const item of items) {
    if (!seen.has(String(item.id))) ordered.push(item);
  }
  const now = new Date().toISOString();
  writeJsonFile(clipboardItemsPath(), { schemaVersion: 1, updatedAt: now, items: ordered });
  appendAuditLog({
    type: "clipboard_items_reordered",
    title: "Clipboard items reordered",
    details: { count: ordered.length },
  });
  return { ok: true, items: ordered };
}

function inferClipboardTitle(text) {
  const value = String(text || "").trim();
  try {
    const url = new URL(value);
    return url.hostname || value.slice(0, 40);
  } catch {
    return value.replace(/\s+/g, " ").slice(0, 40) || "メモなし";
  }
}

function countJsonl(filePath) {
  try {
    return fs.readFileSync(filePath, "utf8").split(/\r?\n/).filter(Boolean).length;
  } catch {
    return 0;
  }
}

async function getDevices() {
  const adbPath = resolveAdbPath();
  const [scanned, xiaowei] = await Promise.all([
    scanActiveAdbDevices({ adbPath }),
    readXiaoweiSources(),
  ]);
  const now = new Date().toISOString();

  if (scanned.available) {
    for (const device of scanned.devices) {
      store.upsertDevice(device.serial, {
        model: device.model,
        product: device.product,
        transportId: device.transportId,
        adbStatus: device.status,
        lastSeenAt: now,
      });
    }
  }

  const devices = mergeXiaoweiDevices(store.mergeScannedDevices(scanned.devices), xiaowei)
    .map((device) => ({
      ...device,
      recommendedAction: device.recommendedAction || suggestAction(device),
    }))
    .sort(compareFleetDevices);

  const xiaoweiMatched = devices.filter((device) => device.xiaowei && device.xiaowei.matched).length;

  appendAuditLog({
    type: "device_scan",
    title: "Device scan",
    details: {
      adbAvailable: scanned.available,
      xiaoweiAvailable: xiaowei.available,
      count: devices.length,
      connected: devices.filter((device) => device.connected).length,
      xiaoweiMatched,
    },
  });

  return {
    ok: true,
    adbAvailable: scanned.available,
    warning: [scanned.warning, xiaowei.dbWarning].filter(Boolean).join(" "),
    xiaowei: {
      available: xiaowei.available,
      dbAvailable: xiaowei.dbAvailable,
      apiAvailable: xiaowei.apiAvailable,
      apiReachable: xiaowei.apiReachable,
      apiLocked: xiaowei.apiLocked,
      apiCode: xiaowei.apiCode,
      apiMessage: xiaowei.apiMessage,
      apiTranslatedMessage: xiaowei.apiTranslatedMessage,
      apiUrl: xiaowei.apiUrl,
      dbPath: xiaowei.dbPath,
      count: xiaowei.count || xiaowei.devices.length,
      matched: xiaoweiMatched,
    },
    scannedAt: now,
    devices,
  };
}

async function readXiaoweiSources() {
  const [db, api] = await Promise.all([
    xiaoweiIntegration.readDevices(),
    xiaoweiApi.listDevices(),
  ]);
  const devices = mergeXiaoweiSourceDevices(db.devices, api.devices);
  const bySerial = {};
  for (const device of devices) {
    bySerial[device.serial] = device;
    bySerial[serialKey(device.serial)] = device;
  }

  return {
    ok: Boolean(db.ok || api.ok),
    available: Boolean(db.available || api.available),
    dbAvailable: Boolean(db.available),
    apiAvailable: Boolean(api.available),
    apiReachable: Boolean(api.reachable),
    apiLocked: Boolean(api.locked),
    apiCode: api.code,
    apiMessage: api.message,
    apiTranslatedMessage: api.translatedMessage || api.warning || "",
    apiUrl: xiaoweiApi.url,
    dbPath: db.dbPath,
    dbWarning: db.warning,
    apiWarning: api.warning,
    warning: [db.warning, api.warning].filter(Boolean).join(" "),
    devices,
    dbDevices: db.devices || [],
    apiDevices: api.devices || [],
    bySerial,
    count: devices.length,
  };
}

async function runPreferredDeviceAction({ serial, action, payload = {} }) {
  let preferredAdbResult = null;
  if (action === "packages" && payload.includeLabels === true) {
    preferredAdbResult = await runAdbDeviceAction({ serial, action, payload });
    if (preferredAdbResult.ok) {
      return {
        ...preferredAdbResult,
        via: preferredAdbResult.result?.labelsAvailable ? "adb-package-manager" : "adb-package-list",
      };
    }
  }

  if (shouldTryXiaoweiAction(action)) {
    const xiaoweiResult = await xiaoweiApi.runDeviceAction(serial, action, payload.data);
    if (xiaoweiResult.ok) {
      return {
        ok: true,
        serial,
        action,
        via: "xiaowei-api",
        at: new Date().toISOString(),
        result: xiaoweiResult.data === null ? { message: xiaoweiResult.translatedMessage || "XiaoWei API returned no data." } : xiaoweiResult.data,
        xiaowei: xiaoweiResult,
      };
    }

    const adbResult = preferredAdbResult || await runAdbDeviceAction({ serial, action, payload });
    return {
      ...adbResult,
      via: adbResult.ok ? "adb-fallback" : "xiaowei-api",
      xiaowei: xiaoweiResult,
      xiaoweiMessage: xiaoweiResult.translatedMessage || xiaoweiResult.message,
    };
  }

  return runAdbDeviceAction({ serial, action, payload });
}

async function runAdbDeviceAction({ serial, action, payload = {} }) {
  const config = readFleetMonitorConfig();
  const adbPath = payload.adbPath || config.adbPath || resolveAdbPath();
  if (
    (action === "input_text" && payload.apnEditorOnly === true)
    || (action === "open_apn_settings" && payload.apnManualOnly === true)
  ) {
    return runSinglePortManualApnAction({
      serial,
      action,
      payload,
      adbPath,
    });
  }
  const ports = uniqueAdbPorts([
    payload.adbPort,
    payload.port,
    XIAOWEI_ADB_PORT,
  ]);

  return runAdbActionAcrossPorts({
    payload,
    serial,
    action,
    adbPath,
    ports,
  });
}

async function runSinglePortManualApnAction({ serial, action, payload, adbPath }) {
  const ports = await resolveActiveAdbPorts();
  const target = await resolveSingleAdbPort({
    serial,
    ports,
    scanPort: (adbPort) => scanAdbDevices({ adbPath, adbPort }),
  });
  if (!target.ok) {
    return {
      ...target,
      serial,
      action,
      adbPath,
    };
  }

  const expectedAdbPort = Number(payload.adbPort || 0);
  if (
    Number.isInteger(expectedAdbPort)
    && expectedAdbPort > 0
    && expectedAdbPort !== target.adbPort
  ) {
    return {
      ok: false,
      serial,
      action,
      adbPath,
      adbPort: target.adbPort,
      status: 409,
      code: "ADB_TARGET_PORT_CHANGED",
      error: "SIM判定後にADBポートが変わったため、APN操作を開始しませんでした。",
      mutationStarted: false,
    };
  }

  const result = await runSinglePortAdbMutation({
    target,
    runAction: (adbPort) => runSafeAdbAction({
      ...payload,
      adbPath,
      adbPort,
      serial,
      action,
      rootDir: paths.root,
      screenshotsDir: paths.screenshotsDir,
    }),
  });
  result.adbPath = adbPath;
  return result;
}

async function readValidatedLiveApnTarget({
  adbPath,
  target,
  serial,
  subscriptionId,
  profileId,
}) {
  let liveSimInfo;
  try {
    liveSimInfo = await readAdbSimInfo(adbPath, {
      serial,
      adbPort: target.adbPort,
    });
  } catch {
    return {
      ok: false,
      status: 409,
      code: "APN_SIM_INFO_UNAVAILABLE",
      error: "SIM情報を再確認できないため、APN設定を開始しませんでした。",
      mutationStarted: false,
      adbPort: target.adbPort,
    };
  }
  return {
    ...validateLiveApnTarget({
      subscriptions: liveSimInfo.subscriptions,
      warning: liveSimInfo.warning,
      simStatusCode: liveSimInfo.simStatusCode,
      requestedSubscriptionId: subscriptionId,
      profileId,
    }),
    adbPort: target.adbPort,
  };
}

async function prepareAdbApnDraft(body = {}) {
  const serial = String(body.serial || "").trim();
  const profileId = String(body.profileId || "").trim().toLowerCase();
  const hasSubscriptionId = body.subscriptionId !== undefined
    && body.subscriptionId !== null;
  const subscriptionId = hasSubscriptionId ? body.subscriptionId : null;
  if (!serial || /\s/.test(serial)) {
    return {
      ok: false,
      status: 400,
      code: "APN_TARGET_INVALID",
      error: "APN設定の対象端末を1台選んでください。",
    };
  }
  if (body.saveAfterFill === true && body.requireFreshEditor !== true) {
    return {
      ok: false,
      status: 400,
      code: "APN_SAVE_REQUIRES_FRESH_EDITOR",
      error: "APN保存は新規追加画面を開いた場合だけ実行できます。",
    };
  }
  if (!/^[a-z0-9][a-z0-9-]{0,63}$/.test(profileId)) {
    return {
      ok: false,
      status: 400,
      code: "APN_PROFILE_INVALID",
      error: "APNプロファイルを確認してください。",
    };
  }
  if (
    Object.prototype.hasOwnProperty.call(body, "dryRun")
    && typeof body.dryRun !== "boolean"
  ) {
    return {
      ok: false,
      status: 400,
      code: "APN_DRY_RUN_INVALID",
      error: "APN事前確認の指定を確認してください。",
      mutationStarted: false,
    };
  }
  if (
    !hasSubscriptionId
    || typeof subscriptionId !== "number"
    || !Number.isSafeInteger(subscriptionId)
    || subscriptionId < 0
  ) {
    return {
      ok: false,
      status: 400,
      code: "APN_SUBSCRIPTION_INVALID",
      error: "APN設定対象のSIM情報を確認してください。",
      mutationStarted: false,
    };
  }
  const lock = apnDraftTargetLock.tryAcquire([{ serial }]);
  if (!lock.ok) {
    return {
      ok: false,
      status: 409,
      code: "APN_DRAFT_ALREADY_RUNNING",
      error: "この端末では別の操作が実行中です。完了後に再試行してください。",
    };
  }
  try {
    let normalizedApn;
    try {
      normalizedApn = normalizeApnFormPayload({
        profileId,
        fields: body.fields,
      });
    } catch (error) {
      return {
        ok: false,
        status: Number(error?.status || 400),
        code: error?.code || "APN_FIELDS_INVALID",
        error: "APN設定内容を確認してください。",
      };
    }
    const canonicalFields = validateRequestedApnFields(profileId, normalizedApn.fields);
    if (!canonicalFields.ok) return canonicalFields;
    normalizedApn.fields = canonicalFields.fields;
    let profileRevision;
    try {
      profileRevision = profileRevisionForApnFields(normalizedApn.fields);
    } catch (error) {
      return apnSaveGuardFailure(error);
    }
    const payload = {
      profileId,
      fields: body.saveAfterFill === true
        ? buildGuardedApnSaveFields(normalizedApn.fields, serial, profileId, profileRevision)
        : normalizedApn.fields,
      requireFreshEditor: body.requireFreshEditor === true,
      saveAfterFill: body.saveAfterFill === true,
      subscriptionId,
      timeout: Math.max(30000, Math.min(180000, Number(body.timeout || 120000))),
    };
    const config = readFleetMonitorConfig();
    const adbPath = body.adbPath || config.adbPath || resolveAdbPath();
    const ports = await resolveActiveAdbPorts();
    const target = await resolveSingleAdbPort({
      serial,
      ports,
      scanPort: (adbPort) => scanAdbDevices({ adbPath, adbPort }),
    });
    if (!target.ok) return target;

    const expectedAdbPort = Number(body.adbPort || 0);
    if (
      Number.isInteger(expectedAdbPort)
      && expectedAdbPort > 0
      && expectedAdbPort !== target.adbPort
    ) {
      return {
        ok: false,
        status: 409,
        code: "ADB_TARGET_PORT_CHANGED",
        error: "SIM判定後にADBポートが変わったため、APN設定を開始しませんでした。",
        mutationStarted: false,
        adbPort: target.adbPort,
      };
    }

    const liveTarget = await readValidatedLiveApnTarget({
      adbPath,
      target,
      serial,
      subscriptionId,
      profileId,
    });
    if (!liveTarget.ok) {
      return liveTarget;
    }
    payload.subscriptionId = liveTarget.subscriptionId;

    if (body.dryRun === true) {
      return {
        ok: true,
        serial,
        action: "prepare_apn_form",
        via: "apn-plan",
        at: new Date().toISOString(),
        mutationStarted: false,
        adbPort: target.adbPort,
        result: {
          prepared: false,
          planned: true,
          profileId,
          profileRevision,
          subscriptionId: liveTarget.subscriptionId,
          stage: "plan-only",
          attemptedFields: [],
          verifiedFields: [],
          fieldKeys: Object.keys(payload.fields),
          saveRequired: body.saveAfterFill === true,
          saveAttempted: false,
          saveVerified: false,
          saved: false,
          saveState: "not-saved",
          reason: "dry-run",
        },
      };
    }

    if (body.saveAfterFill !== true) {
      const finalTarget = await readValidatedLiveApnTarget({
        adbPath,
        target,
        serial,
        subscriptionId: payload.subscriptionId,
        profileId,
      });
      if (!finalTarget.ok) return finalTarget;
      payload.subscriptionId = finalTarget.subscriptionId;
      const actionResult = await runSinglePortAdbMutation({
        target,
        runAction: (adbPort) => runGuardedApnAction({
          ...payload,
          adbPath,
          adbPort,
          serial,
          action: "prepare_apn_form",
          rootDir: paths.root,
          screenshotsDir: paths.screenshotsDir,
        }),
      });
      actionResult.adbPath = adbPath;
      return actionResult;
    }

    const resetScopeResult = await readAdbApnResetScope(adbPath, target, serial);
    if (!resetScopeResult.ok) return resetScopeResult;

    let guardStart;
    try {
      guardStart = apnSaveGuard.begin(serial, profileId, {
        resetScope: resetScopeResult.resetScope,
        profileRevision,
      });
    } catch (error) {
      return apnSaveGuardFailure(error);
    }
    if (!guardStart.ok) {
      if (guardStart.code === "APN_SAVE_ALREADY_VERIFIED") {
        return {
          ok: true,
          serial,
          action: "prepare_apn_form",
          via: "apn-save-guard",
          at: new Date().toISOString(),
          idempotent: true,
          mutationStarted: false,
          adbPort: target.adbPort,
          guard: publicApnSaveGuardEntry(guardStart.entry),
          result: {
            prepared: true,
            profileId,
            stage: "already-saved",
            attemptedFields: [],
            verifiedFields: [],
            needsReview: false,
            saveRequired: false,
            saveAttempted: false,
            saveVerified: true,
            saved: true,
            saveState: "verified",
            saveMethod: "persistent-guard",
            saveVerifiedBy: "persistent-guard",
            reason: "apn-save-already-verified",
          },
        };
      }
      return {
        ok: false,
        status: 409,
        code: "APN_SAVE_STATE_UNKNOWN",
        error: "前回のAPN保存結果が未確認です。端末のAPN一覧を確認してから隔離を解除してください。",
        mutationStarted: false,
        guard: privateApnSaveGuardEntry(guardStart.entry),
      };
    }

    const operationId = guardStart.operationId;
    const finalTarget = await readValidatedLiveApnTarget({
      adbPath,
      target,
      serial,
      subscriptionId: payload.subscriptionId,
      profileId,
    });
    if (!finalTarget.ok) {
      try {
        const cleared = apnSaveGuard.finish(
          serial,
          profileId,
          operationId,
          { definitelyNotSaved: true },
        );
        if (!cleared.ok || cleared.cleared !== true) {
          throw Object.assign(new Error("APN save guard could not be cleared before mutation."), {
            code: "APN_SAVE_GUARD_FAILED",
            status: 500,
          });
        }
      } catch (error) {
        return apnSaveGuardFailure(error, {
          mutationStarted: false,
          adbPort: target.adbPort,
          guardEntry: guardStart.entry,
        });
      }
      return finalTarget;
    }
    payload.subscriptionId = finalTarget.subscriptionId;
    const actionResult = await runSinglePortAdbMutation({
      target,
      runAction: (adbPort) => runGuardedApnAction({
        ...payload,
        adbPath,
        adbPort,
        serial,
        action: "prepare_apn_form",
        rootDir: paths.root,
        screenshotsDir: paths.screenshotsDir,
      }),
    });
    actionResult.adbPath = adbPath;
    const draft = actionResult.result || {};
    const verified = actionResult.ok === true
      && draft.saved === true
      && draft.saveVerified === true
      && draft.saveState === "verified";
    const definitelyNotSaved = actionResult.ok === true
      && draft.saveAttempted !== true
      && draft.saveState === "not-saved";
    let unknownGuardEntry = null;
    try {
      if (verified || definitelyNotSaved) {
        apnSaveGuard.finish(serial, profileId, operationId, {
          verified,
          definitelyNotSaved,
        });
      } else {
        const marked = apnSaveGuard.markUnknown(
          serial,
          profileId,
          operationId,
          draft.reason || actionResult.code || "save-result-unknown",
        );
        if (!marked.ok || !marked.entry) {
          return apnSaveGuardFailure(
            Object.assign(new Error("APN save guard state could not be updated."), {
              code: marked.code || "APN_SAVE_GUARD_FAILED",
              status: 500,
            }),
            {
              mutationStarted: true,
              adbPort: target.adbPort,
              guardEntry: guardStart.entry,
            },
          );
        }
        unknownGuardEntry = marked.entry;
      }
    } catch (error) {
      return apnSaveGuardFailure(error, {
        mutationStarted: true,
        adbPort: target.adbPort,
        guardEntry: guardStart.entry,
      });
    }

    if (unknownGuardEntry) {
      return {
        ...actionResult,
        ok: false,
        status: actionResult.ok ? 409 : actionResult.status || 502,
        code: "APN_SAVE_STATE_UNKNOWN",
        causeCode: actionResult.code || "",
        error: "APN保存処理の結果を確認できません。端末確認まで再実行しないでください。",
        guard: privateApnSaveGuardEntry(unknownGuardEntry),
        result: {
          ...draft,
          saveState: "unknown",
        },
      };
    }
    return actionResult;
  } finally {
    lock.release();
  }
}

async function readAdbApnResetScope(adbPath, target, serial) {
  const result = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial,
    adbArgs: ["shell", "settings", "get", "secure", "android_id"],
    timeoutMs: 8000,
  });
  if (!result.ok) {
    return {
      ok: false,
      status: 503,
      code: "APN_RESET_SCOPE_UNAVAILABLE",
      error: "端末のリセット世代を確認できないため、APN保存を開始しませんでした。",
      mutationStarted: false,
      adbPort: target.adbPort,
    };
  }
  try {
    return {
      ok: true,
      resetScope: resetScopeForAndroidId(result.stdout),
    };
  } catch {
    return {
      ok: false,
      status: 503,
      code: "APN_RESET_SCOPE_UNAVAILABLE",
      error: "端末のリセット世代を厳格に確認できないため、APN保存を開始しませんでした。",
      mutationStarted: false,
      adbPort: target.adbPort,
    };
  }
}

function buildGuardedApnSaveFields(fields, serial, profileId, profileRevision) {
  const source = fields && typeof fields === "object" && !Array.isArray(fields)
    ? { ...fields }
    : {};
  const baseName = String(source.name || "").trim();
  if (!baseName) return source;
  const marker = crypto
    .createHash("sha256")
    .update([
      String(serial).trim().toLowerCase(),
      String(profileId).trim().toLowerCase(),
      String(profileRevision).trim().toLowerCase(),
    ].join("\0"))
    .digest("hex")
    .slice(0, 8)
    .toUpperCase();
  const suffix = ` [AF-${marker}]`;
  source.name = `${baseName.slice(0, Math.max(0, 80 - suffix.length))}${suffix}`;
  return source;
}

function publicApnSaveGuardEntry(entry = {}) {
  return {
    serial: cleanText(entry.serial, 80),
    profileId: cleanText(entry.profileId, 64),
    state: cleanText(entry.state, 24),
    recordedAt: cleanText(entry.recordedAt, 40),
    updatedAt: cleanText(entry.updatedAt, 40),
  };
}

function privateApnSaveGuardEntry(entry = {}) {
  return {
    ...publicApnSaveGuardEntry(entry),
    releaseToken: cleanText(entry.operationId, 160),
  };
}

function apnSaveGuardFailure(error, extra = {}) {
  const mutationStarted = extra.mutationStarted === true;
  return {
    ok: false,
    status: Number(error?.status || 500),
    code: error?.code || "APN_SAVE_GUARD_FAILED",
    error: mutationStarted
      ? "APN保存後の結果と重複防止記録を確認できません。端末確認まで再実行しないでください。"
      : "APN保存の重複防止記録を確認できないため、保存を開始しませんでした。",
    mutationStarted,
    ...(extra.adbPort ? { adbPort: extra.adbPort } : {}),
    ...(extra.guardEntry ? { guard: privateApnSaveGuardEntry(extra.guardEntry) } : {}),
  };
}

function releaseAdbApnSaveGuard(body = {}) {
  const serial = String(body.serial || "").trim();
  const profileId = String(body.profileId || "").trim().toLowerCase();
  const releaseToken = String(body.releaseToken || "").trim();
  if (!serial || /\s/.test(serial) || !/^[a-z0-9][a-z0-9-]{0,63}$/.test(profileId)) {
    return {
      ok: false,
      status: 400,
      code: "APN_SAVE_GUARD_TARGET_INVALID",
      error: "隔離解除の対象端末またはAPNプロファイルを確認してください。",
    };
  }
  if (!releaseToken || releaseToken.length > 160 || /[\u0000-\u001f\u007f]/.test(releaseToken)) {
    return {
      ok: false,
      status: 400,
      code: "APN_SAVE_GUARD_RELEASE_TOKEN_REQUIRED",
      error: "現在の保存試行に対応する隔離解除情報が必要です。",
    };
  }
  if (body.acknowledgeDeviceChecked !== true) {
    return {
      ok: false,
      status: 400,
      code: "APN_SAVE_GUARD_ACK_REQUIRED",
      error: "端末のAPN一覧を確認したことへの同意が必要です。",
    };
  }
  const lock = apnDraftTargetLock.tryAcquire([{ serial }]);
  if (!lock.ok) {
    return {
      ok: false,
      status: 409,
      code: "APN_DRAFT_ALREADY_RUNNING",
      error: "この端末ではAPN操作中のため、隔離を解除できません。",
    };
  }
  try {
    const result = apnSaveGuard.release(serial, profileId, releaseToken);
    if (!result.ok && result.code === "APN_SAVE_VERIFIED_RELEASE_FORBIDDEN") {
      return {
        ok: false,
        status: 409,
        code: result.code,
        error: "保存確認済みAPNの記録は解除できません。同じ端末とAPNへの再保存は不要です。",
        released: false,
        serial,
        profileId,
        previousState: cleanText(result.entry?.state, 24),
      };
    }
    if (!result.ok) {
      return {
        ok: false,
        status: 409,
        code: result.code || "APN_SAVE_GUARD_RELEASE_REJECTED",
        error: result.code === "APN_SAVE_GUARD_RELEASE_TOKEN_MISMATCH"
          ? "隔離状態が更新されています。古い画面からは解除できません。"
          : "現在の隔離記録を確認できないため解除しませんでした。",
        released: false,
        serial,
        profileId,
        previousState: cleanText(result.entry?.state, 24),
      };
    }
    return {
      ok: true,
      released: result.released === true,
      serial,
      profileId,
      previousState: cleanText(result.entry?.state, 24),
    };
  } catch (error) {
    return apnSaveGuardFailure(error);
  } finally {
    lock.release();
  }
}

async function setAutoRotateOffForConnectedDevices() {
  return runAdbActionForConnectedDevices("auto_rotate_off", { skipActiveGroup: true });
}

async function setEarthquakeAlertsOffForConnectedDevices() {
  return runAdbActionForConnectedDevices("earthquake_alerts_off", { skipActiveGroup: true });
}

async function setDataSaverForConnectedDevices() {
  return runAdbActionForConnectedDevices("data_saver_on", { skipActiveGroup: true });
}

async function setNfcOffForConnectedDevices() {
  return runAdbActionForConnectedDevices("nfc_off", { skipActiveGroup: true });
}

async function setSoundOffForConnectedDevices() {
  return runAdbActionForConnectedDevices("sound_off", { skipActiveGroup: true });
}

async function optimizeXiaomiMiuiForConnectedDevices() {
  return runAdbActionForConnectedDevices("xiaomi_miui_optimize", {
    skipActiveGroup: false,
    filterXiaomiLike: true,
    concurrency: 1,
    timeout: 60000,
  });
}

async function applyBaselineDeviceSettingsForConnectedDevices() {
  const steps = [];
  let ok = true;
  for (const setting of BASELINE_DEVICE_SETTINGS) {
    const result = await runAdbActionForConnectedDevices(setting.action, {
      skipActiveGroup: false,
      skipCompletedDeviceSetting: setting.alwaysReapply ? "" : setting.key,
      persistDeviceSettingKey: setting.key,
      settingLabel: setting.label,
      concurrency: 2,
    });
    if (!result.ok || result.failed) ok = false;
    steps.push({
      key: setting.key,
      label: setting.label,
      action: setting.action,
      ok: result.ok,
      connected: result.connected || 0,
      targeted: result.targeted || 0,
      succeeded: result.succeeded || 0,
      failed: result.failed || 0,
      skippedActive: result.skippedActive || 0,
      skippedAlreadyApplied: result.skippedAlreadyApplied || 0,
      warning: result.warning || "",
    });
  }
  const total = steps.reduce((acc, step) => ({
    connected: Math.max(acc.connected, step.connected),
    targeted: acc.targeted + step.targeted,
    succeeded: acc.succeeded + step.succeeded,
    failed: acc.failed + step.failed,
    skippedActive: acc.skippedActive + step.skippedActive,
    skippedAlreadyApplied: acc.skippedAlreadyApplied + step.skippedAlreadyApplied,
  }), { connected: 0, targeted: 0, succeeded: 0, failed: 0, skippedActive: 0, skippedAlreadyApplied: 0 });

  return {
    ok,
    actions: steps.length,
    connected: total.connected,
    targeted: total.targeted,
    succeeded: total.succeeded,
    failed: total.failed,
    skippedActive: total.skippedActive,
    skippedAlreadyApplied: total.skippedAlreadyApplied,
    warning: steps.map((step) => step.warning).filter(Boolean).join("; "),
    steps,
  };
}

async function refreshBaselineDeviceSettingsForConnectedDevices() {
  const result = await runAdbActionForConnectedDevices("read_baseline_settings", {
    skipActiveGroup: false,
    concurrency: 4,
  });
  const update = persistBaselineSettingsRefreshResults(result.results || []);
  const compactResults = (result.results || []).map((item) => ({
    serial: item.serial,
    model: item.model,
    ok: item.ok,
    code: item.code,
    message: item.message,
    states: item.rawResult && item.rawResult.states ? item.rawResult.states : null,
  }));
  return {
    ...result,
    results: compactResults,
    updated: update.changed,
  };
}

async function setLegacyMirrorPermissionsForConnectedDevices() {
  return runAdbActionForConnectedDevices("device_helper_permissions", { skipActiveGroup: true });
}

async function installTtlLineApksForConnectedDevices() {
  const result = await runAdbActionForConnectedDevices("install_ttl_line_apks", { skipActiveGroup: false });
  persistTtlLineInstallResults(result.results || []);
  return result;
}

async function installTtlLineApksForTargets(body = {}) {
  const requestedTargets = Array.isArray(body.targets) ? body.targets : [];
  if (!requestedTargets.length) {
    return { ok: false, error: "No APK install targets selected.", targeted: 0, succeeded: 0, failed: 0, results: [] };
  }
  const result = await runAdbActionForConnectedDevices("install_ttl_line_apks", {
    skipActiveGroup: false,
    targets: requestedTargets,
    concurrency: clampInteger(body.concurrency || 3, 1, 5),
  });
  persistTtlLineInstallResults(result.results || []);
  return result;
}

function persistTtlLineInstallResults(results = []) {
  const packageKeys = {
    ttl: {
      installed: "ttlInstalled",
      checkedAt: "ttlCheckedAt",
      packageName: "ttlPackageName",
      installStatus: "ttlInstallStatus",
      lastError: "ttlInstallLastError",
    },
    line: {
      installed: "lineInstalled",
      checkedAt: "lineCheckedAt",
      packageName: "linePackageName",
      installStatus: "lineInstallStatus",
      lastError: "lineInstallLastError",
    },
  };
  const rows = (results || []).filter((row) => row && row.serial && Array.isArray(row.packages));
  if (!rows.length) return;
  const { dbPath, db } = readFleetDbForWrite();
  const now = new Date().toISOString();
  for (const row of rows) {
    const device = db.physicalDevices[row.serial] || { serial: row.serial };
    for (const pkg of row.packages || []) {
      const fields = packageKeys[pkg.key];
      if (!fields) continue;
      const installed = Boolean(pkg.ok || pkg.skipped || pkg.installed);
      device[fields.installed] = installed;
      device[fields.checkedAt] = now;
      device[fields.packageName] = cleanText(pkg.packageName || "", 120);
      device[fields.installStatus] = installed ? (pkg.skipped ? "installed" : "installed") : "error";
      device[fields.lastError] = installed ? "" : cleanText(pkg.message || pkg.code || pkg.stdout || pkg.stderr || "install failed", 240);
    }
    device.updatedAt = now;
    db.physicalDevices[row.serial] = device;
  }
  db.updatedAt = now;
  writeJsonFile(dbPath, db);
}

async function refreshSwipeAgentInstallStatusForConnectedDevices() {
  return updateSwipeAgentInstallStatus({ installMissing: false });
}

async function installSwipeAgentForConnectedDevices() {
  return updateSwipeAgentInstallStatus({ installMissing: true });
}

async function updateSwipeAgentInstallStatus(options = {}) {
  const installMissing = Boolean(options.installMissing);
  const config = readFleetMonitorConfig();
  const adbPath = config.adbPath || resolveAdbPath();
  if (!adbPath || !fs.existsSync(adbPath)) return { ok: false, error: "ADB was not found.", adbPath };
  if (installMissing && (!fs.existsSync(SWIPE_AGENT_APK_PATH) || !fs.statSync(SWIPE_AGENT_APK_PATH).isFile())) {
    return { ok: false, error: "Swipe Agent APK was not found. Build android-swipe-agent first.", apkPath: SWIPE_AGENT_APK_PATH };
  }

  const adbDevices = await listAdbDevicesForUi();
  const connected = (adbDevices.devices || []).filter((device) => device && device.serial && device.connected);
  const results = [];
  for (const device of connected) {
    const target = {
      serial: device.serial,
      adbPort: device.adbPort || null,
      label: cleanText(`${device.laixiNumber ? device.laixiNumber + " " : ""}${device.label || device.serial}`, 120),
    };
    const before = await readSwipeAgentPackageState(adbPath, target);
    if (before.installed) {
      const accessibility = await ensureSwipeAgentAccessibilityEnabled(adbPath, target);
      const after = await readSwipeAgentPackageState(adbPath, target);
      results.push({ ...target, ok: accessibility.ok && after.installed, installed: true, skipped: true, action: "skip", before, after, accessibility, error: accessibility.ok ? "" : accessibility.error || accessibility.stderr || accessibility.stdout || "accessibility enable failed" });
      continue;
    }
    if (!installMissing) {
      results.push({ ...target, ok: true, installed: false, skipped: false, action: "checked", before, after: before });
      continue;
    }
    const install = await runAdbCommand({
      adbPath,
      adbPort: target.adbPort,
      serial: target.serial,
      adbArgs: ["install", "-r", "-g", "--user", "0", SWIPE_AGENT_APK_PATH],
      timeoutMs: 120000,
    });
    const after = await readSwipeAgentPackageState(adbPath, target);
    const accessibility = after.installed ? await ensureSwipeAgentAccessibilityEnabled(adbPath, target) : null;
    const finalState = after.installed ? await readSwipeAgentPackageState(adbPath, target) : after;
    results.push({
      ...target,
      ok: install.ok && finalState.installed && (!accessibility || accessibility.ok),
      installed: finalState.installed,
      skipped: false,
      action: "install",
      before,
      after: finalState,
      accessibility,
      stdout: install.stdout,
      stderr: install.stderr,
      error: install.ok ? (accessibility && !accessibility.ok ? accessibility.error || accessibility.stderr || accessibility.stdout || "accessibility enable failed" : "") : install.error || install.stderr || install.stdout || "install failed",
    });
  }

  persistSwipeAgentInstallResults(results);
  const failed = results.filter((row) => !row.ok).length;
  return {
    ok: adbDevices.ok && failed === 0,
    adbPath,
    apkPath: SWIPE_AGENT_APK_PATH,
    connected: connected.length,
    installed: results.filter((row) => row.installed && !row.skipped && row.action === "install").length,
    skipped: results.filter((row) => row.skipped).length,
    missing: results.filter((row) => !row.installed && row.ok).length,
    failed,
    results,
  };
}

async function readSwipeAgentPackageState(adbPath, target) {
  const pathResult = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "pm", "path", SWIPE_AGENT_PACKAGE_NAME],
    timeoutMs: 10000,
  });
  const installed = pathResult.ok && /package:/i.test(`${pathResult.stdout}\n${pathResult.stderr}`);
  let versionName = "";
  let versionCode = "";
  let accessibilityEnabled = false;
  if (installed) {
    const dump = await runAdbCommand({
      adbPath,
      adbPort: target.adbPort,
      serial: target.serial,
      adbArgs: ["shell", `dumpsys package ${SWIPE_AGENT_PACKAGE_NAME} | grep -E 'versionName|versionCode' || true`],
      timeoutMs: 10000,
    });
    const text = `${dump.stdout}\n${dump.stderr}`;
    versionName = (text.match(/versionName=([^\s]+)/) || [])[1] || "";
    versionCode = (text.match(/versionCode=(\d+)/) || [])[1] || "";
    accessibilityEnabled = await isSwipeAgentAccessibilityEnabled(adbPath, target);
  }
  return {
    installed,
    packageName: SWIPE_AGENT_PACKAGE_NAME,
    versionName,
    versionCode,
    accessibilityEnabled,
    checkedAt: new Date().toISOString(),
    error: installed ? "" : pathResult.error || pathResult.stderr || pathResult.stdout || "",
  };
}

async function isSwipeAgentAccessibilityEnabled(adbPath, target) {
  const result = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "settings", "get", "secure", "enabled_accessibility_services"],
    timeoutMs: 8000,
  });
  const text = `${result.stdout || ""}\n${result.stderr || ""}`;
  return result.ok && text.toLowerCase().split(":").map((part) => part.trim()).includes(SWIPE_AGENT_ACCESSIBILITY_SERVICE.toLowerCase());
}

async function ensureSwipeAgentAccessibilityEnabled(adbPath, target) {
  const enableService = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", `cmd accessibility enable-service ${shellWord(SWIPE_AGENT_ACCESSIBILITY_SERVICE)}`],
    timeoutMs: 10000,
  });
  const afterEnableService = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "settings", "get", "secure", "enabled_accessibility_services"],
    timeoutMs: 8000,
  });
  const afterEnableText = `${afterEnableService.stdout || ""}\n${afterEnableService.stderr || ""}`.toLowerCase();
  const lower = SWIPE_AGENT_ACCESSIBILITY_SERVICE.toLowerCase();
  if (afterEnableService.ok && afterEnableText.split(":").map((part) => part.trim()).includes(lower)) {
    return {
      ...afterEnableService,
      ok: true,
      stdout: [enableService.stdout, afterEnableService.stdout].filter(Boolean).join("\n"),
      stderr: [enableService.stderr, afterEnableService.stderr].filter(Boolean).join("\n"),
      method: "cmd accessibility enable-service",
    };
  }

  const currentResult = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "settings", "get", "secure", "enabled_accessibility_services"],
    timeoutMs: 8000,
  });
  if (!currentResult.ok) return currentResult;
  const currentText = String(currentResult.stdout || "").trim();
  const parts = currentText && currentText !== "null"
    ? currentText.split(":").map((part) => part.trim()).filter(Boolean)
    : [];
  if (!parts.some((part) => part.toLowerCase() === lower)) {
    parts.push(SWIPE_AGENT_ACCESSIBILITY_SERVICE);
  }
  const next = parts.join(":");
  const putServices = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "settings", "put", "secure", "enabled_accessibility_services", next],
    timeoutMs: 10000,
  });
  const putEnabled = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "settings", "put", "secure", "accessibility_enabled", "1"],
    timeoutMs: 10000,
  });
  const verify = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "settings", "get", "secure", "enabled_accessibility_services"],
    timeoutMs: 8000,
  });
  const text = `${verify.stdout || ""}\n${verify.stderr || ""}`.toLowerCase();
  return {
    ...verify,
    ok: verify.ok && text.split(":").map((part) => part.trim()).includes(lower),
    stdout: [currentResult.stdout, putServices.stdout, putEnabled.stdout, verify.stdout].filter(Boolean).join("\n"),
    stderr: [currentResult.stderr, putServices.stderr, putEnabled.stderr, verify.stderr].filter(Boolean).join("\n"),
    error: putServices.ok && putEnabled.ok ? verify.error : putServices.error || putEnabled.error || verify.error,
  };
}

function persistSwipeAgentInstallResults(results = []) {
  const { dbPath, db } = readFleetDbForWrite();
  const now = new Date().toISOString();
  for (const result of results) {
    if (!result.serial) continue;
    const device = db.physicalDevices[result.serial] || { serial: result.serial };
    const state = result.after || result.before || {};
    device.swipeAgentInstalled = Boolean(state.installed);
    device.swipeAgentCheckedAt = state.checkedAt || now;
    device.swipeAgentPackageName = SWIPE_AGENT_PACKAGE_NAME;
    device.swipeAgentVersionName = cleanText(state.versionName || "", 40);
    device.swipeAgentVersionCode = cleanText(state.versionCode || "", 40);
    device.swipeAgentAccessibilityEnabled = state.accessibilityEnabled === true;
    device.swipeAgentInstallStatus = result.ok ? (state.installed ? "installed" : "missing") : "error";
    device.swipeAgentLastError = result.ok ? "" : cleanText(result.error || state.error || "", 200);
    device.updatedAt = now;
    db.physicalDevices[result.serial] = device;
  }
  writeJsonFile(dbPath, db);
}

async function restartTtlForTargets(body = {}) {
  const config = readFleetMonitorConfig();
  const adbPath = body.adbPath || config.adbPath || resolveAdbPath();
  if (!adbPath || !fs.existsSync(adbPath)) return { ok: false, error: "ADB was not found.", adbPath };
  const requestedTargets = Array.isArray(body.targets) ? body.targets : [];
  if (!requestedTargets.length) return { ok: false, error: "No TTL restart targets selected.", requested: 0, succeeded: 0, failed: 0, results: [] };
  const adbDevices = await listAdbDevicesForUi();
  const connected = (adbDevices.devices || []).filter((device) => device && device.serial && device.connected);
  const bySerial = new Map(connected.map((device) => [String(device.serial), device]));
  const rawTargets = requestedTargets;
  const seen = new Set();
  const targets = rawTargets
    .map((target) => {
      const serial = cleanText(target && target.serial, 80);
      if (!serial || seen.has(serial)) return null;
      seen.add(serial);
      const connectedDevice = bySerial.get(serial) || {};
      return {
        serial,
        adbPort: target.adbPort === undefined || target.adbPort === null || target.adbPort === "" ? (connectedDevice.adbPort || null) : Number(target.adbPort),
        label: cleanText(target.label || connectedDevice.label || connectedDevice.laixiNumber || serial, 120),
        connected: bySerial.has(serial),
      };
    })
    .filter(Boolean);
  const results = [];
  for (const target of targets) {
    if (!target.connected) {
      results.push({ ...target, ok: false, error: "ADB connected device not found." });
      continue;
    }
    const result = await restartTtlClient(adbPath, target);
    results.push({ ...target, ...result });
  }
  const succeeded = results.filter((row) => row.ok).length;
  const failed = results.length - succeeded;
  return {
    ok: results.length > 0 && failed === 0,
    requested: targets.length,
    succeeded,
    failed,
    results,
  };
}

async function closeTtlForTargets(body = {}) {
  const config = readFleetMonitorConfig();
  const adbPath = body.adbPath || config.adbPath || resolveAdbPath();
  if (!adbPath || !fs.existsSync(adbPath)) return { ok: false, error: "ADB was not found.", adbPath };
  const requestedTargets = Array.isArray(body.targets) ? body.targets : [];
  if (!requestedTargets.length) return { ok: false, error: "No TTL close targets selected.", requested: 0, succeeded: 0, failed: 0, results: [] };
  const adbDevices = await listAdbDevicesForUi();
  const connected = (adbDevices.devices || []).filter((device) => device && device.serial && device.connected);
  const bySerial = new Map(connected.map((device) => [String(device.serial), device]));
  const rawTargets = requestedTargets;
  const seen = new Set();
  const targets = rawTargets
    .map((target) => {
      const serial = cleanText(target && target.serial, 80);
      if (!serial || seen.has(serial)) return null;
      seen.add(serial);
      const connectedDevice = bySerial.get(serial) || {};
      return {
        serial,
        adbPort: target.adbPort === undefined || target.adbPort === null || target.adbPort === "" ? (connectedDevice.adbPort || null) : Number(target.adbPort),
        label: cleanText(target.label || connectedDevice.label || connectedDevice.laixiNumber || serial, 120),
        connected: bySerial.has(serial),
      };
    })
    .filter(Boolean);
  const results = [];
  for (const target of targets) {
    if (!target.connected) {
      results.push({ ...target, ok: false, error: "ADB connected device not found." });
      continue;
    }
    const result = await closeTtlClient(adbPath, target);
    results.push({ ...target, ...result });
  }
  const succeeded = results.filter((row) => row.ok).length;
  const failed = results.length - succeeded;
  return {
    ok: results.length > 0 && failed === 0,
    requested: targets.length,
    succeeded,
    failed,
    results,
  };
}

async function launchAppForTargets(body = {}) {
  const packageMap = {
    ttl: TIKTOK_LITE_PACKAGE_NAMES[0],
    line: LINE_PACKAGE_NAME,
  };
  const appKey = cleanText(body.app || body.key || "", 20).toLowerCase();
  const packageName = packageMap[appKey] || cleanText(body.packageName || "", 120);
  if (!/^[A-Za-z0-9_.]+$/.test(packageName)) {
    return { ok: false, error: "Invalid app package.", packageName };
  }

  const config = readFleetMonitorConfig();
  const adbPath = body.adbPath || config.adbPath || resolveAdbPath();
  if (!adbPath || !fs.existsSync(adbPath)) return { ok: false, error: "ADB was not found.", adbPath };
  const requestedTargets = Array.isArray(body.targets) ? body.targets : [];
  if (!requestedTargets.length) return { ok: false, error: "No app launch targets selected.", packageName, requested: 0, succeeded: 0, failed: 0, results: [] };
  const adbDevices = await listAdbDevicesForUi();
  const connected = (adbDevices.devices || []).filter((device) => device && device.serial && device.connected);
  const bySerial = new Map(connected.map((device) => [String(device.serial), device]));
  const rawTargets = requestedTargets;
  const seen = new Set();
  const targets = rawTargets
    .map((target) => {
      const serial = cleanText(target && target.serial, 80);
      if (!serial || seen.has(serial)) return null;
      seen.add(serial);
      const connectedDevice = bySerial.get(serial) || {};
      return {
        serial,
        adbPort: target.adbPort === undefined || target.adbPort === null || target.adbPort === "" ? (connectedDevice.adbPort || null) : Number(target.adbPort),
        label: cleanText(target.label || connectedDevice.label || connectedDevice.laixiNumber || serial, 120),
        connected: bySerial.has(serial),
      };
    })
    .filter(Boolean);
  const results = new Array(targets.length);
  await runWithConcurrency(targets.map((target, index) => ({ target, index })), clampInteger(body.concurrency || 8, 1, 12), async ({ target, index }) => {
    if (!target.connected) {
      results[index] = { ...target, ok: false, error: "ADB connected device not found." };
      return;
    }
    const result = await launchAppOnTarget(adbPath, target, packageName);
    results[index] = { ...target, ...result };
  });
  const succeeded = results.filter((row) => row.ok).length;
  const failed = results.length - succeeded;
  return {
    ok: results.length > 0 && failed === 0,
    packageName,
    requested: targets.length,
    succeeded,
    failed,
    results,
  };
}

async function runSwipeRecoveryTestForTargets(body = {}) {
  const config = readFleetMonitorConfig();
  const adbPath = body.adbPath || config.adbPath || resolveAdbPath();
  if (!adbPath || !fs.existsSync(adbPath)) return { ok: false, error: "ADB was not found.", adbPath };
  const requestedTargets = Array.isArray(body.targets) ? body.targets : [];
  const adbDevices = await listAdbDevicesForUi();
  const connected = (adbDevices.devices || []).filter((device) => device && device.serial && device.connected);
  const bySerial = new Map(connected.map((device) => [String(device.serial), device]));
  const seen = new Set();
  const targets = requestedTargets
    .map((target) => {
      const serial = cleanText(target && target.serial, 80);
      if (!serial || seen.has(serial)) return null;
      seen.add(serial);
      const connectedDevice = bySerial.get(serial) || {};
      return {
        serial,
        adbPort: target.adbPort === undefined || target.adbPort === null || target.adbPort === "" ? (connectedDevice.adbPort || null) : Number(target.adbPort),
        label: cleanText(target.label || connectedDevice.label || connectedDevice.laixiNumber || serial, 120),
        laixiNumber: cleanText(target.laixiNumber || connectedDevice.laixiNumber, 20),
        minutes: roundSwipeAgentMinutes(target.minutes || body.minutes || 10),
        swipeMode: cleanText(target.swipeMode || target.mode || "", 20),
        connected: bySerial.has(serial),
      };
    })
    .filter(Boolean);
  if (!targets.length) return { ok: false, error: "No recovery test targets selected.", requested: 0, succeeded: 0, failed: 0, results: [] };

  const results = [];
  for (const target of targets) {
    if (!target.connected) {
      results.push({ ...target, ok: false, error: "ADB connected device not found." });
      continue;
    }
    try {
      results.push(await runSwipeRecoveryTestOnTarget(adbPath, target, { stopAgent: body.stopAgent !== false }));
    } catch (error) {
      results.push({ ...target, ok: false, error: error.message });
    }
  }
  const succeeded = results.filter((row) => row.ok).length;
  const failed = results.length - succeeded;
  return {
    ok: results.length > 0 && failed === 0,
    requested: targets.length,
    succeeded,
    failed,
    results,
  };
}

async function runSwipeRecoveryTestOnTarget(adbPath, target, options = {}) {
  const steps = [];
  const pushStep = (name, result = {}) => {
    steps.push({
      name,
      at: new Date().toISOString(),
      ok: result.ok !== false,
      error: result.error || result.stderr || "",
      stdout: cleanText(result.stdout || "", 200),
    });
  };

  const useAdbMode = String(target.swipeMode || "").toLowerCase() === "adb";

  if (!useAdbMode && options.stopAgent !== false) {
    const stopAgent = await sendSwipeAgentStop(adbPath, target);
    pushStep("Agent stop", stopAgent);
    await sleep(800);
  } else if (useAdbMode) {
    pushStep("Agent stop", { ok: true, stdout: "skipped for ADB mode" });
  } else {
    pushStep("Agent stop", { ok: true, stdout: "skipped for live recovery test" });
  }

  const stopTtl = await closeTtlClient(adbPath, target);
  pushStep("TTL force-stop", stopTtl);
  await sleep(5000);

  const launchTtl = await launchTtlOnTarget(adbPath, target);
  pushStep("TTL launch", launchTtl);
  await sleep(15000);

  const blockerResult = await clearRecoveryBlockers(adbPath, target, pushStep);
  const closeCandidate = blockerResult.lastCandidate;

  const recoveryJobId = `recovery-test-${localTimestampForId()}-${Math.random().toString(36).slice(2, 6)}`;
  let agentStatus = null;
  let startedJobId = recoveryJobId;
  if (useAdbMode) {
    const adbStart = await startAdbSwipeJob({
      adbPath,
      minutes: target.minutes,
      minIntervalSeconds: 10,
      maxIntervalSeconds: 15,
      targets: [{
        serial: target.serial,
        adbPort: target.adbPort || "",
        label: target.label || target.serial,
        laixiNumber: target.laixiNumber || "",
        minutes: target.minutes,
      }],
    });
    startedJobId = adbStart.job && adbStart.job.jobId || "";
    pushStep(`ADB start ${target.minutes}m`, { ok: adbStart.ok, stdout: `job=${startedJobId}${adbStart.merged ? " merged" : ""}`, error: adbStart.error || "" });
  } else {
    const accessibility = await ensureSwipeAgentAccessibilityEnabled(adbPath, target);
    pushStep("Agent accessibility", accessibility);
    const startAgent = await sendSwipeAgentStart(adbPath, target, target.minutes, recoveryJobId, { launchTtl: false });
    pushStep(`Agent start ${target.minutes}m`, startAgent);
    await sleep(3000);
    for (let i = 0; i < 3; i++) {
      const statusResult = await readSwipeAgentStatus(adbPath, target);
      if (statusResult.ok && statusResult.status) {
        agentStatus = normalizeSwipeAgentStatus(statusResult.status);
        const statusMatchesJob = !agentStatus.jobId || String(agentStatus.jobId) === String(recoveryJobId);
        const statusFresh = isSwipeAgentStatusFresh(agentStatus, 45);
        pushStep(`Agent status ${i + 1}`, {
          ok: Boolean(statusMatchesJob && statusFresh && (agentStatus.running || Number(agentStatus.swipeCount || 0) > 0)),
          stdout: `job=${agentStatus.jobId || ""} match=${statusMatchesJob} fresh=${statusFresh} state=${agentStatus.state || ""} running=${agentStatus.running === true} swipes=${agentStatus.swipeCount || 0} elapsed=${agentStatus.elapsedSeconds || 0}s message=${agentStatus.message || ""}`,
        });
        if (statusMatchesJob && statusFresh && (agentStatus.running || Number(agentStatus.swipeCount || 0) > 0)) break;
        if (i === 0) {
          const retryStart = await sendSwipeAgentStart(adbPath, target, target.minutes, recoveryJobId, { launchTtl: false });
          pushStep("Agent start retry", retryStart);
        }
      } else {
        pushStep(`Agent status ${i + 1}`, { ok: false, error: statusResult.error || statusResult.stderr || "status unavailable" });
      }
      await sleep(2000);
    }
  }
  const returnTtl = await launchTtlOnTarget(adbPath, target);
  pushStep("TTL return", returnTtl);
  if (!useAdbMode) {
    const registered = registerRecoverySwipeAgentJob(adbPath, target, recoveryJobId, agentStatus);
    pushStep("monitor register", { ok: registered.ok, stdout: registered.message || "" });
  }

  const ok = steps.every((step) => step.ok);
  return {
    ...target,
    ok,
    jobId: startedJobId,
    swipeMode: useAdbMode ? "adb" : "agent",
    screenshotUrl: blockerResult.lastScreenshotUrl || "",
    closeCandidate,
    closeCandidates: blockerResult.candidates,
    tappedClose: blockerResult.candidates.length > 0,
    agentStatus,
    steps,
    error: ok ? "" : (steps.find((step) => !step.ok)?.error || "Recovery test failed"),
  };
}

async function captureRecoveryScreenshot(adbPath, target) {
  fs.mkdirSync(paths.screenshotsDir, { recursive: true });
  const fileName = `recovery-${target.laixiNumber || "device"}-${target.serial}-${Date.now()}.png`.replace(/[^\w.-]+/g, "_");
  const filePath = path.join(paths.screenshotsDir, fileName);
  const result = await runAdbBufferCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["exec-out", "screencap", "-p"],
    timeoutMs: 15000,
  });
  if (!result.ok) return { ...result, fileName, filePath, screenshotUrl: "" };
  fs.writeFileSync(filePath, result.stdoutBuffer);
  return { ok: true, fileName, filePath, screenshotUrl: `/screenshots/${encodeURIComponent(fileName)}` };
}

async function clearRecoveryBlockers(adbPath, target, pushStep) {
  const candidates = [];
  let lastCandidate = null;
  let lastScreenshotUrl = "";
  for (let round = 1; round <= 2; round++) {
    const screenshot = await captureRecoveryScreenshot(adbPath, target);
    lastScreenshotUrl = screenshot.screenshotUrl || lastScreenshotUrl;
    pushStep(`screenshot ${round}`, screenshot);
    if (!screenshot.ok || !screenshot.filePath) break;

    let candidate = detectCloseButtonCandidate(screenshot.filePath);
    if (candidate) {
      candidate.type = "x";
      candidate.round = round;
      candidate.text = "x";
    } else {
      candidate = await findTextTapCandidate(adbPath, target, ["\u8a31\u53ef\u3057\u306a\u3044"]);
      if (candidate) {
        candidate.type = "text";
        candidate.round = round;
      }
    }

    if (!candidate) {
      pushStep(`blocker ${round}`, { ok: true, stdout: "x/text not found; tap skipped" });
      break;
    }

    const tap = await runAdbCommand({
      adbPath,
      adbPort: target.adbPort,
      serial: target.serial,
      adbArgs: ["shell", "input", "tap", String(candidate.x), String(candidate.y)],
      timeoutMs: 8000,
    });
    candidates.push(candidate);
    lastCandidate = candidate;
    pushStep(`${candidate.type === "x" ? "x" : "text"} candidate tap ${candidate.text || ""} ${candidate.x},${candidate.y}`, tap);
    await sleep(1500);
  }
  return { candidates, lastCandidate, lastScreenshotUrl };
}

function formatRecoveryStepForLog(name, result = {}) {
  const ok = result.ok === false ? "NG" : "OK";
  const detail = result.error || result.stderr || result.stdout || "";
  return `${name} ${ok}${detail ? ` ${String(detail).slice(0, 140)}` : ""}`;
}

function registerRecoverySwipeAgentJob(adbPath, target, jobId, status = null) {
  const activeStates = activeSwipeTargetStates();
  const existing = [...swipeAgentJobs.values()].find((job) =>
    job && ["running", "stopping"].includes(job.status || "") &&
    (job.devices || []).some((device) => String(device.serial || "") === String(target.serial || "") && activeStates.has(device.state || ""))
  );
  if (existing) {
    return { ok: true, skipped: true, jobId: existing.jobId, message: `already monitored by ${existing.jobId}` };
  }
  const minutes = roundSwipeAgentMinutes(target.minutes || 10);
  const now = new Date();
  const device = {
    serial: target.serial,
    adbPort: target.adbPort || null,
    label: target.label || target.serial,
    laixiNumber: target.laixiNumber || "",
    requestedMinutes: minutes,
    currentMinutes: minutes,
    totalRequestedMinutes: minutes,
    attemptNo: Number(target.attemptNo || 1),
    state: "running",
    startedAt: now.toISOString(),
    expectedEndAt: new Date(now.getTime() + minutes * 60 * 1000).toISOString(),
    lastSeenAt: status ? now.toISOString() : "",
    lastStatusAt: status && status.updatedAt || "",
    lastStartCommandAt: now.toISOString(),
    restartCount: 0,
    swipeCount: Number(status && status.swipeCount || 0),
    elapsedSeconds: Number(status && status.elapsedSeconds || 0),
    completedSeconds: 0,
    lastError: "",
    agentInstalled: true,
    agentStatus: status || null,
  };
  const job = {
    jobId,
    status: "running",
    createdAt: now.toISOString(),
    startedAt: now.toISOString(),
    finishedAt: "",
    adbPath,
    monitorIntervalSeconds: 30,
    staleSeconds: 90,
    stopRequested: false,
    devices: [device],
    fallbackAdbJobIds: [],
    logs: [],
    monitorTimer: null,
  };
  swipeAgentJobs.set(job.jobId, job);
  appendSwipeAgentLog(job, `recovery test registered: ${target.label || target.serial}`);
  startSwipeAgentMonitor(job);
  persistSwipeAgentJobs();
  return { ok: true, jobId: job.jobId, message: `registered ${job.jobId}` };
}

async function findTextTapCandidate(adbPath, target, texts = []) {
  const result = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "uiautomator", "dump", "/dev/tty"],
    timeoutMs: 12000,
  });
  const xml = `${result.stdout || ""}\n${result.stderr || ""}`;
  if (!result.ok && !xml) return null;
  const wanted = texts.map((text) => String(text || "").trim()).filter(Boolean);
  if (!wanted.length) return null;
  const nodePattern = /<node\b[^>]*>/g;
  let match;
  while ((match = nodePattern.exec(xml))) {
    const node = match[0];
    const text = decodeXmlAttr(extractXmlAttr(node, "text"));
    const desc = decodeXmlAttr(extractXmlAttr(node, "content-desc"));
    const haystack = `${text}\n${desc}`;
    const wantedText = wanted.find((item) => haystack.includes(item));
    if (!wantedText) continue;
    const bounds = extractXmlAttr(node, "bounds");
    const parsed = parseAndroidBounds(bounds);
    if (!parsed) continue;
    return {
      type: "text",
      text: wantedText,
      x: Math.round((parsed.left + parsed.right) / 2),
      y: Math.round((parsed.top + parsed.bottom) / 2),
      bounds,
    };
  }
  return null;
}

function extractXmlAttr(node, name) {
  const match = new RegExp(`${name}="([^"]*)"`).exec(node || "");
  return match ? match[1] : "";
}

function decodeXmlAttr(value) {
  return String(value || "")
    .replace(/&quot;/g, "\"")
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");
}

function parseAndroidBounds(value) {
  const match = /\[(\d+),(\d+)\]\[(\d+),(\d+)\]/.exec(String(value || ""));
  if (!match) return null;
  return {
    left: Number(match[1]),
    top: Number(match[2]),
    right: Number(match[3]),
    bottom: Number(match[4]),
  };
}

function startAdbSwipeRunner(body = {}) {
  const config = readFleetMonitorConfig();
  const adbPath = config.adbPath || resolveAdbPath();
  const ports = [XIAOWEI_ADB_PORT];
  const minutes = Math.max(1, Math.min(240, Math.floor(Number(body.minutes || 60))));
  const minInterval = Math.max(1, Math.min(300, Math.floor(Number(body.minIntervalSeconds || 10))));
  const maxInterval = Math.max(minInterval, Math.min(300, Math.floor(Number(body.maxIntervalSeconds || 15))));
  const scriptPath = path.join(paths.root, "tools", "run-adb-swipe.ps1");
  if (!fs.existsSync(scriptPath)) {
    return { ok: false, error: "run-adb-swipe.ps1 not found", scriptPath };
  }

  const args = [
    "-NoProfile",
    "-ExecutionPolicy",
    "Bypass",
    "-File",
    scriptPath,
    "-Minutes",
    String(minutes),
    "-MinIntervalSeconds",
    String(minInterval),
    "-MaxIntervalSeconds",
    String(maxInterval),
  ];
  if (adbPath) args.push("-AdbPath", adbPath);
  if (ports.length) args.push("-AdbPorts", ...ports.map((port) => String(port)));
  if (Array.isArray(body.serials) && body.serials.length) {
    const serials = body.serials.map((value) => String(value).trim()).filter(Boolean);
    if (serials.length) args.push("-Serials", ...serials);
  }

  const child = spawn("powershell.exe", args, {
    cwd: paths.root,
    detached: true,
    stdio: "ignore",
    windowsHide: true,
  });
  child.unref();

  return {
    ok: true,
    pid: child.pid,
    minutes,
    minIntervalSeconds: minInterval,
    maxIntervalSeconds: maxInterval,
    adbPath,
    adbPorts: ports,
    scriptPath,
  };
}

function isSwipeJobMergeable(job) {
  if (!job) return false;
  if (job.status === "running" && !job.stopRequested) return true;
  if (!["done", "stopped", "failed"].includes(job.status || "")) return false;
  const finishedMs = Date.parse(job.finishedAt || 0);
  return Boolean(finishedMs && Date.now() - finishedMs <= SWIPE_JOB_MERGE_GRACE_MS);
}

function activeSwipeTargetStates() {
  return new Set(["queued", "starting", "running", "stopping", "adb_fallback"]);
}

function addRepeatSwipeTargets(job, targets = []) {
  const devices = Array.isArray(job.devices) ? job.devices : [];
  const activeStates = activeSwipeTargetStates();
  const activeSerials = new Set(devices
    .filter((target) => activeStates.has(target.state || ""))
    .map((target) => String(target.serial || "")));
  const attemptBySerial = new Map();
  for (const target of devices) {
    const serial = String(target.serial || "");
    if (!serial) continue;
    const current = Number(target.attemptNo || 1);
    attemptBySerial.set(serial, Math.max(attemptBySerial.get(serial) || 0, current));
  }
  const addTargets = [];
  let skippedActive = 0;
  for (const target of targets) {
    const serial = String(target.serial || "");
    if (!serial) continue;
    if (activeSerials.has(serial)) {
      skippedActive += 1;
      continue;
    }
    const attemptNo = (attemptBySerial.get(serial) || 0) + 1;
    attemptBySerial.set(serial, attemptNo);
    target.attemptNo = attemptNo;
    addTargets.push(target);
  }
  return { addTargets, skippedActive };
}

function findMergeableAdbSwipeJob() {
  return [...adbSwipeJobs.values()]
    .filter(isSwipeJobMergeable)
    .sort((a, b) => {
      const aTime = Date.parse(a.finishedAt || a.createdAt || 0) || 0;
      const bTime = Date.parse(b.finishedAt || b.createdAt || 0) || 0;
      return bTime - aTime;
    })[0] || null;
}

async function startAdbSwipeJob(body = {}) {
  const config = readFleetMonitorConfig();
  const adbPath = body.adbPath || config.adbPath || resolveAdbPath();
  if (!adbPath || !fs.existsSync(adbPath)) {
    return { ok: false, error: "ADB was not found.", adbPath };
  }

  const defaultMinutes = clampInteger(body.minutes || 60, 1, 240);
  const minInterval = clampInteger(body.minIntervalSeconds || 10, 1, 300);
  const maxInterval = Math.max(minInterval, clampInteger(body.maxIntervalSeconds || 15, 1, 300));
  const requestedTargets = Array.isArray(body.targets) ? body.targets : [];
  if (!requestedTargets.length) return { ok: false, error: "No swipe targets selected.", adbPath };
  const adbDevices = await listAdbDevicesForUi();

  const connectedBySerial = new Map((adbDevices.devices || [])
    .filter((device) => device && device.serial && device.connected)
    .map((device) => [String(device.serial), device]));
  const rawTargets = requestedTargets;
  const seen = new Set();
  const targets = rawTargets
    .map((target) => {
      const serial = cleanText(target && target.serial, 80);
      if (!serial || seen.has(serial)) return null;
      seen.add(serial);
      const connected = connectedBySerial.get(serial) || {};
      const minutes = clampInteger(target.minutes || defaultMinutes, 1, 240);
      return {
        serial,
        adbPort: target.adbPort === undefined || target.adbPort === null || target.adbPort === "" ? (connected.adbPort || null) : Number(target.adbPort),
        label: cleanText(target.label || connected.label || connected.laixiNumber || connected.model || serial, 120),
        laixiNumber: cleanText(target.laixiNumber || connected.laixiNumber, 20),
        minutes,
        attemptNo: 1,
        state: connectedBySerial.has(serial) || target.allowOffline ? "queued" : "missing",
        startedAt: "",
        endAt: "",
        nextSwipeAt: "",
        finishedAt: "",
        swipeCount: 0,
        failCount: 0,
        activeElapsedMs: 0,
        lastSwipeAt: "",
        lastError: connectedBySerial.has(serial) || target.allowOffline ? "" : "ADB connected device not found.",
        width: 0,
        height: 0,
      };
    })
    .filter(Boolean);

  if (!targets.length) {
    return { ok: false, error: "No swipe targets selected.", adbPath };
  }

  pruneAdbSwipeJobs();
  const now = new Date();
  const runnable = targets.filter((target) => target.state !== "missing");
  if (body.mergeRunning !== false) {
    const mergeJob = findMergeableAdbSwipeJob();
    if (mergeJob) {
      const { addTargets, skippedActive } = addRepeatSwipeTargets(mergeJob, targets);
      if (addTargets.length) {
        const reopened = mergeJob.status !== "running";
        mergeJob.status = "running";
        mergeJob.finishedAt = "";
        mergeJob.stopRequested = false;
        mergeJob.devices = Array.isArray(mergeJob.devices) ? mergeJob.devices : [];
        mergeJob.devices.push(...addTargets);
        const addRunnable = addTargets.filter((target) => target.state !== "missing");
        mergeJob.runningCount = Number(mergeJob.runningCount || 0) + addRunnable.length;
        const currentEnd = Date.parse(mergeJob.endAt || 0) || now.getTime();
        const addEnd = Math.max(...addTargets.map((target) => now.getTime() + target.minutes * 60 * 1000));
        mergeJob.endAt = new Date(Math.max(currentEnd, addEnd)).toISOString();
        if (reopened) appendAdbSwipeJobLog(mergeJob, "job reopened within 60m merge window");
        appendAdbSwipeJobLog(mergeJob, `targets added: ${addRunnable.length}/${addTargets.length} devices${skippedActive ? ` (${skippedActive} active skipped)` : ""}`);
        startAdbSwipeWatchdog(mergeJob);
        for (const target of addRunnable) {
          launchAdbSwipeTarget(mergeJob, target);
        }
      } else {
        appendAdbSwipeJobLog(mergeJob, `targets add skipped: already running (${skippedActive})`);
      }
      return { ok: true, merged: true, job: serializeAdbSwipeJob(mergeJob) };
    }
  }
  const maxMinutes = Math.max(...targets.map((target) => target.minutes));
  const job = {
    jobId: `swipe_${localTimestampForId()}_${Math.random().toString(36).slice(2, 7)}`,
    status: runnable.length ? "running" : "failed",
    createdAt: now.toISOString(),
    startedAt: now.toISOString(),
    endAt: new Date(now.getTime() + maxMinutes * 60 * 1000).toISOString(),
    finishedAt: "",
    adbPath,
    minIntervalSeconds: minInterval,
    maxIntervalSeconds: maxInterval,
    stopRequested: false,
    runningCount: runnable.length,
    devices: targets,
    logs: [],
    watchdogTimer: null,
  };
  adbSwipeJobs.set(job.jobId, job);
  appendAdbSwipeJobLog(job, `job started: ${runnable.length}/${targets.length} devices`);
  startAdbSwipeWatchdog(job);

  for (const target of runnable) {
    launchAdbSwipeTarget(job, target);
  }

  return { ok: runnable.length > 0, job: serializeAdbSwipeJob(job) };
}

function launchAdbSwipeTarget(job, target, resume = false) {
  const runnerId = `runner_${Math.floor(performance.now())}_${Math.random().toString(36).slice(2, 7)}`;
  target.runnerId = runnerId;
  target.lastHeartbeatAt = new Date().toISOString();
  if (resume) {
    target.state = "running";
    appendAdbSwipeJobLog(job, `${target.label || target.serial}: watchdog resume`);
  }
  runAdbSwipeTarget(job, target, runnerId, resume).catch((error) => {
    if (target.runnerId && target.runnerId !== runnerId) return;
    target.state = "failed";
    target.failCount += 1;
    target.lastError = error.message;
    target.finishedAt = new Date().toISOString();
    finishAdbSwipeTarget(job, target);
  });
}

async function runAdbSwipeTarget(job, target, runnerId, resume = false) {
  const startMs = target.startedAt ? Date.parse(target.startedAt) : Date.now();
  const plannedMs = adbSwipePlannedMs(target);
  const runnerStartedMs = Date.now();
  target.activeRunBaseMs = resume ? Number(target.activeElapsedMs || 0) : 0;
  target.activeRunStartedMonoMs = performance.now();
  target.activeRunStartedAt = new Date(runnerStartedMs).toISOString();
  if (!resume) target.activeElapsedMs = 0;
  target.state = "running";
  target.startedAt = target.startedAt || new Date(startMs).toISOString();
  target.endAt = new Date(Date.now() + adbSwipeRemainingMs(target)).toISOString();
  target.finishedAt = "";
  target.lastHeartbeatAt = new Date().toISOString();
  if (!resume) appendAdbSwipeJobLog(job, `${target.label || target.serial}: started ${target.minutes}m`);

  const size = await getAdbSwipeDeviceSize(job.adbPath, target);
  if (target.runnerId !== runnerId) return;
  target.width = size.width;
  target.height = size.height;

  while (!job.stopRequested && !target.stopRequested && updateAdbSwipeActiveElapsed(target) < plannedMs) {
    if (target.runnerId !== runnerId) return;
    target.lastHeartbeatAt = new Date().toISOString();
    const result = await runAdbSwipeCommand(job.adbPath, target, size);
    if (target.runnerId !== runnerId) return;
    const now = new Date();
    target.lastHeartbeatAt = now.toISOString();
    updateAdbSwipeActiveElapsed(target);
    if (result.ok) {
      target.swipeCount += 1;
      target.lastSwipeAt = now.toISOString();
      target.lastError = "";
    } else {
      target.failCount += 1;
      target.lastError = result.stderr || result.stdout || result.error || `adb exit ${result.code}`;
      appendAdbSwipeJobLog(job, `${target.label || target.serial}: failed ${target.lastError}`);
    }

    const remainingMs = adbSwipeRemainingMs(target);
    if (job.stopRequested || target.stopRequested || remainingMs <= 0) break;
    const sleepMs = randomInteger(job.minIntervalSeconds, job.maxIntervalSeconds) * 1000;
    target.nextSwipeAt = new Date(Date.now() + Math.min(sleepMs, remainingMs)).toISOString();
    target.endAt = new Date(Date.now() + remainingMs).toISOString();
    await sleep(Math.min(sleepMs, remainingMs));
    updateAdbSwipeActiveElapsed(target);
  }

  if (target.runnerId !== runnerId) return;
  updateAdbSwipeActiveElapsed(target);
  target.state = (job.stopRequested || target.stopRequested) ? "stopped" : "done";
  target.nextSwipeAt = "";
  target.finishedAt = new Date().toISOString();
  finishAdbSwipeTarget(job, target);
}

function adbSwipePlannedMs(target) {
  return Math.max(0, Number(target.minutes || 0) * 60 * 1000);
}

function updateAdbSwipeActiveElapsed(target) {
  const base = Object.prototype.hasOwnProperty.call(target, "activeRunBaseMs")
    ? Number(target.activeRunBaseMs || 0)
    : Number(target.activeElapsedMs || 0);
  const startedMonoMs = Number(target.activeRunStartedMonoMs || 0);
  const runningMs = startedMonoMs
    ? Math.max(0, performance.now() - startedMonoMs)
    : Math.max(0, Date.now() - (Date.parse(target.activeRunStartedAt || 0) || Date.now()));
  target.activeElapsedMs = Math.max(Number(target.activeElapsedMs || 0), base + runningMs);
  return Number(target.activeElapsedMs || 0);
}

function adbSwipeRemainingMs(target) {
  return Math.max(0, adbSwipePlannedMs(target) - Number(target.activeElapsedMs || 0));
}

function startAdbSwipeWatchdog(job) {
  if (job.watchdogTimer) clearInterval(job.watchdogTimer);
  job.watchdogTimer = setInterval(() => {
    if (!job || !["running", "stopping"].includes(job.status || "")) {
      clearInterval(job.watchdogTimer);
      job.watchdogTimer = null;
      return;
    }
    const now = Date.now();
    for (const target of job.devices || []) {
      if (target.state !== "running") continue;
      updateAdbSwipeActiveElapsed(target);
      const remainingMs = adbSwipeRemainingMs(target);
      target.endAt = new Date(now + remainingMs).toISOString();
      if (remainingMs <= 0) {
        target.state = job.stopRequested ? "stopped" : "done";
        target.nextSwipeAt = "";
        target.finishedAt = new Date().toISOString();
        finishAdbSwipeTarget(job, target);
        continue;
      }
      const heartbeatMs = Date.parse(target.lastHeartbeatAt || target.lastSwipeAt || target.startedAt || 0);
      const nextMs = Date.parse(target.nextSwipeAt || 0);
      const stalledByHeartbeat = heartbeatMs && now - heartbeatMs > 45000;
      const stalledByNextSwipe = nextMs && now - nextMs > 30000;
      if (!stalledByHeartbeat && !stalledByNextSwipe) continue;
      target.stallCount = Number(target.stallCount || 0) + 1;
      const deepRecovery = target.stallCount >= TTL_DEEP_RECOVERY_AFTER_STALLS;
      target.lastError = deepRecovery
        ? `watchdog deep recovering TTL (${target.stallCount})`
        : `watchdog restarting TTL (${target.stallCount})`;
      appendAdbSwipeJobLog(job, `${target.label || target.serial}: stalled, ${deepRecovery ? "deep recover TTL" : "restart TTL"} ${target.stallCount}`);
      if (target.restartInFlight) continue;
      target.restartInFlight = true;
      const recovery = deepRecovery
        ? (adbPath, target) => deepRecoverTtlClient(adbPath, target, (name, result) => {
            appendAdbSwipeJobLog(job, `${target.label || target.serial}: recovery ${formatRecoveryStepForLog(name, result)}`);
          })
        : restartTtlClient;
      recovery(job.adbPath, target)
        .then((result) => {
          target.restartInFlight = false;
          target.lastError = result.ok ? "" : (result.error || "TTL restart failed");
          appendAdbSwipeJobLog(job, `${target.label || target.serial}: TTL ${deepRecovery ? "deep recovery" : "restart"} ${result.ok ? "OK" : "NG"}`);
          launchAdbSwipeTarget(job, target, true);
        })
        .catch((error) => {
          target.restartInFlight = false;
          target.lastError = error.message;
          appendAdbSwipeJobLog(job, `${target.label || target.serial}: TTL restart error ${error.message}`);
          launchAdbSwipeTarget(job, target, true);
        });
    }
  }, 10000);
  if (typeof job.watchdogTimer.unref === "function") job.watchdogTimer.unref();
}

async function restartTtlClient(adbPath, target) {
  const stop = await forceStopPackagesOnTarget(adbPath, target, TIKTOK_LITE_PACKAGE_NAMES, 10000);
  await sleep(1200);
  const start = await launchTtlOnTarget(adbPath, target, 15000);
  await sleep(3500);
  return {
    ok: Boolean(stop.ok && start.ok),
    stop,
    start,
    packageName: TIKTOK_LITE_PACKAGE_NAME,
    error: !stop.ok ? (stop.stderr || stop.stdout || stop.error || "force-stop failed") : !start.ok ? (start.stderr || start.stdout || start.error || "launch failed") : "",
  };
}

async function deepRecoverTtlClient(adbPath, target, pushStep = () => {}) {
  const agentStop = await sendSwipeAgentStop(adbPath, target).catch((error) => ({ ok: false, error: error.message }));
  const ttlStop = await closeTtlClient(adbPath, target);
  const home = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "input", "keyevent", "HOME"],
    timeoutMs: 8000,
  });
  await sleep(1200);
  const killAll = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "am", "kill-all"],
    timeoutMs: 10000,
  });
  await sleep(3000);
  const start = await launchTtlOnTarget(adbPath, target);
  await sleep(10000);
  const blockerResult = await clearRecoveryBlockers(adbPath, target, pushStep).catch((error) => ({
    candidates: [],
    lastCandidate: null,
    lastScreenshotUrl: "",
    ok: false,
    error: error.message,
  }));
  return {
    ok: Boolean(ttlStop.ok && start.ok),
    agentStop,
    ttlStop,
    home,
    killAll,
    start,
    blockerResult,
    closeCandidates: blockerResult.candidates || [],
    packageName: TIKTOK_LITE_PACKAGE_NAME,
    error: !ttlStop.ok ? ttlStop.error : !start.ok ? (start.stderr || start.stdout || start.error || "launch failed") : blockerResult.ok === false ? blockerResult.error : "",
  };
}

async function closeTtlClient(adbPath, target) {
  const stop = await forceStopPackagesOnTarget(adbPath, target, TIKTOK_LITE_PACKAGE_NAMES, 10000);
  return {
    ok: Boolean(stop.ok),
    stop,
    packageName: TIKTOK_LITE_PACKAGE_NAME,
    error: !stop.ok ? (stop.stderr || stop.stdout || stop.error || "force-stop failed") : "",
  };
}

async function getAdbSwipeDeviceSize(adbPath, target) {
  const result = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "wm", "size"],
    timeoutMs: 8000,
  });
  const text = `${result.stdout || ""}\n${result.stderr || ""}`;
  const match = text.match(/(\d+)x(\d+)/);
  if (match) return { width: Number(match[1]), height: Number(match[2]) };
  return { width: 1080, height: 2400 };
}

async function runAdbSwipeCommand(adbPath, target, size) {
  const width = Number(size.width || target.width || 1080);
  const height = Number(size.height || target.height || 2400);
  const startX = randomInteger(Math.floor(width * 0.46), Math.floor(width * 0.56));
  const startY = randomInteger(Math.floor(height * 0.78), Math.floor(height * 0.84));
  const endX = randomInteger(Math.floor(width * 0.46), Math.floor(width * 0.56));
  const endY = randomInteger(Math.floor(height * 0.13), Math.floor(height * 0.17));
  const duration = randomInteger(350, 650);
  return runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "input", "swipe", String(startX), String(startY), String(endX), String(endY), String(duration)],
    timeoutMs: 15000,
  });
}

function runAdbCommand({ adbPath, adbPort, serial, adbArgs = [], timeoutMs = 15000 }) {
  return new Promise((resolve) => {
    const args = [];
    if (adbPort) args.push("-P", String(adbPort));
    if (serial) args.push("-s", String(serial));
    args.push(...adbArgs);
    const child = spawn(adbPath, args, { windowsHide: true });
    let stdout = "";
    let stderr = "";
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      try { child.kill(); } catch {}
      resolve({ ok: false, code: "TIMEOUT", stdout, stderr, error: "ADB command timed out." });
    }, timeoutMs);
    child.stdout.on("data", (chunk) => { stdout += chunk.toString(); });
    child.stderr.on("data", (chunk) => { stderr += chunk.toString(); });
    child.on("error", (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ ok: false, code: "SPAWN_ERROR", stdout, stderr, error: error.message });
    });
    child.on("close", (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ ok: code === 0, code, stdout: stdout.trim(), stderr: stderr.trim() });
    });
  });
}

function runAdbBufferCommand({ adbPath, adbPort, serial, adbArgs = [], timeoutMs = 15000 }) {
  return new Promise((resolve) => {
    const args = [];
    if (adbPort) args.push("-P", String(adbPort));
    if (serial) args.push("-s", String(serial));
    args.push(...adbArgs);
    const child = spawn(adbPath, args, { windowsHide: true });
    const stdoutChunks = [];
    let stderr = "";
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      try { child.kill(); } catch {}
      resolve({ ok: false, code: "TIMEOUT", stdoutBuffer: Buffer.concat(stdoutChunks), stderr, error: "ADB command timed out." });
    }, timeoutMs);
    child.stdout.on("data", (chunk) => { stdoutChunks.push(Buffer.from(chunk)); });
    child.stderr.on("data", (chunk) => { stderr += chunk.toString(); });
    child.on("error", (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ ok: false, code: "SPAWN_ERROR", stdoutBuffer: Buffer.concat(stdoutChunks), stderr, error: error.message });
    });
    child.on("close", (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ ok: code === 0, code, stdoutBuffer: Buffer.concat(stdoutChunks), stderr: stderr.trim() });
    });
  });
}

function detectCloseButtonCandidate(filePath) {
  try {
    const image = decodePngRgba(fs.readFileSync(filePath));
    if (!image) return null;
    const { width, height } = image;
    const minY = Math.max(24, Math.floor(height * 0.04));
    const maxY = Math.floor(height * 0.58);
    const minX = Math.floor(width * 0.18);
    const maxX = Math.floor(width * 0.96);
    const radius = Math.max(10, Math.min(28, Math.floor(Math.min(width, height) / 55)));
    let best = null;
    for (let y = minY + radius; y < maxY - radius; y += Math.max(4, Math.floor(radius / 2))) {
      for (let x = minX + radius; x < maxX - radius; x += Math.max(4, Math.floor(radius / 2))) {
        const score = closeButtonScore(image, x, y, radius);
        if (!best || score > best.score) best = { x, y, score };
      }
    }
    if (!best || best.score < 18) return null;
    return { x: best.x, y: best.y, score: Math.round(best.score * 10) / 10, width, height };
  } catch {
    return null;
  }
}

function closeButtonScore(image, cx, cy, radius) {
  const samples = [];
  const bg = [];
  for (let i = -radius; i <= radius; i += 3) {
    samples.push(lumaAt(image, cx + i, cy + i));
    samples.push(lumaAt(image, cx + i, cy - i));
    bg.push(lumaAt(image, cx + i, cy));
    bg.push(lumaAt(image, cx, cy + i));
  }
  const sampleAvg = average(samples);
  const bgAvg = average(bg);
  const contrast = Math.abs(sampleAvg - bgAvg);
  if (contrast < 35) return 0;
  let diagHits = 0;
  for (let i = -radius; i <= radius; i += 2) {
    const a = lumaAt(image, cx + i, cy + i);
    const b = lumaAt(image, cx + i, cy - i);
    if (Math.abs(a - bgAvg) > 40) diagHits += 1;
    if (Math.abs(b - bgAvg) > 40) diagHits += 1;
  }
  const centerContrast = Math.abs(lumaAt(image, cx, cy) - bgAvg);
  return diagHits + (contrast / 10) + (centerContrast / 20);
}

function decodePngRgba(buffer) {
  const signature = "89504e470d0a1a0a";
  if (!buffer || buffer.slice(0, 8).toString("hex") !== signature) return null;
  let offset = 8;
  let width = 0;
  let height = 0;
  let bitDepth = 0;
  let colorType = 0;
  const idat = [];
  while (offset + 8 <= buffer.length) {
    const length = buffer.readUInt32BE(offset);
    const type = buffer.slice(offset + 4, offset + 8).toString("ascii");
    const data = buffer.slice(offset + 8, offset + 8 + length);
    offset += 12 + length;
    if (type === "IHDR") {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
    } else if (type === "IDAT") {
      idat.push(data);
    } else if (type === "IEND") {
      break;
    }
  }
  if (!width || !height || bitDepth !== 8 || ![2, 6].includes(colorType)) return null;
  const channels = colorType === 6 ? 4 : 3;
  const stride = width * channels;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const rgba = Buffer.alloc(width * height * 4);
  let rawOffset = 0;
  let prev = Buffer.alloc(stride);
  for (let y = 0; y < height; y++) {
    const filter = raw[rawOffset++];
    const row = Buffer.from(raw.slice(rawOffset, rawOffset + stride));
    rawOffset += stride;
    unfilterPngRow(row, prev, channels, filter);
    for (let x = 0; x < width; x++) {
      const src = x * channels;
      const dst = (y * width + x) * 4;
      rgba[dst] = row[src];
      rgba[dst + 1] = row[src + 1];
      rgba[dst + 2] = row[src + 2];
      rgba[dst + 3] = channels === 4 ? row[src + 3] : 255;
    }
    prev = row;
  }
  return { width, height, rgba };
}

function unfilterPngRow(row, prev, bpp, filter) {
  for (let i = 0; i < row.length; i++) {
    const left = i >= bpp ? row[i - bpp] : 0;
    const up = prev[i] || 0;
    const upLeft = i >= bpp ? (prev[i - bpp] || 0) : 0;
    let value = row[i];
    if (filter === 1) value += left;
    else if (filter === 2) value += up;
    else if (filter === 3) value += Math.floor((left + up) / 2);
    else if (filter === 4) value += paethPredictor(left, up, upLeft);
    row[i] = value & 255;
  }
}

function paethPredictor(a, b, c) {
  const p = a + b - c;
  const pa = Math.abs(p - a);
  const pb = Math.abs(p - b);
  const pc = Math.abs(p - c);
  if (pa <= pb && pa <= pc) return a;
  if (pb <= pc) return b;
  return c;
}

function lumaAt(image, x, y) {
  const px = Math.max(0, Math.min(image.width - 1, Math.round(x)));
  const py = Math.max(0, Math.min(image.height - 1, Math.round(y)));
  const index = (py * image.width + px) * 4;
  return (image.rgba[index] * 0.299) + (image.rgba[index + 1] * 0.587) + (image.rgba[index + 2] * 0.114);
}

function average(values) {
  if (!values.length) return 0;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function finishAdbSwipeTarget(job, target) {
  job.runningCount = Math.max(0, Number(job.runningCount || 0) - 1);
  if (job.runningCount > 0) return;
  if (job.watchdogTimer) {
    clearInterval(job.watchdogTimer);
    job.watchdogTimer = null;
  }
  job.finishedAt = new Date().toISOString();
  if (job.stopRequested) job.status = "stopped";
  else if (job.devices.every((device) => device.state === "missing")) job.status = "failed";
  else if (job.devices.some((device) => device.state === "failed")) job.status = "failed";
  else job.status = "done";
  appendAdbSwipeJobLog(job, `job ${job.status}`);
}

function listAdbSwipeJobs() {
  pruneAdbSwipeJobs();
  return {
    ok: true,
    jobs: [...adbSwipeJobs.values()]
      .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
      .slice(0, 20)
      .map(serializeAdbSwipeJob),
  };
}

function getAdbSwipeJobStatus(jobId) {
  const job = adbSwipeJobs.get(jobId);
  if (!job) return { ok: false, error: "ADB swipe job not found.", jobId };
  return { ok: true, job: serializeAdbSwipeJob(job) };
}

function stopAdbSwipeJob(jobId) {
  const job = adbSwipeJobs.get(jobId);
  if (!job) return { ok: false, error: "ADB swipe job not found.", jobId };
  job.stopRequested = true;
  if (job.status === "running") job.status = "stopping";
  appendAdbSwipeJobLog(job, "stop requested");
  return { ok: true, job: serializeAdbSwipeJob(job) };
}

function serializeAdbSwipeJob(job) {
  const devices = (job.devices || []).map((device) => ({ ...device }));
  return {
    ok: true,
    jobId: job.jobId,
    status: job.status,
    createdAt: job.createdAt,
    startedAt: job.startedAt,
    endAt: job.endAt,
    finishedAt: job.finishedAt,
    minIntervalSeconds: job.minIntervalSeconds,
    maxIntervalSeconds: job.maxIntervalSeconds,
    stopRequested: Boolean(job.stopRequested),
    totals: {
      devices: devices.length,
      running: devices.filter((device) => device.state === "running" || device.state === "queued").length,
      done: devices.filter((device) => device.state === "done").length,
      stopped: devices.filter((device) => device.state === "stopped").length,
      missing: devices.filter((device) => device.state === "missing").length,
      swipes: devices.reduce((sum, device) => sum + Number(device.swipeCount || 0), 0),
      failed: devices.reduce((sum, device) => sum + Number(device.failCount || 0), 0),
    },
    devices,
    logs: (job.logs || []).slice(-1200),
  };
}

function appendAdbSwipeJobLog(job, message) {
  job.logs = Array.isArray(job.logs) ? job.logs : [];
  job.logs.push({ at: new Date().toISOString(), message: cleanText(message, 300) });
  if (job.logs.length > 240) job.logs = job.logs.slice(-240);
}

function pruneAdbSwipeJobs() {
  const jobs = [...adbSwipeJobs.values()].sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  const keepIds = new Set(jobs.slice(0, 20).map((job) => job.jobId));
  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  for (const job of jobs) {
    const running = job.status === "running" || job.status === "stopping";
    if (running) continue;
    if (!keepIds.has(job.jobId) || Date.parse(job.createdAt || 0) < cutoff) adbSwipeJobs.delete(job.jobId);
  }
}

function findMergeableSwipeAgentJob() {
  return [...swipeAgentJobs.values()]
    .filter(isSwipeJobMergeable)
    .sort((a, b) => {
      const aTime = Date.parse(a.finishedAt || a.createdAt || 0) || 0;
      const bTime = Date.parse(b.finishedAt || b.createdAt || 0) || 0;
      return bTime - aTime;
    })[0] || null;
}

async function startSwipeAgentJob(body = {}) {
  const config = readFleetMonitorConfig();
  const adbPath = body.adbPath || config.adbPath || resolveAdbPath();
  if (!adbPath || !fs.existsSync(adbPath)) return { ok: false, error: "ADB was not found.", adbPath };

  const defaultMinutes = roundSwipeAgentMinutes(body.minutes || 60);
  const monitorIntervalSeconds = clampInteger(body.monitorIntervalSeconds || 30, 10, 300);
  const staleSeconds = clampInteger(body.staleSeconds || 90, 30, 600);
  const requestedTargets = Array.isArray(body.targets) ? body.targets : [];
  if (!requestedTargets.length) return { ok: false, error: "No Swipe Agent targets selected.", adbPath };
  const adbDevices = await listAdbDevicesForUi();

  const connectedBySerial = new Map((adbDevices.devices || [])
    .filter((device) => device && device.serial && device.connected)
    .map((device) => [String(device.serial), device]));
  const rawTargets = requestedTargets;
  const seen = new Set();
  const targets = rawTargets
    .map((target) => {
      const serial = cleanText(target && target.serial, 80);
      if (!serial || seen.has(serial)) return null;
      seen.add(serial);
      const connected = connectedBySerial.get(serial) || {};
      const minutes = roundSwipeAgentMinutes(target.minutes || defaultMinutes);
      const now = Date.now();
      return {
        serial,
        adbPort: target.adbPort === undefined || target.adbPort === null || target.adbPort === "" ? (connected.adbPort || null) : Number(target.adbPort),
        label: cleanText(target.label || connected.label || connected.laixiNumber || connected.model || serial, 120),
        laixiNumber: cleanText(target.laixiNumber || connected.laixiNumber, 20),
        requestedMinutes: minutes,
        currentMinutes: minutes,
        totalRequestedMinutes: minutes,
        attemptNo: 1,
        state: connectedBySerial.has(serial) || target.allowOffline ? "queued" : "missing",
        startedAt: "",
        expectedEndAt: new Date(now + minutes * 60 * 1000).toISOString(),
        lastSeenAt: "",
        lastStatusAt: "",
        lastStartCommandAt: "",
        restartCount: 0,
        swipeCount: 0,
        elapsedSeconds: 0,
        completedSeconds: 0,
        lastError: connectedBySerial.has(serial) || target.allowOffline ? "" : "ADB connected device not found.",
        agentInstalled: null,
        agentStatus: null,
      };
    })
    .filter(Boolean);

  if (!targets.length) return { ok: false, error: "No Swipe Agent targets selected.", adbPath };

  pruneSwipeAgentJobs();
  const runnable = targets.filter((target) => target.state !== "missing");
  const now = new Date();
  if (body.mergeRunning !== false) {
    const mergeJob = findMergeableSwipeAgentJob();
    if (mergeJob) {
      const { addTargets, skippedActive } = addRepeatSwipeTargets(mergeJob, targets);
      if (addTargets.length) {
        const reopened = mergeJob.status !== "running";
        mergeJob.status = "running";
        mergeJob.finishedAt = "";
        mergeJob.stopRequested = false;
        mergeJob.devices = Array.isArray(mergeJob.devices) ? mergeJob.devices : [];
        mergeJob.devices.push(...addTargets);
        const addRunnable = addTargets.filter((target) => target.state !== "missing");
        if (reopened) appendSwipeAgentLog(mergeJob, "job reopened within 60m merge window");
        appendSwipeAgentLog(mergeJob, `targets added: ${addRunnable.length}/${addTargets.length} devices${skippedActive ? ` (${skippedActive} active skipped)` : ""}`);
        await runWithConcurrency(addRunnable, 12, async (target) => {
          await startSwipeAgentOnTarget(mergeJob, target, target.requestedMinutes, "added");
        });
        startSwipeAgentMonitor(mergeJob);
      } else {
        appendSwipeAgentLog(mergeJob, `targets add skipped: already running (${skippedActive})`);
      }
      persistSwipeAgentJobs();
      return { ok: true, merged: true, job: serializeSwipeAgentJob(mergeJob) };
    }
  }
  const job = {
    jobId: `agent_${localTimestampForId()}_${Math.random().toString(36).slice(2, 7)}`,
    status: runnable.length ? "running" : "failed",
    createdAt: now.toISOString(),
    startedAt: now.toISOString(),
    finishedAt: "",
    adbPath,
    monitorIntervalSeconds,
    staleSeconds,
    stopRequested: false,
    devices: targets,
    fallbackAdbJobIds: [],
    logs: [],
    monitorTimer: null,
  };
  swipeAgentJobs.set(job.jobId, job);
  appendSwipeAgentLog(job, `job started: ${runnable.length}/${targets.length} devices`);

  await runWithConcurrency(runnable, 12, async (target) => {
    await startSwipeAgentOnTarget(job, target, target.requestedMinutes, "initial");
  });
  startSwipeAgentMonitor(job);

  return { ok: runnable.length > 0, job: serializeSwipeAgentJob(job) };
}

async function startSwipeAgentOnTarget(job, target, minutes, reason) {
  if (job.stopRequested || target.state === "missing") return;
  const roundedMinutes = roundSwipeAgentMinutes(minutes);
  if (!["initial", "added"].includes(String(reason || ""))) {
    target.elapsedBaseSeconds = Math.max(Number(target.elapsedBaseSeconds || 0), Number(target.elapsedSeconds || 0));
  }
  target.currentMinutes = roundedMinutes;
  target.state = "starting";
  target.lastStartCommandAt = new Date().toISOString();
  target.lastError = "";
  const installed = await isSwipeAgentInstalled(job.adbPath, target);
  target.agentInstalled = installed.ok;
  if (!installed.ok) {
    target.lastError = "Swipe Agent app is not installed.";
    appendSwipeAgentLog(job, `${target.label || target.serial}: agent missing`);
    await fallbackSwipeAgentTargetToAdb(job, target, roundedMinutes, "agent missing");
    return;
  }
  const accessibility = await ensureSwipeAgentAccessibilityEnabled(job.adbPath, target);
  if (!accessibility.ok) {
    target.lastError = accessibility.stderr || accessibility.stdout || accessibility.error || "Swipe Agent accessibility enable failed.";
    appendSwipeAgentLog(job, `${target.label || target.serial}: accessibility NG ${target.lastError}`);
    await fallbackSwipeAgentTargetToAdb(job, target, roundedMinutes, "accessibility NG");
    return;
  }
  const result = await sendSwipeAgentStart(job.adbPath, target, roundedMinutes, job.jobId);
  if (!result.ok) {
    target.lastError = result.stderr || result.stdout || result.error || "start broadcast failed";
    appendSwipeAgentLog(job, `${target.label || target.serial}: start NG ${target.lastError}`);
    await fallbackSwipeAgentTargetToAdb(job, target, roundedMinutes, "start NG");
    return;
  }
  const now = new Date();
  target.state = "running";
  target.startedAt = target.startedAt || now.toISOString();
  target.expectedEndAt = new Date(now.getTime() + roundedMinutes * 60 * 1000).toISOString();
  appendSwipeAgentLog(job, `${target.label || target.serial}: start ${roundedMinutes}m (${reason})`);
}

async function fallbackSwipeAgentTargetToAdb(job, target, minutes, reason) {
  if (job.stopRequested || target.state === "missing") return;
  if (target.fallbackAdbJobId || target.state === "adb_fallback") return;
  const fallbackMinutes = clampInteger(minutes || target.currentMinutes || target.requestedMinutes || 60, 1, 240);
  const error = target.lastError || reason || "Swipe Agent failed";
  markSwipeModeAutoAdb(target.serial, error);
  target.state = "adb_fallback";
  target.fallbackAt = new Date().toISOString();
  target.fallbackReason = reason || "";
  target.fallbackMinutes = fallbackMinutes;
  appendSwipeAgentLog(job, `${target.label || target.serial}: Agent NG -> ADB fallback ${fallbackMinutes}m (${reason || "fallback"})`);
  const result = await startAdbSwipeJob({
    adbPath: job.adbPath,
    minutes: fallbackMinutes,
    minIntervalSeconds: 10,
    maxIntervalSeconds: 15,
    targets: [{
      serial: target.serial,
      adbPort: target.adbPort || "",
      label: target.label || `${target.laixiNumber ? target.laixiNumber + " " : ""}${target.serial}`,
      laixiNumber: target.laixiNumber || "",
      minutes: fallbackMinutes,
    }],
  });
  if (result.ok && result.job && result.job.jobId) {
    target.fallbackAdbJobId = result.job.jobId;
    job.fallbackAdbJobIds = Array.isArray(job.fallbackAdbJobIds) ? job.fallbackAdbJobIds : [];
    if (!job.fallbackAdbJobIds.includes(result.job.jobId)) job.fallbackAdbJobIds.push(result.job.jobId);
    appendSwipeAgentLog(job, `${target.label || target.serial}: ADB fallback started job ${result.job.jobId}`);
    return;
  }
  target.state = "failed";
  target.lastError = result.error || "ADB fallback failed";
  appendSwipeAgentLog(job, `${target.label || target.serial}: ADB fallback NG ${target.lastError}`);
}

function startSwipeAgentMonitor(job) {
  if (job.monitorTimer) clearInterval(job.monitorTimer);
  job.monitorTimer = setInterval(() => {
    monitorSwipeAgentJob(job).catch((error) => {
      appendSwipeAgentLog(job, `monitor error: ${error.message}`);
    });
  }, Math.max(10, job.monitorIntervalSeconds || 30) * 1000);
  if (typeof job.monitorTimer.unref === "function") job.monitorTimer.unref();
  monitorSwipeAgentJob(job).catch((error) => appendSwipeAgentLog(job, `monitor error: ${error.message}`));
  persistSwipeAgentJobs();
}

async function monitorSwipeAgentJob(job) {
  if (!job || !["running", "stopping"].includes(job.status || "")) {
    if (job && job.monitorTimer) {
      clearInterval(job.monitorTimer);
      job.monitorTimer = null;
    }
    persistSwipeAgentJobs();
    return;
  }

  const activeTargets = (job.devices || []).filter((target) => ["starting", "running"].includes(target.state || ""));
  await runWithConcurrency(activeTargets, 10, async (target) => {
    await monitorSwipeAgentTarget(job, target);
  });

  finishSwipeAgentJobIfDone(job);
  persistSwipeAgentJobs();
}

async function monitorSwipeAgentTarget(job, target) {
  if (job.stopRequested) {
    await sendSwipeAgentStop(job.adbPath, target).catch(() => null);
    target.state = "stopped";
    target.finishedAt = new Date().toISOString();
    return;
  }

  const statusResult = await readSwipeAgentStatus(job.adbPath, target);
  const now = Date.now();
  const plannedSeconds = swipeAgentPlannedSeconds(target);
  if (statusResult.ok && statusResult.status) {
    const status = normalizeSwipeAgentStatus(statusResult.status);
    const statusMatchesJob = !status.jobId || String(status.jobId) === String(job.jobId);
    const statusFresh = isSwipeAgentStatusFresh(status, Math.max(45, job.staleSeconds || 90));
    if (statusMatchesJob && statusFresh) {
      target.agentStatus = status;
      target.lastSeenAt = new Date().toISOString();
      target.lastStatusAt = status.updatedAt || target.lastSeenAt;
      target.swipeCount = Math.max(Number(target.swipeCount || 0), Number(status.swipeCount || 0));
      target.elapsedSeconds = Math.max(Number(target.elapsedSeconds || 0), Number(target.elapsedBaseSeconds || 0) + Number(status.elapsedSeconds || 0));
      if (status.running === true) {
        await ensureTtlInForegroundForAgentJob(job, target);
      }
      const terminalState = status.state === "done" ||
        status.state === "completed" ||
        (status.state === "stopped" && /completed/i.test(String(status.message || "")));
      if (terminalState) {
        target.completedSeconds = Math.max(Number(target.completedSeconds || 0), Number(status.elapsedSeconds || 0));
        if (plannedSeconds > 0 && Number(target.elapsedSeconds || 0) < plannedSeconds) {
          const remainingMinutes = swipeAgentRemainingMinutes(target);
          target.restartCount = Number(target.restartCount || 0) + 1;
          target.lastError = `Agent stopped early, restart remaining ${remainingMinutes}m`;
          appendSwipeAgentLog(job, `${target.label || target.serial}: early stop at ${target.elapsedSeconds || 0}s -> restart ${remainingMinutes}m`);
          await restartSwipeAgentTargetFromMonitor(job, target, remainingMinutes || target.currentMinutes || target.requestedMinutes, `early restart ${target.restartCount}`);
          return;
        }
        requestSwipeAgentStop(job, target, "terminal status");
        target.state = "done";
        target.finishedAt = new Date().toISOString();
        appendSwipeAgentLog(job, `${target.label || target.serial}: done`);
        return;
      }
    } else {
      target.lastError = `stale or foreign Agent status ignored: job=${status.jobId || ""} fresh=${statusFresh}`;
    }
  }

  const expectedEndMs = Date.parse(target.expectedEndAt || 0);
  if (expectedEndMs && now >= expectedEndMs + 15000) {
    const remainingMinutes = swipeAgentRemainingMinutes(target);
    if (remainingMinutes <= 0) {
      target.state = "done";
      target.finishedAt = new Date().toISOString();
      requestSwipeAgentStop(job, target, "agent elapsed reached target");
      appendSwipeAgentLog(job, `${target.label || target.serial}: done by agent elapsed`);
    } else if (Number(target.swipeCount || 0) <= 0 && !(target.agentStatus && target.agentStatus.running === true)) {
      target.state = "failed";
      target.finishedAt = new Date().toISOString();
      requestSwipeAgentStop(job, target, "planned time elapsed without agent progress");
      target.lastError = target.lastError || "planned time elapsed before Swipe Agent started";
      appendSwipeAgentLog(job, `${target.label || target.serial}: failed before start`);
    } else if (target.agentStatus && target.agentStatus.running === true) {
      target.expectedEndAt = new Date(now + remainingMinutes * 60 * 1000).toISOString();
      target.lastError = `Agent worked ${target.elapsedSeconds || 0}s / planned ${plannedSeconds}s; wait remaining ${remainingMinutes}m`;
      appendSwipeAgentLog(job, `${target.label || target.serial}: agent elapsed ${target.elapsedSeconds || 0}s/${plannedSeconds}s -> wait remaining ${remainingMinutes}m`);
    } else {
      target.restartCount = Number(target.restartCount || 0) + 1;
      target.lastError = `real time elapsed but agent worked ${target.elapsedSeconds || 0}s -> restart ${remainingMinutes}m`;
      appendSwipeAgentLog(job, `${target.label || target.serial}: real time elapsed, agent ${target.elapsedSeconds || 0}s -> restart ${remainingMinutes}m`);
      await restartSwipeAgentTargetFromMonitor(job, target, remainingMinutes, `elapsed restart ${target.restartCount}`);
    }
    return;
  }

  const lastMs = Date.parse(target.lastStatusAt || target.lastSeenAt || target.lastStartCommandAt || 0);
  const statusState = String(target.agentStatus && target.agentStatus.state || "");
  const zeroSwipeRestarts = Number(target.restartCount || 0) >= SWIPE_AGENT_MAX_ZERO_SWIPE_RESTARTS && Number(target.swipeCount || 0) <= 0;
  if (zeroSwipeRestarts && /commanded|starting|idle|stopped|error|failed/i.test(statusState || "commanded")) {
    const remainingMinutes = swipeAgentRemainingMinutes(target);
    target.lastError = `Agent did not start after ${target.restartCount} restarts`;
    appendSwipeAgentLog(job, `${target.label || target.serial}: zero swipe after ${target.restartCount} restarts -> ADB`);
    await fallbackSwipeAgentTargetToAdb(job, target, remainingMinutes || target.currentMinutes || target.requestedMinutes, "zero swipe restart limit");
    return;
  }
  const stale = !lastMs || now - lastMs > Math.max(30, job.staleSeconds || 90) * 1000;
  if (!stale) return;

  const remainingMinutes = swipeAgentRemainingMinutes(target);
  if (zeroSwipeRestarts && /commanded|starting|idle|stopped|error|failed/i.test(statusState || "commanded")) {
    target.lastError = `Agent did not start after ${target.restartCount} restarts`;
    appendSwipeAgentLog(job, `${target.label || target.serial}: zero swipe after ${target.restartCount} restarts -> ADB`);
    await fallbackSwipeAgentTargetToAdb(job, target, remainingMinutes || target.currentMinutes || target.requestedMinutes, "zero swipe restart limit");
    return;
  }
  if (remainingMinutes <= 0) {
    target.state = "done";
    target.finishedAt = new Date().toISOString();
    requestSwipeAgentStop(job, target, "stale agent elapsed reached target");
    appendSwipeAgentLog(job, `${target.label || target.serial}: stale but agent elapsed reached target`);
    return;
  }

  target.restartCount = Number(target.restartCount || 0) + 1;
  target.lastError = `stale, restart remaining ${remainingMinutes}m`;
  appendSwipeAgentLog(job, `${target.label || target.serial}: stale -> restart ${remainingMinutes}m`);
  await restartSwipeAgentTargetFromMonitor(job, target, remainingMinutes, `restart ${target.restartCount}`);
}

async function restartSwipeAgentTargetFromMonitor(job, target, minutes, reason) {
  const stopResult = await sendSwipeAgentStop(job.adbPath, target).catch((error) => ({ ok: false, error: error.message }));
  appendSwipeAgentLog(job, `${target.label || target.serial}: restart stop ${stopResult.ok ? "OK" : "NG"} (${reason || "monitor"})`);
  const deepRecovery = Number(target.restartCount || 0) >= TTL_DEEP_RECOVERY_AFTER_AGENT_RESTARTS;
  if (deepRecovery) {
    const recovery = await deepRecoverTtlClient(job.adbPath, target, (name, result) => {
      appendSwipeAgentLog(job, `${target.label || target.serial}: recovery ${formatRecoveryStepForLog(name, result)}`);
    }).catch((error) => ({ ok: false, error: error.message }));
    appendSwipeAgentLog(job, `${target.label || target.serial}: TTL deep recovery before Agent restart ${recovery.ok ? "OK" : "NG"}${recovery.error ? " " + recovery.error : ""}`);
  } else {
    await sleep(800);
  }
  await startSwipeAgentOnTarget(job, target, minutes, reason);
}

async function ensureTtlInForegroundForAgentJob(job, target) {
  const now = Date.now();
  const lastFixMs = Date.parse(target.lastTtlForegroundFixAt || 0) || 0;
  if (lastFixMs && now - lastFixMs < 30000) return;
  const focus = await readFocusedWindowPackage(job.adbPath, target).catch(() => "");
  if (focus && TIKTOK_LITE_PACKAGE_NAMES.some((packageName) => focus.includes(packageName))) return;
  target.lastTtlForegroundFixAt = new Date().toISOString();
  appendSwipeAgentLog(job, `${target.label || target.serial}: TTL not foreground (${focus || "unknown"}) -> launch TTL`);
  await launchTtlOnTarget(job.adbPath, target);
}

async function readFocusedWindowPackage(adbPath, target) {
  const result = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "dumpsys", "window"],
    timeoutMs: 8000,
  });
  const text = `${result.stdout || ""}\n${result.stderr || ""}`;
  const line = text.split(/\r?\n/).find((item) => /mCurrentFocus|mFocusedApp/.test(item) && /\//.test(item));
  return cleanText(line || "", 300);
}

function swipeAgentPlannedSeconds(target) {
  return Math.max(0, Number(target.totalRequestedMinutes || target.requestedMinutes || target.currentMinutes || 0) * 60);
}

function swipeAgentRemainingMinutes(target) {
  const plannedSeconds = swipeAgentPlannedSeconds(target);
  const elapsedSeconds = Math.max(0, Number(target.elapsedSeconds || target.completedSeconds || 0));
  const remainingSeconds = Math.max(0, plannedSeconds - elapsedSeconds);
  return roundSwipeAgentMinutes(Math.ceil(remainingSeconds / 60));
}

function requestSwipeAgentStop(job, target, reason) {
  if (!job || !target || target.stopSentAt) return;
  target.stopSentAt = new Date().toISOString();
  sendSwipeAgentStop(job.adbPath, target)
    .then((result) => {
      if (!result.ok) {
        target.lastError = result.stderr || result.stdout || result.forceStopStderr || result.forceStopStdout || "Swipe Agent stop failed";
        appendSwipeAgentLog(job, `${target.label || target.serial}: stop NG after ${reason} ${target.lastError}`);
      } else {
        appendSwipeAgentLog(job, `${target.label || target.serial}: stop OK after ${reason}`);
      }
      persistSwipeAgentJobs();
    })
    .catch((error) => {
      target.lastError = error.message;
      appendSwipeAgentLog(job, `${target.label || target.serial}: stop error after ${reason} ${error.message}`);
      persistSwipeAgentJobs();
    });
}

async function isSwipeAgentInstalled(adbPath, target) {
  const result = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "pm", "path", SWIPE_AGENT_PACKAGE_NAME],
    timeoutMs: 8000,
  });
  return { ...result, ok: result.ok && /package:/i.test(result.stdout || "") };
}

async function sendSwipeAgentStart(adbPath, target, minutes, jobId, options = {}) {
  await wakeSwipeAgent(adbPath, target);
  const broadcast = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: [
      "shell", "am", "broadcast", "--receiver-foreground", "-p", SWIPE_AGENT_PACKAGE_NAME,
      "-a", SWIPE_AGENT_ACTION_START,
      "--ei", "minutes", String(roundSwipeAgentMinutes(minutes)),
      "--es", "jobId", String(jobId || ""),
    ],
    timeoutMs: 12000,
  });
  const shouldLaunchTtl = options.launchTtl !== false;
  const ttl = shouldLaunchTtl ? await launchTtlOnTarget(adbPath, target) : { ok: true, stdout: "", stderr: "" };
  return {
    ...broadcast,
    ttlLaunched: shouldLaunchTtl && ttl.ok,
    ttlStdout: ttl.stdout,
    ttlStderr: ttl.stderr,
  };
}

async function sendSwipeAgentStop(adbPath, target) {
  const broadcast = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "am", "broadcast", "--receiver-foreground", "-p", SWIPE_AGENT_PACKAGE_NAME, "-a", SWIPE_AGENT_ACTION_STOP],
    timeoutMs: 10000,
  });
  await sleep(500);
  const forceStop = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "am", "force-stop", SWIPE_AGENT_PACKAGE_NAME],
    timeoutMs: 8000,
  });
  return {
    ...broadcast,
    forceStopped: forceStop.ok,
    forceStopStdout: forceStop.stdout,
    forceStopStderr: forceStop.stderr,
    ok: broadcast.ok || forceStop.ok,
  };
}

async function wakeSwipeAgent(adbPath, target) {
  const result = await launchAppOnTarget(adbPath, target, SWIPE_AGENT_PACKAGE_NAME);
  await sleep(800);
  return result;
}

async function installSelectedApksForTargets(body = {}) {
  const requestedTargets = Array.isArray(body.targets) ? body.targets : [];
  if (!requestedTargets.length) {
    return { ok: false, error: "APKを入れる端末が選択されていません。", targeted: 0, succeeded: 0, failed: 0, results: [] };
  }
  if (normalizeTargetKeys(requestedTargets).length !== requestedTargets.length) {
    return {
      ok: false,
      status: 400,
      code: "INVALID_APK_INSTALL_TARGETS",
      error: "APKインストール対象に空または重複した端末が含まれています。",
      targeted: requestedTargets.length,
      succeeded: 0,
      failed: 0,
      results: [],
    };
  }
  const apkDir = path.join(paths.root, "data", "apk");
  const selection = resolveApkSelection(apkDir, body.files);
  if (!selection.ok) {
    return { ok: false, error: selection.error, targeted: requestedTargets.length, succeeded: 0, failed: 0, results: [] };
  }
  const fileNames = selection.files.map((item) => item.name);
  const targetLock = apkInstallTargetLock.tryAcquire(requestedTargets);
  if (!targetLock.ok) {
    return {
      ok: false,
      status: 409,
      code: "APK_INSTALL_ALREADY_RUNNING",
      error: "同じ端末へのAPKインストールが進行中です。完了するまで再操作しないでください。",
      files: fileNames,
      fileCount: fileNames.length,
      targeted: requestedTargets.length,
      succeeded: 0,
      failed: 0,
      conflictCount: targetLock.conflictCount,
      results: [],
    };
  }
  try {
    const result = await runAdbActionForConnectedDevices("install_apk_files", {
      skipActiveGroup: false,
      targets: requestedTargets,
      apkFiles: fileNames,
      concurrency: clampInteger(body.concurrency || 2, 1, 4),
    });
    persistTtlLineInstallResults(result.results || []);
    return {
      ...result,
      files: fileNames,
      fileCount: fileNames.length,
    };
  } finally {
    targetLock.release();
  }
}

async function launchTtlOnTarget(adbPath, target) {
  return launchFirstAvailableAppOnTarget(adbPath, target, TIKTOK_LITE_PACKAGE_NAMES);
}

async function forceStopPackagesOnTarget(adbPath, target, packageNames, timeoutMs = 10000) {
  const results = [];
  for (const packageName of packageNames) {
    const result = await runAdbCommand({
      adbPath,
      adbPort: target.adbPort,
      serial: target.serial,
      adbArgs: ["shell", "am", "force-stop", packageName],
      timeoutMs,
    });
    results.push({ ...result, packageName });
  }
  const ok = results.some((result) => result.ok);
  return {
    ok,
    results,
    stdout: results.map((result) => result.stdout).filter(Boolean).join("\n"),
    stderr: results.map((result) => result.stderr || result.error).filter(Boolean).join("\n"),
  };
}

async function launchFirstAvailableAppOnTarget(adbPath, target, packageNames, timeoutMs = 12000) {
  const results = [];
  for (const packageName of packageNames) {
    const result = await launchAppOnTarget(adbPath, target, packageName, timeoutMs);
    results.push({ ...result, packageName });
    if (result.ok) return { ...result, packageName, attempts: results };
  }
  const last = results[results.length - 1] || {};
  return {
    ...last,
    ok: false,
    packageName: packageNames[0] || "",
    attempts: results,
    error: results.map((result) => result.stderr || result.stdout || result.error).filter(Boolean).join("\n") || "launch failed",
  };
}

async function launchAppOnTarget(adbPath, target, packageName, timeoutMs = 12000) {
  return runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", "am", "start", "-a", "android.intent.action.MAIN", "-c", "android.intent.category.LAUNCHER", "-p", packageName],
    timeoutMs,
  });
}

async function readSwipeAgentStatus(adbPath, target) {
  const result = await runAdbCommand({
    adbPath,
    adbPort: target.adbPort,
    serial: target.serial,
    adbArgs: ["shell", `cat ${shellWord(SWIPE_AGENT_STATUS_PATH)} 2>/dev/null || true`],
    timeoutMs: 8000,
  });
  const text = String(result.stdout || "").trim();
  if (!result.ok || !text) return { ...result, ok: false, status: null };
  try {
    return { ...result, ok: true, status: JSON.parse(text) };
  } catch (error) {
    return { ...result, ok: false, status: null, error: `status JSON parse failed: ${error.message}` };
  }
}

function normalizeSwipeAgentStatus(status) {
  const elapsedSeconds = Number(status.elapsedSeconds || status.elapsed || 0);
  const swipeCount = Number(status.swipeCount || status.swipes || 0);
  const updatedAtMs = Number(status.updatedAtMs || 0);
  return {
    ...status,
    elapsedSeconds: Number.isFinite(elapsedSeconds) ? elapsedSeconds : 0,
    swipeCount: Number.isFinite(swipeCount) ? swipeCount : 0,
    state: cleanText(status.state || status.status, 40),
    updatedAt: cleanText(status.updatedAt || status.lastUpdateAt || (updatedAtMs ? new Date(updatedAtMs).toISOString() : ""), 80),
  };
}

function isSwipeAgentStatusFresh(status, maxAgeSeconds = 60) {
  const updatedAtMs = Number(status && status.updatedAtMs || 0);
  const updatedAt = updatedAtMs || Date.parse(status && status.updatedAt || 0);
  if (!updatedAt || !Number.isFinite(updatedAt)) return false;
  return Math.abs(Date.now() - updatedAt) <= Math.max(10, Number(maxAgeSeconds || 60)) * 1000;
}

function listSwipeAgentJobs() {
  pruneSwipeAgentJobs();
  return {
    ok: true,
    jobs: [...swipeAgentJobs.values()]
      .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
      .slice(0, 20)
      .map(serializeSwipeAgentJob),
  };
}

function getSwipeAgentJobStatus(jobId) {
  const job = swipeAgentJobs.get(jobId);
  if (!job) return { ok: false, error: "Swipe Agent job not found.", jobId };
  return { ok: true, job: serializeSwipeAgentJob(job) };
}

function stopSwipeAgentJob(jobId) {
  const job = swipeAgentJobs.get(jobId);
  if (!job) return { ok: false, error: "Swipe Agent job not found.", jobId };
  job.stopRequested = true;
  if (job.status === "running") job.status = "stopping";
  appendSwipeAgentLog(job, "stop requested");
  for (const fallbackJobId of job.fallbackAdbJobIds || []) {
    const fallbackJob = adbSwipeJobs.get(fallbackJobId);
    if (fallbackJob && ["running", "stopping"].includes(fallbackJob.status || "")) {
      stopAdbSwipeJob(fallbackJobId);
      appendSwipeAgentLog(job, `fallback ADB stop requested: ${fallbackJobId}`);
    }
  }
  for (const target of job.devices || []) {
    if (["starting", "running"].includes(target.state || "")) {
      sendSwipeAgentStop(job.adbPath, target).catch((error) => appendSwipeAgentLog(job, `${target.label || target.serial}: stop error ${error.message}`));
    }
  }
  persistSwipeAgentJobs();
  return { ok: true, job: serializeSwipeAgentJob(job) };
}

async function stopAllSwipeWork(body = {}) {
  const config = readFleetMonitorConfig();
  const adbPath = body.adbPath || config.adbPath || resolveAdbPath();
  if (!adbPath || !fs.existsSync(adbPath)) return { ok: false, error: "ADB was not found.", adbPath };

  const activeStatuses = new Set(["running", "stopping"]);
  const agentJobs = [...swipeAgentJobs.values()].filter((job) => activeStatuses.has(job.status || ""));
  const adbJobs = [...adbSwipeJobs.values()].filter((job) => activeStatuses.has(job.status || ""));
  const requestedTargets = Array.isArray(body.targets) ? body.targets : [];
  const selectedOnly = body.selectedOnly === true && requestedTargets.length > 0 && body.includeConnected !== true;
  const requestedSerials = new Set(requestedTargets.map((target) => cleanText(target && target.serial, 80)).filter(Boolean));
  const targetMap = new Map();

  const addTarget = (target, source) => {
    if (!target || !target.serial) return;
    const serial = cleanText(target.serial, 80);
    if (!serial) return;
    const existing = targetMap.get(serial) || {};
    targetMap.set(serial, {
      ...existing,
      ...target,
      serial,
      adbPort: target.adbPort === undefined || target.adbPort === "" ? (existing.adbPort || null) : target.adbPort,
      label: cleanText(target.label || existing.label || target.laixiNumber || serial, 120),
      source: existing.source ? `${existing.source},${source}` : source,
    });
  };

  if (!selectedOnly) {
    for (const job of agentJobs) {
      for (const target of job.devices || []) addTarget(target, "agent-job");
    }
    for (const job of adbJobs) {
      for (const target of job.devices || []) addTarget(target, "adb-job");
    }
  }
  for (const target of requestedTargets) addTarget(target, "request");

  const includeConnected = body.includeConnected === true;
  let connectedCount = 0;
  let connectedWarning = "";
  if (includeConnected) {
    const ports = await resolveActiveAdbPorts();
    const summary = buildFleetDbSummary();
    const dbBySerial = new Map((summary.devices || []).filter((row) => row.serial).map((row) => [String(row.serial), row]));
    const seenConnected = new Set();
    const warnings = [];
    for (const adbPort of ports) {
      const scan = await scanAdbDevices({ adbPath, adbPort });
      if (scan.warning) warnings.push(scan.warning);
      for (const device of scan.devices || []) {
        if (!device.serial || device.status !== "device" || seenConnected.has(device.serial)) continue;
        seenConnected.add(device.serial);
        const row = dbBySerial.get(String(device.serial)) || {};
        addTarget({
          serial: device.serial,
          adbPort: device.adbPort || null,
          laixiNumber: row.laixiNumber || "",
          label: row.deviceLabel || row.name || device.model || device.serial,
        }, "connected");
      }
    }
    connectedCount = seenConnected.size;
    connectedWarning = warnings.join("; ");
  }

  const agentStopResults = selectedOnly ? stopSwipeAgentTargets(agentJobs, requestedSerials) : agentJobs.map((job) => stopSwipeAgentJob(job.jobId));
  const adbStopResults = selectedOnly ? stopAdbSwipeTargets(adbJobs, requestedSerials) : adbJobs.map((job) => stopAdbSwipeJob(job.jobId));
  const targets = [...targetMap.values()];
  const directResults = [];
  const concurrency = clampInteger(body.concurrency || 16, 1, 32);

  await runWithConcurrency(targets, concurrency, async (target) => {
    const result = await sendSwipeAgentStop(adbPath, target).catch((error) => ({ ok: false, error: error.message }));
    if (selectedOnly) markSwipeAgentTargetStopped(agentJobs, target.serial, result);
    directResults.push({
      serial: target.serial,
      label: target.label || target.serial,
      adbPort: target.adbPort || null,
      source: target.source || "",
      ok: Boolean(result.ok),
      forceStopped: Boolean(result.forceStopped),
      error: result.error || result.stderr || result.forceStopStderr || "",
    });
  });

  const directSucceeded = directResults.filter((result) => result.ok).length;
  const directFailed = directResults.length - directSucceeded;
  return {
    ok: true,
    adbPath,
    selectedOnly,
    includeConnected,
    connectedCount,
    connectedWarning,
    agentJobs: agentJobs.length,
    adbJobs: adbJobs.length,
    agentStopOk: agentStopResults.filter((result) => result.ok).length,
    adbStopOk: adbStopResults.filter((result) => result.ok).length,
    directTargets: targets.length,
    directSucceeded,
    directFailed,
    directResults,
  };
}

function stopSwipeAgentTargets(jobs, serials) {
  const results = [];
  for (const job of jobs) {
    let count = 0;
    for (const target of job.devices || []) {
      if (!serials.has(String(target.serial || ""))) continue;
      if (!["queued", "starting", "running", "stopping", "adb_fallback"].includes(target.state || "")) continue;
      target.state = "stopping";
      target.lastError = "selected stop requested";
      count += 1;
    }
    if (!count) continue;
    appendSwipeAgentLog(job, `selected stop requested: ${count} devices`);
    results.push({ ok: true, jobId: job.jobId, targets: count });
  }
  return results;
}

function markSwipeAgentTargetStopped(jobs, serial, stopResult) {
  for (const job of jobs) {
    let changed = false;
    for (const target of job.devices || []) {
      if (String(target.serial || "") !== String(serial || "")) continue;
      if (!["queued", "starting", "running", "stopping", "adb_fallback"].includes(target.state || "")) continue;
      target.state = stopResult && stopResult.ok ? "stopped" : "failed";
      target.finishedAt = new Date().toISOString();
      target.lastError = stopResult && stopResult.ok ? "stopped by selected stop" : (stopResult.error || stopResult.stderr || "selected stop failed");
      changed = true;
    }
    if (changed) finishSwipeAgentJobIfDone(job);
  }
}

function stopAdbSwipeTargets(jobs, serials) {
  const results = [];
  for (const job of jobs) {
    let count = 0;
    for (const target of job.devices || []) {
      if (!serials.has(String(target.serial || ""))) continue;
      if (!["queued", "running", "stopping"].includes(target.state || "")) continue;
      target.stopRequested = true;
      target.state = "stopping";
      target.lastError = "selected stop requested via ADB";
      count += 1;
    }
    if (!count) continue;
    appendAdbSwipeJobLog(job, `selected stop requested: ${count} devices`);
    results.push({ ok: true, jobId: job.jobId, targets: count });
  }
  return results;
}

function finishSwipeAgentJobIfDone(job) {
  const active = (job.devices || []).filter((target) => ["queued", "starting", "running"].includes(target.state || ""));
  if (active.length) return;
  if (job.monitorTimer) {
    clearInterval(job.monitorTimer);
    job.monitorTimer = null;
  }
  job.finishedAt = new Date().toISOString();
  if (job.stopRequested) job.status = "stopped";
  else if ((job.devices || []).some((target) => target.state === "failed")) job.status = "failed";
  else job.status = "done";
  appendSwipeAgentLog(job, `job ${job.status}`);
  persistSwipeAgentJobs();
}

function serializeSwipeAgentJob(job) {
  const devices = (job.devices || []).map((device) => ({ ...device }));
  return {
    ok: true,
    jobId: job.jobId,
    status: job.status,
    createdAt: job.createdAt,
    startedAt: job.startedAt,
    finishedAt: job.finishedAt,
    monitorIntervalSeconds: job.monitorIntervalSeconds,
    staleSeconds: job.staleSeconds,
    stopRequested: Boolean(job.stopRequested),
    fallbackAdbJobIds: Array.isArray(job.fallbackAdbJobIds) ? job.fallbackAdbJobIds.slice() : [],
    totals: {
      devices: devices.length,
      running: devices.filter((device) => ["queued", "starting", "running"].includes(device.state || "")).length,
      done: devices.filter((device) => device.state === "done").length,
      stopped: devices.filter((device) => device.state === "stopped").length,
      missing: devices.filter((device) => device.state === "missing").length,
      failed: devices.filter((device) => device.state === "failed").length,
      adbFallback: devices.filter((device) => device.state === "adb_fallback").length,
      restarts: devices.reduce((sum, device) => sum + Number(device.restartCount || 0), 0),
      swipes: devices.reduce((sum, device) => sum + Number(device.swipeCount || 0), 0),
    },
    devices,
    logs: (job.logs || []).slice(-160),
  };
}

function appendSwipeAgentLog(job, message) {
  job.logs = Array.isArray(job.logs) ? job.logs : [];
  job.logs.push({ at: new Date().toISOString(), message: cleanText(message, 300) });
  if (job.logs.length > 1200) job.logs = job.logs.slice(-1200);
  persistSwipeAgentJobs();
}

function swipeAgentJobsPath() {
  return path.join(paths.dataDir, "swipe-agent-jobs.json");
}

function persistSwipeAgentJobs() {
  const jobs = [...swipeAgentJobs.values()].map((job) => {
    const { monitorTimer, ...plain } = job;
    return {
      ...plain,
      logs: Array.isArray(plain.logs) ? plain.logs.slice(-1200) : [],
      devices: Array.isArray(plain.devices) ? plain.devices.map((device) => ({ ...device })) : [],
    };
  });
  writeJsonFile(swipeAgentJobsPath(), { schemaVersion: 1, updatedAt: new Date().toISOString(), jobs });
}

function restoreSwipeAgentJobs() {
  const data = readJsonFile(swipeAgentJobsPath(), { jobs: [] });
  const jobs = Array.isArray(data.jobs) ? data.jobs : [];
  let restored = 0;
  for (const saved of jobs
    .filter((job) => job && job.jobId)
    .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
    .slice(0, 20)) {
    if (!saved || !saved.jobId) continue;
    const job = {
      ...saved,
      monitorTimer: null,
      logs: Array.isArray(saved.logs) ? saved.logs : [],
      devices: Array.isArray(saved.devices) ? saved.devices : [],
    };
    swipeAgentJobs.set(job.jobId, job);
    if (["running", "stopping"].includes(job.status || "")) {
      appendSwipeAgentLog(job, "monitor restored after server restart");
      startSwipeAgentMonitor(job);
    }
    restored++;
  }
  if (restored) console.log(`Restored ${restored} Swipe Agent job(s).`);
}

function pruneSwipeAgentJobs() {
  const jobs = [...swipeAgentJobs.values()].sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  const keepIds = new Set(jobs.slice(0, 20).map((job) => job.jobId));
  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  for (const job of jobs) {
    const running = job.status === "running" || job.status === "stopping";
    if (running) continue;
    if (!keepIds.has(job.jobId) || Date.parse(job.createdAt || 0) < cutoff) swipeAgentJobs.delete(job.jobId);
  }
}

function roundSwipeAgentMinutes(value) {
  const minutes = Math.ceil(clampInteger(value || 10, 1, 100) / 10) * 10;
  return Math.max(10, Math.min(100, minutes));
}

function shellWord(value) {
  const text = String(value || "");
  if (/^[A-Za-z0-9_./:-]+$/.test(text)) return text;
  return `'${text.replace(/'/g, "'\\''")}'`;
}

async function runWithConcurrency(items, limit, worker) {
  const queue = [...items];
  const workers = Array.from({ length: Math.max(1, Math.min(limit, queue.length || 1)) }, async () => {
    while (queue.length) {
      const item = queue.shift();
      await worker(item);
    }
  });
  await Promise.all(workers);
}

function clampInteger(value, min, max) {
  const number = Math.floor(Number(value));
  if (!Number.isFinite(number)) return min;
  return Math.max(min, Math.min(max, number));
}

function randomInteger(min, max) {
  const low = Math.ceil(Math.min(min, max));
  const high = Math.floor(Math.max(min, max));
  return low + Math.floor(Math.random() * (high - low + 1));
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, Math.max(0, ms)));
}

function localTimestampForId() {
  const date = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join("");
}

function fleetConnectionHistoryPath() {
  return path.join(paths.dataDir, "fleet-db", "connection-history.json");
}

function readFleetConnectionHistory() {
  return normalizeConnectionHistory(readJsonFile(fleetConnectionHistoryPath(), {}));
}

function recordFleetConnectionSnapshot(options = {}) {
  if (!options.available) return { changed: false, events: [] };
  try {
    const summaryDevices = Array.isArray(options.summaryDevices) ? options.summaryDevices : [];
    const adbDevices = Array.isArray(options.adbDevices) ? options.adbDevices : [];
    const serials = summaryDevices.map((row) => cleanText(row && row.serial, 80)).filter(Boolean);
    const statuses = Object.fromEntries(adbDevices
      .filter((row) => row && row.serial)
      .map((row) => [cleanText(row.serial, 80), cleanText(row.status, 40) || (row.connected ? "device" : "missing")]));
    const result = observeAdbConnectionSnapshot(readFleetConnectionHistory(), {
      serials,
      statuses,
      observedAt: new Date().toISOString(),
      confirmationCount: 2,
      minConfirmIntervalMs: 10000,
      maxIncidents: 200,
    });
    if (result.changed) writeJsonFile(fleetConnectionHistoryPath(), result.history);
    for (const event of result.events) {
      appendAuditLog({
        type: `adb_connection_${event.type}`,
        serial: event.serial,
        title: event.type === "confirmed" ? "ADB切断を記録" : "ADB接続が復旧",
        level: event.type === "confirmed" ? "warn" : "info",
        details: event.incident,
      });
    }
    return { changed: result.events.length > 0, events: result.events };
  } catch (error) {
    console.warn("Failed to record ADB connection history:", error.message);
    return { changed: false, events: [], warning: error.message };
  }
}

function ignoreFleetConnectionIncidents(body = {}) {
  const requested = Array.isArray(body.serials) ? body.serials.map((serial) => cleanText(serial, 80)).filter(Boolean) : [];
  if (!requested.length) return { ok: false, error: "対象端末がありません" };
  const summary = buildFleetDbSummary();
  const known = new Set((summary.devices || []).map((row) => cleanText(row.serial, 80)).filter(Boolean));
  const serials = [...new Set(requested.filter((serial) => known.has(serial)))];
  if (!serials.length) return { ok: false, error: "管理対象の端末がありません" };
  const result = ignoreConnectionIncidents(readFleetConnectionHistory(), {
    serials,
    ignoredAt: new Date().toISOString(),
  });
  if (result.changed) writeJsonFile(fleetConnectionHistoryPath(), result.history);
  for (const event of result.events) {
    appendAuditLog({
      type: "adb_connection_ignored",
      serial: event.serial,
      title: "意図的な取り外しとして切断集計から除外",
      level: "info",
      details: event.incident,
    });
  }
  return {
    ok: true,
    serials,
    ignored: result.events.length,
    message: "再接続するまで切断履歴の集計対象から外しました",
  };
}

function recordFleetRecoveryAttempts(serials, options = {}) {
  try {
    const result = recordRecoveryAttempts(readFleetConnectionHistory(), {
      serials,
      at: new Date().toISOString(),
      source: "usb-auto-repair",
      requestId: options.requestId || "",
      deepRepair: options.deepRepair !== false,
    });
    if (result.changed) writeJsonFile(fleetConnectionHistoryPath(), result.history);
    return { changed: result.changed, count: result.events.length };
  } catch (error) {
    console.warn("Failed to record USB recovery attempts:", error.message);
    return { changed: false, count: 0, warning: error.message };
  }
}

async function listAdbDevicesForUi(options = {}) {
  const includeUptime = options.includeUptime !== false;
  const includeFacts = options.includeFacts === true;
  const persistFacts = options.persistFacts === true;
  const config = readFleetMonitorConfig();
  const adbPath = config.adbPath || resolveAdbPath();
  const ports = await resolveActiveAdbPorts();
  const scans = await Promise.all(ports.map((adbPort) => scanAdbDevices({ adbPath, adbPort })));

  const summary = buildFleetDbSummaryCached();
  const dbBySerial = new Map((summary.devices || []).filter((row) => row.serial).map((row) => [String(row.serial), row]));
  const devices = [];
  const seen = new Set();
  for (const scan of scans) {
    for (const device of scan.devices || []) {
      if (!device.serial || seen.has(device.serial)) continue;
      seen.add(device.serial);
      const row = dbBySerial.get(String(device.serial)) || {};
      devices.push({
        serial: device.serial,
        status: device.status || "",
        connected: device.status === "device",
        adbPort: device.adbPort || null,
        model: device.model || "",
        product: device.product || "",
        device: device.device || "",
        laixiNumber: row.laixiNumber || "",
        label: row.deviceLabel || row.name || device.model || device.serial,
        group: row.group || "",
        tags: row.tags || [],
      });
    }
  }
  const connectionHistoryResult = recordFleetConnectionSnapshot({
    available: scans.some((scan) => scan.available),
    summaryDevices: summary.devices || [],
    adbDevices: devices,
  });
  if (includeUptime) {
    await runWithConcurrency(devices.filter((device) => device.connected), 12, async (device) => {
      const [uptime, battery] = await Promise.all([
        readAdbUptimeSeconds(adbPath, device),
        readAdbBatteryPercent(adbPath, device),
      ]);
      device.uptimeSeconds = uptime.seconds;
      device.uptimeRaw = uptime.raw;
      device.uptimeError = uptime.error;
      device.batteryPercent = battery.percent;
      device.batteryRaw = battery.raw;
      device.batteryError = battery.error;
    });
  }
  if (includeFacts) {
    await runWithConcurrency(devices.filter((device) => device.connected), 10, async (device) => {
      const facts = await readAdbDeviceInviteFacts(adbPath, device);
      Object.assign(device, facts);
    });
  }
  if (persistFacts && (includeUptime || includeFacts)) {
    persistAdbDeviceInviteFacts(devices);
  }

  return {
    ok: scans.some((scan) => scan.available),
    adbPath,
    ports: scans.map((scan) => ({ port: scan.port || null, available: scan.available, count: (scan.devices || []).length, warning: scan.warning || "" })),
    warning: scans.filter((scan) => scan.warning).map((scan) => scan.warning).join("; "),
    devices,
    connected: devices.filter((device) => device.connected).length,
    includeUptime,
    includeFacts,
    connectionHistoryChanged: connectionHistoryResult.changed,
    connectionHistoryEvents: connectionHistoryResult.events,
  };
}

function parseAdbPropertyDump(value) {
  const properties = {};
  for (const line of String(value || "").split(/\r?\n/)) {
    const match = line.match(/^\[([^\]]+)\]:\s*\[(.*)\]\s*$/);
    if (!match) continue;
    properties[match[1]] = match[2];
  }
  return properties;
}

function simCarrierFamilyDisplay(value) {
  if (value === "KDDI") return "KDDI回線";
  if (value === "SoftBank") return "SoftBank回線";
  if (value === "docomo") return "docomo回線";
  if (value === "Rakuten") return "楽天回線";
  return "";
}

function simStateDisplay(value) {
  const state = String(value || "").toUpperCase();
  if (state === "LOADED" || state === "READY") return "利用可能";
  if (state === "ABSENT") return "SIMなし";
  if (state === "NOT_READY" || state === "UNKNOWN") return "状態不明";
  if (state === "CARD_IO_ERROR") return "SIMエラー";
  if (state === "PIN_REQUIRED") return "PIN入力待ち";
  if (state === "PUK_REQUIRED") return "PUK入力待ち";
  if (state === "NETWORK_LOCKED") return "ネットワークロック";
  if (state === "CARD_RESTRICTED" || state === "PERM_DISABLED") return "SIM制限";
  return state || "状態不明";
}

function normalizeAdbSimInfoForUi(parsed) {
  const subscriptions = (parsed.subscriptions || []).map((subscription) => {
    const carrier = String(subscription.carrierLabel || "不明");
    const carrierConfidence = subscription.carrierSource === "android_carrier_id"
      ? "android-carrier-id"
      : /系$/.test(carrier)
      || subscription.carrierSource === "mccmnc"
      ? "network-family"
      : carrier === "不明"
        ? "unknown"
        : "brand";
    return {
      slotIndex: Number(subscription.slotIndex),
      subscriptionId: normalizeNullableSubscriptionId(subscription.subscriptionId),
      state: String(subscription.state || ""),
      stateLabel: simStateDisplay(subscription.state),
      carrier,
      carrierFamily: simCarrierFamilyDisplay(subscription.carrierFamily),
      carrierConfidence,
      carrierSource: String(subscription.carrierSource || ""),
      operatorNumeric: String(subscription.mccmnc || ""),
      apnRecommendation: {
        status: ["exact", "ambiguous", "none"].includes(subscription.apnRecommendation?.status)
          ? subscription.apnRecommendation.status
          : "none",
        profileId: String(subscription.apnRecommendation?.profileId || ""),
        candidateProfileIds: (Array.isArray(subscription.apnRecommendation?.candidateProfileIds)
          ? subscription.apnRecommendation.candidateProfileIds
          : []).map((value) => String(value || "")).filter(Boolean),
      },
      serviceStatus: String(subscription.serviceStatus || "unknown"),
      serviceLabel: String(subscription.serviceLabel || "回線状態不明"),
      lineContractStatus: "not_determinable",
    };
  });
  return {
    subscriptions,
    simCount: subscriptions.length,
    simStatus: String(parsed.simStatus || ""),
    simStatusCode: String(parsed.simStatusCode || "unknown"),
    lineContractStatus: "not_determinable",
    warning: parsed.warning || "",
  };
}

function normalizeNullableSubscriptionId(value) {
  if (value === undefined || value === null || value === "") return null;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= 0 ? parsed : null;
}

function parseAdbCarrierIdentityOutput(value, subscriptionId) {
  const text = String(value || "");
  const carrierId = Number((text.match(/\bcarrier_id\s*=\s*(\d+)/i) || [])[1]);
  const carrierName = String((text.match(/\bcarrier_name\s*=\s*([^,\r\n]+)/i) || [])[1] || "").trim();
  if (!Number.isSafeInteger(carrierId) && !carrierName) return null;
  return {
    subscriptionId,
    carrierId: Number.isSafeInteger(carrierId) ? carrierId : null,
    carrierName,
  };
}

function parseAdbSpecificCarrierIdentities(value, subscriptions = []) {
  const text = String(value || "");
  if (!text.trim() || /permission denial|securityexception/i.test(text)) return [];
  const headers = [...text.matchAll(/(?:^|\r?\n)\s*Phone(?:\s+Id)?\s*[:=]\s*(\d+)\s*(?=\r?\n|$)/gim)];
  const blocks = headers.length
    ? headers.map((match, index) => ({
      slotIndex: Number(match[1]),
      text: text.slice(
        Number(match.index || 0) + match[0].length,
        index + 1 < headers.length ? Number(headers[index + 1].index || text.length) : text.length,
      ),
    }))
    : [{ slotIndex: 0, text }];
  const rows = [];
  for (const block of blocks) {
    const idMatch = block.text.match(/\bmSpecificCarrierId\s*[:=]\s*(\d+)/i);
    const nameMatch = block.text.match(/\bmSpecificCarrierName\s*[:=]\s*([^\r\n,}\]]+)/i);
    const carrierId = Number(idMatch?.[1]);
    const carrierName = String(nameMatch?.[1] || "")
      .replace(/^["']|["']$/g, "")
      .trim()
      .slice(0, 80);
    const validId = Number.isSafeInteger(carrierId) && carrierId > 0;
    const validName = carrierName && !/^(?:null|unknown|n\/a)$/i.test(carrierName);
    if (!validId && !validName) continue;
    const subscription = subscriptions.find((item) => Number(item.slotIndex) === block.slotIndex);
    rows.push({
      subscriptionId: Number.isSafeInteger(subscription?.subscriptionId) ? subscription.subscriptionId : null,
      carrierId: validId ? carrierId : null,
      carrierName: validName ? carrierName : "",
    });
  }
  return rows;
}

function parseAdbServiceStates(value) {
  const text = String(value || "");
  const states = [];
  const blocks = text.match(/mServiceState=\{[^}\r\n]*/gi) || [];
  for (const block of blocks) {
    const data = block.match(/\bmDataRegState\s*=\s*(\d+)(?:\(([^)]+)\))?/i);
    const voice = block.match(/\bmVoiceRegState\s*=\s*(\d+)(?:\(([^)]+)\))?/i);
    const selected = data || voice;
    if (!selected) continue;
    states.push(selected[2] || selected[1]);
  }
  return states;
}

async function readAdbSimInfo(adbPath, device) {
  const [propertyResult, subscriptionResult, serviceStateResult, phoneResult] = await Promise.all([
    runAdbCommand({
      adbPath,
      adbPort: device.adbPort || null,
      serial: device.serial,
      adbArgs: ["shell", "getprop"],
      timeoutMs: 7000,
    }),
    runAdbCommand({
      adbPath,
      adbPort: device.adbPort || null,
      serial: device.serial,
      adbArgs: ["shell", "dumpsys", "isub"],
      timeoutMs: 9000,
    }),
    runAdbCommand({
      adbPath,
      adbPort: device.adbPort || null,
      serial: device.serial,
      adbArgs: ["shell", "dumpsys", "telephony.registry"],
      timeoutMs: 9000,
    }),
    runAdbCommand({
      adbPath,
      adbPort: device.adbPort || null,
      serial: device.serial,
      adbArgs: ["shell", "dumpsys", "phone"],
      timeoutMs: 9000,
    }),
  ]);
  const properties = parseAdbPropertyDump(propertyResult.stdout);
  const subscriptions = parseSubscriptionDump(subscriptionResult.stdout || "");
  const regularCarrierIdentities = (await Promise.all(subscriptions
    .filter((subscription) => Number.isSafeInteger(subscription.subscriptionId))
    .map(async (subscription) => {
      const result = await runAdbCommand({
        adbPath,
        adbPort: device.adbPort || null,
        serial: device.serial,
        adbArgs: [
          "shell",
          "content",
          "query",
          "--uri",
          `content://carrier_id/${subscription.subscriptionId}`,
          "--projection",
          "carrier_id:carrier_name",
        ],
        timeoutMs: 5000,
      });
      return result.ok ? parseAdbCarrierIdentityOutput(result.stdout, subscription.subscriptionId) : null;
    }))).filter(Boolean);
  const carrierIdentities = [
    ...parseAdbSpecificCarrierIdentities(phoneResult.stdout || "", subscriptions),
    ...regularCarrierIdentities,
  ];
  const parsed = buildDeviceSimInfo({
    simState: properties["gsm.sim.state"] || "",
    simOperatorAlpha: properties["gsm.sim.operator.alpha"] || "",
    operatorAlpha: properties["gsm.operator.alpha"] || "",
    simOperatorNumeric: properties["gsm.sim.operator.numeric"] || "",
    operatorNumeric: properties["gsm.operator.numeric"] || "",
    subscriptionDump: subscriptionResult.stdout || "",
    carrierIdentities,
    serviceStates: parseAdbServiceStates(serviceStateResult.stdout || ""),
  });
  const normalized = normalizeAdbSimInfoForUi(parsed);
  const warnings = [];
  if (!propertyResult.ok) warnings.push("SIM_PROPERTY_UNAVAILABLE");
  if (!subscriptionResult.ok) warnings.push("SUBSCRIPTION_INFO_UNAVAILABLE");
  if (!serviceStateResult.ok) warnings.push("SERVICE_STATE_UNAVAILABLE");
  if (normalized.warning) warnings.push(normalized.warning);
  return {
    ...normalized,
    warning: [...new Set(warnings)].join(","),
  };
}

async function listAdbSimInfoForUi() {
  const adbDevices = await listAdbDevicesForUi({ includeUptime: false, includeFacts: false });
  const config = readFleetMonitorConfig();
  const adbPath = config.adbPath || adbDevices.adbPath || resolveAdbPath();
  const devices = (adbDevices.devices || []).filter((device) => device.connected).map((device) => ({ ...device }));
  await runWithConcurrency(devices, 8, async (device) => {
    try {
      Object.assign(device, await readAdbSimInfo(adbPath, device));
    } catch {
      device.subscriptions = [];
      device.simCount = 0;
      device.warning = "SIM_INFO_READ_FAILED";
    }
  });
  const warningCount = devices.filter((device) => device.warning).length;
  return {
    ok: adbDevices.ok,
    connected: devices.length,
    simCount: devices.reduce((sum, device) => sum + Number(device.simCount || 0), 0),
    warning: adbDevices.warning || (warningCount ? `${warningCount}台で一部情報を取得できませんでした。` : ""),
    devices: devices.map((device) => ({
      serial: device.serial,
      adbPort: device.adbPort || null,
      label: device.label,
      laixiNumber: device.laixiNumber,
      model: device.model,
      status: device.status,
      simCount: device.simCount,
      simStatus: device.simStatus,
      simStatusCode: device.simStatusCode,
      lineContractStatus: "not_determinable",
      warning: device.warning,
      subscriptions: device.subscriptions,
    })),
  };
}

async function listAdbSimInfoForUiSingleFlight(options = {}) {
  if (options.fresh) {
    if (adbSimInfoFlight) {
      try {
        await adbSimInfoFlight;
      } catch {
        // A fresh APN decision must not reuse a failed or stale in-flight scan.
      }
    }
    adbSimInfoCache = null;
  }
  const now = Date.now();
  if (adbSimInfoCache && adbSimInfoCache.expiresAt > now) {
    return adbSimInfoCache.result;
  }
  if (adbSimInfoFlight) return adbSimInfoFlight;
  adbSimInfoFlight = (async () => {
    const result = await listAdbSimInfoForUi();
    adbSimInfoCache = {
      expiresAt: Date.now() + SIM_INFO_CACHE_MS,
      result,
    };
    return result;
  })();
  try {
    return await adbSimInfoFlight;
  } finally {
    adbSimInfoFlight = null;
  }
}

const NAVIGATION_PROBE_FIELDS = Object.freeze([
  "manufacturer",
  "brand",
  "model",
  "navMode",
  "samsungSecureOrder",
  "samsungGlobalOrder",
  "xiaomiButtonSet",
  "miuiVersion",
  "hyperOsVersion",
  "oneUiVersion",
  "probeComplete",
]);

function parseNavigationProbe(value) {
  const result = {};
  for (const line of String(value || "").split(/\r?\n/)) {
    const index = line.indexOf("=");
    if (index <= 0) continue;
    const key = line.slice(0, index).trim();
    if (!NAVIGATION_PROBE_FIELDS.includes(key)) continue;
    result[key] = line.slice(index + 1).trim();
  }
  return result;
}

function validateNavigationProbeOutput(value) {
  const counts = new Map(NAVIGATION_PROBE_FIELDS.map((key) => [key, 0]));
  for (const line of String(value || "").split(/\r?\n/)) {
    const index = line.indexOf("=");
    if (index <= 0) continue;
    const key = line.slice(0, index).trim();
    if (counts.has(key)) counts.set(key, counts.get(key) + 1);
  }
  const missingFields = NAVIGATION_PROBE_FIELDS.filter((key) => counts.get(key) === 0);
  const duplicateFields = NAVIGATION_PROBE_FIELDS.filter((key) => counts.get(key) > 1);
  return {
    ok: missingFields.length === 0 && duplicateFields.length === 0,
    missingFields,
    duplicateFields,
  };
}

async function readAdbNavigationLayout(adbPath, device) {
  const command = [
    "set -e",
    "printf 'manufacturer='; getprop ro.product.manufacturer",
    "printf 'brand='; getprop ro.product.brand",
    "printf 'model='; getprop ro.product.model",
    "printf 'navMode='; settings get secure navigation_mode",
    "printf 'samsungSecureOrder='; settings get secure navigationbar_key_order",
    "printf 'samsungGlobalOrder='; settings get global navigationbar_key_order",
    "printf 'xiaomiButtonSet='; settings get global button_set",
    "printf 'miuiVersion='; getprop ro.miui.ui.version.name",
    "printf 'hyperOsVersion='; getprop ro.mi.os.version.name",
    "printf 'oneUiVersion='; getprop ro.build.version.oneui",
    "printf 'probeComplete=1\\n'",
  ].join("; ");
  const probe = await runAdbCommand({
    adbPath,
    adbPort: device.adbPort || null,
    serial: device.serial,
    adbArgs: ["shell", command],
    timeoutMs: 9000,
  });
  const values = parseNavigationProbe(probe.stdout);
  const probeOutput = validateNavigationProbeOutput(probe.stdout);
  const probeStderr = String(probe.stderr || "").trim();
  const probeComplete = probe.ok === true
    && !probeStderr
    && probeOutput.ok
    && values.probeComplete === "1";
  const input = {
    manufacturer: values.manufacturer || "",
    brand: values.brand || "",
    model: values.model || device.model || "",
    navMode: values.navMode,
    miuiVersion: values.miuiVersion || "",
    hyperOsVersion: values.hyperOsVersion || "",
    oneUiVersion: values.oneUiVersion || "",
    settings: {
      secure: {
        navigation_mode: values.navMode,
        navigationbar_key_order: values.samsungSecureOrder,
      },
      global: {
        navigationbar_key_order: values.samsungGlobalOrder,
        button_set: values.xiaomiButtonSet,
      },
    },
  };
  const classification = classifyNavigationLayout(input);
  const supportedPositions = probeComplete && Array.isArray(classification.supportedBackPositions)
    ? classification.supportedBackPositions
    : [];
  let reason = "";
  if (!probeComplete) reason = "ADBから設定を完全に取得できません";
  else if (!classification.threeButtonMode) reason = classification.navMode === null ? "ナビ方式を確認できません" : "ジェスチャーナビのため変更しません";
  else if (classification.oem === "xiaomi" && !classification.setting?.exists) reason = "このXiaomiでは安全な設定キーを確認できません";
  else if (classification.oem === "xiaomi" && !classification.xiaomiButtonSetValid) reason = "ナビ設定値が0/1以外のため安全に変更できません";
  else if (classification.oem === "xiaomi" && !classification.xiaomiRomVerified) reason = "MIUI/HyperOSの正規ROM情報を確認できないため変更しません";
  else if (classification.oem === "xiaomi" && !classification.xiaomiMappingVerified) reason = "このXiaomi機種は実画面との対応を未確認のため変更しません";
  else if (classification.oem === "samsung" && (!classification.samsungIdentityVerified || !classification.samsungExistingSettingsValid || !classification.activeSetting?.exists || !classification.activeSetting?.valid)) reason = "Samsungの実効設定値を安全に確認できないため変更しません";
  else if (classification.oem === "oppo" || classification.oem === "huawei" || classification.oem === "unknown") reason = "このメーカーは初版では状態確認のみです";
  else if (classification.oem === "aosp") reason = "Android標準配置は戻る左固定です";
  else if (classification.setting && !classification.setting.exists) reason = "設定値が存在しないため変更しません";
  return {
    serial: device.serial,
    label: device.label,
    laixiNumber: device.laixiNumber,
    model: values.model || device.model || "",
    manufacturer: values.manufacturer || values.brand || "",
    oem: classification.oem,
    navMode: classification.navMode,
    backPosition: probeComplete && classification.threeButtonMode
      ? classification.currentBackPosition
      : probeComplete && classification.navMode !== null
        ? "gesture"
        : null,
    supportedPositions,
    writeSupported: probeComplete && classification.writeSupported === true,
    settingConflict: classification.settingConflict === true,
    activeSettingNamespace: classification.activeSetting?.namespace || "",
    activeSettingKey: classification.activeSetting?.key || "",
    reason,
    input,
    probeOk: probeComplete,
    probeFailureCode: probeComplete
      ? ""
      : probe.ok !== true
        ? String(probe.code || probe.error || "ADB_PROBE_FAILED")
        : probeStderr
          ? "ADB_PROBE_STDERR"
          : !probeOutput.ok
            ? "ADB_PROBE_INCOMPLETE_OUTPUT"
            : "ADB_PROBE_SENTINEL_MISSING",
    probeMissingFields: probeOutput.missingFields,
    probeDuplicateFields: probeOutput.duplicateFields,
  };
}

function publicAdbNavigationLayout(row) {
  return {
    serial: row.serial,
    label: row.label,
    laixiNumber: row.laixiNumber,
    model: row.model,
    manufacturer: row.manufacturer,
    oem: row.oem,
    navMode: row.navMode,
    backPosition: row.backPosition,
    supportedPositions: row.supportedPositions,
    writeSupported: row.writeSupported === true,
    settingConflict: row.settingConflict === true,
    activeSettingNamespace: row.activeSettingNamespace || "",
    activeSettingKey: row.activeSettingKey || "",
    reason: row.reason,
    probeFailureCode: row.probeFailureCode || "",
    probeMissingFields: Array.isArray(row.probeMissingFields) ? row.probeMissingFields : [],
    probeDuplicateFields: Array.isArray(row.probeDuplicateFields) ? row.probeDuplicateFields : [],
  };
}

async function listAdbNavigationLayoutsForUi() {
  const adbDevices = await listAdbDevicesForUi({ includeUptime: false, includeFacts: false });
  const config = readFleetMonitorConfig();
  const adbPath = config.adbPath || adbDevices.adbPath || resolveAdbPath();
  const targets = (adbDevices.devices || []).filter((device) => device.connected);
  const layouts = [];
  await runWithConcurrency(targets, 10, async (device) => {
    try {
      layouts.push(await readAdbNavigationLayout(adbPath, device));
    } catch {
      layouts.push({
        serial: device.serial,
        label: device.label,
        laixiNumber: device.laixiNumber,
        model: device.model,
        manufacturer: "",
        oem: "unknown",
        navMode: null,
        backPosition: null,
        supportedPositions: [],
        reason: "ナビ設定を取得できません",
      });
    }
  });
  layouts.sort((a, b) => {
    const numberDiff = Number(a.laixiNumber || Number.MAX_SAFE_INTEGER) - Number(b.laixiNumber || Number.MAX_SAFE_INTEGER);
    return numberDiff || String(a.label || a.serial).localeCompare(String(b.label || b.serial), "ja");
  });
  return {
    ok: adbDevices.ok,
    connected: layouts.length,
    changeable: layouts.filter((row) => row.writeSupported === true).length,
    warning: adbDevices.warning || "",
    devices: layouts.map(publicAdbNavigationLayout),
  };
}

function navigationPlanWrites(plan) {
  if (Array.isArray(plan?.writes) && plan.writes.length) {
    return plan.writes.filter((item) => item?.namespace && item?.key);
  }
  if (!plan?.namespace || !plan?.key) return [];
  return [{
    namespace: plan.namespace,
    key: plan.key,
    value: plan.value,
    previousValue: plan.previousValue,
    previousRawValue: plan.previousRawValue,
    shouldWrite: plan.shouldWrite === true,
  }];
}

async function readAdbNavigationSetting(adbPath, device, item) {
  return runAdbCommand({
    adbPath,
    adbPort: device.adbPort || null,
    serial: device.serial,
    adbArgs: ["shell", "settings", "get", item.namespace, item.key],
    timeoutMs: 5000,
  });
}

async function verifyAdbNavigationSettings(adbPath, device, writes, usePrevious = false) {
  const failures = [];
  const readings = [];
  for (const item of writes) {
    let verify;
    try {
      verify = await readAdbNavigationSetting(adbPath, device, item);
    } catch (error) {
      verify = {
        ok: false,
        stdout: "",
        error: error instanceof Error ? error.message : String(error || ""),
      };
    }
    const expectedValue = usePrevious ? item.previousValue : item.value;
    const expected = expectedValue === null || expectedValue === undefined
      ? "null"
      : String(expectedValue).trim().toLowerCase();
    const actual = String(verify.stdout || "").trim().toLowerCase();
    const ok = verify.ok === true && actual === expected;
    const reading = {
      ok,
      namespace: item.namespace,
      key: item.key,
      expected,
      actual,
    };
    readings.push(reading);
    if (!ok) {
      failures.push(reading);
    }
  }
  const firstFailure = failures[0] || null;
  return {
    ok: failures.length === 0,
    failures,
    readings,
    namespace: firstFailure?.namespace || "",
    key: firstFailure?.key || "",
    expected: firstFailure?.expected || "",
    actual: firstFailure?.actual || "",
  };
}

async function restoreAdbNavigationSettings(adbPath, device, writes) {
  const failedSettings = [];
  for (const item of [...writes].reverse()) {
    const args = item.previousValue === null || item.previousValue === undefined
      ? ["shell", "settings", "delete", item.namespace, item.key]
      : ["shell", "settings", "put", item.namespace, item.key, String(item.previousValue)];
    try {
      const restored = await runAdbCommand({
        adbPath,
        adbPort: device.adbPort || null,
        serial: device.serial,
        adbArgs: args,
        timeoutMs: 7000,
      });
      if (!restored.ok) failedSettings.push(`${item.namespace}:${item.key}`);
    } catch {
      failedSettings.push(`${item.namespace}:${item.key}`);
    }
  }
  const verify = await verifyAdbNavigationSettings(adbPath, device, writes, true);
  for (const failure of verify.failures || []) {
    if (failure.namespace && failure.key) {
      failedSettings.push(`${failure.namespace}:${failure.key}`);
    }
  }
  await sleep(650);
  const stableVerify = await verifyAdbNavigationSettings(adbPath, device, writes, true);
  for (const failure of stableVerify.failures || []) {
    if (failure.namespace && failure.key) {
      failedSettings.push(`${failure.namespace}:${failure.key}`);
    }
  }
  const uniqueFailedSettings = [...new Set(failedSettings)];
  return {
    ok: uniqueFailedSettings.length === 0 && verify.ok && stableVerify.ok,
    failedSettings: uniqueFailedSettings,
    verify,
    stableVerify,
  };
}

async function applyAdbNavigationLayoutOne(adbPath, device, desiredBackPosition, options = {}) {
  let current;
  try {
    current = await readAdbNavigationLayout(adbPath, device);
  } catch {
    return { ok: false, serial: device.serial, code: "NAVIGATION_READ_FAILED", message: "現在のナビ設定を取得できませんでした。" };
  }
  if (current.probeOk !== true) {
    return {
      ok: false,
      serial: device.serial,
      model: current.model || device.model || "",
      oem: current.oem || "",
      code: "NAVIGATION_READ_FAILED",
      message: current.reason || "現在のナビ設定を完全に取得できないため変更しませんでした。",
    };
  }
  const plan = navigationWritePlan(current.input || {}, desiredBackPosition);
  if (!plan.ok) {
    return {
      ok: false,
      serial: device.serial,
      model: current.model || device.model || "",
      oem: current.oem || plan.oem || "",
      code: plan.code,
      message: current.reason || plan.message,
    };
  }
  const writes = navigationPlanWrites(plan);
  if (!plan.classification?.writeSupported || !writes.length) {
    return {
      ok: false,
      serial: device.serial,
      model: current.model || device.model || "",
      oem: current.oem || plan.oem || "",
      code: "NAVIGATION_SETTING_MISSING",
      message: "安全に確認できる書込み設定がないため変更しませんでした。",
    };
  }
  const forceReapply = options.forceReapply === true;
  const writesToIssue = forceReapply ? writes : writes.filter((item) => item.shouldWrite);
  if (!writesToIssue.length) {
    return {
      ok: true,
      serial: device.serial,
      model: current.model || device.model || "",
      oem: current.oem || plan.oem || "",
      code: "NAVIGATION_SETTING_ALREADY_REPORTED",
      message: "端末が報告した設定値は指定どおりです。画面上の並びは未確認です。",
      changed: false,
      reapplied: false,
      settingVerified: true,
      screenVerified: false,
      visualCheckRequired: true,
      settingPaths: writes.map((item) => `${item.namespace}:${item.key}`),
    };
  }

  let writeOk = true;
  for (const item of writesToIssue) {
    const result = await runAdbCommand({
      adbPath,
      adbPort: device.adbPort || null,
      serial: device.serial,
      adbArgs: ["shell", "settings", "put", item.namespace, item.key, String(item.value)],
      timeoutMs: 7000,
    });
    if (!result.ok) {
      writeOk = false;
      break;
    }
  }
  const verify = writeOk
    ? await verifyAdbNavigationSettings(adbPath, device, writes)
    : { ok: false };
  if (verify.ok) await sleep(650);
  const stableVerify = verify.ok
    ? await verifyAdbNavigationSettings(adbPath, device, writes)
    : { ok: false };
  if (!writeOk || !stableVerify.ok) {
    const rollback = await restoreAdbNavigationSettings(adbPath, device, writes).catch(() => ({
      ok: false,
      failedSettings: writes.map((item) => `${item.namespace}:${item.key}`),
    }));
    const rollbackOk = rollback.ok === true;
    return {
      ok: false,
      serial: device.serial,
      model: current.model || device.model || "",
      oem: current.oem || plan.oem || "",
      code: rollbackOk ? "NAVIGATION_VERIFY_FAILED_ROLLED_BACK" : "NAVIGATION_ROLLBACK_FAILED",
      message: rollbackOk
        ? "変更を確認できなかったため元の設定値へ戻し、2回再読取しました。画面は未確認です。"
        : "変更確認と設定値の復元に失敗しました。端末画面を確認してください。",
      rollbackOk,
      rollbackFailedSettings: Array.isArray(rollback.failedSettings) ? rollback.failedSettings : [],
      changed: rollbackOk ? false : null,
      stateUncertain: !rollbackOk,
      reapplied: false,
      settingVerified: false,
      screenVerified: false,
      visualCheckRequired: true,
      settingPaths: writes.map((item) => `${item.namespace}:${item.key}`),
    };
  }
  const changed = plan.shouldWrite === true;
  const reapplied = forceReapply && !changed;
  return {
    ok: true,
    serial: device.serial,
    model: current.model || device.model || "",
    oem: current.oem || plan.oem || "",
    code: changed ? "NAVIGATION_SETTING_WRITTEN_VISUAL_PENDING" : "NAVIGATION_SETTING_REAPPLIED_VISUAL_PENDING",
    message: `端末が実際に使う設定値を2回確認しました。画面で「${desiredBackPosition === "left" ? "戻る左" : "戻る右"}」か確認してください。`,
    changed,
    reapplied,
    settingVerified: true,
    screenVerified: false,
    visualCheckRequired: true,
    settingPaths: writes.map((item) => `${item.namespace}:${item.key}`),
  };
}

async function applyAdbNavigationLayouts(body = {}) {
  const backPosition = String(body.backPosition || "").trim().toLowerCase();
  const forceReapply = body.forceReapply === true;
  const scope = body.scope === "all_eligible_snapshot" ? "all_eligible_snapshot" : "selected";
  const serials = [...new Set((Array.isArray(body.serials) ? body.serials : [])
    .map((serial) => String(serial || "").trim())
    .filter(Boolean))];
  if (!["left", "right"].includes(backPosition)) {
    return { ok: false, status: 400, code: "INVALID_BACK_POSITION", error: "戻るボタンの位置を選んでください。" };
  }
  if (!serials.length || serials.length > 200) {
    return { ok: false, status: 400, code: "INVALID_NAVIGATION_TARGETS", error: "対象端末を1〜200台で選んでください。" };
  }
  const lock = navigationLayoutTargetLock.tryAcquire(serials.map((serial) => ({ serial })));
  if (!lock.ok) {
    return {
      ok: false,
      status: 409,
      code: "NAVIGATION_LAYOUT_ALREADY_RUNNING",
      error: "選択端末のナビ変更がすでに実行中です。",
      requested: serials.length,
      conflictCount: lock.conflictCount,
    };
  }
  try {
    const adbDevices = await listAdbDevicesForUi({ includeUptime: false, includeFacts: false });
    const bySerial = new Map((adbDevices.devices || []).filter((device) => device.connected).map((device) => [String(device.serial), device]));
    const targets = serials.map((serial) => bySerial.get(serial)).filter(Boolean);
    const results = serials.filter((serial) => !bySerial.has(serial)).map((serial) => ({
      ok: false,
      serial,
      code: "ADB_DEVICE_NOT_CONNECTED",
      message: "ADB接続を確認できないため変更しませんでした。",
      changed: false,
      reapplied: false,
      settingVerified: false,
      screenVerified: false,
      visualCheckRequired: false,
    }));
    const config = readFleetMonitorConfig();
    const adbPath = config.adbPath || adbDevices.adbPath || resolveAdbPath();
    await runWithConcurrency(targets, 6, async (device) => {
      results.push(await applyAdbNavigationLayoutOne(adbPath, device, backPosition, { forceReapply }));
    });
    const settingVerified = results.filter((row) => row.settingVerified === true).length;
    const written = results.filter((row) => row.changed === true && row.settingVerified === true).length;
    const reapplied = results.filter((row) => row.reapplied === true && row.settingVerified === true).length;
    const visualCheckRequired = results.filter((row) => row.visualCheckRequired === true && row.screenVerified !== true).length;
    const screenVerified = results.filter((row) => row.screenVerified === true).length;
    const failed = results.filter((row) => !row.ok).length;
    const blocked = results.filter((row) => !row.ok && ![
      "NAVIGATION_VERIFY_FAILED_ROLLED_BACK",
      "NAVIGATION_ROLLBACK_FAILED",
    ].includes(row.code)).length;
    return {
      ok: true,
      allSucceeded: failed === 0,
      status: 200,
      backPosition,
      scope,
      forceReapply,
      requested: serials.length,
      targeted: targets.length,
      succeeded: settingVerified,
      settingVerified,
      written,
      reapplied,
      screenVerified,
      visualCheckRequired,
      blocked,
      failed,
      results,
    };
  } finally {
    lock.release();
  }
}

function publicBatteryProtectionResult(row = {}) {
  const raw = row.rawResult && typeof row.rawResult === "object" ? row.rawResult : {};
  const identity = raw.identity && typeof raw.identity === "object" ? raw.identity : {};
  const battery = raw.battery && typeof raw.battery === "object" ? raw.battery : {};
  const percent = battery.percent === null || battery.percent === undefined
    ? null
    : Number(battery.percent);
  const temperatureC = battery.temperatureC === null || battery.temperatureC === undefined
    ? null
    : Number(battery.temperatureC);
  const sdk = identity.sdk === null || identity.sdk === undefined ? null : Number(identity.sdk);
  return {
    serial: cleanText(row.serial, 80),
    adbPort: row.adbPort || null,
    label: cleanText(row.label || row.serial, 120),
    model: cleanText(identity.model || row.model, 120),
    ok: row.ok === true,
    code: cleanText(raw.code || row.code, 80),
    message: cleanText(row.message || raw.reason, 240),
    capability: "unknown",
    supported: null,
    state: "unknown",
    verification: "manual_required",
    writable: false,
    manualOnly: true,
    opened: ["power_usage_summary", "settings", "none"].includes(raw.opened) ? raw.opened : "",
    fallbackUsed: raw.fallbackUsed === true,
    identity: {
      manufacturer: cleanText(identity.manufacturer, 80),
      brand: cleanText(identity.brand, 80),
      model: cleanText(identity.model || row.model, 120),
      device: cleanText(identity.device, 120),
      sdk: Number.isInteger(sdk) ? sdk : null,
      androidVersion: cleanText(identity.androidVersion, 40),
    },
    battery: {
      percent: Number.isFinite(percent) ? Math.max(0, Math.min(100, Math.round(percent))) : null,
      status: cleanText(battery.status, 40),
      health: cleanText(battery.health, 40),
      acPowered: battery.acPowered === true ? true : battery.acPowered === false ? false : null,
      usbPowered: battery.usbPowered === true ? true : battery.usbPowered === false ? false : null,
      wirelessPowered: battery.wirelessPowered === true ? true : battery.wirelessPowered === false ? false : null,
      dockPowered: battery.dockPowered === true ? true : battery.dockPowered === false ? false : null,
      temperatureC: Number.isFinite(temperatureC) ? temperatureC : null,
    },
  };
}

async function runBatteryProtectionForTargets(body = {}) {
  const mode = body.mode === "open" ? "open" : body.mode === "probe" ? "probe" : "";
  const serials = [...new Set((Array.isArray(body.serials) ? body.serials : [])
    .map((serial) => cleanText(serial, 80))
    .filter(Boolean))];
  if (!mode) {
    return {
      ok: false,
      status: 400,
      code: "BATTERY_PROTECTION_MODE_INVALID",
      error: "バッテリー保護の操作を確認してください。",
    };
  }
  if (!serials.length || serials.length > 200) {
    return {
      ok: false,
      status: 400,
      code: "BATTERY_PROTECTION_TARGETS_INVALID",
      error: "対象端末を1〜200台で選んでください。",
    };
  }

  const requestedTargets = serials.map((serial) => ({ serial }));
  const lock = batteryProtectionTargetLock.tryAcquire(requestedTargets);
  if (!lock.ok) {
    return {
      ok: false,
      status: 409,
      code: "BATTERY_PROTECTION_ALREADY_RUNNING",
      error: "選択端末では別の端末設定操作が実行中です。",
      mode,
      requested: serials.length,
      conflictCount: lock.conflictCount,
      results: [],
    };
  }

  try {
    const summary = buildFleetDbSummaryCached();
    const bySerial = new Map((summary.devices || [])
      .filter((row) => row && row.serial)
      .map((row) => [String(row.serial).toLowerCase(), row]));
    const targets = serials.map((serial) => {
      const row = bySerial.get(String(serial).toLowerCase()) || {};
      return {
        serial,
        label: cleanText(
          row.deviceLabel || row.laixiName || row.deviceName || row.modelGroup || serial,
          120
        ),
      };
    });
    const action = mode === "open"
      ? "open_battery_protection_settings"
      : "battery_protection_probe";
    const batch = await runAdbActionForConnectedDevices(action, {
      targets,
      concurrency: mode === "open" ? 2 : 4,
      timeout: mode === "open" ? 25000 : 18000,
    });
    const results = (batch.results || [])
      .filter((row) => !row.skipped)
      .map(publicBatteryProtectionResult);
    const succeeded = results.filter((row) => row.ok).length;
    const failed = results.length - succeeded;
    return {
      ok: batch.ok,
      allSucceeded: failed === 0,
      status: batch.ok ? 200 : 502,
      mode,
      requested: serials.length,
      targeted: batch.targeted || results.length,
      succeeded,
      manualRequired: results.filter((row) => row.ok && row.manualOnly).length,
      failed,
      warning: cleanText(batch.warning, 500),
      results,
    };
  } finally {
    lock.release();
  }
}

async function readAdbUptimeSeconds(adbPath, device) {
  const result = await runAdbCommand({
    adbPath,
    adbPort: device.adbPort || null,
    serial: device.serial,
    adbArgs: ["shell", "cat", "/proc/uptime"],
    timeoutMs: 5000,
  });
  const raw = String(result.stdout || "").trim();
  const seconds = Number((raw.match(/^([0-9]+(?:\.[0-9]+)?)/) || [])[1]);
  if (result.ok && Number.isFinite(seconds)) {
    return { seconds: Math.floor(seconds), raw, error: "" };
  }
  return { seconds: null, raw, error: result.error || result.stderr || result.stdout || "uptime read failed" };
}

async function readAdbBatteryPercent(adbPath, device) {
  const result = await runAdbCommand({
    adbPath,
    adbPort: device.adbPort || null,
    serial: device.serial,
    adbArgs: ["shell", "dumpsys", "battery"],
    timeoutMs: 5000,
  });
  const raw = String(result.stdout || "").trim();
  const level = Number((raw.match(/^\s*level:\s*(\d+)/mi) || [])[1]);
  const scale = Number((raw.match(/^\s*scale:\s*(\d+)/mi) || [])[1]);
  if (result.ok && Number.isFinite(level)) {
    const percent = Number.isFinite(scale) && scale > 0 ? Math.round((level / scale) * 100) : level;
    return { percent: Math.max(0, Math.min(100, percent)), raw, error: "" };
  }
  return { percent: null, raw, error: result.error || result.stderr || result.stdout || "battery read failed" };
}

async function readAdbDeviceInviteFacts(adbPath, device) {
  const base = { osVersion: "", osSdk: "", simStatus: "", networkType: "", factError: "" };
  try {
    const [release, sdk, sim, connectivity] = await Promise.all([
      runAdbShellText(adbPath, device, ["getprop", "ro.build.version.release"], 3000),
      runAdbShellText(adbPath, device, ["getprop", "ro.build.version.sdk"], 3000),
      runAdbShellText(adbPath, device, ["getprop", "gsm.sim.state"], 3000),
      runAdbShellText(adbPath, device, ["dumpsys", "connectivity"], 4500),
    ]);
    const osVersion = formatAdbOsVersion(release);
    return {
      ...base,
      osVersion,
      osSdk: sdk,
      simStatus: normalizeAdbSimStatus(sim),
      networkType: normalizeAdbNetworkType(connectivity),
    };
  } catch (error) {
    return { ...base, factError: error.message || String(error) };
  }
}

async function runAdbShellText(adbPath, device, shellArgs, timeoutMs = 5000) {
  const result = await runAdbCommand({
    adbPath,
    adbPort: device.adbPort || null,
    serial: device.serial,
    adbArgs: ["shell", ...shellArgs],
    timeoutMs,
  });
  return String(result.stdout || "").trim();
}

function formatAdbOsVersion(value) {
  const release = String(value || "")
    .replace(/^OS\s*/i, "")
    .replace(/\s*\/\s*SDK\s*\d+\s*$/i, "")
    .trim();
  return release ? `OS ${release}` : "";
}

function normalizeAdbSimStatus(value) {
  const states = String(value || "")
    .toUpperCase()
    .split(",")
    .map((state) => state.trim())
    .filter(Boolean);
  if (!states.length) return "";
  if (states.some((state) => ["LOADED", "READY", "PIN_REQUIRED", "PUK_REQUIRED", "NETWORK_LOCKED", "CARD_RESTRICTED", "PERM_DISABLED"].includes(state))) return "SIMあり";
  if (states.some((state) => state === "CARD_IO_ERROR")) return "SIMエラー";
  if (states.every((state) => state === "ABSENT")) return "SIMなし";
  if (states.some((state) => ["NOT_READY", "UNKNOWN"].includes(state))) return "不明";
  return "不明";
}

function normalizeAdbNetworkType(connectivityDump) {
  const text = String(connectivityDump || "");
  const activeMatch = text.match(/Active default network:\s*(\d+)/i);
  if (activeMatch) {
    const activeId = activeMatch[1];
    const blockMatch = text.match(new RegExp(`NetworkAgentInfo\\{network\\{${activeId}\\}[\\s\\S]*?(?=\\n\\s*NetworkAgentInfo\\{network\\{|\\n\\s*uid\\/pid:|$)`, "i"));
    const activeBlock = blockMatch ? blockMatch[0] : "";
    if (/WIFI|TRANSPORT_WIFI|Transports:\s*WIFI/i.test(activeBlock)) return "Wi-Fi";
    if (/CELLULAR|TRANSPORT_CELLULAR|MOBILE|Transports:\s*CELLULAR/i.test(activeBlock)) return "SIM通信";
  }
  const active = text
    .split(/\r?\n/)
    .filter((line) => /NetworkAgentInfo|NetworkCapabilities|active|default/i.test(line))
    .slice(0, 80)
    .join("\n");
  const source = active || text;
  const wifi = /WIFI|TRANSPORT_WIFI|type:\s*WIFI/i.test(source);
  const cellular = /CELLULAR|TRANSPORT_CELLULAR|MOBILE|type:\s*MOBILE/i.test(source);
  if (wifi && cellular) return "併用";
  if (wifi) return "Wi-Fi";
  if (cellular) return "SIM通信";
  return "";
}

function persistAdbDeviceInviteFacts(devices = []) {
  const rows = (devices || []).filter((device) => device && device.serial && device.connected);
  if (!rows.length) return { ok: true, changed: 0 };
  const { dbPath, db } = readFleetDbForWrite();
  const now = new Date().toISOString();
  let changed = 0;
  for (const row of rows) {
    const device = db.physicalDevices[String(row.serial)];
    if (!device) continue;
    let deviceChanged = false;
    if (row.osVersion) {
      const osVersion = cleanText(formatAdbOsVersion(row.osVersion), 40);
      if (osVersion && device.osVersion !== osVersion) {
        device.osVersion = osVersion;
        deviceChanged = true;
      }
    } else if (device.osVersion) {
      const osVersion = cleanText(formatAdbOsVersion(device.osVersion), 40);
      if (osVersion && device.osVersion !== osVersion) {
        device.osVersion = osVersion;
        deviceChanged = true;
      }
    }
    if (row.simStatus && !device.simStatus) {
      device.simStatus = cleanText(row.simStatus, 40);
      deviceChanged = true;
    }
    if (row.networkType && device.networkType !== row.networkType) {
      const previous = device.networkType || "";
      device.networkType = cleanText(row.networkType, 40);
      if (previous && previous !== device.networkType) {
        appendInviteOpsNote(device, `通信方式自動検知: ${previous} -> ${device.networkType}`);
        if (!device.networkSwitchedDay && previous !== "Wi-Fi" && device.networkType === "Wi-Fi") {
          const switchedDay = extractDay(device.tags || []);
          if (switchedDay) {
            device.networkSwitchedDay = String(switchedDay);
            appendInviteOpsNote(device, `SIM→Wi-Fi切替日を自動記録: DAY${String(switchedDay).padStart(2, "0")}`);
          }
        }
      }
      deviceChanged = true;
    }
    if (Number.isFinite(Number(row.uptimeSeconds)) && Number(row.uptimeSeconds) >= 0) {
      device.adbLastUptimeSeconds = Math.floor(Number(row.uptimeSeconds));
      device.adbLastUptimeRaw = cleanText(row.uptimeRaw, 80);
      device.adbLastUptimeCheckedAt = now;
      deviceChanged = true;
    }
    if (Number.isFinite(Number(row.batteryPercent)) && Number(row.batteryPercent) >= 0) {
      device.adbLastBatteryPercent = Math.max(0, Math.min(100, Math.round(Number(row.batteryPercent))));
      device.adbLastBatteryCheckedAt = now;
      deviceChanged = true;
    }
    if (deviceChanged) {
      changed += 1;
      device.updatedAt = now;
    }
  }
  if (changed) {
    db.updatedAt = now;
    writeJsonFile(dbPath, db);
    fleetDbSummaryCache.key = "";
    fleetDbSummaryCache.summary = null;
  }
  return { ok: true, changed };
}

function appendInviteOpsNote(device, text) {
  const stamp = new Date().toISOString().slice(0, 10);
  const line = `${stamp} ${text}`;
  const profiles = normalizeInviteProfiles(device);
  const current = cleanText(profiles.lite.inviteOpsNote, 800);
  profiles.lite.inviteOpsNote = cleanText([current, line].filter(Boolean).join("\n"), 800);
  persistInviteProfiles(device, profiles);
}

async function runAdbActionForConnectedDevices(action, options = {}) {
  const config = readFleetMonitorConfig();
  const adbPath = config.adbPath || resolveAdbPath();
  const ports = await resolveActiveAdbPorts();
  const scans = [];
  const skipActiveGroup = Boolean(options.skipActiveGroup);
  const filterXiaomiLike = Boolean(options.filterXiaomiLike);
  const skipCompletedDeviceSetting = cleanText(options.skipCompletedDeviceSetting, 60);
  const requestedTargets = Array.isArray(options.targets) ? options.targets : [];
  const dbBySerial = new Map();
  if (skipActiveGroup || skipCompletedDeviceSetting || filterXiaomiLike) {
    const summary = buildFleetDbSummary();
    for (const row of summary.devices || []) {
      if (row && row.serial) dbBySerial.set(String(row.serial), row);
    }
  }

  for (const adbPort of ports) {
    scans.push(await scanAdbDevices({ adbPath, adbPort }));
  }

  const devices = [];
  const seen = new Set();
  for (const scan of scans) {
    for (const device of scan.devices || []) {
      if (!device.serial || seen.has(device.serial)) continue;
      seen.add(device.serial);
      devices.push(device);
    }
  }

  const connected = devices.filter((device) => device.status === "device");
  const targets = [];
  const skippedDevices = [];
  const missingTargetResults = [];
  const sourceDevices = requestedTargets.length
    ? requestedTargets
      .map((target) => {
        const serial = cleanText(target && target.serial, 80);
        if (!serial) return null;
        const connectedDevice = connected.find((device) => String(device.serial) === serial);
        if (!connectedDevice) {
          missingTargetResults.push({
            serial,
            adbPort: target.adbPort || null,
            model: "",
            label: cleanText(target.label || serial, 120),
            ok: false,
            code: "ADB_DEVICE_NOT_CONNECTED",
            message: "ADB connected device not found.",
          });
          return null;
        }
        return {
          ...connectedDevice,
          adbPort: target.adbPort === undefined || target.adbPort === null || target.adbPort === "" ? (connectedDevice.adbPort || null) : Number(target.adbPort),
          label: cleanText(target.label || connectedDevice.label || connectedDevice.serial, 120),
        };
      })
      .filter(Boolean)
    : connected;
  const selectedSeen = new Set();
  for (const device of sourceDevices) {
    if (!device.serial || selectedSeen.has(String(device.serial))) continue;
    selectedSeen.add(String(device.serial));
    const dbRow = dbBySerial.get(String(device.serial)) || {};
    if (filterXiaomiLike && !isXiaomiLikeFleetDevice(device, dbRow)) {
      skippedDevices.push({
        serial: device.serial,
        adbPort: device.adbPort || null,
        model: device.model || "",
        group: dbRow.group || "",
        skipped: true,
        skipReason: "NOT_XIAOMI_CANDIDATE",
        ok: true,
        message: "Skipped because this device is not Xiaomi/Redmi/POCO candidate.",
      });
      continue;
    }
    const dbTags = Array.isArray(dbRow.tags) ? dbRow.tags : [];
    const isActiveGroup = dbRow.group === "\u7a3c\u50cd\u4e2d" || dbTags.includes("GROUP_ACTIVE");
    if (skipActiveGroup && isActiveGroup) {
      skippedDevices.push({
        serial: device.serial,
        adbPort: device.adbPort || null,
        model: device.model || "",
        group: dbRow.group || "",
        skipped: true,
        skipReason: "ACTIVE_GROUP",
        ok: true,
        message: "Skipped because device is in active group.",
      });
      continue;
    }
    if (skipCompletedDeviceSetting && deviceSettingApplied(dbRow, skipCompletedDeviceSetting)) {
      skippedDevices.push({
        serial: device.serial,
        adbPort: device.adbPort || null,
        model: device.model || "",
        group: dbRow.group || "",
        skipped: true,
        skipReason: "SETTING_ALREADY_APPLIED",
        settingKey: skipCompletedDeviceSetting,
        ok: true,
        message: "Skipped because this setting is already recorded in DB.",
      });
      continue;
    }
    targets.push(device);
  }
  const results = [...missingTargetResults];
  const actionConcurrency = clampInteger(options.concurrency || 1, 1, 5);
  const actionResults = new Array(targets.length);
  const runTarget = async ({ device, index }) => {
    const result = await runSafeAdbAction({
      adbPath,
      adbPort: device.adbPort || null,
      serial: device.serial,
      action,
      timeout: options.timeout || undefined,
      rootDir: paths.root,
      screenshotsDir: paths.screenshotsDir,
      apkFiles: options.apkFiles,
    });
    const actionOk = Boolean(result.ok) && !(result.result && result.result.ok === false);
    const verificationError = !actionOk && result.ok && result.result && result.result.ok === false
      ? `${options.settingLabel || action}を設定後に確認できませんでした。`
      : "";
    actionResults[index] = {
      serial: device.serial,
      adbPort: device.adbPort || null,
      model: device.model || "",
      ok: actionOk,
      code: result.code,
      message: result.message || (result.result && result.result.message) || verificationError,
      before: result.result && result.result.before,
      after: result.result && result.result.after,
      changed: result.result && result.result.changed,
      settingCount: result.result && result.result.settingCount,
      settingsSucceeded: result.result && result.result.succeeded,
      settingsFailed: result.result && result.result.failed,
      packages: result.result && result.result.packages,
      missingApks: result.result && result.result.missingApks,
      rawResult: result.result || null,
    };
  };
  await runWithConcurrency(targets.map((device, index) => ({ device, index })), actionConcurrency, runTarget);
  results.push(...actionResults.filter(Boolean));

  const warnings = scans.filter((scan) => scan.warning).map((scan) => {
    const label = scan.port ? `port ${scan.port}` : "default";
    return `${label}: ${scan.warning}`;
  });
  const succeeded = results.filter((item) => item.ok).length;
  const failed = results.length - succeeded;
  const packageResults = results.flatMap((item) =>
    Array.isArray(item.packages)
      ? item.packages.map((pkg) => ({
        serial: item.serial,
        model: item.model,
        ...pkg,
      }))
      : []
  );
  if (options.persistDeviceSettingKey) {
    persistDeviceSettingResults(options.persistDeviceSettingKey, action, results);
  }
  const packageSummary = packageResults.length
    ? {
      total: packageResults.length,
      installed: packageResults.filter((item) => item.ok && !item.skipped).length,
      skipped: packageResults.filter((item) => item.skipped).length,
      failed: packageResults.filter((item) => !item.ok).length,
      missingApk: packageResults.filter((item) => item.code === "APK_NOT_FOUND").length,
    }
    : null;

  return {
    ok: scans.some((scan) => scan.available),
    adbPath,
    action,
    ports: ports.map((port) => port || "default"),
    scanned: devices.length,
    connected: connected.length,
    targeted: targets.length + missingTargetResults.length,
    concurrency: actionConcurrency,
    skipped: skippedDevices.length,
    skippedActive: skippedDevices.filter((item) => item.skipReason === "ACTIVE_GROUP").length,
    skippedAlreadyApplied: skippedDevices.filter((item) => item.skipReason === "SETTING_ALREADY_APPLIED").length,
    succeeded,
    failed,
    warning: warnings.join("; "),
    packageSummary,
    results: [...skippedDevices, ...results],
  };
}

function isXiaomiLikeFleetDevice(device = {}, dbRow = {}) {
  const haystack = [
    device.model,
    device.product,
    device.device,
    device.label,
    dbRow.deviceLabel,
    dbRow.deviceName,
    dbRow.laixiName,
    dbRow.xiaoweiName,
    dbRow.modelGroup,
    dbRow.model,
    dbRow.deviceCode,
    dbRow.originalName,
    dbRow.uiName,
  ].map((value) => String(value || "")).join(" ");
  if (/xiaomi|redmi|poco/i.test(haystack)) return true;
  if (/\b(XIG02|XIG03|A401XM|2409BRN2CL)\b/i.test(haystack)) return true;
  if (/\b(REDMI9T|REDMI12|10JE)\b/i.test(haystack)) return true;
  if (/\b9T-\d{2}\b/i.test(haystack)) return true;
  if (/\b12-\d{2}\b/i.test(haystack) && /\b(A401XM|SBM|SIMFREE|KDDI|DOCOMO)\b/i.test(haystack)) return true;
  return false;
}

async function runAdbActionAcrossPorts({ payload, serial, action, adbPath, ports }) {
  if (
    (action === "input_text" && payload.apnEditorOnly === true)
    || (action === "open_apn_settings" && payload.apnManualOnly === true)
  ) {
    return {
      ok: false,
      serial,
      action,
      adbPath,
      status: 500,
      code: "APN_MANUAL_ACTION_REQUIRES_SINGLE_PORT",
      message: "Manual APN actions require one resolved ADB port and cannot be retried.",
      mutationStarted: false,
    };
  }
  const failures = [];
  for (const adbPort of ports) {
    const result = await runSafeAdbAction({
      ...payload,
      adbPath,
      adbPort,
      serial,
      action,
      rootDir: paths.root,
      screenshotsDir: paths.screenshotsDir,
    });
    result.adbPath = adbPath;
    result.adbPort = adbPort || null;
    if (result.ok || result.status === 400) return result;
    failures.push({
      adbPort: adbPort || null,
      code: result.code,
      message: result.message,
    });
  }

  const last = failures[failures.length - 1] || {};
  return {
    ok: false,
    serial,
    action,
    adbPath,
    adbPort: last.adbPort || null,
    status: 502,
    code: last.code || "ADB_ACTION_FAILED",
    message: last.message || "ADB action failed.",
    triedAdbPorts: failures,
  };
}

function readFleetMonitorConfig() {
  const config = readJsonFile(path.join(paths.root, "config", "fleet-monitor.json"), {});
  config.adbPath = normalizeConfiguredAdbPath(config.adbPath);
  return config;
}

function normalizeConfiguredAdbPath(value) {
  const text = cleanText(value, 500);
  if (!text || text.toLowerCase() === "adb") return resolveAdbPath();
  if (fs.existsSync(text)) return text;
  return resolveAdbPath();
}

function uniqueAdbPorts(values) {
  const ports = [];
  const seen = new Set();
  for (const value of values) {
    const port = value === null || value === undefined || value === "" ? null : Number(value);
    if (port !== null && (!Number.isInteger(port) || port <= 0)) continue;
    const key = port === null ? "default" : String(port);
    if (seen.has(key)) continue;
    seen.add(key);
    ports.push(port);
  }
  return ports.length ? ports : [null];
}

function shouldTryXiaoweiAction(action) {
  return ["home", "back", "packages", "task_manager"].includes(action);
}

function summarizeXiaoweiRead(xiaowei) {
  return {
    ok: xiaowei.ok,
    available: xiaowei.available,
    dbAvailable: xiaowei.dbAvailable,
    apiAvailable: xiaowei.apiAvailable,
    apiReachable: xiaowei.apiReachable,
    apiLocked: xiaowei.apiLocked,
    apiCode: xiaowei.apiCode,
    apiMessage: xiaowei.apiMessage,
    apiTranslatedMessage: xiaowei.apiTranslatedMessage,
    apiUrl: xiaowei.apiUrl,
    dbPath: xiaowei.dbPath,
    count: xiaowei.count || xiaowei.devices.length,
    warning: xiaowei.warning,
    devices: xiaowei.devices,
  };
}

async function findFleetDevicesMissingFromXiaowei() {
  const [summary, xiaowei] = await Promise.all([
    Promise.resolve(buildFleetDbSummaryCached()),
    readXiaoweiSources(),
  ]);
  const xiaoweiSerials = new Set((xiaowei.devices || [])
    .map((device) => serialKey(device && device.serial))
    .filter(Boolean));
  const xiaoweiApiSerials = new Set((xiaowei.apiDevices || [])
    .map((device) => serialKey(device && device.serial))
    .filter(Boolean));
  const xiaoweiDbSerials = new Set((xiaowei.dbDevices || [])
    .map((device) => serialKey(device && device.serial))
    .filter(Boolean));
  const visibleSerials = xiaowei.apiAvailable || xiaowei.apiReachable ? xiaoweiApiSerials : xiaoweiSerials;
  const rows = (summary.devices || [])
    .filter((row) => row && row.serial && !visibleSerials.has(serialKey(row.serial)))
    .map((row) => ({
      managementId: row.managementId || "",
      xiaoweiNumber: row.xiaoweiNumber || row.laixiNumber || "",
      laixiNumber: row.laixiNumber || "",
      serial: row.serial || "",
      name: row.laixiName || row.deviceLabel || row.deviceName || row.xiaoweiName || "",
      deviceLabel: row.deviceLabel || "",
      deviceName: row.deviceName || "",
      xiaoweiName: row.xiaoweiName || "",
      xiaoweiSource: xiaoweiSerials.has(serialKey(row.serial)) ? (xiaoweiApiSerials.has(serialKey(row.serial)) ? "api" : "db_only") : "missing",
      status: row.status || "",
      lastSeenAt: row.lastSeenAt || "",
      adbConnected: row.adbConnected ?? null,
    }))
    .sort((a, b) => Number(a.laixiNumber || 0) - Number(b.laixiNumber || 0) || String(a.serial).localeCompare(String(b.serial)));
  return {
    ok: xiaowei.ok !== false,
    checkedAt: new Date().toISOString(),
    dbCount: (summary.devices || []).length,
    xiaoweiCount: xiaowei.count || (xiaowei.devices || []).length,
    xiaoweiApiCount: xiaoweiApiSerials.size,
    xiaoweiDbCount: xiaoweiDbSerials.size,
    basis: xiaowei.apiAvailable || xiaowei.apiReachable ? "api" : "merged",
    missingCount: rows.length,
    warning: xiaowei.warning || "",
    rows,
  };
}

async function findXiaoweiProjectionIssues() {
  const [summary, xiaowei] = await Promise.all([
    Promise.resolve(buildFleetDbSummaryCached()),
    readXiaoweiSources(),
  ]);
  const fleetBySerial = new Map((summary.devices || [])
    .filter((row) => row && row.serial)
    .map((row) => [serialKey(row.serial), row]));
  const xiaoweiBySerial = new Map((xiaowei.devices || [])
    .filter((device) => device && device.serial)
    .map((device) => [serialKey(device.serial), device]));
  const apiSerials = new Set((xiaowei.apiDevices || [])
    .map((device) => serialKey(device && device.serial))
    .filter(Boolean));
  const dbSerials = new Set((xiaowei.dbDevices || [])
    .map((device) => serialKey(device && device.serial))
    .filter(Boolean));
  const serials = new Set([...fleetBySerial.keys(), ...xiaoweiBySerial.keys()]);
  const rows = [];

  for (const serial of serials) {
    const fleet = fleetBySerial.get(serial) || null;
    const xw = xiaoweiBySerial.get(serial) || null;
    const issues = xiaoweiProjectionIssueCodes(fleet, xw, { apiSerials, dbSerials });
    if (!issues.length) continue;
    rows.push({
      serial: fleet && fleet.serial || xw && xw.serial || serial,
      managementId: fleet && fleet.managementId || "",
      xiaoweiNumber: fleet && (fleet.xiaoweiNumber || fleet.laixiNumber) || "",
      dbNumber: fleet && (fleet.xiaoweiNumber || fleet.laixiNumber || fleet.xiaoweiSort) || "",
      xiaoweiListNumber: xw && xw.sort !== null && xw.sort !== undefined ? String(xw.sort) : "",
      dbName: fleet && (fleet.deviceLabel || fleet.laixiName || fleet.xiaoweiName || fleet.deviceName) || "",
      masterName: fleet && fleet.deviceName || "",
      xiaoweiName: xw && xw.name || "",
      model: xw && xw.model || fleet && fleet.modelGroup || "",
      status: fleet && fleet.status || "",
      xiaoweiSource: xw && xw.source || "",
      projectionState: xiaoweiProjectionState(xw, { apiSerials }),
      resolution: xiaoweiResolutionLabel(xw),
      sourceWidth: xw && xw.sourceWidth,
      sourceHeight: xw && xw.sourceHeight,
      width: xw && xw.width,
      height: xw && xw.height,
      issues,
      issueLabels: issues.map(xiaoweiProjectionIssueLabel),
    });
  }

  rows.sort((a, b) => Number(a.dbNumber || a.xiaoweiListNumber || 9999) - Number(b.dbNumber || b.xiaoweiListNumber || 9999)
    || String(a.serial).localeCompare(String(b.serial)));
  return {
    ok: xiaowei.ok !== false,
    checkedAt: new Date().toISOString(),
    dbCount: (summary.devices || []).length,
    xiaoweiCount: xiaowei.count || (xiaowei.devices || []).length,
    xiaoweiApiCount: apiSerials.size,
    xiaoweiDbCount: dbSerials.size,
    issueCount: rows.length,
    warning: xiaowei.warning || "",
    rows,
  };
}

async function diagnoseUsbAdbDevices(options = {}) {
  const includeOk = options.includeOk === true;
  const includeXiaoweiOnly = options.includeXiaoweiOnly === true;
  const [summary, xiaowei] = await Promise.all([
    Promise.resolve(buildFleetDbSummaryCached()),
    readXiaoweiSources().catch((error) => ({ ok: false, warning: error.message, devices: [], apiDevices: [], dbDevices: [] })),
  ]);
  const config = readFleetMonitorConfig();
  const adbPath = config.adbPath || resolveAdbPath();
  // Read only ADB servers that are already listening. This never starts a
  // competing 5037 daemon, and keeps devices visible whichever server owns them.
  const ports = await resolveActiveAdbPorts();
  const scans = [];
  for (const adbPort of ports) {
    scans.push(await scanAdbDevices({ adbPath, adbPort }));
  }

  const dbRows = (summary.devices || []).filter((row) => row && row.serial);
  const fleetRows = dbRows.slice();
  if (includeXiaoweiOnly) {
    const dbSerials = new Set(dbRows.map((row) => serialKey(row.serial)));
    for (const device of xiaowei.devices || []) {
      const serial = String(device && device.serial || "").trim();
      const key = serialKey(serial);
      if (!key || dbSerials.has(key)) continue;
      dbSerials.add(key);
      fleetRows.push({
        serial,
        managementId: "",
        xiaoweiNumber: device.sort || "",
        laixiNumber: device.sort || "",
        deviceLabel: device.name || "",
        xiaoweiName: device.name || "",
        model: device.model || "",
        status: "XIAOWEI_ONLY",
        xiaoweiOnly: true,
      });
    }
  }
  const adbBySerial = new Map();
  for (const scan of scans) {
    for (const device of scan.devices || []) {
      const key = serialKey(device && device.serial);
      if (!key || adbBySerial.has(key)) continue;
      adbBySerial.set(key, device);
    }
  }
  const xiaoweiBySerial = new Map((xiaowei.devices || [])
    .filter((device) => device && device.serial)
    .map((device) => [serialKey(device.serial), device]));
  const apiSerials = new Set((xiaowei.apiDevices || [])
    .map((device) => serialKey(device && device.serial))
    .filter(Boolean));
  const pnp = readWindowsPnpDevicesForSerials(fleetRows.map((row) => row.serial));
  const topologyCache = readUsbTopologyCache();
  const topologyUpdatedMs = Date.parse(topologyCache.updatedAt || "") || 0;
  if (!usbTopologyRefreshRunning && Date.now() - topologyUpdatedMs > 2 * 60 * 1000) {
    refreshUsbTopologyCache().catch((error) => console.warn(`USB topology cache: ${error.message}`));
  }
  const pnpBySerial = new Map();
  for (const item of pnp.rows || []) {
    const key = serialKey(item && item.serial);
    if (!key) continue;
    if (!pnpBySerial.has(key)) pnpBySerial.set(key, []);
    pnpBySerial.get(key).push(item);
  }

  const rows = fleetRows.map((row) => {
    const serial = String(row.serial || "");
    const key = serialKey(serial);
    const adb = adbBySerial.get(key) || null;
    const xw = xiaoweiBySerial.get(key) || null;
    const pnpRows = pnpBySerial.get(key) || [];
    const savedUsbTopology = findUsbTopologyRecord(topologyCache, serial);
    const diagnosis = classifyUsbAdbDiagnosis({ row, adb, xw, pnpRows, apiSerials, savedUsbTopology });
    return {
      managementId: row.managementId || "",
      number: row.xiaoweiNumber || row.laixiNumber || row.xiaoweiSort || "",
      laixiNumber: row.laixiNumber || "",
      name: row.deviceLabel || row.laixiName || row.deviceName || row.xiaoweiName || "",
      model: row.modelGroup || row.model || "",
      status: row.status || "",
      xiaoweiOnly: row.xiaoweiOnly === true,
      serial,
      adbStatus: adb && adb.status || "",
      adbPort: adb && adb.adbPort || null,
      adbModel: adb && adb.model || "",
      xiaoweiState: xiaoweiProjectionState(xw, { apiSerials }),
      xiaoweiName: xw && xw.name || "",
      pnpStatus: summarizePnpStatus(pnpRows),
      pnpRows: pnpRows.slice(0, 8),
      hasSavedUsbTopology: Boolean(savedUsbTopology),
      savedUsbTopology: savedUsbTopology ? {
        hubInstanceId: savedUsbTopology.hubInstanceId || "",
        port: Number(savedUsbTopology.port || 0),
        observedAt: savedUsbTopology.observedAt || "",
      } : null,
      diagnosis: diagnosis.code,
      diagnosisLabel: diagnosis.label,
      severity: diagnosis.severity,
      action: diagnosis.action,
      recoveryCommand: serial ? `cd "${paths.root}"; powershell -NoProfile -ExecutionPolicy Bypass -File tools\\reset-target-usb-pnp.ps1 -Apply -ForceReenumerate -Serials ${serial} -TopologyPath "${usbTopologyCachePath()}"` : "",
      recoveryCommandLabel: "対象だけ強制復旧コマンド",
    };
  });

  const visibleRows = includeOk ? rows : rows.filter((row) => row.diagnosis !== "adb_ok");
  visibleRows.sort((a, b) => diagnosisSeverityRank(b.severity) - diagnosisSeverityRank(a.severity)
    || Number(a.number || 99999) - Number(b.number || 99999)
    || String(a.serial).localeCompare(String(b.serial)));

  return {
    ok: pnp.ok !== false,
    checkedAt: new Date().toISOString(),
    adbPath,
    ports: scans.map((scan) => ({ port: scan.port || null, available: scan.available, count: (scan.devices || []).length, warning: scan.warning || "" })),
    dbCount: dbRows.length,
    targetCount: fleetRows.length,
    adbCount: adbBySerial.size,
    xiaoweiCount: xiaowei.count || (xiaowei.devices || []).length,
    pnpAvailable: pnp.ok !== false,
    usbTopologyCachePath: usbTopologyCachePath(),
    savedUsbTopologyCount: fleetRows.filter((row) => findUsbTopologyRecord(topologyCache, row.serial)).length,
    usbTopologyUpdatedAt: topologyCache.updatedAt || "",
    warning: [pnp.warning, xiaowei.warning, scans.filter((scan) => scan.warning).map((scan) => scan.warning).join("; ")].filter(Boolean).join(" / "),
    counts: countBy(rows, "diagnosis"),
    rows: visibleRows,
  };
}

function classifyUsbAdbDiagnosis({ adb, xw, pnpRows = [], apiSerials = new Set(), savedUsbTopology = null }) {
  const adbStatus = String(adb && adb.status || "");
  const isProjected = xw && xiaoweiProjectionState(xw, { apiSerials }) === "投影中";
  const hasPnpOk = pnpRows.some((row) => String(row.status || "").toUpperCase() === "OK" || String(row.problem || "") === "CM_PROB_NONE");
  const hasPnpRows = pnpRows.length > 0;
  const presentInstanceIds = pnpRows
    .filter((row) => String(row.status || "").toUpperCase() === "OK" || String(row.problem || "") === "CM_PROB_NONE")
    .map((row) => String(row.instanceId || ""));
  const usbModeNeedsPhone = presentInstanceIds.some((instanceId) => /VID_18D1&PID_4EE8/i.test(instanceId));

  if (adbStatus === "device") return { code: "adb_ok", label: "正常", severity: "ok", action: "そのままでOK" };
  if (adbStatus === "unauthorized") return { code: "adb_unauthorized", label: "許可待ち(スマホ画面)", severity: "warn", action: "スマホ画面に出ているUSBデバッグ許可を押す" };
  if (isProjected) return { code: "projection_ok_adb_ng", label: "画面は見えるが操作NG", severity: "warn", action: "ADB更新、USBデバッグOFF→ON、抜き差しを試す" };
  if (usbModeNeedsPhone) return { code: "usb_mode_no_adb", label: "USBモード要確認", severity: "warn", action: "スマホ側でUSBデバッグをOFF→ONし、USB接続モードをファイル転送へ戻す" };
  if (hasPnpOk) return { code: "usb_only", label: "半分見えてる(USBだけ)", severity: "warn", action: "USBデバッグOFF→ON、抜き差し。ダメなら対象だけ復旧コマンド" };
  if (hasPnpRows) return { code: "pnp_phantom", label: "記録だけ残ってる", severity: "bad", action: "対象だけ復旧コマンドを管理者PowerShellで実行してから抜き差し" };
  if (savedUsbTopology) return { code: "not_seen", label: "未接続(USB位置記憶あり)", severity: "bad", action: "保存したUSBポートから遠隔復旧できます" };
  return { code: "not_seen", label: "線が届いてない", severity: "bad", action: "電源、ハブ、ケーブル、端末USB端子を確認" };
}

function readWindowsPnpDevicesForSerials(serials = []) {
  const cleanSerials = uniqueStrings(serials.map((serial) => cleanText(serial, 80)).filter(Boolean));
  if (process.platform !== "win32" || !cleanSerials.length) return { ok: true, rows: [], warning: "" };
  const script = [
    "$ErrorActionPreference = 'SilentlyContinue'",
    "$serials = ConvertFrom-Json $env:FLEET_USB_DIAG_SERIALS",
    "$devices = Get-PnpDevice -ErrorAction SilentlyContinue | Select-Object Status,Class,FriendlyName,InstanceId,Problem",
    "$rows = foreach ($serial in $serials) {",
    "  foreach ($device in $devices) {",
    "    $id = [string]$device.InstanceId",
    "    if ($id -match [regex]::Escape([string]$serial)) {",
    "      [pscustomobject]@{ serial = [string]$serial; status = $device.Status; class = $device.Class; friendlyName = $device.FriendlyName; problem = $device.Problem; instanceId = $device.InstanceId }",
    "    }",
    "  }",
    "}",
    "$rows | ConvertTo-Json -Depth 4 -Compress",
  ].join("; ");
  const result = spawnSync("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], {
    cwd: paths.root,
    encoding: "utf8",
    windowsHide: true,
    timeout: 15000,
    env: { ...process.env, FLEET_USB_DIAG_SERIALS: JSON.stringify(cleanSerials) },
  });
  if (result.error || result.status !== 0) {
    return {
      ok: false,
      rows: [],
      warning: result.error && result.error.message || result.stderr || "Windows PnP scan failed",
    };
  }
  const raw = String(result.stdout || "").trim();
  if (!raw) return { ok: true, rows: [], warning: "" };
  try {
    const parsed = JSON.parse(raw);
    const rows = Array.isArray(parsed) ? parsed : [parsed];
    return { ok: true, rows: rows.filter(Boolean), warning: "" };
  } catch (error) {
    return { ok: false, rows: [], warning: `Windows PnP parse failed: ${error.message}` };
  }
}

function runPowerShellJsonAsync(script, env = {}, timeoutMs = 90000) {
  return new Promise((resolve) => {
    const child = spawn("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], {
      cwd: paths.root,
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"],
      env: { ...process.env, ...env },
    });
    let stdout = "";
    let stderr = "";
    let settled = false;
    let timedOut = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(value);
    };
    const timer = setTimeout(() => {
      timedOut = true;
      try { child.kill(); } catch {}
    }, timeoutMs);
    if (typeof timer.unref === "function") timer.unref();
    child.stdout.on("data", (chunk) => { stdout += chunk.toString("utf8"); });
    child.stderr.on("data", (chunk) => { stderr += chunk.toString("utf8"); });
    child.once("error", (error) => finish({ ok: false, rows: [], warning: error.message }));
    child.once("close", (code) => {
      if (timedOut) return finish({ ok: false, rows: [], warning: `USB位置取得が${Math.round(timeoutMs / 1000)}秒でタイムアウトしました` });
      if (code !== 0) return finish({ ok: false, rows: [], warning: stderr.trim() || `PowerShell exited with ${code}` });
      const raw = stdout.trim();
      if (!raw) return finish({ ok: true, rows: [], warning: "" });
      try {
        const parsed = JSON.parse(raw);
        return finish({ ok: true, rows: (Array.isArray(parsed) ? parsed : [parsed]).filter(Boolean), warning: "" });
      } catch (error) {
        return finish({ ok: false, rows: [], warning: `USB位置情報の解析に失敗: ${error.message}` });
      }
    });
  });
}

async function captureWindowsUsbTopologies(serials = []) {
  const cleanSerials = uniqueStrings(serials.map((serial) => cleanText(serial, 80)).filter(Boolean));
  if (process.platform !== "win32" || !cleanSerials.length) return { ok: true, rows: [], warning: "" };
  const script = `
$ErrorActionPreference = 'SilentlyContinue'
$serials = ConvertFrom-Json $env:FLEET_USB_TOPOLOGY_SERIALS
$devices = @(Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Select-Object Status,Class,FriendlyName,InstanceId,Problem)
$deviceById = @{}
foreach ($device in $devices) {
  $id = [string]$device.InstanceId
  if (-not [string]::IsNullOrWhiteSpace($id)) { $deviceById[$id.ToUpperInvariant()] = $device }
}
$candidates = @()
foreach ($serial in $serials) {
  $matches = @($devices | Where-Object { ([string]$_.InstanceId) -match [regex]::Escape([string]$serial) })
  $roots = @($matches | Where-Object { ([string]$_.InstanceId) -match '^USB\\VID_' -and ([string]$_.InstanceId) -notmatch '&MI_' })
  $candidate = $roots | Sort-Object @{ Expression = { if ([string]$_.Class -eq 'USB') { 0 } else { 1 } } }, InstanceId | Select-Object -First 1
  if ($null -eq $candidate) {
    $candidate = $matches | Sort-Object @{ Expression = { if ([string]$_.Class -eq 'USB') { 0 } else { 1 } } }, InstanceId | Select-Object -First 1
  }
  if ($null -ne $candidate) {
    $candidates += [pscustomobject]@{ serial = [string]$serial; device = $candidate }
  }
}
function New-PropertyIndex {
  param([object[]]$Properties)
  $index = @{}
  foreach ($property in @($Properties)) {
    $id = [string]$property.InstanceId
    $keyName = [string]$property.KeyName
    if ([string]::IsNullOrWhiteSpace($id) -or [string]::IsNullOrWhiteSpace($keyName)) { continue }
    $idKey = $id.ToUpperInvariant()
    if (-not $index.ContainsKey($idKey)) { $index[$idKey] = @{} }
    $index[$idKey][$keyName.ToUpperInvariant()] = $property.Data
  }
  return $index
}
function Get-IndexedProperty {
  param($Index, [string]$InstanceId, [string]$KeyName)
  $idKey = $InstanceId.ToUpperInvariant()
  $propertyKey = $KeyName.ToUpperInvariant()
  if (-not $Index.ContainsKey($idKey)) { return $null }
  if (-not $Index[$idKey].ContainsKey($propertyKey)) { return $null }
  return $Index[$idKey][$propertyKey]
}
$candidateIds = @($candidates | ForEach-Object { [string]$_.device.InstanceId } | Sort-Object -Unique)
$deviceProperties = if ($candidateIds.Count) { @(Get-PnpDeviceProperty -InstanceId $candidateIds -ErrorAction SilentlyContinue) } else { @() }
$devicePropertyIndex = New-PropertyIndex -Properties $deviceProperties
$parentIds = @($candidateIds | ForEach-Object { [string](Get-IndexedProperty -Index $devicePropertyIndex -InstanceId $_ -KeyName 'DEVPKEY_Device_Parent') } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Sort-Object -Unique)
$parentProperties = if ($parentIds.Count) { @(Get-PnpDeviceProperty -InstanceId $parentIds -ErrorAction SilentlyContinue) } else { @() }
$parentPropertyIndex = New-PropertyIndex -Properties $parentProperties
$rows = foreach ($candidate in $candidates) {
  $device = $candidate.device
  $deviceId = [string]$device.InstanceId
  $parentId = [string](Get-IndexedProperty -Index $devicePropertyIndex -InstanceId $deviceId -KeyName 'DEVPKEY_Device_Parent')
  $parentService = [string](Get-IndexedProperty -Index $parentPropertyIndex -InstanceId $parentId -KeyName 'DEVPKEY_Device_Service')
  $port = Get-IndexedProperty -Index $devicePropertyIndex -InstanceId $deviceId -KeyName 'DEVPKEY_Device_Address'
  if (($parentService -ieq 'USBHUB3' -or $parentService -ieq 'USBHUB') -and $null -ne $port -and [uint32]$port -gt 0) {
    $hubDevice = $deviceById[$parentId.ToUpperInvariant()]
    [pscustomobject]@{
      serial = [string]$candidate.serial
      status = $device.Status
      class = $device.Class
      friendlyName = $device.FriendlyName
      problem = $device.Problem
      instanceId = $device.InstanceId
      deviceInstanceId = $deviceId
      hubInstanceId = $parentId
      hubService = $parentService
      hubFriendlyName = [string]$hubDevice.FriendlyName
      usbPort = [uint32]$port
      locationInfo = [string](Get-IndexedProperty -Index $devicePropertyIndex -InstanceId $deviceId -KeyName 'DEVPKEY_Device_LocationInfo')
      locationPaths = @((Get-IndexedProperty -Index $devicePropertyIndex -InstanceId $deviceId -KeyName 'DEVPKEY_Device_LocationPaths') | ForEach-Object { [string]$_ })
      hubLocationPaths = @((Get-IndexedProperty -Index $parentPropertyIndex -InstanceId $parentId -KeyName 'DEVPKEY_Device_LocationPaths') | ForEach-Object { [string]$_ })
    }
  }
}
$rows | ConvertTo-Json -Depth 6 -Compress
`;
  return runPowerShellJsonAsync(script, { FLEET_USB_TOPOLOGY_SERIALS: JSON.stringify(cleanSerials) }, 90000);
}

function usbTopologyCachePath() {
  return path.join(paths.dataDir, "usb-topology-cache.json");
}

function readUsbTopologyCache() {
  const raw = readJsonFile(usbTopologyCachePath(), {});
  const devices = raw && raw.devices && typeof raw.devices === "object" && !Array.isArray(raw.devices)
    ? raw.devices
    : {};
  return {
    schemaVersion: 1,
    updatedAt: raw && raw.updatedAt || "",
    devices,
  };
}

function findUsbTopologyRecord(cache, serial) {
  const devices = cache && cache.devices && typeof cache.devices === "object" ? cache.devices : {};
  const wanted = String(serial || "").trim();
  if (!wanted) return null;
  if (devices[wanted]) return devices[wanted];
  const key = Object.keys(devices).find((value) => value.toLowerCase() === wanted.toLowerCase());
  return key ? devices[key] : null;
}

function usbTopologyStringArray(value) {
  const values = Array.isArray(value) ? value : value ? [value] : [];
  return uniqueStrings(values.map((item) => cleanText(item, 500)).filter(Boolean));
}

function usbTopologyCandidateRank(row) {
  const instanceId = String(row && row.instanceId || "");
  const className = String(row && row.class || "").toUpperCase();
  let rank = 0;
  if (/^USB\\VID_/i.test(instanceId)) rank += 40;
  if (!/&MI_/i.test(instanceId)) rank += 40;
  if (className === "USB") rank += 20;
  if (/composite/i.test(String(row && row.friendlyName || ""))) rank += 5;
  return rank;
}

function updateUsbTopologyCache(rows = []) {
  const cache = readUsbTopologyCache();
  const candidates = new Map();
  for (const row of rows || []) {
    const serial = cleanText(row && row.serial, 120);
    const hubInstanceId = cleanText(row && row.hubInstanceId, 500);
    const hubService = cleanText(row && row.hubService, 80).toUpperCase();
    const port = Number(row && row.usbPort || 0);
    const isPresent = String(row && row.status || "").toUpperCase() === "OK"
      || String(row && row.problem || "") === "CM_PROB_NONE";
    if (!serial || !isPresent || !hubInstanceId || !["USBHUB", "USBHUB3"].includes(hubService) || !Number.isInteger(port) || port < 1 || port > 255) continue;
    const rank = usbTopologyCandidateRank(row);
    const previous = candidates.get(serial.toLowerCase());
    if (!previous || rank > previous.rank) candidates.set(serial.toLowerCase(), { row, serial, rank });
  }
  if (!candidates.size) return { ok: true, cache, updated: 0, warning: "" };

  const observedAt = new Date().toISOString();
  for (const candidate of candidates.values()) {
    const row = candidate.row;
    const existingKey = Object.keys(cache.devices).find((key) => key.toLowerCase() === candidate.serial.toLowerCase());
    if (existingKey && existingKey !== candidate.serial) delete cache.devices[existingKey];
    cache.devices[candidate.serial] = {
      serial: candidate.serial,
      deviceInstanceId: cleanText(row.deviceInstanceId || row.instanceId, 500),
      hubInstanceId: cleanText(row.hubInstanceId, 500),
      hubService: cleanText(row.hubService, 80),
      hubFriendlyName: cleanText(row.hubFriendlyName, 200),
      port: Number(row.usbPort),
      friendlyName: cleanText(row.friendlyName, 200),
      locationInfo: cleanText(row.locationInfo, 300),
      locationPaths: usbTopologyStringArray(row.locationPaths),
      hubLocationPaths: usbTopologyStringArray(row.hubLocationPaths),
      observedAt,
    };
  }
  cache.updatedAt = observedAt;
  try {
    writeJsonFile(usbTopologyCachePath(), cache);
    return { ok: true, cache, updated: candidates.size, warning: "" };
  } catch (error) {
    return { ok: false, cache, updated: 0, warning: `USB位置記録の保存に失敗: ${error.message}` };
  }
}

async function refreshUsbTopologyCache() {
  if (usbTopologyRefreshRunning || process.platform !== "win32") return { ok: true, skipped: true };
  usbTopologyRefreshRunning = true;
  try {
    const summary = buildFleetDbSummaryCached();
    const serials = uniqueStrings((summary.devices || []).map((row) => row && row.serial).filter(Boolean));
    const scanned = await scanActiveAdbDevices({ adbPath: resolveAdbPath() }).catch((error) => ({ devices: [], warning: error.message }));
    const connectedSerials = uniqueStrings((scanned.devices || [])
      .filter((row) => row && row.connected && row.serial)
      .map((row) => String(row.serial)));
    let requested = serials;
    let cache = readUsbTopologyCache();
    let updated = 0;
    let warning = "";
    for (let pass = 1; pass <= 3 && requested.length; pass += 1) {
      const topology = await captureWindowsUsbTopologies(requested);
      if (topology.ok === false) {
        warning = topology.warning || "Windows USB topology scan failed";
        break;
      }
      const saved = updateUsbTopologyCache(topology.rows || []);
      cache = saved.cache || readUsbTopologyCache();
      updated += Number(saved.updated || 0);
      if (saved.warning) warning = saved.warning;
      const missingConnected = connectedSerials.filter((serial) => !findUsbTopologyRecord(cache, serial));
      if (!missingConnected.length) break;
      requested = missingConnected;
    }
    const missingConnected = connectedSerials.filter((serial) => !findUsbTopologyRecord(cache, serial));
    return {
      ok: !warning,
      cache,
      updated,
      connected: connectedSerials.length,
      missingConnected,
      warning,
    };
  } finally {
    usbTopologyRefreshRunning = false;
  }
}

function startUsbTopologyCacheScheduler() {
  const run = () => {
    refreshUsbTopologyCache().then((result) => {
      if (result && result.ok === false) console.warn(`USB topology cache: ${result.warning || "failed"}`);
    }).catch((error) => {
      console.warn(`USB topology cache: ${error.message}`);
    });
  };
  const startupTimer = setTimeout(run, 8000);
  const intervalTimer = setInterval(run, USB_TOPOLOGY_REFRESH_INTERVAL_MS);
  if (typeof startupTimer.unref === "function") startupTimer.unref();
  if (typeof intervalTimer.unref === "function") intervalTimer.unref();
  return intervalTimer;
}

function summarizePnpStatus(rows = []) {
  if (!rows.length) return "なし";
  const okCount = rows.filter((row) => String(row.status || "").toUpperCase() === "OK" || String(row.problem || "") === "CM_PROB_NONE").length;
  const phantomCount = rows.filter((row) => String(row.problem || "").toUpperCase().includes("PHANTOM")).length;
  if (okCount && phantomCount) return `OK ${okCount} / 残骸 ${phantomCount}`;
  if (okCount) return `OK ${okCount}`;
  if (phantomCount) return `残骸 ${phantomCount}`;
  return `${rows.length}件`;
}

function countBy(rows = [], key) {
  const counts = {};
  for (const row of rows) {
    const value = String(row && row[key] || "");
    if (!value) continue;
    counts[value] = (counts[value] || 0) + 1;
  }
  return counts;
}

function diagnosisSeverityRank(value) {
  return { bad: 3, warn: 2, ok: 1 }[String(value || "")] || 0;
}

async function launchUsbPnpRepair(body = {}) {
  if (process.platform !== "win32") {
    return { ok: false, error: "USB自動復旧はWindows専用です。" };
  }
  const requested = normalizeUsbRepairSerials(body);
  if (!requested.length) return { ok: false, error: "復旧対象の端末IDがありません。" };

  const summary = buildFleetDbSummaryCached();
  const allowed = new Set((summary.devices || [])
    .map((row) => serialKey(row && row.serial))
    .filter(Boolean));
  if (body.allowXiaoweiKnown === true) {
    const xiaowei = await readXiaoweiSources().catch(() => ({ devices: [] }));
    for (const row of xiaowei.devices || []) {
      const serial = String(row && row.serial || "").trim();
      if (serial) allowed.add(serialKey(serial));
    }
  }
  const serials = requested.filter((serial) => allowed.has(serialKey(serial)));
  if (!serials.length) {
    return { ok: false, error: "DBまたはXiaoWeiで確認できる端末IDだけ復旧できます。", requested };
  }

  const stamp = localTimestampForId();
  const toolsDir = path.join(paths.root, "tools");
  fs.mkdirSync(toolsDir, { recursive: true });
  const repairScript = path.join(toolsDir, `usb-auto-repair-${stamp}.ps1`);
  const logPath = path.join(toolsDir, `usb-auto-repair-${stamp}.log`);
  const launcherLogPath = path.join(toolsDir, `usb-auto-repair-${stamp}.launcher.log`);
  const resetScript = path.join(toolsDir, "reset-target-usb-pnp.ps1");
  const cycleScript = path.join(toolsDir, "cycle-target-usb-port.ps1");
  const topologyPath = usbTopologyCachePath();
  const adbPath = resolveAdbPath();
  const retryRepair = body.deep !== false;
  const takeover5038 = retryRepair && body.takeover5038 !== false;
  const script = [
    "$ErrorActionPreference = 'Continue'",
    "$serials = @(" + serials.map((serial) => `'${serial.replace(/'/g, "''")}'`).join(", ") + ")",
    `$retryRepair = ${retryRepair ? "$true" : "$false"}`,
    `$takeover5038 = ${takeover5038 ? "$true" : "$false"}`,
    `$root = '${paths.root.replace(/'/g, "''")}'`,
    `$logPath = '${logPath.replace(/'/g, "''")}'`,
    `$resetScript = '${resetScript.replace(/'/g, "''")}'`,
    `$cycleScript = '${cycleScript.replace(/'/g, "''")}'`,
    `$topologyPath = '${topologyPath.replace(/'/g, "''")}'`,
    `$adbPath = '${adbPath.replace(/'/g, "''")}'`,
    "Set-Location -LiteralPath $root",
    "try { Start-Transcript -LiteralPath $logPath -Force | Out-Null } catch {}",
    "Write-Host 'USB/ADB 自動復旧を開始します'",
    "Write-Host ('対象: ' + ($serials -join ', '))",
    "Write-Host ''",
    "Write-Host 'ADBサーバーを止めず、5038の待受だけ確認します'",
    "if (Test-Path -LiteralPath $adbPath) {",
    "  & $adbPath -P 5038 start-server",
    "  Start-Sleep -Seconds 2",
    "  $ports = @(5038)",
    "  if (Get-NetTCPConnection -LocalPort 5037 -State Listen -ErrorAction SilentlyContinue) { $ports += 5037 }",
    "  foreach ($port in $ports) {",
    "    $adbRows = @(& $adbPath -P $port devices 2>$null)",
    "    foreach ($serial in $serials) {",
    "      $offlinePattern = '^' + [regex]::Escape($serial) + '\\s+offline(?:\\s|$)'",
    "      if ($adbRows -match $offlinePattern) {",
    "        Write-Host ($port.ToString() + ' ADB offline再接続: ' + $serial)",
    "        & $adbPath -P $port -s $serial reconnect 2>$null | Out-Host",
    "      }",
    "    }",
    "  }",
    "}",
    "Write-Host ''",
    "& $resetScript -Apply -Serials $serials -TopologyPath $topologyPath",
    "Write-Host ''",
    "Write-Host '対象端末が待受中のADBへ戻るのを確認します'",
    "$waiting = @($serials)",
    "if (Test-Path -LiteralPath $adbPath) {",
    "  & $adbPath -P 5038 start-server",
    "  foreach ($pass in 1..8) {",
    "    $ports = @(5038)",
    "    if (Get-NetTCPConnection -LocalPort 5037 -State Listen -ErrorAction SilentlyContinue) { $ports += 5037 }",
    "    $adbRowsByPort = @{}",
    "    foreach ($port in $ports) { $adbRowsByPort[$port] = @(& $adbPath -P $port devices 2>$null) }",
    "    $waiting = @()",
    "    foreach ($serial in $serials) {",
    "      $pattern = '^' + [regex]::Escape($serial) + '\\s+device(?:\\s|$)'",
    "      $foundPort = $null",
    "      foreach ($port in $ports) {",
    "        if ($adbRowsByPort[$port] -match $pattern) { $foundPort = $port; break }",
    "      }",
    "      if ($foundPort) { Write-Host ($foundPort.ToString() + '復帰: ' + $serial) } else { $waiting += $serial }",
    "    }",
    "    if (-not $waiting.Count) { break }",
    "    Write-Host ('ADB待機 ' + $pass + '/8: ' + ($waiting -join ', '))",
    "    Start-Sleep -Seconds 2",
    "  }",
    "} else {",
    "  Write-Host ('ADBが見つかりません: ' + $adbPath)",
    "}",
    "if ($waiting.Count -and $retryRepair -and (Test-Path -LiteralPath $cycleScript)) {",
    "  Write-Host ''",
    "  Write-Host '第1段階で戻らない端末だけ、記憶済みの対象USBポートをもう一度再接続します' -ForegroundColor Yellow",
    "  Write-Host 'USBハブ全体や他の端末は再起動しません。' -ForegroundColor Yellow",
    "  Write-Host ('対象: ' + ($waiting -join ', '))",
    "  & $cycleScript -Serials $waiting -TopologyPath $topologyPath",
    "  Start-Sleep -Seconds 6",
    "  foreach ($pass in 1..8) {",
    "    $ports = @(5038)",
    "    if (Get-NetTCPConnection -LocalPort 5037 -State Listen -ErrorAction SilentlyContinue) { $ports += 5037 }",
    "    $adbRowsByPort = @{}",
    "    foreach ($port in $ports) { $adbRowsByPort[$port] = @(& $adbPath -P $port devices 2>$null) }",
    "    $stillWaiting = @()",
    "    foreach ($serial in $waiting) {",
    "      $pattern = '^' + [regex]::Escape($serial) + '\\s+device(?:\\s|$)'",
    "      $foundPort = $null",
    "      foreach ($port in $ports) {",
    "        if ($adbRowsByPort[$port] -match $pattern) { $foundPort = $port; break }",
    "      }",
    "      if ($foundPort) { Write-Host ($foundPort.ToString() + '復帰: ' + $serial) } else { $stillWaiting += $serial }",
    "    }",
    "    $waiting = @($stillWaiting)",
    "    if (-not $waiting.Count) { break }",
    "    Write-Host ('対象ポート再接続後のADB待機 ' + $pass + '/8: ' + ($waiting -join ', '))",
    "    Start-Sleep -Seconds 2",
    "  }",
    "}",
    "if ($waiting.Count -and $retryRepair) {",
    "  Write-Host ''",
    "  Write-Host '強い復旧: 戻らない選択端末のWindows USB記録を現役分も含めて作り直します' -ForegroundColor Yellow",
    "  Write-Host '親USBハブは無効化しません。選択していない端末のPnP記録も削除しません。' -ForegroundColor Yellow",
    "  Write-Host ('対象: ' + ($waiting -join ', '))",
    "  if ($takeover5038 -and (Test-Path -LiteralPath $adbPath)) {",
    "    if (Get-NetTCPConnection -LocalPort 5037 -State Listen -ErrorAction SilentlyContinue) {",
    "      Write-Host 'ADB 5037を停止し、XiaoWei用5038へ主導権を戻します。5037利用端末は一時的に再接続されます。' -ForegroundColor Yellow",
    "      & $adbPath -P 5037 kill-server 2>$null | Out-Host",
    "      Start-Sleep -Seconds 2",
    "    }",
    "    & $adbPath -P 5038 start-server 2>$null | Out-Host",
    "    & $adbPath -P 5038 reconnect offline 2>$null | Out-Host",
    "  }",
    "  & $resetScript -Apply -ForceReenumerate -Serials $waiting -TopologyPath $topologyPath",
    "  Start-Sleep -Seconds 6",
    "  if (Test-Path -LiteralPath $adbPath) {",
    "    foreach ($pass in 1..12) {",
    "      & $adbPath -P 5038 start-server 2>$null | Out-Null",
    "      $ports = @(5038)",
    "      if (Get-NetTCPConnection -LocalPort 5037 -State Listen -ErrorAction SilentlyContinue) { $ports += 5037 }",
    "      $adbRowsByPort = @{}",
    "      foreach ($port in $ports) { $adbRowsByPort[$port] = @(& $adbPath -P $port devices 2>$null) }",
    "      $stillWaiting = @()",
    "      foreach ($serial in $waiting) {",
    "        $pattern = '^' + [regex]::Escape($serial) + '\\s+device(?:\\s|$)'",
    "        $foundPort = $null",
    "        foreach ($port in $ports) {",
    "          if ($adbRowsByPort[$port] -match $pattern) { $foundPort = $port; break }",
    "        }",
    "        if ($foundPort) { Write-Host ($foundPort.ToString() + '強制復帰: ' + $serial) } else { $stillWaiting += $serial }",
    "      }",
    "      $waiting = @($stillWaiting)",
    "      if (-not $waiting.Count) { break }",
    "      Write-Host ('強制再列挙後のADB待機 ' + $pass + '/12: ' + ($waiting -join ', '))",
    "      Start-Sleep -Seconds 2",
    "    }",
    "  }",
    "}",
    "Write-Host ''",
    "if ($waiting.Count) {",
    "  Write-Host ('自動処置後もADBに戻っていません: ' + ($waiting -join ', ')) -ForegroundColor Yellow",
    "  foreach ($serial in $waiting) {",
    "    $pnpIds = @(Get-PnpDevice -Class USB,USBDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object { ([string]$_.InstanceId) -match [regex]::Escape($serial) } | ForEach-Object { [string]$_.InstanceId })",
    "    if ($pnpIds -match 'VID_18D1&PID_4EE8') {",
    "      Write-Host ($serial + ': スマホ側がUSB MIDIモードで、ADB機能を出していません。USBデバッグをOFF→ONしてから抜き差ししてください。') -ForegroundColor Yellow",
    "    } else {",
    "      Write-Host ($serial + ': USBデバッグをOFF→ONし、直らない場合だけ抜き差ししてください。') -ForegroundColor Yellow",
    "    }",
    "  }",
    "} else {",
    "  Write-Host '自動復旧成功。対象端末はADBへ戻りました。' -ForegroundColor Green",
    "}",
    "try { Stop-Transcript | Out-Null } catch {}",
    "Start-Sleep -Seconds 12",
  ].join("\r\n");
  // Windows PowerShell 5.1 requires a BOM to reliably parse UTF-8 scripts containing Japanese text.
  fs.writeFileSync(repairScript, `\uFEFF${script}`, "utf8");

  const elevatedCommand = `& ${powershellSingleQuote(repairScript)}`;
  const encodedCommand = Buffer.from(elevatedCommand, "utf16le").toString("base64");
  const command = [
    "$ErrorActionPreference = 'Stop'",
    "$launcherLog = " + powershellSingleQuote(launcherLogPath),
    "try {",
    `  Start-Process -FilePath 'powershell.exe' -ArgumentList '-NoProfile -ExecutionPolicy Bypass -EncodedCommand ${encodedCommand}' -Verb RunAs -WindowStyle Normal`,
    "  ('STARTED ' + (Get-Date -Format o)) | Set-Content -LiteralPath $launcherLog -Encoding UTF8",
    "} catch {",
    "  ('FAILED ' + $_.Exception.Message) | Set-Content -LiteralPath $launcherLog -Encoding UTF8",
    "  exit 1",
    "}",
  ].join("; ");
  const child = spawn("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command], {
    cwd: paths.root,
    windowsHide: false,
    detached: false,
    stdio: "ignore",
  });
  const recoveryHistory = recordFleetRecoveryAttempts(serials, {
    requestId: stamp,
    deepRepair: retryRepair,
    takeover5038,
  });
  return {
    ok: true,
    launched: true,
    deepRepair: retryRepair,
    takeover5038,
    serials,
    requested,
    repairScript,
    logPath,
    launcherLogPath,
    launcherPid: child.pid || null,
    recoveryHistory,
    message: "管理者PowerShellを起動しました。UACが出たら許可してください。",
  };
}

function normalizeUsbRepairSerials(body = {}) {
  const values = Array.isArray(body.serials)
    ? body.serials
    : body.serial
      ? [body.serial]
      : [];
  return uniqueStrings(values
    .map((value) => cleanText(value, 120))
    .filter((value) => /^[A-Za-z0-9_.:-]+$/.test(value)));
}

function powershellSingleQuote(value) {
  return `'${String(value || "").replace(/'/g, "''")}'`;
}

function xiaoweiProjectionIssueCodes(fleet, xw, context = {}) {
  const issues = [];
  const serial = String((fleet && fleet.serial) || (xw && xw.serial) || "");
  const apiSerials = context.apiSerials || new Set();
  const hasFleet = Boolean(fleet);
  const hasXw = Boolean(xw);
  const hasApi = serial && apiSerials.has(serialKey(serial));
  const desiredNumber = cleanText(hasFleet ? (fleet.xiaoweiNumber || fleet.laixiNumber || fleet.xiaoweiSort) : "", 20);
  const xwNumber = xw && xw.sort !== null && xw.sort !== undefined ? cleanText(xw.sort, 20) : "";
  const desiredName = cleanText(hasFleet ? (fleet.deviceLabel || fleet.laixiName || fleet.xiaoweiName) : "", 120);
  const xwName = cleanText(xw && xw.name, 120);

  if (!hasFleet) issues.push("fleet_missing");
  if (!hasXw) issues.push("xiaowei_missing");
  if (hasXw && !hasApi) issues.push("not_projected");
  if (hasApi && !xiaoweiHasUsableResolution(xw)) issues.push("resolution_zero");
  if (hasXw && !xwNumber) issues.push("number_missing");
  if (hasXw && (!xwName || xwName === "-")) issues.push("name_missing");
  if (desiredNumber && xwNumber && desiredNumber !== xwNumber) issues.push("number_mismatch");
  if (desiredName && xwName && xwName !== "-" && !normalizeCompareText(xwName).includes(normalizeCompareText(desiredName))) {
    issues.push("name_mismatch");
  }

  return [...new Set(issues)];
}

function xiaoweiHasUsableResolution(xw) {
  const sourceWidth = Number(xw && xw.sourceWidth);
  const sourceHeight = Number(xw && xw.sourceHeight);
  if (Number.isFinite(sourceWidth) || Number.isFinite(sourceHeight)) {
    return sourceWidth > 0 && sourceHeight > 0;
  }
  const raw = xw && xw.apiRaw || {};
  const rawWidth = Number(raw.sourceWidth || raw.screenWidth || raw.displayWidth);
  const rawHeight = Number(raw.sourceHeight || raw.screenHeight || raw.displayHeight);
  if (Number.isFinite(rawWidth) || Number.isFinite(rawHeight)) return rawWidth > 0 && rawHeight > 0;
  return false;
}

function xiaoweiProjectionState(xw, context = {}) {
  if (!xw) return "未認識";
  const serial = String(xw.serial || "");
  if (!serial || !(context.apiSerials || new Set()).has(serialKey(serial))) return "未投影";
  return xiaoweiHasUsableResolution(xw) ? "投影中" : "投影NG";
}

function xiaoweiResolutionLabel(xw) {
  if (!xw) return "-";
  const width = Number(xw.sourceWidth);
  const height = Number(xw.sourceHeight);
  if (Number.isFinite(width) && Number.isFinite(height)) return `${width}x${height}`;
  return "0x0";
}

function xiaoweiProjectionIssueLabel(code) {
  return {
    fleet_missing: "DB未登録",
    xiaowei_missing: "XiaoWei未認識",
    not_projected: "未投影",
    resolution_zero: "0x0",
    number_missing: "番号なし",
    name_missing: "名前なし",
    number_mismatch: "番号違い",
    name_mismatch: "名前違い",
  }[String(code || "")] || String(code || "");
}

function normalizeCompareText(value) {
  return cleanText(value, 120).toLowerCase().replace(/\s+/g, "");
}

function auditFleetDeviceCodes() {
  const summary = buildFleetDbSummaryCached();
  if (!summary || summary.ok === false) return { ok: false, error: summary && summary.error || "fleet-db summary failed" };
  const { db } = readFleetDbForWrite();
  const retiredReservations = retiredDeviceCodeReservations(db);
  const rows = (summary.devices || [])
    .filter((row) => row && row.serial)
    .map((row) => {
      const parsed = parseDeviceCode(row.deviceCode, row.modelGroup, row.carrierCode) || parseDeviceCode(row.deviceCode);
      const sequence = parsed && Number(parsed.sequence);
      const expectedLabel = parsed ? `${parsed.base}-${String(parsed.sequence).padStart(2, "0")} ${parsed.carrier || row.carrierCode || ""}`.trim() : "";
      const label = row.deviceLabel || "";
      const issues = [];
      if (!parsed) issues.push("code_missing");
      if (parsed && label && normalizeCompareText(label) !== normalizeCompareText(expectedLabel)) issues.push("display_mismatch");
      return {
        managementId: row.managementId || "",
        xiaoweiNumber: row.xiaoweiNumberOverride || row.laixiNumberOverride || row.xiaoweiSort || row.xiaoweiNumber || row.laixiNumber || "",
        serial: row.serial || "",
        base: parsed && parsed.base || row.modelGroup || "",
        carrier: parsed && parsed.carrier || row.carrierCode || "",
        sequence: Number.isFinite(sequence) ? sequence : null,
        deviceCode: row.deviceCode || "",
        deviceLabel: label,
        expectedLabel,
        xiaoweiName: row.xiaoweiName || "",
        status: row.status || "",
        issues,
      };
    });

  const groups = new Map();
  for (const row of rows) {
    const key = `${row.base}::${row.carrier}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(row);
  }

  const issueRows = [];
  const groupRows = [];
  for (const [key, group] of groups.entries()) {
    const [base, carrier] = key.split("::");
    const reservedSequences = retiredReservations.get(key) || new Set();
    const withSequence = group.filter((row) => Number.isFinite(Number(row.sequence)));
    const bySequence = new Map();
    for (const row of withSequence) {
      const seq = Number(row.sequence);
      if (!bySequence.has(seq)) bySequence.set(seq, []);
      bySequence.get(seq).push(row);
    }

    const sequences = [...new Set([...bySequence.keys(), ...reservedSequences])].sort((a, b) => a - b);
    const max = sequences.length ? sequences[sequences.length - 1] : 0;
    const missing = [];
    for (let seq = 1; seq <= max; seq += 1) {
      if (!bySequence.has(seq) && !reservedSequences.has(seq)) missing.push(seq);
    }
    const duplicates = [...new Set([
      ...[...bySequence.entries()]
      .filter(([, items]) => items.length > 1)
      .map(([seq]) => seq),
      ...[...bySequence.keys()].filter((seq) => reservedSequences.has(seq)),
    ])].sort((a, b) => a - b);

    const orderedBands = new Map();
    for (const row of withSequence) {
      const band = Number(row.xiaoweiNumber || 0) >= 1000 ? "parking" : "active";
      if (!orderedBands.has(band)) orderedBands.set(band, []);
      orderedBands.get(band).push(row);
    }
    for (const bandRows of orderedBands.values()) {
      const ordered = bandRows.slice().sort(compareDeviceCodeAuditOrder);
      let previousSequence = 0;
      for (const row of ordered) {
        if (previousSequence && row.sequence < previousSequence) row.issues.push("order_mismatch");
        previousSequence = row.sequence;
      }
    }
    withSequence.forEach((row) => {
      if (duplicates.includes(row.sequence)) row.issues.push("duplicate_sequence");
    });
    for (const row of group) {
      if (row.issues.length) {
        issueRows.push({
          ...row,
          issueLabels: row.issues.map(deviceCodeAuditIssueLabel),
          expectedSequenceByOrder: null,
        });
      }
    }
    if (missing.length || duplicates.length || group.some((row) => row.issues.length)) {
      groupRows.push({
        base,
        carrier,
        count: group.length,
        reservedSequences: [...reservedSequences].sort((a, b) => a - b),
        missingSequences: missing,
        duplicateSequences: duplicates,
        issueCount: group.filter((row) => row.issues.length).length,
      });
    }
  }

  issueRows.sort((a, b) =>
    String(a.base).localeCompare(String(b.base), "en", { numeric: true }) ||
    carrierSortValue(a.carrier) - carrierSortValue(b.carrier) ||
    Number(a.sequence || 9999) - Number(b.sequence || 9999) ||
    String(a.managementId).localeCompare(String(b.managementId), "en", { numeric: true })
  );
  groupRows.sort((a, b) =>
    String(a.base).localeCompare(String(b.base), "en", { numeric: true }) ||
    carrierSortValue(a.carrier) - carrierSortValue(b.carrier)
  );

  return {
    ok: true,
    checkedAt: new Date().toISOString(),
    dbCount: rows.length,
    groupCount: groups.size,
    issueCount: issueRows.length,
    groups: groupRows,
    rows: issueRows,
  };
}

function repairFleetDeviceCodeGaps() {
  const { dbPath, db } = readFleetDbForWrite();
  const repairGroups = findRepairableDeviceCodeGroups(db);
  const targets = repairGroups.filter((group) => group.missingSequences.length || group.duplicateSequences.length);
  if (!targets.length) {
    return {
      ok: true,
      repaired: 0,
      changedDevices: 0,
      backup: "",
      message: "重複または抜けがある連番グループはありません。",
      groups: repairGroups.map(summarizeRepairGroup),
      audit: auditFleetDeviceCodes(),
    };
  }

  const backup = backupFleetDb();
  const now = new Date().toISOString();
  const devicesBySerial = buildDevicesBySerial(db);
  const changes = [];
  for (const group of targets) {
    const ordered = group.rows.slice().sort(compareDeviceCodeRepairOrder);
    const reserved = new Set(group.reservedSequences || []);
    let nextSequence = 1;
    ordered.forEach((row) => {
      const device = devicesBySerial.get(row.serial);
      if (!device) return;
      while (reserved.has(nextSequence)) nextSequence += 1;
      const nextCode = `${group.base}-${group.carrier}-${String(nextSequence).padStart(2, "0")}`;
      const beforeCode = device.deviceCode || "";
      const beforeUi = device.uiNameOverride || "";
      device.deviceCode = nextCode;
      device.uiNameOverride = fixedDeviceLabel(device);
      if (device.deviceCode !== beforeCode || device.uiNameOverride !== beforeUi) {
        device.updatedAt = now;
        changes.push({
          serial: row.serial,
          managementId: device.managementId || "",
          xiaoweiNumber: device.laixiNumberOverride || device.xiaoweiSort || "",
          base: group.base,
          carrier: group.carrier,
          beforeCode,
          afterCode: device.deviceCode,
          beforeLabel: beforeUi,
          afterLabel: device.uiNameOverride,
        });
      }
      nextSequence += 1;
    });
  }

  let changedWithdrawals = 0;
  for (const row of db.withdrawals || []) {
    if (!row || !row.serial) continue;
    const device = devicesBySerial.get(row.serial);
    if (!device) continue;
    const desiredName = fixedDeviceLabel(device) || device.name || row.deviceName || "";
    const desiredManagementId = device.managementId || row.managementId || "";
    const before = `${row.deviceName || ""}::${row.managementId || ""}`;
    row.deviceName = desiredName;
    row.managementId = desiredManagementId;
    if (`${row.deviceName || ""}::${row.managementId || ""}` !== before) {
      row.updatedAt = now;
      changedWithdrawals += 1;
    }
  }

  db.updatedAt = now;
  writeJsonFile(dbPath, db);
  return {
    ok: true,
    repaired: targets.length,
    changedDevices: changes.length,
    changedWithdrawals,
    generatedAt: now,
    backup,
    groups: targets.map(summarizeRepairGroup),
    changes,
    audit: auditFleetDeviceCodes(),
  };
}

function findRepairableDeviceCodeGroups(db) {
  const groups = new Map();
  const retiredReservations = retiredDeviceCodeReservations(db);
  for (const device of Object.values(db.physicalDevices || {})) {
    if (!device || !device.serial || device.retiredAt) continue;
    const base = deviceCodeBase(device);
    const carrier = deviceCarrierCode(device);
    const parsed = parseDeviceCode(fixedDeviceCode(device), base, carrier) || parseDeviceCode(fixedDeviceCode(device));
    if (!parsed || !Number.isFinite(Number(parsed.sequence))) continue;
    const key = `${parsed.base}::${parsed.carrier || carrier}`;
    if (!groups.has(key)) groups.set(key, { base: parsed.base, carrier: parsed.carrier || carrier, rows: [] });
    groups.get(key).rows.push({
      serial: device.serial,
      managementId: device.managementId || "",
      xiaoweiNumber: device.laixiNumberOverride || device.xiaoweiSort || "",
      sequence: Number(parsed.sequence),
      deviceCode: device.deviceCode || "",
    });
  }
  return [...groups.values()].map((group) => {
    const bySequence = new Map();
    for (const row of group.rows) {
      if (!bySequence.has(row.sequence)) bySequence.set(row.sequence, []);
      bySequence.get(row.sequence).push(row);
    }
    const key = `${group.base}::${group.carrier}`;
    const reservedSequences = retiredReservations.get(key) || new Set();
    const sequences = [...new Set([...bySequence.keys(), ...reservedSequences])].sort((a, b) => a - b);
    const max = sequences.length ? sequences[sequences.length - 1] : 0;
    const missingSequences = [];
    for (let seq = 1; seq <= max; seq += 1) {
      if (!bySequence.has(seq) && !reservedSequences.has(seq)) missingSequences.push(seq);
    }
    const duplicateSequences = [...new Set([
      ...[...bySequence.entries()]
      .filter(([, items]) => items.length > 1)
      .map(([seq]) => seq),
      ...[...bySequence.keys()].filter((seq) => reservedSequences.has(seq)),
    ])].sort((a, b) => a - b);
    return {
      ...group,
      reservedSequences: [...reservedSequences].sort((a, b) => a - b),
      missingSequences,
      duplicateSequences,
    };
  });
}

function summarizeRepairGroup(group) {
  return {
    base: group.base,
    carrier: group.carrier,
    count: group.rows.length,
    reservedSequences: group.reservedSequences || [],
    missingSequences: group.missingSequences,
    duplicateSequences: group.duplicateSequences,
  };
}

function compareDeviceCodeRepairOrder(a, b) {
  return Number(a.xiaoweiNumber || 999999) - Number(b.xiaoweiNumber || 999999) ||
    Number(managementNumberFromId(a.managementId) || 999999) - Number(managementNumberFromId(b.managementId) || 999999) ||
    String(a.serial || "").localeCompare(String(b.serial || ""), "en");
}

function compareDeviceCodeAuditOrder(a, b) {
  return Number(a.xiaoweiNumber || 999999) - Number(b.xiaoweiNumber || 999999) ||
    Number(managementNumberFromId(a.managementId) || 999999) - Number(managementNumberFromId(b.managementId) || 999999) ||
    String(a.serial || "").localeCompare(String(b.serial || ""), "en");
}

function deviceCodeAuditIssueLabel(code) {
  return {
    code_missing: "端末名なし",
    display_mismatch: "表示名ズレ",
    order_mismatch: "連番順ズレ",
    duplicate_sequence: "連番重複",
  }[String(code || "")] || String(code || "");
}

function summarizeLegacyMirrorRead(legacyMirror) {
  return {
    ok: legacyMirror.ok,
    available: legacyMirror.available,
    apiReachable: legacyMirror.reachable,
    apiStatusCode: legacyMirror.statusCode,
    apiMessage: legacyMirror.message,
    apiUrl: legacyMirror.url,
    count: legacyMirror.count || legacyMirror.devices.length,
    warning: legacyMirror.warning,
    devices: legacyMirror.devices,
  };
}

function summarizeLegacyMirrorGroupsRead(legacyMirror) {
  return {
    ok: legacyMirror.ok,
    available: legacyMirror.available,
    apiReachable: legacyMirror.reachable,
    apiStatusCode: legacyMirror.statusCode,
    apiMessage: legacyMirror.message,
    apiUrl: legacyMirror.url,
    count: legacyMirror.count || legacyMirror.groups.length,
    warning: legacyMirror.warning,
    groups: legacyMirror.groups,
  };
}

function summarizeLegacyMirrorMutation(legacyMirror) {
  return {
    ok: legacyMirror.ok,
    available: legacyMirror.available,
    apiReachable: legacyMirror.reachable,
    apiStatusCode: legacyMirror.statusCode,
    apiMessage: legacyMirror.message,
    apiUrl: legacyMirror.url,
    warning: legacyMirror.warning,
    data: legacyMirror.data,
    raw: legacyMirror.raw,
  };
}

async function exportObsidianSummary(options = {}) {
  const snapshot = await getDevices();
  const events = readEvents({ limit: Number(options.limit || 40) });
  const now = new Date();
  const day = localDateStamp(now);
  const content = buildObsidianSummary({ snapshot, events, date: now });
  const fileName = `${day}-android-fleet.md`;
  const candidates = resolveObsidianExportDirs(options.targetDir);
  const errors = [];

  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      const file = path.join(dir, fileName);
      fs.writeFileSync(file, content, "utf8");
      appendAuditLog({
        type: "obsidian_export",
        title: "Obsidian daily summary exported",
        level: "info",
        details: { file, devices: snapshot.devices.length },
      });
      return { ok: true, file, fallback: dir.includes(`${path.sep}data${path.sep}`), errors };
    } catch (error) {
      errors.push({ dir, error: error.message });
    }
  }

  return { ok: false, error: "Obsidian vault path was not found", errors };
}

function buildObsidianSummary({ snapshot, events, date }) {
  const devices = Array.isArray(snapshot.devices) ? snapshot.devices : [];
  const connected = devices.filter((device) => device.connected).length;
  const reviewDevices = devices.filter((device) => ["blocked", "watch", "reset"].includes(device.state));
  const xiaowei = snapshot.xiaowei || {};
  const lines = [
    `# Android Fleet Daily Snapshot ${localDateStamp(date)}`,
    "",
    "## Summary",
    `- Generated: ${localDateTime(date)}`,
    `- Devices: ${devices.length}`,
    `- Connected: ${connected}`,
    `- Review: ${reviewDevices.length}`,
    `- ADB: ${snapshot.adbAvailable ? "available" : "unavailable"}`,
    `- XiaoWei DB: ${xiaowei.dbAvailable ? "available" : "unavailable"}`,
    `- XiaoWei API: ${xiaowei.apiAvailable ? "available" : xiaowei.apiLocked ? "locked" : "unavailable"}`,
    "",
    "## Review Devices",
  ];

  if (reviewDevices.length) {
    for (const device of reviewDevices) {
      lines.push(`- ${deviceLabel(device)} / ${device.state || "unknown"} / ${device.recommendedAction || "check"}`);
    }
  } else {
    lines.push("- None");
  }

  lines.push("", "## Devices", "| XiaoWei | Name | Serial | Connected | State | Action | Screenshot |", "| --- | --- | --- | --- | --- | --- | --- |");
  for (const device of devices) {
    lines.push([
      markdownCell(Number.isFinite(device.xiaoweiSort) ? `#${device.xiaoweiSort}` : ""),
      markdownCell(device.displayName || device.name || ""),
      markdownCell(device.serial || ""),
      markdownCell(device.connected ? "yes" : "no"),
      markdownCell(device.state || "unknown"),
      markdownCell(device.recommendedAction || ""),
      markdownCell(device.lastScreenshotAt ? localDateTime(new Date(device.lastScreenshotAt)) : ""),
    ].join("|").replace(/^/, "|").replace(/$/, "|"));
  }

  const recentEvents = Array.isArray(events) ? events.slice(0, 20) : [];
  lines.push("", "## Recent Events");
  if (recentEvents.length) {
    for (const event of recentEvents) {
      lines.push(`- ${localDateTime(new Date(event.at))} / ${event.type || "event"} / ${event.serial || "-"} / ${event.title || summarizeEventForMarkdown(event)}`);
    }
  } else {
    lines.push("- None");
  }

  lines.push("", "## Notes", "- Generated from the local Android Fleet database.");
  return lines.join("\n");
}
function readEvents(options = {}) {
  const file = path.join(paths.dataDir, "events.jsonl");
  const limit = clamp(Number(options.limit || 50), 1, 500);
  const serial = options.serial || "";
  const includeScans = Boolean(options.includeScans);

  if (!fs.existsSync(file)) return [];

  const lines = fs.readFileSync(file, "utf8").split(/\r?\n/).filter(Boolean);
  const events = [];

  for (let index = lines.length - 1; index >= 0; index -= 1) {
    const event = parseEventLine(lines[index]);
    if (!event) continue;
    if (!includeScans && event.type === "device_scan") continue;
    if (serial && event.serial !== serial) continue;
    events.push(event);
    if (events.length >= limit) break;
  }

  return events;
}

function parseEventLine(line) {
  try {
    const event = JSON.parse(line);
    return event && typeof event === "object" ? event : null;
  } catch {
    return null;
  }
}

function resolveObsidianExportDirs(preferredDir) {
  const dirs = [];
  if (preferredDir) dirs.push(path.resolve(preferredDir));
  if (process.env.OBSIDIAN_VAULT_DIR) {
    dirs.push(path.join(path.resolve(process.env.OBSIDIAN_VAULT_DIR), "AI_Context", "logs", "android_fleet"));
  }
  dirs.push(path.join(DEFAULT_OBSIDIAN_VAULT_DIR, "AI_Context", "logs", "android_fleet"));
  dirs.push(path.join(paths.dataDir, "obsidian-export", "android_fleet"));
  return [...new Set(dirs)];
}

function deviceLabel(device) {
  return [device.displayName || device.name || "unknown device", device.serial].filter(Boolean).join(" / ");
}

function summarizeEventForMarkdown(event) {
  if (!event || typeof event !== "object") return "";
  if (event.content) return String(event.content).replace(/\s+/g, " ").slice(0, 120);
  if (event.details && event.details.error) return event.details.error;
  if (event.details && event.details.action) return `action ${event.details.action}`;
  return "";
}

function markdownCell(value) {
  return ` ${String(value === undefined || value === null ? "" : value).replace(/\|/g, "\\|").replace(/\r?\n/g, " ")} `;
}

function localDateStamp(date) {
  return new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

function localDateTime(date) {
  return new Intl.DateTimeFormat("ja-JP", {
    timeZone: "Asia/Tokyo",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function clamp(value, min, max) {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, value));
}

function mergeXiaoweiSourceDevices(dbDevices = [], apiDevices = []) {
  const merged = new Map();

  for (const device of dbDevices) {
    if (!device.serial) continue;
    merged.set(serialKey(device.serial), {
      ...device,
      dbSort: device.sort,
      source: "db",
    });
  }

  for (const device of apiDevices) {
    if (!device.serial) continue;
    const key = serialKey(device.serial);
    const fromDb = merged.get(key);
    merged.set(key, {
      ...(fromDb || {}),
      ...device,
      dbSort: fromDb ? fromDb.dbSort : undefined,
      apiSort: device.sort,
      source: fromDb ? "db+api" : "api",
    });
  }

  return [...merged.values()];
}

function suggestAction(device) {
  if (!device.connected) return "Connect device and check USB/ADB.";
  if (device.state === "blocked") return "Manual check required.";
  if (device.state === "watch") return "Monitor this device.";
  if (device.state === "rest") return "Inactive device.";
  return "";
}

function mergeXiaoweiDevices(devices, xiaowei) {
  const bySerial = xiaowei && xiaowei.bySerial ? xiaowei.bySerial : {};
  const out = [];
  const seen = new Set();

  for (const device of devices) {
    const key = serialKey(device.serial);
    const match = bySerial[device.serial] || bySerial[key];
    seen.add(key);
    out.push(decorateWithXiaowei(device, match));
  }

  if (xiaowei && Array.isArray(xiaowei.devices)) {
    for (const item of xiaowei.devices) {
      if (seen.has(serialKey(item.serial))) continue;
      out.push(decorateWithXiaowei({
        serial: item.serial,
        connected: false,
        adbStatus: "offline",
      }, item));
    }
  }

  return out;
}

function decorateWithXiaowei(device, xiaoweiDevice) {
  if (!xiaoweiDevice) {
    return {
      ...device,
      displayName: device.name || device.model || device.serial,
      xiaowei: { matched: false },
    };
  }

  return {
    ...device,
    displayName: xiaoweiDevice.name || device.name || device.model || device.serial,
    xiaoweiName: xiaoweiDevice.name,
    xiaoweiSort: xiaoweiDevice.sort,
    xiaoweiRemark: xiaoweiDevice.remark,
    xiaoweiIntranetIp: xiaoweiDevice.intranetIp,
    xiaowei: {
      matched: true,
      ...xiaoweiDevice,
    },
  };
}

function compareFleetDevices(a, b) {
  const aSort = Number.isFinite(a.xiaoweiSort) ? a.xiaoweiSort : null;
  const bSort = Number.isFinite(b.xiaoweiSort) ? b.xiaoweiSort : null;

  if (aSort !== null && bSort !== null && aSort !== bSort) return aSort - bSort;
  if (aSort !== null && bSort === null) return -1;
  if (aSort === null && bSort !== null) return 1;

  return String(a.displayName || a.name || a.serial).localeCompare(String(b.displayName || b.name || b.serial));
}

function summarizeAdbActionResult(result) {
  if (!result || typeof result !== "object") return {};

  const summary = {
    ok: Boolean(result.ok),
    action: result.action,
    code: result.code,
    error: result.error,
    via: result.via,
  };

  const actionResult = result.result && typeof result.result === "object" ? result.result : {};

  if (result.action === "extract_app_bundle") {
    delete summary.error;
    summary.result = {
      bundleType: "apkm",
      bundleCreated: actionResult.ok === true,
      splitCount: safeAuditCount(actionResult.splitCount),
      pulledCount: Array.isArray(actionResult.pulled) ? actionResult.pulled.length : 0,
      backupCreated: Boolean(actionResult.backupPath),
      versionRead: actionResult.version?.ok === true,
      packageDetected: Boolean(actionResult.detected?.packageName),
    };
    return summary;
  }

  if (result.action === "packages") {
    const directPackages = Array.isArray(actionResult.packages) ? actionResult.packages.length : 0;
    const xiaoweiPackages = directPackages
      ? 0
      : Object.values(actionResult)
        .filter((value) => Array.isArray(value))
        .reduce((sum, value) => sum + value.length, 0);
    summary.result = {
      packageCount: directPackages || xiaoweiPackages,
      labelCount: safeAuditCount(actionResult.labelCount),
      labelsAvailable: actionResult.labelsAvailable === true,
      labelStatus: ["complete", "partial", "unavailable"].includes(actionResult.labelStatus)
        ? actionResult.labelStatus
        : "",
    };
    return summary;
  }

  if (result.result && typeof result.result === "object") {
    summary.result = {
      ...result.result,
      text: result.action === "clipboard_text" && result.result.text
        ? `[${String(result.result.text).length} clipboard characters omitted from audit log]`
        : result.result.text,
      packages: Array.isArray(result.result.packages)
        ? `[${result.result.packages.length} package names omitted from audit log]`
        : result.result.packages,
      apps: Array.isArray(result.result.apps)
        ? `[${result.result.apps.length} app labels omitted from audit log]`
        : result.result.apps,
      raw: result.result.raw ? "[raw output omitted from audit log]" : result.result.raw,
    };
  }

  return summary;
}

function safeAuditCount(value) {
  const count = Number(value);
  return Number.isSafeInteger(count) && count >= 0 ? count : 0;
}

async function createSupportDiagnosticsReport(requestBody = {}) {
  const fleetSnapshot = buildFleetDbSummaryCached();
  const planSnapshot = readSupportDiagnosticsPlanSnapshot();
  const liveSnapshot = await readSupportDiagnosticsLiveSnapshot(fleetSnapshot, planSnapshot);
  const installation = readOrCreateSupportInstallationId();
  const expectedAssets = readSupportDiagnosticsExpectedAssets();
  const clientAssets = requestBody && requestBody.clientAssets && typeof requestBody.clientAssets === "object"
    ? requestBody.clientAssets
    : {};
  return buildSupportDiagnostics({
    appDir: __dirname,
    appVersion: readFleetAppVersion({ appDir: __dirname }),
    integrity: readPackageIntegritySummary(),
    fleetSnapshot,
    liveSnapshot,
    installationId: installation.id,
    installationIdStable: installation.stable,
    processUptimeSec: process.uptime(),
    reflectionProof: {
      ui: {
        clientJsFingerprint: supportBuildFingerprint(clientAssets.jsBuild),
        expectedJsFingerprint: supportBuildFingerprint(expectedAssets.jsBuild),
        clientCssFingerprint: supportBuildFingerprint(clientAssets.cssBuild),
        expectedCssFingerprint: supportBuildFingerprint(expectedAssets.cssBuild),
      },
      xiaoweiDisplayNames: liveSnapshot.xiaoweiDisplayNameReadback,
    },
    planSourceSnapshot: planSnapshot,
  });
}

function readSupportDiagnosticsExpectedAssets() {
  try {
    const js = fs.readFileSync(path.join(__dirname, "public", "fleet-app.js"), "utf8");
    const css = fs.readFileSync(path.join(__dirname, "public", "fleet-app.css"), "utf8");
    const jsMatch = js.match(/const FLEET_UI_JS_BUILD_ID = "([A-Za-z0-9._-]{1,160})";/);
    const cssMatch = css.match(/--fleet-ui-build:\s*"([A-Za-z0-9._-]{1,160})";/);
    return {
      jsBuild: safeSupportBuildId(jsMatch && jsMatch[1]),
      cssBuild: safeSupportBuildId(cssMatch && cssMatch[1]),
    };
  } catch {
    return { jsBuild: "", cssBuild: "" };
  }
}

function safeSupportBuildId(value) {
  const build = typeof value === "string" ? value.trim() : "";
  return /^[A-Za-z0-9._-]{1,160}$/.test(build) ? build : "";
}

function supportBuildFingerprint(value) {
  const build = safeSupportBuildId(value);
  if (!build) return "";
  return crypto.createHash("sha256").update(build, "utf8").digest("hex").slice(0, 12);
}

async function readSupportDiagnosticsLiveSnapshot(fleetSnapshot = {}, planSnapshot = {}) {
  const counts = fleetSnapshot.counts || {};
  const key = [
    fleetSnapshot.cache && fleetSnapshot.cache.key || "",
    fleetSnapshot.generatedAt || "",
    counts.devices || 0,
    counts.retired || 0,
    planSnapshot.key || "plan-unavailable",
  ].join("|");
  const now = Date.now();
  if (
    supportDiagnosticsLiveCache.value
    && supportDiagnosticsLiveCache.key === key
    && now - supportDiagnosticsLiveCache.at < SUPPORT_DIAGNOSTICS_LIVE_CACHE_MS
  ) {
    return supportDiagnosticsLiveCache.value;
  }
  if (supportDiagnosticsLiveFlight) {
    await supportDiagnosticsLiveFlight.promise;
    return readSupportDiagnosticsLiveSnapshot(fleetSnapshot, planSnapshot);
  }

  const promise = collectSupportDiagnosticsLiveSnapshot(fleetSnapshot, planSnapshot)
    .then((value) => {
      supportDiagnosticsLiveCache = { key, at: Date.now(), value };
      return value;
    })
    .finally(() => {
      if (supportDiagnosticsLiveFlight && supportDiagnosticsLiveFlight.promise === promise) {
        supportDiagnosticsLiveFlight = null;
      }
    });
  supportDiagnosticsLiveFlight = { key, promise };
  return promise;
}

async function collectSupportDiagnosticsLiveSnapshot(fleetSnapshot = {}, planSnapshot = {}) {
  const dbReadable = fleetSnapshot.ok === true;
  const dbRowsAvailable = dbReadable && Array.isArray(fleetSnapshot.devices);
  const dbRows = dbRowsAvailable ? fleetSnapshot.devices : [];
  const dbSerialCandidates = dbRows.map((row) => normalizeSupportDiagnosticSerial(row && row.serial));
  const dbIdentityReadable = dbReadable
    && dbRowsAvailable
    && dbSerialCandidates.every(Boolean)
    && new Set(dbSerialCandidates.map(serialKey)).size === dbSerialCandidates.length;
  const dbSerials = dbIdentityReadable ? dbSerialCandidates : [];
  const dbKeys = new Set(dbSerials.map(serialKey).filter(Boolean));
  const config = readFleetMonitorConfig();
  const adbPath = config.adbPath || resolveAdbPath();
  const [adb5037Listening, adb5038Listening] = await Promise.all([
    isLocalPortListening(5037),
    isLocalPortListening(5038),
  ]);
  const ports = [
    ...(adb5037Listening ? [5037] : []),
    ...(adb5038Listening ? [5038] : []),
  ];

  const [scans, xiaowei, windowsPnp] = await Promise.all([
    Promise.all(ports.map((adbPort) => scanAdbDevices({ adbPath, adbPort }))),
    readXiaoweiSources().catch(() => ({
      dbAvailable: false,
      apiAvailable: false,
      apiReachable: false,
      dbDevices: [],
      apiDevices: [],
    })),
    readWindowsPnpSupportCounts(dbSerials),
  ]);

  const adbAuthorizedKeys = new Set();
  for (const scan of scans) {
    for (const device of scan.devices || []) {
      if (device && device.status === "device") adbAuthorizedKeys.add(serialKey(device.serial));
    }
  }
  adbAuthorizedKeys.delete("");

  const scan5037 = scans.find((scan) => Number(scan.port) === 5037);
  const scan5038 = scans.find((scan) => Number(scan.port) === 5038);
  // Aggregate/mismatch values are only trustworthy when every listening ADB
  // server was scanned successfully. A partial result can otherwise mark
  // devices that exist only on the failed port as missing.
  const adbComplete = ports.length > 0
    && scans.length === ports.length
    && scans.every((scan) => scan.available === true);
  const rawXiaoweiBasis = xiaowei.apiAvailable === true
    ? "api"
    : xiaowei.dbAvailable === true
      ? "db"
      : "unavailable";
  const xiaoweiDevices = rawXiaoweiBasis === "api"
    ? xiaowei.apiDevices || []
    : rawXiaoweiBasis === "db"
      ? xiaowei.dbDevices || []
      : [];
  const xiaoweiSerials = xiaoweiDevices.map((device) => normalizeSupportDiagnosticSerial(device && device.serial));
  const xiaoweiIdentityReadable = rawXiaoweiBasis !== "unavailable"
    && Array.isArray(xiaoweiDevices)
    && xiaoweiSerials.every(Boolean)
    && new Set(xiaoweiSerials.map(serialKey)).size === xiaoweiSerials.length;
  const xiaoweiKeys = new Set(xiaoweiIdentityReadable ? xiaoweiSerials.map(serialKey) : []);
  const xiaoweiAvailable = xiaoweiIdentityReadable;
  const xiaoweiBasis = xiaoweiAvailable ? rawXiaoweiBasis : "unavailable";
  const xiaoweiDisplayNameReadback = buildSupportXiaoweiDisplayNameReadback(xiaowei, planSnapshot);

  return {
    sourceCounts: {
      windowsPnp: dbIdentityReadable && windowsPnp.available ? windowsPnp.fleetMatched : null,
      windowsAndroidInterfaces: windowsPnp.available ? windowsPnp.androidInterfaces : null,
      adb5037: scan5037 && scan5037.available ? (scan5037.devices || []).length : null,
      adb5038: scan5038 && scan5038.available ? (scan5038.devices || []).length : null,
      adbAuthorizedUnique: adbComplete ? adbAuthorizedKeys.size : null,
      xiaowei: xiaoweiAvailable ? xiaoweiKeys.size : null,
    },
    sourceStatus: {
      windowsPnp: process.platform !== "win32"
        ? "not_applicable"
        : windowsPnp.available ? "available" : "scan_failed",
      adb5037: !adb5037Listening ? "not_listening" : scan5037 && scan5037.available ? "available" : "scan_failed",
      adb5038: !adb5038Listening ? "not_listening" : scan5038 && scan5038.available ? "available" : "scan_failed",
      xiaoweiDb: xiaowei.dbAvailable === true ? "available" : "unavailable",
      xiaoweiApi: xiaowei.apiAvailable === true ? "available" : "unavailable",
      xiaoweiApiReachable: xiaowei.apiReachable === true,
      xiaoweiBasis,
    },
    mismatchCounts: {
      dbMissingFromAdb: dbIdentityReadable && adbComplete ? setDifferenceCount(dbKeys, adbAuthorizedKeys) : null,
      adbMissingFromDb: dbIdentityReadable && adbComplete ? setDifferenceCount(adbAuthorizedKeys, dbKeys) : null,
      dbMissingFromXiaowei: dbIdentityReadable && xiaoweiAvailable ? setDifferenceCount(dbKeys, xiaoweiKeys) : null,
      xiaoweiMissingFromDb: dbIdentityReadable && xiaoweiAvailable ? setDifferenceCount(xiaoweiKeys, dbKeys) : null,
    },
    connectionDiagnosisCounts: {
      adb5037: summarizeSupportAdbStatuses(scan5037),
      adb5038: summarizeSupportAdbStatuses(scan5038),
      windowsPnp: {
        presentUsbNodes: windowsPnp.available ? windowsPnp.presentUsbNodes : null,
        presentAndroidInterfaces: windowsPnp.available ? windowsPnp.androidInterfaces : null,
        fleetNotSeen: dbIdentityReadable && windowsPnp.available
          ? Math.max(0, dbKeys.size - windowsPnp.fleetMatched)
          : null,
        problemCode10: windowsPnp.problemReadable ? windowsPnp.problemCode10 : null,
        problemCode12: windowsPnp.problemReadable ? windowsPnp.problemCode12 : null,
        problemCode28: windowsPnp.problemReadable ? windowsPnp.problemCode28 : null,
        problemCode31: windowsPnp.problemReadable ? windowsPnp.problemCode31 : null,
        problemCode43: windowsPnp.problemReadable ? windowsPnp.problemCode43 : null,
        problemOther: windowsPnp.problemReadable ? windowsPnp.problemOther : null,
      },
    },
    xiaoweiDisplayNameReadback,
    dbIdentityReadable,
  };
}

function buildSupportXiaoweiDisplayNameReadback(xiaowei = {}, planSnapshot = {}) {
  const base = {
    planReadable: false,
    apiReachable: xiaowei.apiReachable === true,
    apiAvailable: xiaowei.apiAvailable === true,
    apiLocked: xiaowei.apiLocked === true,
    desiredCount: null,
    invalidPlanRowCount: null,
    liveComparedCount: null,
    liveMatchCount: null,
    liveMismatchCount: null,
    liveMissingCount: null,
    emptyLiveNameCount: null,
    duplicateIdentityCount: null,
    outcomeCode: "plan_unavailable",
  };
  const plan = planSnapshot && planSnapshot.readable === true && Array.isArray(planSnapshot.value)
    ? planSnapshot.value
    : null;
  if (!plan) return base;

  const desiredByKey = new Map();
  const duplicateKeys = new Set();
  let invalidPlanRowCount = 0;
  for (const row of plan) {
    const key = supportDiagnosticSerialKey(row && row.serial);
    const desiredName = normalizeSupportDisplayName(row && row.displayName);
    if (!row || typeof row !== "object" || !key || !desiredName) {
      invalidPlanRowCount += 1;
      continue;
    }
    if (desiredByKey.has(key)) duplicateKeys.add(key);
    else desiredByKey.set(key, desiredName);
  }
  base.planReadable = true;
  base.desiredCount = desiredByKey.size;
  base.invalidPlanRowCount = invalidPlanRowCount;
  if (invalidPlanRowCount > 0) return { ...base, outcomeCode: "plan_invalid" };
  if (base.apiLocked) return { ...base, outcomeCode: "api_locked" };
  if (!base.apiAvailable) return { ...base, outcomeCode: "api_unavailable" };

  const apiByKey = new Map();
  for (const device of Array.isArray(xiaowei.apiDevices) ? xiaowei.apiDevices : []) {
    const key = supportDiagnosticSerialKey(device && device.serial);
    if (!key) continue;
    if (apiByKey.has(key)) duplicateKeys.add(key);
    else apiByKey.set(key, normalizeSupportDisplayName(device && device.name));
  }

  let liveMatchCount = 0;
  let liveMismatchCount = 0;
  let liveMissingCount = 0;
  let emptyLiveNameCount = 0;
  for (const [key, desiredName] of desiredByKey) {
    if (!apiByKey.has(key)) {
      liveMissingCount += 1;
      continue;
    }
    const liveName = apiByKey.get(key);
    if (!liveName) {
      emptyLiveNameCount += 1;
      continue;
    }
    if (liveName === desiredName) liveMatchCount += 1;
    else liveMismatchCount += 1;
  }
  const liveComparedCount = liveMatchCount + liveMismatchCount;
  const verified = desiredByKey.size > 0
    && invalidPlanRowCount === 0
    && liveMatchCount === desiredByKey.size
    && liveMismatchCount === 0
    && liveMissingCount === 0
    && emptyLiveNameCount === 0
    && duplicateKeys.size === 0;
  return {
    ...base,
    liveComparedCount,
    liveMatchCount,
    liveMismatchCount,
    liveMissingCount,
    emptyLiveNameCount,
    duplicateIdentityCount: duplicateKeys.size,
    outcomeCode: invalidPlanRowCount > 0
      ? "plan_invalid"
      : desiredByKey.size === 0 ? "no_targets" : verified ? "verified" : "mismatch",
  };
}

function readSupportDiagnosticsPlanSnapshot() {
  const filePath = path.join(paths.dataDir, "fleet-db", "xiaowei-display-name-plan.json");
  let handle = null;
  try {
    handle = fs.openSync(filePath, "r");
    const stat = fs.fstatSync(handle);
    if (!stat.isFile()) return unavailableSupportPlanSnapshot("unreadable");
    if (stat.size > SUPPORT_DIAGNOSTICS_MAX_SOURCE_BYTES) return unavailableSupportPlanSnapshot("oversized");
    const buffer = Buffer.alloc(SUPPORT_DIAGNOSTICS_MAX_SOURCE_BYTES + 1);
    const bytes = fs.readSync(handle, buffer, 0, buffer.length, 0);
    if (bytes > SUPPORT_DIAGNOSTICS_MAX_SOURCE_BYTES) return unavailableSupportPlanSnapshot("oversized");
    const content = buffer.subarray(0, bytes);
    const value = JSON.parse(content.toString("utf8").replace(/^\uFEFF/, ""));
    if (!Array.isArray(value)) return unavailableSupportPlanSnapshot("unreadable");
    const fingerprint = crypto.createHash("sha256").update(content).digest("hex");
    return {
      readable: true,
      status: "available",
      value,
      modifiedAt: stat.mtime.toISOString(),
      key: `available:${stat.size}:${stat.mtimeMs}:${fingerprint}`,
    };
  } catch (error) {
    return unavailableSupportPlanSnapshot(error && error.code === "ENOENT" ? "missing" : "unreadable");
  } finally {
    if (handle !== null) {
      try { fs.closeSync(handle); } catch { /* Ignore close failures. */ }
    }
  }
}

function unavailableSupportPlanSnapshot(status) {
  return { readable: false, status, value: null, modifiedAt: "", key: status || "unreadable" };
}

function normalizeSupportDisplayName(value) {
  if (typeof value !== "string") return "";
  const text = value.normalize("NFKC").replace(/\s+/g, " ").trim();
  if (
    !text
    || text.length > 160
    || /[\u0000-\u001f\u007f]/.test(text)
    || /^\[object (?:object|array)\]$/i.test(text)
  ) return "";
  return text;
}

function supportDiagnosticSerialKey(value) {
  const text = normalizeSupportDiagnosticSerial(value);
  if (!text) return "";
  return serialKey(text);
}

function normalizeSupportDiagnosticSerial(value) {
  if (typeof value !== "string") return "";
  const text = value.normalize("NFKC").trim();
  if (
    !text
    || text.length > 160
    || /[\u0000-\u001f\u007f\s]/.test(text)
    || !/^[A-Za-z0-9._:+@#-]{1,160}$/.test(text)
    || /^\[object (?:object|array)\]$/i.test(text)
  ) return "";
  return text;
}

function summarizeSupportAdbStatuses(scan) {
  const unavailable = { device: null, unauthorized: null, offline: null, other: null };
  if (!scan || scan.available !== true || !Array.isArray(scan.devices)) return unavailable;
  const counts = { device: 0, unauthorized: 0, offline: 0, other: 0 };
  for (const row of scan.devices) {
    const status = String(row && row.status || "").trim().toLowerCase();
    if (status === "device") counts.device += 1;
    else if (status === "unauthorized") counts.unauthorized += 1;
    else if (status === "offline") counts.offline += 1;
    else counts.other += 1;
  }
  return counts;
}

async function readWindowsPnpSupportCounts(serials = []) {
  const cleanSerials = uniqueStrings(serials
    .map((serial) => normalizeSupportDiagnosticSerial(serial))
    .filter(Boolean));
  if (process.platform !== "win32") return unavailableSupportPnpCounts();
  const script = [
    "$ErrorActionPreference = 'Stop'",
    "if (-not (Get-Command Get-PnpDevice -ErrorAction SilentlyContinue)) { exit 4 }",
    "$serials = @(ConvertFrom-Json $env:FLEET_SUPPORT_PNP_SERIALS)",
    "$devices = @(Get-PnpDevice -PresentOnly -ErrorAction Stop | Select-Object Class,FriendlyName,InstanceId,Problem)",
    "$usbNodes = @($devices | Where-Object { ([string]$_.Class) -match '(?i)^USB(?:Device)?$' -or ([string]$_.InstanceId).StartsWith('USB\\') })",
    "$androidNodes = @($devices | Where-Object { ([string]$_.Class) -match '(?i)Android|WPD' -or ([string]$_.FriendlyName) -match '(?i)ADB|Android|MTP' })",
    "$relevant = @($devices | Where-Object { ([string]$_.Class) -match '(?i)^USB(?:Device)?$|Android|WPD' -or ([string]$_.InstanceId).StartsWith('USB\\') -or ([string]$_.FriendlyName) -match '(?i)ADB|Android|MTP' })",
    "$ids = @($relevant | ForEach-Object { [string]$_.InstanceId })",
    "$count = 0",
    "foreach ($serial in $serials) { $pattern = '(?i)(?:^|\\\\)' + [regex]::Escape([string]$serial) + '(?:$|&)'; if (@($ids | Where-Object { $_ -match $pattern }).Count -gt 0) { $count++ } }",
    "$problemReadable = $true",
    "$p10 = 0; $p12 = 0; $p28 = 0; $p31 = 0; $p43 = 0; $pOther = 0",
    "foreach ($device in $relevant) { if ($null -eq $device.Problem -or [string]::IsNullOrWhiteSpace([string]$device.Problem)) { $problemReadable = $false; continue }; try { $code = [int]$device.Problem } catch { $problemReadable = $false; continue }; switch ($code) { 0 {} 10 {$p10++} 12 {$p12++} 28 {$p28++} 31 {$p31++} 43 {$p43++} default { if ($code -gt 0) { $pOther++ } } } }",
    "[pscustomobject]@{ fleetMatched = $count; presentUsbNodes = $usbNodes.Count; androidInterfaces = $androidNodes.Count; problemReadable = $problemReadable; problemCode10 = $p10; problemCode12 = $p12; problemCode28 = $p28; problemCode31 = $p31; problemCode43 = $p43; problemOther = $pOther } | ConvertTo-Json -Compress",
  ].join("; ");
  const result = await runPowerShellJsonAsync(script, {
    FLEET_SUPPORT_PNP_SERIALS: JSON.stringify(cleanSerials),
  }, 15000);
  const row = result && result.ok && result.rows && result.rows[0] || null;
  const fleetMatched = Number(row && row.fleetMatched);
  const presentUsbNodes = Number(row && row.presentUsbNodes);
  const androidInterfaces = Number(row && row.androidInterfaces);
  if (
    !row
    || !Number.isSafeInteger(fleetMatched)
    || fleetMatched < 0
    || !Number.isSafeInteger(presentUsbNodes)
    || presentUsbNodes < 0
    || !Number.isSafeInteger(androidInterfaces)
    || androidInterfaces < 0
  ) {
    return unavailableSupportPnpCounts();
  }
  const problemReadable = row.problemReadable === true;
  const resultRow = {
    available: true,
    fleetMatched,
    presentUsbNodes,
    androidInterfaces,
    problemReadable,
  };
  for (const key of ["problemCode10", "problemCode12", "problemCode28", "problemCode31", "problemCode43", "problemOther"]) {
    const count = Number(row[key]);
    resultRow[key] = problemReadable && Number.isSafeInteger(count) && count >= 0 ? count : null;
    if (problemReadable && resultRow[key] === null) resultRow.problemReadable = false;
  }
  if (!resultRow.problemReadable) {
    for (const key of ["problemCode10", "problemCode12", "problemCode28", "problemCode31", "problemCode43", "problemOther"]) {
      resultRow[key] = null;
    }
  }
  return resultRow;
}

function unavailableSupportPnpCounts() {
  return {
    available: false,
    fleetMatched: null,
    presentUsbNodes: null,
    androidInterfaces: null,
    problemReadable: false,
    problemCode10: null,
    problemCode12: null,
    problemCode28: null,
    problemCode31: null,
    problemCode43: null,
    problemOther: null,
  };
}

function setDifferenceCount(left, right) {
  let count = 0;
  for (const value of left) if (!right.has(value)) count += 1;
  return count;
}

function supportDiagnosticsStateRoot() {
  return process.env.ANDROID_FLEET_SUPPORT_STATE_DIR
    ? path.resolve(process.env.ANDROID_FLEET_SUPPORT_STATE_DIR)
    : path.join(
      process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local"),
      "AndroidFleet",
      "support"
    );
}

function readOrCreateSupportInstallationId() {
  if (supportInstallationStateCache) return supportInstallationStateCache;
  const stateRoot = supportDiagnosticsStateRoot();
  const filePath = path.join(stateRoot, "installation.json");
  const existing = readJsonFile(filePath, {});
  const current = validSupportInstallationId(existing.installationId);
  if (current) {
    supportInstallationStateCache = { id: current, stable: true };
    return supportInstallationStateCache;
  }

  const lockPath = `${filePath}.lock`;
  let lockHandle = null;
  try {
    fs.mkdirSync(stateRoot, { recursive: true });
    lockHandle = fs.openSync(lockPath, "wx");
    const afterLock = readJsonFile(filePath, {});
    const afterLockId = validSupportInstallationId(afterLock.installationId);
    if (afterLockId) {
      supportInstallationStateCache = { id: afterLockId, stable: true };
      return supportInstallationStateCache;
    }
    const installationId = crypto.randomUUID();
    fs.writeFileSync(filePath, `${JSON.stringify({
      schemaVersion: 1,
      installationId,
      createdAt: new Date().toISOString(),
    }, null, 2)}\n`, "utf8");
    supportInstallationStateCache = { id: installationId, stable: true };
    return supportInstallationStateCache;
  } catch {
    const concurrent = readJsonFile(filePath, {});
    const concurrentId = validSupportInstallationId(concurrent.installationId);
    supportInstallationStateCache = {
      id: concurrentId || crypto.randomUUID(),
      stable: Boolean(concurrentId),
    };
    return supportInstallationStateCache;
  } finally {
    if (lockHandle !== null) {
      try { fs.closeSync(lockHandle); } catch {}
      try { fs.unlinkSync(lockPath); } catch {}
    }
  }
}

function validSupportInstallationId(value) {
  const id = String(value || "").trim().toLowerCase();
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(id)
    ? id
    : "";
}

function pruneSupportDiagnosticsConsentReceipts(now = Date.now()) {
  for (const [nonce, entry] of supportDiagnosticsConsentReceipts) {
    if (!entry || now - Number(entry.createdAt || 0) > SUPPORT_DIAGNOSTICS_CONSENT_TTL_MS) {
      supportDiagnosticsConsentReceipts.delete(nonce);
    }
  }
}

function safeSupportDiagnosticsSendErrorCode(error) {
  const code = String(error && error.code || "").trim();
  return /^SUPPORT_DIAGNOSTICS_[A-Z0-9_]{1,56}$/.test(code)
    ? code
    : "SUPPORT_DIAGNOSTICS_SEND_FAILED";
}

function decorateAdbActionResult(result) {
  if (!result || result.action !== "screenshot" || !result.result || !result.result.fileName) return result;
  result.screenshotUrl = `/screenshots/${encodeURIComponent(result.result.fileName)}`;
  return result;
}

function appendAuditLog(entry) {
  const file = path.join(paths.dataDir, "events.jsonl");
  const license = readCustomerLicense();
  const payload = {
    at: new Date().toISOString(),
    ...(license.customerId ? { customerId: license.customerId } : {}),
    ...entry,
  };
  fs.appendFileSync(file, `${JSON.stringify(payload)}\n`, "utf8");
}

function rejectXiaoweiWriteWhenIsolated(res, operation) {
  if (XIAOWEI_WRITE_SYNC_ENABLED) return false;
  const result = {
    ok: false,
    blocked: true,
    dryRun: true,
    operation,
    error: "XiaoWei書込みは隔離受入環境または明示的な同期無効設定で禁止されています。",
  };
  appendAuditLog({
    type: "xiaowei_write_blocked",
    title: "XiaoWei write blocked",
    level: "info",
    details: {
      operation,
      port: PORT,
      explicitDisable: process.env.ANDROID_FLEET_DISABLE_DAY_XIAOWEI_SYNC === "1",
    },
  });
  sendJson(res, result, 409);
  return true;
}

function readCustomerLicense() {
  const fromFile = readJsonFile(CUSTOMER_LICENSE_PATH, {});
  const customerId = cleanText(process.env.ANDROID_FLEET_CUSTOMER_ID || fromFile.customerId, 80);
  const customerName = cleanText(process.env.ANDROID_FLEET_CUSTOMER_NAME || fromFile.customerName, 80);
  const packageId = cleanText(process.env.ANDROID_FLEET_PACKAGE_ID || fromFile.packageId, 80);
  const serialKey = cleanText(process.env.ANDROID_FLEET_SERIAL_KEY || fromFile.serialKey, 80);
  const licenseMode = cleanText(fromFile.licenseMode || "single-pc", 40);
  const enforceMachineLock = Boolean(fromFile.enforceMachineLock);
  const machineHash = currentMachineHash();
  const activation = enforceMachineLock ? ensureLicenseActivation({ customerId, packageId, machineHash }) : {};
  const lockedMachineHash = cleanText(activation.machineHash || fromFile.machineHash, 128);
  const machineOk = !enforceMachineLock || !lockedMachineHash || lockedMachineHash === machineHash;
  const integrity = readPackageIntegritySummary();
  return {
    customerId,
    customerName,
    packageId,
    serialKey: serialKey ? `${serialKey.slice(0, 8)}...${serialKey.slice(-5)}` : "",
    licenseMode,
    issuedAt: cleanText(fromFile.issuedAt, 40),
    enforceMachineLock,
    activationId: cleanText(activation.activationId || "", 80),
    machineHash: machineHash ? `${machineHash.slice(0, 12)}...` : "",
    lockedMachineHash: lockedMachineHash ? `${lockedMachineHash.slice(0, 12)}...` : "",
    machineOk,
    integrityOk: integrity.ok,
    integrity,
    status: enforceMachineLock ? machineOk ? "activated" : "machine_mismatch" : "unlocked",
    configured: Boolean(customerId || customerName || packageId),
  };
}

function checkLicenseGate(pathname) {
  if (!String(pathname || "").startsWith("/api/")) return { ok: true };
  if (pathname === "/api/config") return { ok: true };
  const license = readCustomerLicense();
  if (license.integrity && license.integrity.configured && !license.integrity.ok) {
    return {
      ok: false,
      code: "PACKAGE_INTEGRITY_FAILED",
      message: "This package was modified after issue. Contact the seller for a clean package.",
      license,
    };
  }
  if (!license.enforceMachineLock || license.machineOk) return { ok: true };
  return {
    ok: false,
    code: "LICENSE_MACHINE_MISMATCH",
    message: "This package is locked to another Windows PC. Contact the seller for reissue.",
    license,
  };
}

function ensureLicenseActivation({ customerId, packageId, machineHash }) {
  if (!machineHash) return {};
  const existing = readJsonFile(LICENSE_ACTIVATION_PATH, null);
  if (existing && existing.machineHash) return existing;
  const activation = {
    activationId: `AF-ACT-${Date.now().toString(36).toUpperCase()}`,
    customerId,
    packageId,
    machineHash,
    activatedAt: new Date().toISOString(),
  };
  try {
    fs.mkdirSync(path.dirname(LICENSE_ACTIVATION_PATH), { recursive: true });
    fs.writeFileSync(LICENSE_ACTIVATION_PATH, JSON.stringify(activation, null, 2), "utf8");
  } catch {
    return {};
  }
  return activation;
}

function currentMachineHash() {
  const parts = [
    os.hostname(),
    os.arch(),
    windowsMachineGuid(),
  ].filter(Boolean);
  return crypto.createHash("sha256").update(parts.join("|")).digest("hex");
}

function windowsMachineGuid() {
  if (process.platform !== "win32") return "";
  try {
    const result = spawnSync("reg.exe", [
      "query",
      "HKLM\\SOFTWARE\\Microsoft\\Cryptography",
      "/v",
      "MachineGuid",
    ], {
      encoding: "utf8",
      windowsHide: true,
      timeout: 5000,
      maxBuffer: 1024 * 1024,
    });
    const match = String(result.stdout || "").match(/MachineGuid\s+REG_SZ\s+([^\r\n]+)/i);
    return match ? match[1].trim() : "";
  } catch {
    return "";
  }
}

function readPackageIntegritySummary() {
  const manifest = readJsonFile(PACKAGE_MANIFEST_PATH, null);
  if (!manifest || !manifest.files || typeof manifest.files !== "object") {
    return { configured: false, ok: true, checked: 0, failed: 0 };
  }
  const allowedHashes = new Map();
  addPackageIntegrityHashes(allowedHashes, manifest.files);
  const appliedUpdates = readJsonFile(path.join(__dirname, "config", "applied-updates.json"), []);
  for (const update of Array.isArray(appliedUpdates) ? appliedUpdates : []) {
    addPackageIntegrityHashes(allowedHashes, update && update.files);
  }
  const failures = [];
  let checked = 0;
  for (const [relativePath, expectedHashes] of allowedHashes) {
    const normalized = path.normalize(String(relativePath || ""));
    if (!normalized || normalized.startsWith("..") || path.isAbsolute(normalized)) {
      failures.push({ file: relativePath, error: "invalid path" });
      continue;
    }
    const filePath = path.join(__dirname, normalized);
    checked += 1;
    try {
      const actual = sha256File(filePath);
      if (!expectedHashes.has(actual)) failures.push({ file: relativePath, error: "hash mismatch" });
    } catch (error) {
      failures.push({ file: relativePath, error: error.message });
    }
  }
  return {
    configured: true,
    ok: failures.length === 0,
    checked,
    failed: failures.length,
    failures: failures.slice(0, 8),
    packageId: cleanText(manifest.packageId, 80),
    builtAt: cleanText(manifest.builtAt, 40),
  };
}

function addPackageIntegrityHashes(target, files) {
  if (!files || typeof files !== "object" || Array.isArray(files)) return;
  for (const [relativePath, expectedHash] of Object.entries(files)) {
    const normalized = String(relativePath || "").replace(/\\/g, "/").replace(/^\/+/, "");
    const hash = String(expectedHash || "").trim().toLowerCase();
    if (!normalized || normalized.split("/").includes("..") || !/^[0-9a-f]{64}$/.test(hash)) continue;
    if (!target.has(normalized)) target.set(normalized, new Set());
    target.get(normalized).add(hash);
  }
}

function sha256File(filePath) {
  return crypto.createHash("sha256").update(fs.readFileSync(filePath)).digest("hex");
}

function normalizeSwipeModePreference(value) {
  return ["auto", "agent", "adb", "disabled"].includes(String(value || "")) ? String(value) : "auto";
}

function swipeModeRecommendation(device) {
  const preference = normalizeSwipeModePreference(device && device.swipeModePreference);
  if (preference === "agent") return { mode: "agent", source: "manual", label: "Agent" };
  if (preference === "adb") return { mode: "adb", source: "manual", label: "ADB" };
  if (preference === "disabled") return { mode: "disabled", source: "manual", label: "無効" };

  const lastError = String(device && device.swipeAgentLastError || "");
  if (device && device.swipeAgentInstalled === false) return { mode: "adb", source: "auto", label: "ADB" };
  if (device && device.swipeAgentAccessibilityEnabled === false) return { mode: "adb", source: "auto", label: "ADB" };
  if (device && device.swipeModeLastAutoDecision === "adb") return { mode: "adb", source: "auto", label: "ADB" };
  if (/WRITE_SECURE_SETTINGS|Permission denial|accessibility/i.test(lastError)) return { mode: "adb", source: "auto", label: "ADB" };
  return { mode: "agent", source: "auto", label: "Agent" };
}
function markSwipeModeAutoAdb(serial, error) {
  const cleanSerial = cleanText(serial, 80);
  if (!cleanSerial) return;
  try {
    const { dbPath, db } = readFleetDbForWrite();
    const device = db.physicalDevices[cleanSerial] || { serial: cleanSerial };
    const now = new Date().toISOString();
    device.swipeAgentLastError = cleanText(error || "Swipe Agent failed; fallback to ADB", 200);
    device.swipeAgentCheckedAt = now;
    device.swipeModeLastAutoDecision = "adb";
    device.swipeModeLastAutoDecisionAt = now;
    db.physicalDevices[cleanSerial] = device;
    db.updatedAt = now;
    writeJsonFile(dbPath, db);
  } catch (error) {
    console.warn("Failed to mark swipe mode fallback:", error.message);
  }
}

function buildOfflineDeviceRows(db, withdrawals, now = new Date()) {
  const records = normalizeOfflineDevices(db && db.offlineDevices);
  const statsById = new Map();
  for (const withdrawal of Array.isArray(withdrawals) ? withdrawals : []) {
    const offlineId = cleanText(withdrawal && withdrawal.serial, 80);
    if (!records[offlineId]) continue;
    const stats = statsById.get(offlineId) || { withdrawalCount: 0, withdrawalTotalYen: 0, lastWithdrawalDate: "" };
    stats.withdrawalCount += 1;
    stats.withdrawalTotalYen += Number(withdrawal.amountYen || 0);
    if (String(withdrawal.withdrawalDate || "") > stats.lastWithdrawalDate) {
      stats.lastWithdrawalDate = String(withdrawal.withdrawalDate || "");
    }
    statsById.set(offlineId, stats);
  }
  return Object.values(records)
    .map((device) => ({
      ...offlineDeviceSummary(device, { now }),
      ...(statsById.get(device.offlineId) || { withdrawalCount: 0, withdrawalTotalYen: 0, lastWithdrawalDate: "" }),
    }))
    .sort((left, right) => {
      const leftArchived = left.status === "archived" ? 1 : 0;
      const rightArchived = right.status === "archived" ? 1 : 0;
      const leftNumber = Number(String(left.number || "").match(/\d+/)?.[0] || 999999);
      const rightNumber = Number(String(right.number || "").match(/\d+/)?.[0] || 999999);
      return leftArchived - rightArchived
        || right.day - left.day
        || leftNumber - rightNumber
        || String(left.name || left.offlineId).localeCompare(String(right.name || right.offlineId), "ja");
    });
}

function isFleetDbRowCollection(value, options = {}) {
  if (!value || typeof value !== "object") return false;
  if (options.arrayOnly === true && !Array.isArray(value)) return false;
  if (options.allowArray === false && Array.isArray(value)) return false;
  return Object.values(value).every((row) => row && typeof row === "object" && !Array.isArray(row));
}

function isOptionalFleetDbRowCollection(db, key, options = {}) {
  return !Object.prototype.hasOwnProperty.call(db, key)
    || isFleetDbRowCollection(db[key], options);
}

function hasStableOfflineDeviceIdentities(value) {
  const normalized = Object.values(normalizeOfflineDevices(value));
  if (normalized.length !== Object.values(value).length) return false;
  const idKeys = normalized.map((row) => fleetIdentityKey(row.offlineId));
  const numberKeys = normalized.map((row) => {
    const number = String(row.number || "");
    return /^\d{1,4}$/.test(number) && Number(number) >= 1
      ? String(Number(number))
      : "";
  });
  return idKeys.every(Boolean)
    && numberKeys.every(Boolean)
    && new Set(idKeys).size === idKeys.length
    && new Set(numberKeys).size === numberKeys.length;
}

function buildFleetDbSummary() {
  const dbDir = path.join(paths.dataDir, "fleet-db");
  const dbPath = path.join(dbDir, "fleet-db.json");
  const db = readJsonFile(dbPath, null);
  if (!db) return { ok: false, error: "fleet-db.json not found" };
  if (
    typeof db !== "object"
    || Array.isArray(db)
    || !db.physicalDevices
    || typeof db.physicalDevices !== "object"
    || !isFleetDbRowCollection(db.physicalDevices)
    || !isOptionalFleetDbRowCollection(db, "cycles")
    || !isOptionalFleetDbRowCollection(db, "offlineDevices")
    || (Object.prototype.hasOwnProperty.call(db, "offlineDevices")
      && !hasStableOfflineDeviceIdentities(db.offlineDevices))
    || !isOptionalFleetDbRowCollection(db, "withdrawals", { arrayOnly: true })
  ) return { ok: false, error: "fleet-db.json has an invalid schema" };

  const allDevices = Object.values(db.physicalDevices);
  const devices = allDevices.filter((device) => device && !device.retiredAt);
  const canonicalOperationSerials = allDevices.map((device) => device && device.serial).filter(Boolean);
  const operationGroups = operationGroupList(db.operationGroups, { canonicalSerials: canonicalOperationSerials });
  const cycles = Object.values(db.cycles || {});
  const connectionHistory = readFleetConnectionHistory();
  const connectionStatsAt = Date.now();
  const errorStats = summarizeErrorOutcomes(collectFleetErrorOutcomes(db));
  const withdrawals = Array.isArray(db.withdrawals) ? db.withdrawals : [];
  const offlineDevices = buildOfflineDeviceRows(db, withdrawals);
  const activeCyclesBySerial = new Map(
    cycles
      .filter((cycle) => cycle && cycle.status === "active" && cycle.physicalSerial)
      .map((cycle) => [cycle.physicalSerial, cycle])
  );
  const lastWithdrawalBySerial = new Map();
  for (const row of withdrawals) {
    if (!row || !row.serial) continue;
    const prev = lastWithdrawalBySerial.get(row.serial);
    if (!prev || String(row.withdrawalDate || "").localeCompare(String(prev.withdrawalDate || "")) >= 0) {
      lastWithdrawalBySerial.set(row.serial, row);
    }
  }

  const deviceRows = devices
    .map((device) => {
      const active = activeCyclesBySerial.get(device.serial);
      const lastWithdrawal = lastWithdrawalBySerial.get(device.serial);
      const tags = canonicalizeTags(Array.isArray(active && active.tags) ? active.tags : []);
      const taskHistory = taskHistoryForDevice(db, device);
      const connectionIncidents = normalizeConnectionIncidents(connectionHistory.devices[device.serial]?.incidents);
      const connectionStats = connectionIncidentStats(connectionIncidents, connectionStatsAt);
      const recoveryAttempts = normalizeRecoveryAttempts(connectionHistory.devices[device.serial]?.recoveryAttempts);
      const recoveryStats = recoveryAttemptStats(recoveryAttempts, connectionStatsAt);
      const economics = active && active.economics || {};
      const modelGroup = deviceCodeBase(device);
      const carrierCode = deviceCarrierCode(device);
      const masterRegistrationIssue = deviceMasterRegistrationIssueForDevice(device);
      const deviceCode = fixedDeviceCode(device);
      const parsedDeviceCode = parseDeviceCode(deviceCode, modelGroup, carrierCode) || parseDeviceCode(deviceCode);
      const deviceDisplayCode = fixedDeviceDisplayCode(device);
      const deviceLabel = fixedDeviceLabel(device);
      const waiting = tags.includes("WAITING") || tags.includes("GROUP_REST") || tags.includes("GROUP_INACTIVE");
      const online = !waiting && (active && (active.lastAdbStatus === "device" || active.lastXiaoweiStatus === "api_connected"));
      const activeTagged = !waiting && active && tags.length > 0;
      const inviteProfiles = normalizeInviteProfiles(device);
      const projectedInviteProfiles = waiting ? emptyInviteProfiles() : inviteProfiles;
      return {
        managementId: device.managementId || "",
        xiaoweiSort: device.xiaoweiSort || device.number || "",
        laixiNumberOverride: device.laixiNumberOverride || "",
        deviceCode,
        deviceDisplayCode,
        deviceNameSequence: parsedDeviceCode && parsedDeviceCode.sequence || "",
        deviceNameSequenceOverride: Number(device.deviceNameSequenceOverride || 0) || "",
        deviceLabel,
        modelGroup,
        carrierCode,
        masterRegistered: !masterRegistrationIssue,
        masterLookupModelCode: masterRegistrationIssue && masterRegistrationIssue.modelCode || "",
        masterLookupCarrierCode: masterRegistrationIssue && masterRegistrationIssue.carrierCode || "",
        originalName: [deviceLabel, device.name || ""].filter(Boolean).join(" "),
        deviceName: deviceMasterDisplayNameForDevice(device) || device.name || "",
        uiName: deviceLabel || device.uiNameOverride || shortModelName(device.name || device.xiaoweiName || ""),
        uiNameOverride: device.uiNameOverride || "",
        xiaoweiName: device.xiaoweiName || "",
        serial: device.serial || "",
        firstSeenAt: device.firstSeenAt || "",
        lastSeenAt: device.lastSeenAt || "",
        updatedAt: device.updatedAt || "",
        notes: device.notes || "",
        startedAt: active && active.startedAt || "",
        cycleId: active && active.cycleId || "",
        resetAt: active && active.status === "completed" ? active.endedAt || "" : lastWithdrawal && lastWithdrawal.recordedAt || "",
        lastWithdrawalDate: lastWithdrawal && lastWithdrawal.withdrawalDate || "",
        lastWithdrawalYen: lastWithdrawal && lastWithdrawal.amountYen || "",
        ciReward: rewardLabel(findCheckinAmountTag(tags), "ci"),
        video180: rewardLabel(findVideo180AmountTag(tags), "v180"),
        video10: rewardLabel(findVideo10AmountTag(tags), "v10"),
        taskHistory,
        connectionIncidents,
        connectionIncidentStats: connectionStats,
        recoveryAttempts,
        recoveryAttemptStats: recoveryStats,
        hasErrorHistory: Number(taskHistory.errorStats && taskHistory.errorStats.error || 0) > 0,
        status: waiting ? "INACTIVE" : online ? "ONLINE" : activeTagged ? "ACTIVE" : active ? "ACTIVE" : "NO CYCLE",
        batteryPercent: active && active.lastBatteryPercent !== null && active.lastBatteryPercent !== undefined ? active.lastBatteryPercent : (
          device.adbLastBatteryPercent !== null && device.adbLastBatteryPercent !== undefined ? device.adbLastBatteryPercent : ""
        ),
        currentYen: active && active.currentYen !== null && active.currentYen !== undefined ? active.currentYen : "",
        currentPoints: active && active.currentPoints !== null && active.currentPoints !== undefined ? active.currentPoints : "",
        swipeAgentInstalled: device.swipeAgentInstalled === true ? true : device.swipeAgentInstalled === false ? false : null,
        swipeAgentAccessibilityEnabled: device.swipeAgentAccessibilityEnabled === true ? true : device.swipeAgentAccessibilityEnabled === false ? false : null,
        swipeAgentCheckedAt: device.swipeAgentCheckedAt || "",
        swipeAgentPackageName: device.swipeAgentPackageName || "",
        swipeAgentVersionName: device.swipeAgentVersionName || "",
        swipeAgentVersionCode: device.swipeAgentVersionCode || "",
        swipeAgentInstallStatus: device.swipeAgentInstallStatus || "",
        swipeAgentLastError: device.swipeAgentLastError || "",
        ttlInstalled: device.ttlInstalled === true ? true : device.ttlInstalled === false ? false : null,
        ttlCheckedAt: device.ttlCheckedAt || "",
        ttlPackageName: device.ttlPackageName || "",
        ttlInstallStatus: device.ttlInstallStatus || "",
        ttlInstallLastError: device.ttlInstallLastError || "",
        lineInstalled: device.lineInstalled === true ? true : device.lineInstalled === false ? false : null,
        lineCheckedAt: device.lineCheckedAt || "",
        linePackageName: device.linePackageName || "",
        lineInstallStatus: device.lineInstallStatus || "",
        lineInstallLastError: device.lineInstallLastError || "",
        simStatus: waiting ? "" : device.simStatus || "",
        networkType: waiting ? "" : device.networkType || "",
        deviceSimStatus: device.simStatus || "",
        deviceNetworkType: device.networkType || "",
        networkSwitchedDay: waiting ? "" : device.networkSwitchedDay || "",
        inviteProfiles: projectedInviteProfiles,
        inviteType: waiting ? "" : inviteProfiles.lite.inviteType,
        inviteRole: waiting ? "" : inviteProfiles.lite.inviteRole,
        inviteResult: waiting ? "" : inviteProfiles.lite.inviteResult,
        invitePartner: waiting ? "" : inviteProfiles.lite.invitePartner,
        inviteHistory: sanitizeInviteHistory(device.inviteHistory),
        osVersion: waiting ? "" : formatAdbOsVersion(device.osVersion),
        deviceOsVersion: formatAdbOsVersion(device.osVersion),
        adbLastUptimeSeconds: Number.isFinite(Number(device.adbLastUptimeSeconds)) ? Number(device.adbLastUptimeSeconds) : null,
        adbLastUptimeRaw: device.adbLastUptimeRaw || "",
        adbLastUptimeCheckedAt: device.adbLastUptimeCheckedAt || "",
        adbLastBatteryPercent: Number.isFinite(Number(device.adbLastBatteryPercent)) ? Number(device.adbLastBatteryPercent) : null,
        adbLastBatteryCheckedAt: device.adbLastBatteryCheckedAt || "",
        ttlRegisterMethod: waiting ? "" : inviteProfiles.lite.ttlRegisterMethod,
        inviteOpsNote: waiting ? "" : inviteProfiles.lite.inviteOpsNote,
        deviceSettings: normalizeDeviceSettings(device.deviceSettings),
        baselineSettingsComplete: baselineDeviceSettingsComplete(device),
        swipeModePreference: normalizeSwipeModePreference(device.swipeModePreference),
        swipeModeRecommendation: swipeModeRecommendation(device),
        day: waiting ? "" : extractDay(tags) || economics.elapsedDay || "",
        tags,
        operationGroupIds: operationGroupIdsForSerial(operationGroups, device.serial, { canonicalSerials: canonicalOperationSerials }),
      };
    });
  annotateLegacyMirrorProjection(deviceRows);
  for (const row of deviceRows) {
    row.xiaoweiNumber = row.laixiNumber || "";
    row.xiaoweiNumberOverride = row.laixiNumberOverride || "";
  }
  deviceRows.sort(compareLegacyMirrorNumberRows);

  const settings = normalizeFleetDbSettings(db.settings);
  const monthlyRevenue = monthlyRevenueRows(withdrawals);
  const monthlyRevenueBySite = monthlyRevenueBySiteRows(withdrawals, settings.siteName);
  const siteRevenue = siteRevenueRows(withdrawals, settings.siteName);
  const deviceNumberBySerial = new Map(deviceRows.map((row) => [row.serial, row.laixiNumber || row.xiaoweiSort || managementNumberFromId(row.managementId) || ""]));
  for (const row of offlineDevices) deviceNumberBySerial.set(row.offlineId, row.number || "");
  const deviceRevenue = deviceRevenueRows(withdrawals, db, settings.siteName, deviceNumberBySerial);
  return {
    ok: true,
    generatedAt: new Date().toISOString(),
    appVersion: readFleetAppVersion({ appDir: __dirname }),
    settings,
    license: readCustomerLicense(),
    counts: {
      devices: deviceRows.length,
      retired: allDevices.filter((device) => device && device.retiredAt).length,
      online: deviceRows.filter((row) => row.status === "ONLINE").length,
      waiting: deviceRows.filter((row) => row.status === "INACTIVE").length,
      offlineDevices: offlineDevices.filter((row) => row.status !== "archived").length,
      offlineReady: offlineDevices.filter((row) => row.effectiveStatus === "ready").length,
      offlineArchived: offlineDevices.filter((row) => row.status === "archived").length,
      withdrawals: withdrawals.length,
    },
    errorStats,
    devices: deviceRows,
    operationGroups,
    offlineDevices,
    withdrawals: withdrawals.slice().sort(compareWithdrawalRows),
    monthlyRevenue,
    monthlyRevenueBySite,
    siteRevenue,
    deviceRevenue,
  };
}

function buildFleetDbSummaryCached() {
  const dbPath = path.join(paths.dataDir, "fleet-db", "fleet-db.json");
  const masterPath = deviceMasterPath();
  const connectionPath = fleetConnectionHistoryPath();
  let stat = null;
  let masterStat = null;
  let connectionStat = null;
  try {
    stat = fs.statSync(dbPath);
    masterStat = fs.existsSync(masterPath) ? fs.statSync(masterPath) : null;
    connectionStat = fs.existsSync(connectionPath) ? fs.statSync(connectionPath) : null;
  } catch {
    return buildFleetDbSummary();
  }

  const masterKey = masterStat ? `${masterStat.mtimeMs}:${masterStat.size}` : "no-master";
  const connectionKey = connectionStat ? `${connectionStat.mtimeMs}:${connectionStat.size}` : "no-connection-history";
  const key = `${stat.mtimeMs}:${stat.size}:${masterKey}:${connectionKey}`;
  if (fleetDbSummaryCache.key === key && fleetDbSummaryCache.summary) {
    return {
      ...fleetDbSummaryCache.summary,
      cache: { hit: true, key },
    };
  }

  const summary = buildFleetDbSummary();
  fleetDbSummaryCache.key = key;
  fleetDbSummaryCache.summary = summary;
  return {
    ...summary,
    cache: { hit: false, key },
  };
}

async function buildLegacyMirrorNameSyncPlan() {
  const summary = buildFleetDbSummary();
  if (!summary.ok) return summary;

  const legacyMirror = await legacyMirrorWsapi.listDevices();
  if (!legacyMirror.ok) {
    return {
      ok: false,
      error: legacyMirror.warning || legacyMirror.message || "Legacy WSAPI is not available",
      legacyMirror,
    };
  }

  const dbBySerial = new Map();
  for (const row of summary.devices || []) {
    if (row.serial) dbBySerial.set(String(row.serial), row);
  }

  const updates = [];
  const matchedRows = [];
  const unmatchedRows = [];
  for (const device of legacyMirror.devices || []) {
    const row = findFleetRowForLegacyMirrorDevice(dbBySerial, device);
    if (!row) {
      unmatchedRows.push({
        deviceId: device.deviceId || "",
        number: device.number || "",
        currentName: device.name || "",
      });
      continue;
    }

    matchedRows.push(row);
    const desiredName = buildLegacyMirrorDeviceName(row);
    if (!desiredName || desiredName === (device.name || "")) continue;
    updates.push({
      deviceId: device.deviceId || device.serial || "",
      serial: row.serial || "",
      number: device.number || "",
      managementId: row.managementId || "",
      currentName: device.name || "",
      desiredName,
      tags: row.tags || [],
      status: row.status || "",
    });
  }

  return {
    ok: true,
    generatedAt: new Date().toISOString(),
    legacyMirrorCount: (legacyMirror.devices || []).length,
    dbCount: (summary.devices || []).length,
    matched: matchedRows.length,
    unmatched: unmatchedRows.length,
    unchanged: matchedRows.length - updates.length,
    updates,
    unmatchedRows,
  };
}

async function syncLegacyMirrorNamesFromFleetDb() {
  const plan = await buildLegacyMirrorNameSyncPlan();
  if (!plan.ok) return plan;

  const results = [];
  for (const update of plan.updates) {
    const result = await legacyMirrorWsapi.editDeviceName(update.deviceId, update.desiredName);
    results.push({
      ...update,
      ok: Boolean(result.ok),
      statusCode: result.statusCode,
      message: result.message || result.warning || "",
    });
  }

  const failed = results.filter((row) => !row.ok);
  return {
    ok: failed.length === 0,
    requested: plan.updates.length,
    succeeded: results.length - failed.length,
    failed: failed.length,
    matched: plan.matched,
    unmatched: plan.unmatched,
    unchanged: plan.unchanged,
    results,
    failedResults: failed,
  };
}

async function syncLegacyMirrorFromFleetDb() {
  const groups = await syncLegacyMirrorGroupsFromFleetDb();
  const names = await syncLegacyMirrorNamesFromFleetDb();
  const numbers = await syncLegacyMirrorNumbersFromFleetDb({ apply: true });
  return {
    ok: Boolean(groups.ok && names.ok && numbers.ok),
    groups,
    names,
    numbers,
    refresh: { tagBoard: regenerateTagBoard() },
  };
}

async function syncLegacyMirrorGroupsFromFleetDb() {
  const summary = buildFleetDbSummary();
  if (!summary.ok) return summary;

  const laixiDevices = await legacyMirrorWsapi.listDevices();
  if (!laixiDevices.ok) {
    return {
      ok: false,
      error: laixiDevices.warning || laixiDevices.message || "Legacy WSAPI is not available",
      legacyMirror: laixiDevices,
    };
  }

  const groupsResult = await ensureLegacyMirrorFleetGroups();
  if (!groupsResult.ok) return groupsResult;

  const groupById = new Map(groupsResult.groups.map((group) => [String(group.id), group]));
  const currentGroupByDeviceId = new Map();
  for (const group of groupsResult.groups) {
    for (const deviceId of group.deviceIds || []) currentGroupByDeviceId.set(String(deviceId), group);
  }

  const dbBySerial = new Map((summary.devices || []).filter((row) => row.serial).map((row) => [String(row.serial), row]));
  const results = [];
  const unmatched = [];
  for (const device of laixiDevices.devices || []) {
    const row = findFleetRowForLegacyMirrorDevice(dbBySerial, device);
    if (!row) {
      unmatched.push({ deviceId: device.deviceId || "", serial: device.serial || "", name: device.name || "" });
      continue;
    }

    const desiredName = laixiGroupNameForRow(row);
    const targetGroup = groupsResult.groupByName[desiredName];
    if (!targetGroup || !targetGroup.id) {
      results.push({ serial: row.serial, deviceId: device.deviceId || "", targetGroupName: desiredName, ok: false, error: "target group not found" });
      continue;
    }

    const deviceId = String(device.deviceId || device.serial || row.serial || "");
    const currentGroup = currentGroupByDeviceId.get(deviceId) || groupById.get(String((device.groupIds || [])[0] || ""));
    if (currentGroup && String(currentGroup.id) === String(targetGroup.id)) {
      results.push({ serial: row.serial, deviceId, targetGroupName: desiredName, ok: true, unchanged: true });
      continue;
    }

    const result = await legacyMirrorWsapi.moveToGroup({
      androidIds: deviceId,
      deleteGroupId: currentGroup && currentGroup.id || "",
      newGroupId: targetGroup.id,
    });
    results.push({
      serial: row.serial,
      deviceId,
      currentGroupName: currentGroup && currentGroup.name || "",
      targetGroupName: desiredName,
      ok: Boolean(result.ok),
      statusCode: result.statusCode,
      message: result.message || result.warning || "",
    });
  }

  const failed = results.filter((row) => !row.ok);
  return {
    ok: failed.length === 0,
    requested: results.length,
    moveRequested: results.filter((row) => !row.unchanged).length,
    succeeded: results.filter((row) => row.ok && !row.unchanged).length,
    unchanged: results.filter((row) => row.unchanged).length,
    failed: failed.length,
    unmatched: unmatched.length,
    duplicateGroups: groupsResult.duplicateGroups || [],
    results,
    failedResults: failed,
    unmatchedRows: unmatched,
  };
}

async function ensureLegacyMirrorFleetGroups() {
  let groupsRead = await legacyMirrorWsapi.getGroups();
  if (!groupsRead.ok) {
    return {
      ok: false,
      error: groupsRead.warning || groupsRead.message || "Legacy group list is not available",
      legacyMirror: groupsRead,
    };
  }

  const required = ["\u7a3c\u50cd\u4e2d", "\u975e\u7a3c\u50cd"];
  let groups = groupsRead.groups || [];
  for (const name of required) {
    if (findLegacyMirrorGroupByName(groups, name)) continue;
    await legacyMirrorWsapi.createGroup(name);
    groupsRead = await legacyMirrorWsapi.getGroups();
    groups = groupsRead.groups || groups;
  }

  const groupByName = {};
  const duplicateGroups = [];
  for (const name of required) {
    const sameNameGroups = groups
      .filter((group) => normalizeLegacyMirrorGroupName(group.name) === name)
      .sort(compareLegacyMirrorGroupPriority);
    if (sameNameGroups[0]) groupByName[name] = sameNameGroups[0];
    for (const duplicate of sameNameGroups.slice(1)) {
      duplicateGroups.push({
        id: duplicate.id,
        name: duplicate.name,
        canonicalId: sameNameGroups[0] && sameNameGroups[0].id || "",
        deviceCount: Array.isArray(duplicate.deviceIds) ? duplicate.deviceIds.length : 0,
      });
    }
  }
  const missing = required.filter((name) => !groupByName[name]);
  return {
    ok: missing.length === 0,
    missing,
    groups,
    groupByName,
    duplicateGroups,
  };
}

function findLegacyMirrorGroupByName(groups, name) {
  return (groups || []).find((group) => normalizeLegacyMirrorGroupName(group.name) === name) || null;
}

function normalizeLegacyMirrorGroupName(value) {
  return cleanText(value, 40)
    .replace(/\s+/g, "")
    .replace(/[()（）\[\]【】0-9０-９]/g, "");
}

function compareLegacyMirrorGroupPriority(a, b) {
  const countA = Array.isArray(a && a.deviceIds) ? a.deviceIds.length : 0;
  const countB = Array.isArray(b && b.deviceIds) ? b.deviceIds.length : 0;
  if (countA !== countB) return countB - countA;
  const idA = Number(a && a.id);
  const idB = Number(b && b.id);
  if (Number.isFinite(idA) && Number.isFinite(idB) && idA !== idB) return idA - idB;
  return String(a && a.id || "").localeCompare(String(b && b.id || ""), "en", { numeric: true });
}

function buildLegacyMirrorDeviceName(row) {
  const uiName = cleanText(row.deviceDisplayCode || displayDeviceCode(row.deviceCode) || row.uiName || row.deviceName || "", 24);
  const carrier = cleanText(row.carrierCode || "", 12);
  const tags = canonicalizeTags(Array.isArray(row.tags) ? row.tags : []);
  const prefix = tags.includes("STATE_ERROR") ? "ERROR中 " : "";
  const groupName = laixiGroupNameForRow({ ...row, tags });

  const day = row.day ? `DAY${row.day}` : tagValue(tags, /^DAY_(\d{2})$/, (value) => `DAY${Number(value)}`);
  if (groupName === "\u975e\u7a3c\u50cd") return compactLegacyMirrorName([prefix, "\u975e\u7a3c\u50cd", uiName, carrier]);
  const video180 = taskMarker(tags, /^V180_(\d+)$/, "V180_DONE", "180分\u25cb");
  const video10 = taskMarker(tags, /^V10_(\d+)$/, "V10_DONE", "追加\u25cb");
  if (!day && !video180 && !video10) return compactLegacyMirrorName([prefix, uiName, carrier]);
  return compactLegacyMirrorName([prefix, day, video180, video10, uiName, carrier]);
}

function laixiGroupNameForRow(row) {
  const tags = canonicalizeTags(Array.isArray(row && row.tags) ? row.tags : []);
  const status = cleanText(row && row.status, 20);
  if (tags.includes("GROUP_REST") || tags.includes("WAITING") || status === "WAITING") return "\u975e\u7a3c\u50cd";
  if (tags.includes("GROUP_INACTIVE")) return "\u975e\u7a3c\u50cd";
  if (tags.includes("GROUP_ACTIVE")) return "\u7a3c\u50cd\u4e2d";
  const day = row && row.day || tagValue(tags, /^DAY_(\d{2})$/, (value) => Number(value));
  return day ? "\u7a3c\u50cd\u4e2d" : "\u975e\u7a3c\u50cd";
}

function findFleetRowForLegacyMirrorDevice(dbBySerial, device) {
  const keys = laixiDeviceKeys(device);
  for (const key of keys) {
    const row = dbBySerial.get(key);
    if (row) return row;
  }
  for (const [serial, row] of dbBySerial.entries()) {
    if (keys.some((key) => key && (key === serial || key.endsWith(serial)))) return row;
  }
  return null;
}

function findLegacyMirrorDeviceForFleetRow(devices, row) {
  const serial = String(row && row.serial || "");
  if (!serial) return null;
  return (devices || []).find((device) => laixiDeviceKeys(device).some((key) => key === serial || key.endsWith(serial))) || null;
}

function laixiDeviceKeys(device) {
  return [device && device.serial, device && device.rawSerial, device && device.deviceId]
    .map((value) => String(value || "").trim())
    .filter(Boolean);
}

function taskMarker(tags, activePattern, doneTag, label) {
  if (tags.includes(doneTag)) return "";
  if (tags.some((tag) => activePattern.test(String(tag || "")))) return label;
  return "";
}

function tagValue(tags, pattern, mapValue) {
  for (const tag of tags) {
    const match = pattern.exec(String(tag || ""));
    if (match) return mapValue(match[1]);
  }
  return "";
}

function compactLegacyMirrorName(parts) {
  return parts
    .map((part) => cleanText(part, 48))
    .filter(Boolean)
    .join(" ")
    .slice(0, 48);
}

function annotateLegacyMirrorProjection(rows) {
  for (const row of rows) {
    row.laixiName = buildLegacyMirrorDeviceName(row);
    row.laixiNumber = "";
  }

  const bands = [
    { key: "active", start: 1 },
    { key: "inactive", start: INACTIVE_NUMBER_START },
  ];

  for (const band of bands) {
    const bandRows = rows
      .filter((row) => row && row.serial && laixiNumberBand(row) === band.key)
      .sort(compareLegacyMirrorNumberRows);
    const usedNumbers = new Set();
    const useOverrides = true;
    if (useOverrides) {
      for (const row of bandRows) {
        const fixedNumber = Number(row.laixiNumberOverride || 0);
        const bandEnd = band.key === "inactive" ? RETIRED_NUMBER_START : INACTIVE_NUMBER_START;
        if (Number.isInteger(fixedNumber) && fixedNumber >= band.start && fixedNumber < bandEnd && !usedNumbers.has(fixedNumber)) {
          row.laixiNumber = String(fixedNumber);
          usedNumbers.add(fixedNumber);
        }
      }
    }
    let next = band.start;
    for (const row of bandRows) {
      if (row.laixiNumber) continue;
      while (usedNumbers.has(next)) next += 1;
      row.laixiNumber = String(next);
      usedNumbers.add(next);
      next += 1;
    }
  }

  return rows;
}

function persistProjectedFleetNumbersFromRows(rows = []) {
  const projected = (rows || [])
    .filter((row) => row && row.serial && row.laixiNumber)
    .map((row) => ({
      serial: String(row.serial),
      number: Number(row.laixiNumber),
    }))
    .filter((row) => Number.isInteger(row.number) && row.number > 0);
  if (!projected.length) return { ok: true, changed: 0, checked: 0 };

  const { dbPath, db } = readFleetDbForWrite();
  const now = new Date().toISOString();
  let changed = 0;
  for (const row of projected) {
    const device = db.physicalDevices[row.serial];
    if (!device) continue;
    const before = JSON.stringify({
      xiaoweiSort: device.xiaoweiSort || "",
      laixiNumberOverride: device.laixiNumberOverride || "",
    });
    device.xiaoweiSort = row.number;
    device.laixiNumberOverride = row.number;
    const after = JSON.stringify({
      xiaoweiSort: device.xiaoweiSort || "",
      laixiNumberOverride: device.laixiNumberOverride || "",
    });
    if (before !== after) {
      device.updatedAt = now;
      changed += 1;
    }
  }
  if (changed) {
    db.updatedAt = now;
    writeJsonFile(dbPath, db);
  }
  return { ok: true, changed, checked: projected.length };
}

function persistProjectedFleetNumbers() {
  const summary = buildFleetDbSummary();
  if (!summary.ok) return summary;
  return persistProjectedFleetNumbersFromRows(summary.devices || []);
}

function laixiNumberBand(row) {
  const tags = canonicalizeTags(Array.isArray(row && row.tags) ? row.tags : []);
  const status = cleanText(row && row.status, 20).toUpperCase();
  if (tags.includes("GROUP_REST") || tags.includes("WAITING") || status === "WAITING" || tags.includes("GROUP_INACTIVE")) return "inactive";
  if (tags.includes("GROUP_ACTIVE")) return "active";
  const day = row && row.day || tagValue(tags, /^DAY_(\d{2})$/, (value) => Number(value));
  return day ? "active" : "inactive";
}

function formatManagementId(value) {
  const text = String(value || "").trim();
  const numberMatch = /^(?:A-)?(\d+)$/.exec(text);
  if (numberMatch) return `A-${numberMatch[1].padStart(2, "0")}`;
  return text;
}

function buildFleetDbExport() {
  const dbPath = path.join(paths.dataDir, "fleet-db", "fleet-db.json");
  const db = readJsonFile(dbPath, null);
  if (!db) return { ok: false, error: "fleet-db.json not found" };
  const summary = buildFleetDbSummary();
  return {
    ok: true,
    exportedAt: new Date().toISOString(),
    source: "Android Fleet local DB",
    fleetDb: db,
    summary: summary.ok ? {
      settings: summary.settings,
      counts: summary.counts,
      devices: summary.devices,
      withdrawals: summary.withdrawals,
      monthlyRevenue: summary.monthlyRevenue,
      monthlyRevenueBySite: summary.monthlyRevenueBySite,
      siteRevenue: summary.siteRevenue,
      deviceRevenue: summary.deviceRevenue,
    } : null,
  };
}

function findOfflineFleetDevice(db, value) {
  const target = cleanText(value, 80);
  if (!target) return null;
  const wanted = fleetIdentityKey(target);
  for (const [key, device] of Object.entries(normalizeOfflineDevices(db && db.offlineDevices))) {
    const candidates = [key, device.offlineId, device.number];
    if (candidates.some((candidate) => fleetIdentityKey(candidate) === wanted)) return device;
  }
  return null;
}

function listOfflineFleetDevices() {
  const dbPath = path.join(paths.dataDir, "fleet-db", "fleet-db.json");
  const db = readJsonFile(dbPath, null);
  if (!db) return { ok: false, error: "fleet-db.json not found" };
  const withdrawals = Array.isArray(db.withdrawals) ? db.withdrawals : [];
  const devices = buildOfflineDeviceRows(db, withdrawals);
  return {
    ok: true,
    generatedAt: new Date().toISOString(),
    counts: {
      total: devices.filter((row) => row.status !== "archived").length,
      active: devices.filter((row) => row.effectiveStatus === "active").length,
      resting: devices.filter((row) => row.effectiveStatus === "resting").length,
      ready: devices.filter((row) => row.effectiveStatus === "ready").length,
      archived: devices.filter((row) => row.status === "archived").length,
    },
    devices,
  };
}

function offlineDevicePayload(body, existing, offlineId, now) {
  const source = body && typeof body === "object" ? body : {};
  const number = cleanText(source.number, 24);
  const name = cleanText(source.name, 80);
  const operationStartedOn = cleanText(source.operationStartedOn, 10) || existing.operationStartedOn || localDateStamp(now);
  const initialDay = Number(source.initialDay === undefined ? existing.initialDay || 1 : source.initialDay);
  const uptimeHours = Number(source.uptimeHours === undefined ? effectiveOfflineUptimeMinutes(existing, now) / 60 : source.uptimeHours);
  const restHours = Number(source.restHours === undefined ? existing.restHours || 24 : source.restHours);
  if (!/^\d{1,4}$/.test(number) || Number(number) < 1) throw new Error("番号は1〜9999で入力してください");
  if (!name) throw new Error("端末名を入力してください");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(operationStartedOn)) throw new Error("開始日を確認してください");
  if (!Number.isInteger(initialDay) || initialDay < 1 || initialDay > MAX_OPERATION_DAY) throw new Error("開始DAYは1〜14で入力してください");
  if (!Number.isFinite(uptimeHours) || uptimeHours < 0 || uptimeHours > 1000000) throw new Error("UPTIMEを確認してください");
  if (!Number.isFinite(restHours) || restHours < 0.25 || restHours > 720) throw new Error("寝かせ時間は0.25〜720時間で入力してください");
  const taskConfig = source.taskConfig && typeof source.taskConfig === "object" ? source.taskConfig : {};
  const uptimeRunning = source.uptimeRunning === true;
  const device = normalizeOfflineDevice({
    ...existing,
    offlineId,
    number: String(Number(number)),
    name,
    model: cleanText(source.model, 80),
    carrier: cleanText(source.carrier, 40),
    simStatus: cleanText(source.simStatus, 40),
    networkType: cleanText(source.networkType, 40),
    networkSwitchedDay: cleanText(source.networkSwitchedDay, 8),
    osVersion: cleanText(source.osVersion, 40),
    notes: cleanText(source.notes, 800),
    operationStartedOn,
    initialDay,
    uptimeBaseMinutes: Math.round(uptimeHours * 60),
    uptimeRecordedAt: now.toISOString(),
    uptimeRunning,
    restHours,
    taskConfig: {
      ciYen: taskConfig.ciYen,
      video180PointsPerDay: taskConfig.video180PointsPerDay,
      video10Yen: taskConfig.video10Yen,
      note: taskConfig.note,
    },
    status: existing.status || "active",
    createdAt: existing.createdAt || now.toISOString(),
    updatedAt: now.toISOString(),
  }, offlineId);
  return updateOfflineInviteProfile(device, inviteProductFromPayload(source), source, {
    at: now.toISOString(),
    uptimeSeconds: Math.round(device.uptimeBaseMinutes * 60),
    uptimeSource: "manual",
  }).device;
}

function upsertOfflineFleetDevice(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const now = new Date();
  const requestedId = cleanText(body && body.offlineId, 40);
  const existing = requestedId ? findOfflineFleetDevice(db, requestedId) : null;
  if (requestedId && !existing) throw new Error("未接続端末が見つかりません");
  const offlineId = existing && existing.offlineId || nextOfflineDeviceId(db.offlineDevices);
  let device = offlineDevicePayload(body, existing || {}, offlineId, now);
  const duplicate = Object.values(db.offlineDevices).find((item) => item.offlineId !== offlineId && Number(item.number) === Number(device.number));
  if (duplicate) throw new Error(`未接続DB番号 ${device.number} は使用済みです`);
  device = appendOfflineHistory(device, {
    at: now.toISOString(),
    type: existing ? "updated" : "created",
    label: existing ? "手動登録を更新" : "未接続端末を登録",
  });
  db.offlineDevices[offlineId] = device;
  db.updatedAt = now.toISOString();
  writeJsonFile(dbPath, db);
  appendAuditLog({
    type: existing ? "offline_device_updated" : "offline_device_created",
    title: existing ? "Offline device updated" : "Offline device created",
    details: { offlineId, number: device.number, name: device.name },
  });
  return { ok: true, created: !existing, device: offlineDeviceSummary(device, { now }) };
}

function updateOfflineFleetTaskChecks(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const original = findOfflineFleetDevice(db, body && (body.offlineId || body.device));
  if (!original) throw new Error("未接続端末が見つかりません");
  const now = new Date();
  const date = cleanText(body && body.date, 10) || localDateStamp(now);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error("日付を確認してください");
  let device = normalizeOfflineDevice(original, original.offlineId);
  device.taskChecks[date] = {
    ci: body && body.ci === true,
    video180: body && body.video180 === true,
    video10: body && body.video10 === true,
    note: cleanText(body && body.note, 240),
    updatedAt: now.toISOString(),
  };
  device.updatedAt = now.toISOString();
  device = appendOfflineHistory(device, {
    at: now.toISOString(),
    type: "task_checks",
    label: `${date} タスク ${[body && body.ci, body && body.video180, body && body.video10].filter(Boolean).length}/3`,
  });
  db.offlineDevices[device.offlineId] = device;
  db.updatedAt = now.toISOString();
  writeJsonFile(dbPath, db);
  return { ok: true, device: offlineDeviceSummary(device, { now }) };
}

function moveOfflineDeviceToRest(device, now, reason) {
  const normalized = normalizeOfflineDevice(device, device && device.offlineId);
  const uptimeMinutes = effectiveOfflineUptimeMinutes(normalized, now);
  if (normalized.status === "active") {
    const snapshot = offlineDeviceSummary(normalized, { now });
    normalized.cycleHistory.push({
      startedOn: normalized.operationStartedOn,
      initialDay: normalized.initialDay,
      finalDay: snapshot.day || normalized.initialDay,
      endedAt: now.toISOString(),
      reason: cleanText(reason, 80) || "manual_complete",
      uptimeMinutes,
      taskConfig: normalized.taskConfig,
      taskChecks: normalized.taskChecks,
    });
    normalized.cycleHistory = normalized.cycleHistory.slice(-100);
  }
  normalized.status = "resting";
  normalized.cycleCompletedAt = now.toISOString();
  normalized.restStartedAt = now.toISOString();
  normalized.uptimeBaseMinutes = uptimeMinutes;
  normalized.uptimeRecordedAt = now.toISOString();
  normalized.uptimeRunning = false;
  normalized.updatedAt = now.toISOString();
  return normalized;
}

function runOfflineFleetDeviceAction(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const original = findOfflineFleetDevice(db, body && (body.offlineId || body.device));
  if (!original) throw new Error("未接続端末が見つかりません");
  const action = cleanText(body && body.action, 40);
  const now = new Date();
  let device = normalizeOfflineDevice(original, original.offlineId);
  let label = "";

  if (action === "toggle-uptime") {
    if (device.status !== "active") throw new Error("稼働中の端末だけUPTIMEを操作できます");
    if (device.uptimeRunning) {
      device.uptimeBaseMinutes = effectiveOfflineUptimeMinutes(device, now);
      device.uptimeRunning = false;
      label = "UPTIMEを停止";
    } else {
      device.uptimeRunning = true;
      label = "UPTIMEを開始";
    }
    device.uptimeRecordedAt = now.toISOString();
    device.updatedAt = now.toISOString();
  } else if (action === "complete-cycle" || action === "start-rest") {
    if (device.status !== "active") throw new Error("稼働中の端末だけ完走処理できます");
    device = archiveOfflineInviteVerification(device, {
      at: now.toISOString(),
      uptimeSeconds: effectiveOfflineUptimeMinutes(device, now) * 60,
      uptimeSource: "manual",
    }).device;
    device = moveOfflineDeviceToRest(device, now, action === "complete-cycle" ? "manual_complete" : "manual_rest");
    label = "完走・寝かせ開始";
  } else if (action === "start-cycle") {
    if (device.status === "archived") throw new Error("管理終了端末は再開できません");
    const rest = offlineRestState(device, now);
    if (device.status === "resting" && !rest.completed && body && body.force !== true) {
      throw new Error(`寝かせ終了まで残り${rest.remainingMinutes}分です`);
    }
    const initialDay = Number(body && body.initialDay || 1);
    const operationStartedOn = cleanText(body && body.operationStartedOn, 10) || localDateStamp(now);
    if (!Number.isInteger(initialDay) || initialDay < 1 || initialDay > MAX_OPERATION_DAY) throw new Error("開始DAYは1〜14で入力してください");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(operationStartedOn)) throw new Error("開始日を確認してください");
    device.status = "active";
    device.operationStartedOn = operationStartedOn;
    device.initialDay = initialDay;
    device.cycleCompletedAt = "";
    device.restStartedAt = "";
    device.taskChecks = {};
    device.uptimeRecordedAt = now.toISOString();
    device.uptimeRunning = body && body.uptimeRunning === false ? false : true;
    device.updatedAt = now.toISOString();
    label = "次周期を開始";
  } else if (action === "archive") {
    device.uptimeBaseMinutes = effectiveOfflineUptimeMinutes(device, now);
    device = archiveOfflineInviteVerification(device, {
      at: now.toISOString(),
      uptimeSeconds: device.uptimeBaseMinutes * 60,
      uptimeSource: "manual",
    }).device;
    device.uptimeRunning = false;
    device.uptimeRecordedAt = now.toISOString();
    device.status = "archived";
    device.archivedAt = now.toISOString();
    device.updatedAt = now.toISOString();
    label = "管理終了";
  } else if (action === "restore") {
    if (device.status !== "archived") throw new Error("管理終了端末ではありません");
    device.status = "active";
    device.archivedAt = "";
    device.operationStartedOn = localDateStamp(now);
    device.initialDay = 1;
    device.taskChecks = {};
    device.uptimeRecordedAt = now.toISOString();
    device.uptimeRunning = false;
    device.updatedAt = now.toISOString();
    label = "管理を再開";
  } else {
    throw new Error("未対応の操作です");
  }

  device = appendOfflineHistory(device, { at: now.toISOString(), type: action, label });
  db.offlineDevices[device.offlineId] = device;
  db.updatedAt = now.toISOString();
  writeJsonFile(dbPath, db);
  appendAuditLog({
    type: `offline_device_${action.replace(/-/g, "_")}`,
    title: `Offline device ${action}`,
    details: { offlineId: device.offlineId, number: device.number, label },
  });
  return { ok: true, action, device: offlineDeviceSummary(device, { now }) };
}

function updateFleetDbSettings(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const siteName = cleanText(body && body.siteName, 40);
  if (!siteName) throw new Error("Invalid input");
  db.settings = {
    ...normalizeFleetDbSettings(db.settings),
    siteName,
    updatedAt: new Date().toISOString(),
  };
  db.updatedAt = db.settings.updatedAt;
  writeJsonFile(dbPath, db);
  appendAuditLog({
    type: "fleet_db_settings_updated",
    title: "Fleet DB settings updated",
    details: { siteName },
  });
  return { ok: true, settings: db.settings };
}

function findWithdrawalFleetDevice(db, value) {
  const physical = findFleetDbDevice(db, value);
  if (physical) return { kind: "physical", device: physical };
  const offline = findOfflineFleetDevice(db, value);
  return offline ? { kind: "offline", device: offline } : null;
}

function withdrawalFleetDeviceIdentity(found) {
  if (!found || !found.device) return null;
  if (found.kind === "offline") {
    const device = normalizeOfflineDevice(found.device, found.device.offlineId);
    return {
      subjectKind: "offline",
      subjectId: `offline:${device.offlineId}`,
      serial: device.offlineId,
      managementId: device.number || "",
      deviceName: device.name || device.model || device.offlineId,
      day: offlineDeviceSummary(device).day || "",
      source: "manual_offline_app",
    };
  }
  const device = found.device;
  return {
    subjectKind: "fleet",
    subjectId: `fleet:${device.serial}`,
    serial: device.serial,
    managementId: device.managementId || "",
    deviceName: fixedDeviceLabel(device) || device.name || device.xiaoweiName || device.model || "",
    day: "",
    source: "manual_app",
  };
}

function resolveWithdrawalSubject(db, body, fallback = null) {
  const requestedKind = cleanText(body && body.subjectKind, 20).toLowerCase();
  const requestedSubjectId = cleanText(body && body.subjectId, 100).toLowerCase();
  if (requestedKind === "custom") {
    const identity = createCustomWithdrawalSubject((body && (body.deviceName || body.device)) || (fallback && fallback.deviceName));
    if (!identity) throw new Error("端末名を1～80文字で入力してください");
    if (requestedSubjectId && requestedSubjectId !== identity.subjectId) throw new Error("端末名と識別子が一致しません");
    return { kind: "custom", device: null, identity };
  }

  const value = body && body.device || fallback && (fallback.serial || fallback.managementId);
  const found = findWithdrawalFleetDevice(db, value);
  if (!found) throw new Error("端末を候補から選ぶか、任意名を入力してください");
  const actualKind = found.kind === "physical" ? "fleet" : "offline";
  if (requestedKind && requestedKind !== actualKind) throw new Error("端末の種類が一致しません");
  const identity = withdrawalFleetDeviceIdentity(found);
  if (requestedSubjectId && requestedSubjectId !== String(identity.subjectId || "").toLowerCase()) {
    throw new Error("端末の識別子が一致しません");
  }
  return { ...found, identity };
}

function addManualWithdrawal(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const found = resolveWithdrawalSubject(db, body);
  const device = found.device;
  const identity = found.identity;
  const amountYen = Number(body && body.amountYen);
  if (!Number.isInteger(amountYen) || amountYen <= 0) throw new Error("Invalid input");
  const withdrawalDate = cleanText(body && body.withdrawalDate, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(withdrawalDate)) throw new Error("Invalid input");

  const now = new Date().toISOString();
  const cycle = found.kind === "physical" ? latestCycleForDevice(db, device) : null;
  const siteName = normalizeFleetDbSettings(db.settings).siteName;
  const memo = cleanText(body && body.memo, 160);
  const withdrawal = {
    withdrawalId: `manual:${crypto.randomUUID()}`,
    recordedAt: now,
    withdrawalDate,
    subjectKind: identity.subjectKind,
    subjectId: identity.subjectId,
    managementId: identity.managementId,
    serial: identity.serial,
    cycleId: cycle && cycle.cycleId || "",
    sequence: cycle && cycle.sequence || "",
    deviceName: identity.deviceName,
    amountYen,
    amountPoints: amountYen * 100,
    finalCurrentPoints: "",
    finalCurrentYen: "",
    day: cycle && cycle.economics && (cycle.economics.elapsedDay || cycle.economics.day) || identity.day,
    ciTag: "",
    video180Tag: "",
    video10Tag: "",
    source: identity.source,
    siteName,
    sourceSnapshotDate: "",
    sourceTags: [],
    memo: memo || `${siteName} manual record`,
  };
  if (!hasStableWithdrawalIdentity(withdrawal)) throw new Error("Device identity is required");
  db.withdrawals.push(withdrawal);
  db.updatedAt = now;
  writeJsonFile(dbPath, db);
  appendAuditLog({
    type: "manual_withdrawal_recorded",
    title: "Manual withdrawal recorded",
    details: {
      siteName,
      managementId: withdrawal.managementId,
      deviceName: withdrawal.deviceName,
      amountYen,
      withdrawalDate,
    },
  });
  return { ok: true, withdrawal };
}

function updateWithdrawal(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const withdrawal = findWithdrawal(db, body && body.withdrawalId);
  if (!withdrawal) throw new Error("Invalid input");
  if (withdrawalIsCycleLinked(db, withdrawal)) {
    throw new Error("非稼働へ反映済みの出金は通常の訂正から変更できません");
  }
  const found = resolveWithdrawalSubject(db, body, withdrawal);
  const identity = found.identity;
  const previousStableSubjectId = stableWithdrawalSubjectId(withdrawal);
  const nextStableSubjectId = stableWithdrawalSubjectId(identity);
  const sameLegacyManagementId = !previousStableSubjectId
    && cleanText(withdrawal.managementId, 80)
    && cleanText(withdrawal.managementId, 80) === cleanText(identity.managementId, 80);
  const subjectChanged = !(previousStableSubjectId && previousStableSubjectId === nextStableSubjectId) && !sameLegacyManagementId;
  const cycle = subjectChanged && found.kind === "physical" ? latestCycleForDevice(db, found.device) : null;
  const amountYen = Number(body && body.amountYen);
  if (!Number.isInteger(amountYen) || amountYen <= 0) throw new Error("Invalid input");
  const withdrawalDate = cleanText(body && body.withdrawalDate, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(withdrawalDate)) throw new Error("Invalid input");
  withdrawal.withdrawalDate = withdrawalDate;
  withdrawal.subjectKind = identity.subjectKind;
  withdrawal.subjectId = identity.subjectId;
  withdrawal.managementId = identity.managementId || "";
  withdrawal.serial = identity.serial;
  withdrawal.deviceName = identity.deviceName || "";
  if (subjectChanged) {
    withdrawal.cycleId = cycle && cycle.cycleId || "";
    withdrawal.sequence = cycle && cycle.sequence || "";
    withdrawal.day = cycle && cycle.economics && (cycle.economics.elapsedDay || cycle.economics.day) || identity.day;
  }
  withdrawal.source = identity.source;
  withdrawal.amountYen = amountYen;
  withdrawal.amountPoints = amountYen * 100;
  withdrawal.memo = cleanText(body && body.memo, 160);
  withdrawal.updatedAt = new Date().toISOString();
  if (!hasStableWithdrawalIdentity(withdrawal)) throw new Error("Device identity is required");
  db.updatedAt = withdrawal.updatedAt;
  writeJsonFile(dbPath, db);
  appendAuditLog({
    type: "withdrawal_updated",
    title: "Withdrawal updated",
    details: { withdrawalId: withdrawal.withdrawalId, managementId: withdrawal.managementId, amountYen },
  });
  return { ok: true, withdrawal };
}

function deleteWithdrawal(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const withdrawalId = cleanText(body && body.withdrawalId, 180);
  const index = db.withdrawals.findIndex((row) => row && row.withdrawalId === withdrawalId);
  if (index < 0) throw new Error("Invalid input");
  if (withdrawalIsCycleLinked(db, db.withdrawals[index])) {
    throw new Error("非稼働へ反映済みの出金は通常の削除から削除できません");
  }
  const [deleted] = db.withdrawals.splice(index, 1);
  db.updatedAt = new Date().toISOString();
  writeJsonFile(dbPath, db);
  appendAuditLog({
    type: "withdrawal_deleted",
    title: "Withdrawal deleted",
    details: { withdrawalId, managementId: deleted.managementId, amountYen: deleted.amountYen },
  });
  return { ok: true, deleted };
}

function markWithdrawalResetDone(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const withdrawal = findWithdrawal(db, body && body.withdrawalId);
  if (!withdrawal) throw new Error("Invalid input");
  const found = findWithdrawalFleetDevice(db, withdrawal.serial || withdrawal.managementId);
  if (!found) throw new Error("Invalid input");
  if (found.kind === "offline") {
    const now = new Date();
    let device = normalizeOfflineDevice(found.device, found.device.offlineId);
    if (device.status === "active") device = moveOfflineDeviceToRest(device, now, "withdrawal_reset_done");
    device = appendOfflineHistory(device, {
      at: now.toISOString(),
      type: "withdrawal_reset_done",
      label: "出金後リセット・寝かせ開始",
      details: { withdrawalId: withdrawal.withdrawalId, amountYen: Number(withdrawal.amountYen || 0) },
    });
    db.offlineDevices[device.offlineId] = device;
    withdrawal.resetDone = true;
    withdrawal.resetDoneAt = now.toISOString();
    withdrawal.updatedAt = now.toISOString();
    db.updatedAt = now.toISOString();
    writeJsonFile(dbPath, db);
    appendAuditLog({
      type: "offline_withdrawal_reset_done",
      title: "Offline withdrawal reset done",
      details: { withdrawalId: withdrawal.withdrawalId, offlineId: device.offlineId, amountYen: withdrawal.amountYen },
    });
    return { ok: true, withdrawal, reset: { at: now.toISOString(), offline: true }, refresh: { skipped: true } };
  }
  const device = found.device;
  const result = closeActiveCycleAndStartWaiting(db, device, {
    resetReason: "withdrawal_reset_done",
    withdrawalId: withdrawal.withdrawalId,
    amountYen: Number(withdrawal.amountYen || 0),
    memo: "withdrawal reset done; moved to inactive",
  });
  withdrawal.resetDone = true;
  withdrawal.resetDoneAt = result.at;
  withdrawal.updatedAt = result.at;
  db.updatedAt = result.at;
  writeJsonFile(dbPath, db);
  const refresh = refreshAfterLocalWaitingReset();
  appendAuditLog({
    type: "withdrawal_reset_done",
    title: "Withdrawal reset done",
    details: { withdrawalId: withdrawal.withdrawalId, managementId: withdrawal.managementId, amountYen: withdrawal.amountYen, refresh },
  });
  return { ok: true, withdrawal, reset: result, refresh };
}

function resetDeviceToWaiting(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const device = findFleetDbDevice(db, body && body.device);
  if (!device) throw new Error("Invalid input");
  const result = closeActiveCycleAndStartWaiting(db, device, {
    resetReason: cleanText(body && body.reason, 80) || "manual_device_reset",
    withdrawalId: "",
    amountYen: 0,
    memo: cleanText(body && body.memo, 160) || "manual reset; moved to inactive",
  });
  db.updatedAt = result.at;
  writeJsonFile(dbPath, db);
  const refresh = refreshAfterLocalWaitingReset();
  appendAuditLog({
    type: "device_reset_to_inactive",
    title: "Device moved to inactive",
    details: { managementId: device.managementId, serial: device.serial, reason: result.resetReason, refresh },
  });
  return { ok: true, device: { managementId: device.managementId, serial: device.serial }, reset: result, refresh };
}

function updateFleetDbDevice(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const device = findFleetDbDevice(db, body && body.device);
  if (!device) throw new Error("device not found");
  const payload = body || {};
  const inviteProduct = inviteProductFromPayload(payload);
  const previousInviteResult = normalizeInviteProfiles(device)[inviteProduct].inviteResult;
  if (Object.prototype.hasOwnProperty.call(payload, "name")) {
    device.name = cleanText(payload.name, 80);
  }
  if (Object.prototype.hasOwnProperty.call(payload, "uiName")) {
    device.uiNameOverride = cleanText(payload.uiName, 24);
  }
  if (Object.prototype.hasOwnProperty.call(payload, "shortName")) {
    const shortName = cleanShortName(payload.shortName);
    if (!shortName) throw new Error("shortName cannot be empty");
    const masterUpdate = updateDeviceMasterShortNameForDevice(device, shortName);
    device.shortNameOverride = masterUpdate.updated ? "" : shortName;
    const parsed = parseDeviceCode(fixedDeviceCode(device));
    if (shortName && parsed) {
      device.deviceCode = `${shortName}-${parsed.carrier || deviceCarrierCode(device)}-${String(parsed.sequence).padStart(2, "0")}`;
      device.uiNameOverride = fixedDeviceLabel(device);
    }
  }
  if (Object.prototype.hasOwnProperty.call(payload, "swipeModePreference")) {
    device.swipeModePreference = normalizeSwipeModePreference(payload.swipeModePreference);
  }
  if (Object.prototype.hasOwnProperty.call(payload, "simStatus")) {
    device.simStatus = cleanText(payload.simStatus, 40);
  }
  if (Object.prototype.hasOwnProperty.call(payload, "networkType")) {
    device.networkType = cleanText(payload.networkType, 40);
  }
  if (Object.prototype.hasOwnProperty.call(payload, "networkSwitchedDay")) {
    const day = Number(payload.networkSwitchedDay);
    device.networkSwitchedDay = Number.isFinite(day) && day > 0 ? String(Math.floor(day)) : "";
  }
  if (Object.prototype.hasOwnProperty.call(payload, "osVersion")) {
    device.osVersion = cleanText(payload.osVersion, 40);
  }
  const inviteProfile = applyInviteProfilePayload(device, inviteProduct, payload);
  const nextInviteResult = inviteProfile.inviteResult;
  if (Object.prototype.hasOwnProperty.call(payload, "inviteResult") && nextInviteResult && nextInviteResult !== previousInviteResult) {
    device.inviteHistory = sanitizeInviteHistory(device.inviteHistory);
    device.inviteHistory.push({
      at: new Date().toISOString(),
      product: inviteProduct,
      type: inviteProfile.inviteType,
      role: inviteProfile.inviteRole,
      result: nextInviteResult,
      partner: inviteProfile.invitePartner,
      simStatus: cleanText(device.simStatus, 40),
      networkType: cleanText(device.networkType, 40),
      networkSwitchedDay: cleanText(device.networkSwitchedDay, 8),
      ttlRegisterMethod: inviteProfile.ttlRegisterMethod,
      osVersion: cleanText(device.osVersion, 40),
      uptimeSeconds: historyUptimeSeconds(device.adbLastUptimeSeconds),
      uptimeSource: "adb",
      note: lastNonEmptyLine(inviteProfile.inviteOpsNote),
    });
    device.inviteHistory = device.inviteHistory.slice(-100);
  }
  if (device.name) {
    rememberDeviceNameAliases(device, device.name);
  }
  device.updatedAt = new Date().toISOString();
  db.updatedAt = device.updatedAt;
  writeJsonFile(dbPath, db);
  appendAuditLog({
    type: "fleet_db_device_updated",
    title: "Fleet DB device updated",
    details: {
      managementId: device.managementId,
      serial: device.serial,
      name: device.name || "",
      uiNameOverride: device.uiNameOverride || "",
      shortNameOverride: device.shortNameOverride || "",
      swipeModePreference: device.swipeModePreference || "auto",
      inviteProduct,
      inviteFieldsUpdated: Boolean(
        Object.prototype.hasOwnProperty.call(payload, "simStatus") ||
        Object.prototype.hasOwnProperty.call(payload, "networkType") ||
        Object.prototype.hasOwnProperty.call(payload, "networkSwitchedDay") ||
        Object.prototype.hasOwnProperty.call(payload, "inviteType") ||
        Object.prototype.hasOwnProperty.call(payload, "inviteRole") ||
        Object.prototype.hasOwnProperty.call(payload, "inviteResult") ||
        Object.prototype.hasOwnProperty.call(payload, "invitePartner") ||
        Object.prototype.hasOwnProperty.call(payload, "osVersion") ||
        Object.prototype.hasOwnProperty.call(payload, "ttlRegisterMethod") ||
        Object.prototype.hasOwnProperty.call(payload, "inviteOpsNote")
      ),
    },
  });
  const syncName = Boolean(payload.syncName);
  const refresh = syncName ? refreshDisplayNamesOnly() : null;
  return { ok: true, device, refresh };
}

async function importNewAdbDevicesToFleetDb() {
  const { dbPath, db } = readFleetDbForWrite();
  const adbPath = resolveAdbPath();
  const [scanned, xiaowei] = await Promise.all([
    scanActiveAdbDevices({ adbPath }).catch((error) => ({ ok: false, warning: error.message, devices: [] })),
    readXiaoweiSources().catch((error) => ({ ok: false, warning: error.message, devices: [] })),
  ]);
  const existing = buildDevicesBySerial(db);
  const existingSerialKeys = new Set([...existing.keys()].map(serialKey));
  const initialSelection = selectNewDeviceImportCandidates({
    adbDevices: scanned && scanned.devices,
    xiaowei,
  });
  const initialCandidateSerials = new Set(initialSelection.candidates.map((candidate) => serialKey(candidate.serial)));
  const pnpCheckSerials = uniqueStrings((xiaowei && xiaowei.devices || [])
    .map((device) => cleanText(device && device.serial, 80))
    .filter((serial) => serial && !existingSerialKeys.has(serialKey(serial)) && !initialCandidateSerials.has(serialKey(serial))));
  const windowsPnp = readWindowsPresentPnpSerials(pnpCheckSerials);
  const selection = windowsPnp.serials.length
    ? selectNewDeviceImportCandidates({
      adbDevices: scanned && scanned.devices,
      xiaowei,
      windowsPresentSerials: windowsPnp.serials,
    })
    : initialSelection;
  selection.stats.windowsPnpWarning = windowsPnp.warning || "";
  const connected = selection.connectedAdb;
  const candidateRows = selection.candidates;
  const importStats = selection.stats;
  if (!candidateRows.length) {
    return {
      ok: false,
      error: [
        scanned && scanned.warning,
        xiaowei && xiaowei.warning,
        windowsPnp.warning,
        importStats.xiaoweiHistorySkipped
          ? `XiaoWeiの未接続保存履歴 ${importStats.xiaoweiHistorySkipped}台は取込対象外です。`
          : "",
      ].filter(Boolean).join(" ") || "現在接続中のADB端末または投影中のXiaoWei端末が見つかりません。",
      scanned: 0,
      ...importStats,
      imported: 0,
      skipped: 0,
      devices: [],
    };
  }
  const newCandidateSerials = new Set(candidateRows
    .filter((candidate) => !existingSerialKeys.has(serialKey(candidate.serial)))
    .map((candidate) => serialKey(candidate.serial)));
  const now = new Date().toISOString();
  let nextNumber = nextManagementNumber(db);
  const importedDevices = [];
  const skippedDevices = [];
  const backup = backupFleetDb();

  const adbFacts = new Map();
  const connectedNewDevices = connected.filter((device) => newCandidateSerials.has(serialKey(device.serial)));
  if (connectedNewDevices.length) {
    await runWithConcurrency(connectedNewDevices, 4, async (device) => {
      const facts = await readAdbDeviceInviteFacts(adbPath, device);
      adbFacts.set(serialKey(device.serial), facts);
    });
  }

  for (const candidate of candidateRows) {
    const candidateSerialKey = serialKey(candidate.serial);
    if (existingSerialKeys.has(candidateSerialKey)) {
      skippedDevices.push({ serial: candidate.serial, source: candidate.source, reason: "already_in_db" });
      continue;
    }
    const number = nextNumber++;
    const adbDevice = candidate.adb || {};
    const facts = adbFacts.get(candidateSerialKey) || {};
    const xiaoweiDevice = candidate.xiaowei || {};
    const model = cleanText(adbDevice.model || adbDevice.product || adbDevice.device || xiaoweiDevice.model || "Android", 80);
    const hardwareName = resolveHardwareModelName({
      adbModel: adbDevice.model,
      xiaoweiModel: xiaoweiDevice.model,
      model,
      product: adbDevice.product,
      device: adbDevice.device,
    });
    const preliminaryName = hardwareName || resolveModelName({
      knownName: xiaoweiDevice.name,
      model,
      adbModel: adbDevice.model,
      product: adbDevice.product,
      device: adbDevice.device,
      xiaoweiName: xiaoweiDevice.name,
      serial: candidate.serial,
    }) || UNRESOLVED_MODEL_NAME;
    const device = {
      serial: candidate.serial,
      firstSeenAt: now,
      lastSeenAt: now,
      managementId: `A-${String(number).padStart(2, "0")}`,
      number,
      name: preliminaryName,
      model,
      product: cleanText(adbDevice.product, 80),
      device: cleanText(adbDevice.device, 80),
      adbPortsSeen: uniqueStrings([adbDevice.adbPort ? String(adbDevice.adbPort) : ""]),
      cycleIds: [],
      notes: `Imported from ${candidate.source} new-device scan.`,
      excluded: false,
      xiaoweiSort: Number.isFinite(Number(xiaoweiDevice.sort)) ? Number(xiaoweiDevice.sort) : number,
      xiaoweiName: cleanText(xiaoweiDevice.name, 80),
      xiaoweiRemark: cleanText(xiaoweiDevice.remark, 120),
      xiaoweiIntranetIp: cleanText(xiaoweiDevice.intranetIp, 80),
      simStatus: cleanText(facts.simStatus, 40),
      networkType: cleanText(facts.networkType, 40),
      osVersion: cleanText(facts.osVersion, 40),
      deviceCode: "",
      uiNameOverride: "",
      swipeModePreference: "auto",
      updatedAt: now,
    };
    device.name = deviceMasterDisplayNameForDevice(device) || hardwareName || preliminaryName;
    db.physicalDevices[candidate.serial] = device;
    ensureInactiveCurrentCycle(db, device, {
      at: now,
      startReason: "new_device_import",
    });
    existing.set(candidate.serial, device);
    existingSerialKeys.add(candidateSerialKey);
    importedDevices.push({
      serial: device.serial,
      managementId: device.managementId,
      number: device.number,
      name: device.name,
      model: device.model,
      xiaoweiSort: device.xiaoweiSort,
      source: candidate.source,
    });
  }
  let codeSync = null;
  let orderSync = null;
  let tagBoard = null;
  const needsCodeSync = importedDevices.length || hasDevicesMissingDeviceCodes(db);
  if (importedDevices.length) {
    db.updatedAt = now;
    writeJsonFile(dbPath, db);
  }
  if (needsCodeSync) {
    codeSync = syncFleetDeviceCodes({ force: false });
    if (!importedDevices.length && (codeSync.changedDevices || codeSync.changedWithdrawals)) {
      tagBoard = regenerateTagBoard();
    }
  }
  if (importedDevices.length) {
    const projectedNumbers = persistProjectedFleetNumbers();
    orderSync = {
      ok: projectedNumbers.ok !== false,
      changedDevices: Number(projectedNumbers.changed || 0),
      numberChanges: Number(projectedNumbers.changed || 0),
      codeChanges: 0,
    };
    tagBoard = regenerateTagBoard();
    const latest = readFleetDbForWrite().db;
    for (const row of importedDevices) {
      const device = latest.physicalDevices && latest.physicalDevices[row.serial];
      if (!device) continue;
      row.xiaoweiSort = device.laixiNumberOverride || device.xiaoweiSort || row.xiaoweiSort;
      row.deviceCode = device.deviceCode || "";
      row.deviceLabel = fixedDeviceLabel(device) || device.uiNameOverride || device.name || "";
    }
  }
  const latestDb = readFleetDbForWrite().db;
  const masterUnregisteredDevices = importedDevices
    .map((row) => deviceMasterRegistrationIssueForDevice(latestDb.physicalDevices && latestDb.physicalDevices[row.serial]))
    .filter(Boolean);
  return {
    ok: true,
    scanned: candidateRows.length,
    ...importStats,
    imported: importedDevices.length,
    skipped: skippedDevices.length,
    backup,
    devices: importedDevices,
    skippedDevices: skippedDevices.slice(0, 20),
    masterUnregisteredCount: masterUnregisteredDevices.length,
    masterUnregisteredDevices,
    refresh: {
      codeSync: codeSync && { ok: codeSync.ok, changedDevices: codeSync.changedDevices, changedWithdrawals: codeSync.changedWithdrawals },
      orderSync: orderSync && {
        ok: orderSync.ok,
        changedDevices: orderSync.changedDevices,
        numberChanges: orderSync.numberChanges.length,
        codeChanges: orderSync.codeChanges.length,
      },
      tagBoard,
    },
  };
}

function syncFleetDeviceCodes(options = {}) {
  const { dbPath, db } = readFleetDbForWrite();
  const force = options.force !== false;
  const generatedAt = new Date().toISOString();
  const devicesBySerial = buildDevicesBySerial(db);
  const codes = buildDeviceCodePlan(db);
  let changedDevices = 0;
  let changedWithdrawals = 0;

  for (const item of codes) {
    const device = devicesBySerial.get(item.serial);
    if (!device) continue;
    const beforeCode = device.deviceCode || "";
    const beforeUi = device.uiNameOverride || "";
    const codeIsStaleForCurrentMaster = beforeCode && !item.existing;
    if (force || !beforeCode || codeIsStaleForCurrentMaster) device.deviceCode = item.code;
    if (force || !beforeUi || /^[ A-Za-z0-9]+-\d{2,3}(?:\s+[A-Z]+)?$/.test(beforeUi)) device.uiNameOverride = fixedDeviceLabel(device);
    if (device.deviceCode !== beforeCode || device.uiNameOverride !== beforeUi) {
      device.updatedAt = generatedAt;
      changedDevices += 1;
    }
  }

  for (const row of db.withdrawals || []) {
    if (!row || !row.serial) continue;
    const device = devicesBySerial.get(row.serial);
    if (!device) continue;
    const desiredName = fixedDeviceLabel(device) || device.name || row.deviceName || "";
    const desiredManagementId = device.managementId || row.managementId || "";
    const before = `${row.deviceName || ""}::${row.managementId || ""}`;
    row.deviceName = desiredName;
    row.managementId = desiredManagementId;
    if (`${row.deviceName || ""}::${row.managementId || ""}` !== before) {
      row.updatedAt = generatedAt;
      changedWithdrawals += 1;
    }
  }

  const changed = changedDevices > 0 || changedWithdrawals > 0;
  const backup = changed && options.backup !== false ? backupFleetDb() : null;
  if (changed) {
    db.updatedAt = generatedAt;
    writeJsonFile(dbPath, db);
  }
  return {
    ok: true,
    generatedAt,
    backup,
    force,
    changedDevices,
    changedWithdrawals,
    codes,
    refresh: null,
  };
}

function buildDevicesBySerial(db) {
  const devices = new Map();
  for (const device of Object.values(db.physicalDevices || {})) {
    if (device && device.serial) devices.set(device.serial, device);
  }
  return devices;
}

function readWindowsPresentPnpSerials(serials = []) {
  const cleanSerials = uniqueStrings(serials.map((serial) => cleanText(serial, 80)).filter(Boolean));
  if (process.platform !== "win32" || !cleanSerials.length) return { ok: true, serials: [], warning: "" };
  const script = [
    "$ErrorActionPreference = 'SilentlyContinue'",
    "$serials = ConvertFrom-Json $env:FLEET_USB_IMPORT_SERIALS",
    "$ids = @(Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | ForEach-Object { [string]$_.InstanceId })",
    "$found = foreach ($serial in $serials) {",
    "  if ($ids | Where-Object { $_ -match [regex]::Escape([string]$serial) } | Select-Object -First 1) { [string]$serial }",
    "}",
    "@($found | Sort-Object -Unique) | ConvertTo-Json -Compress",
  ].join("; ");
  const result = spawnSync("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], {
    cwd: paths.root,
    encoding: "utf8",
    windowsHide: true,
    timeout: 15000,
    env: { ...process.env, FLEET_USB_IMPORT_SERIALS: JSON.stringify(cleanSerials) },
  });
  if (result.error || result.status !== 0) {
    return {
      ok: false,
      serials: [],
      warning: result.error && result.error.message || result.stderr || "Windowsの現在USB端末確認に失敗しました",
    };
  }
  const raw = String(result.stdout || "").trim();
  if (!raw) return { ok: true, serials: [], warning: "" };
  try {
    const parsed = JSON.parse(raw);
    const found = Array.isArray(parsed) ? parsed : [parsed];
    return { ok: true, serials: uniqueStrings(found.map((serial) => cleanText(serial, 80)).filter(Boolean)), warning: "" };
  } catch (error) {
    return { ok: false, serials: [], warning: `Windowsの現在USB端末確認結果を解析できません: ${error.message}` };
  }
}

async function refreshExistingDeviceIdentitiesFromSources() {
  const { dbPath, db } = readFleetDbForWrite();
  const adbPath = resolveAdbPath();
  const [scanned, xiaowei] = await Promise.all([
    scanActiveAdbDevices({ adbPath }).catch((error) => ({ ok: false, warning: error.message, devices: [] })),
    readXiaoweiSources().catch((error) => ({ ok: false, warning: error.message, devices: [] })),
  ]);
  const adbBySerial = new Map((scanned.devices || [])
    .filter((device) => device && device.connected && device.serial)
    .map((device) => [serialKey(device.serial), device]));
  const xiaoweiBySerial = new Map((xiaowei.devices || [])
    .filter((device) => device && device.serial)
    .map((device) => [serialKey(device.serial), device]));
  const corrections = [];
  const masterUnregisteredDevices = [];
  let matchedDevices = 0;
  let changedDevices = 0;
  const now = new Date().toISOString();

  for (const device of Object.values(db.physicalDevices || {})) {
    if (!device || !device.serial) continue;
    const serial = String(device.serial);
    const key = serialKey(serial);
    const adbDevice = adbBySerial.get(key) || {};
    const xiaoweiDevice = xiaoweiBySerial.get(key) || {};
    if (!adbBySerial.has(key) && !xiaoweiBySerial.has(key)) continue;
    matchedDevices += 1;
    let changed = false;
    const hardwareName = resolveHardwareModelName({
      adbModel: adbDevice.model,
      xiaoweiModel: xiaoweiDevice.model,
      product: adbDevice.product,
      device: adbDevice.device,
    });
    for (const [field, value] of [
      ["model", adbDevice.model],
      ["product", adbDevice.product],
      ["device", adbDevice.device],
      ["xiaoweiModel", xiaoweiDevice.model],
    ]) {
      const next = cleanText(value, 80);
      if (!next || isGenericModelName(next) || device[field] === next) continue;
      device[field] = next;
      changed = true;
    }
    const xiaoweiName = cleanText(xiaoweiDevice.name, 80);
    if (xiaoweiName && device.xiaoweiName !== xiaoweiName) {
      device.xiaoweiName = xiaoweiName;
      changed = true;
    }
    const canonicalName = deviceMasterDisplayNameForDevice(device) || hardwareName;
    if (canonicalName && device.name !== canonicalName) {
      corrections.push({ serial, before: device.name || "", after: canonicalName });
      device.name = canonicalName;
      changed = true;
    }
    const masterRegistrationIssue = deviceMasterRegistrationIssueForDevice(device);
    if (masterRegistrationIssue) masterUnregisteredDevices.push(masterRegistrationIssue);
    if (changed) {
      device.updatedAt = now;
      changedDevices += 1;
    }
  }

  if (changedDevices) {
    db.updatedAt = now;
    writeJsonFile(dbPath, db);
  }
  return {
    ok: true,
    adbScanned: adbBySerial.size,
    xiaoweiScanned: xiaoweiBySerial.size,
    matchedDevices,
    changedDevices,
    correctedDevices: corrections.length,
    corrections: corrections.slice(0, 100),
    masterUnregisteredCount: masterUnregisteredDevices.length,
    masterUnregisteredDevices: masterUnregisteredDevices.slice(0, 200),
    warnings: [scanned.warning, xiaowei.warning].filter(Boolean),
  };
}

function listRetiredFleetDevices() {
  const { db } = readFleetDbForWrite();
  const devices = Object.values(db.physicalDevices || {})
    .filter((device) => device && device.retiredAt)
    .map((device) => ({
      serial: device.serial || "",
      managementId: device.managementId || "",
      xiaoweiNumber: device.laixiNumberOverride || device.xiaoweiSort || device.number || "",
      retiredFromXiaoweiNumber: device.retiredFromXiaoweiNumber || "",
      deviceLabel: fixedDeviceLabel(device) || device.uiNameOverride || device.name || "",
      deviceName: deviceMasterDisplayNameForDevice(device) || device.name || "",
      retiredAt: device.retiredAt || "",
      retiredReason: device.retiredReason || "",
      historyCount: Array.isArray(device.cycleIds) ? device.cycleIds.length : 0,
    }))
    .sort((a, b) => Number(a.xiaoweiNumber || 999999) - Number(b.xiaoweiNumber || 999999)
      || String(a.serial).localeCompare(String(b.serial), "en"));
  return { ok: true, count: devices.length, devices };
}

function retireFleetDbDevice(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const device = findFleetDbDevice(db, body && body.device);
  if (!device) throw new Error("device not found");
  if (device.retiredAt) return { ok: true, unchanged: true, device: summarizeRetiredDevice(device), backup: "" };
  const backup = backupFleetDb();
  const at = new Date().toISOString();
  const reason = cleanText(body && body.reason, 160) || "管理対象から手動で除外";
  const originalNumber = storedFleetDeviceNumber(device);
  const archiveNumber = nextAvailableFleetNumber(db, RETIRED_NUMBER_START, Number.MAX_SAFE_INTEGER, device.serial);
  device.retiredFromXiaoweiNumber = originalNumber && originalNumber < RETIRED_NUMBER_START ? originalNumber : "";
  device.retiredFromManagementId = device.managementId || "";
  device.number = archiveNumber;
  device.xiaoweiSort = archiveNumber;
  device.laixiNumberOverride = archiveNumber;
  device.managementId = `A-${archiveNumber}`;
  device.retiredAt = at;
  device.retiredReason = reason;
  device.excluded = true;
  device.updatedAt = at;
  for (const cycleId of Array.isArray(device.cycleIds) ? device.cycleIds : []) {
    const cycle = db.cycles && db.cycles[cycleId];
    if (!cycle || cycle.status !== "active") continue;
    cycle.status = "retired";
    cycle.endedAt = at;
    cycle.operationEndedAt = at;
    cycle.outcome = cycle.outcome || {};
    cycle.outcome.resetReason = "retired_device";
  }
  db.updatedAt = at;
  writeJsonFile(dbPath, db);
  appendAuditLog({
    type: "fleet_device_retired",
    title: "Fleet device retired",
    details: { serial: device.serial, managementId: device.managementId, originalNumber, archiveNumber, reason },
  });
  return { ok: true, device: summarizeRetiredDevice(device), backup };
}

function restoreFleetDbDevice(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const device = findFleetDbDevice(db, body && body.device);
  if (!device) throw new Error("device not found");
  if (!device.retiredAt) return { ok: true, unchanged: true, device: summarizeRetiredDevice(device), backup: "" };
  const backup = backupFleetDb();
  const at = new Date().toISOString();
  const preferredNumber = Number(device.retiredFromXiaoweiNumber || 0);
  const restoredNumber = Number.isInteger(preferredNumber)
    && preferredNumber > 0
    && preferredNumber < RETIRED_NUMBER_START
    && isFleetNumberAvailable(db, preferredNumber, device.serial)
    ? preferredNumber
    : nextAvailableFleetNumber(db, INACTIVE_NUMBER_START, RETIRED_NUMBER_START, device.serial);
  const restoredManagementId = restoredNumber === preferredNumber && device.retiredFromManagementId
    ? device.retiredFromManagementId
    : `A-${String(restoredNumber).padStart(2, "0")}`;
  device.number = restoredNumber;
  device.xiaoweiSort = restoredNumber;
  device.laixiNumberOverride = restoredNumber;
  device.managementId = restoredManagementId;
  device.retiredAt = "";
  device.retiredReason = "";
  device.retiredFromXiaoweiNumber = "";
  device.retiredFromManagementId = "";
  device.excluded = false;
  device.updatedAt = at;
  db.updatedAt = at;
  writeJsonFile(dbPath, db);
  appendAuditLog({
    type: "fleet_device_restored",
    title: "Fleet device restored",
    details: { serial: device.serial, managementId: device.managementId, restoredNumber },
  });
  return { ok: true, device: summarizeRetiredDevice(device), backup };
}

function summarizeRetiredDevice(device) {
  return {
    serial: device.serial || "",
    managementId: device.managementId || "",
    xiaoweiNumber: device.laixiNumberOverride || device.xiaoweiSort || device.number || "",
    retiredFromXiaoweiNumber: device.retiredFromXiaoweiNumber || "",
    deviceLabel: fixedDeviceLabel(device) || device.uiNameOverride || device.name || "",
    retiredAt: device.retiredAt || "",
    retiredReason: device.retiredReason || "",
  };
}

function storedFleetDeviceNumber(device) {
  const managementMatch = /^A-(\d+)$/.exec(String(device && device.managementId || ""));
  const candidates = [
    device && device.laixiNumberOverride,
    device && device.xiaoweiSort,
    device && device.number,
    managementMatch ? Number(managementMatch[1]) : 0,
  ];
  for (const value of candidates) {
    const number = Number(value || 0);
    if (Number.isInteger(number) && number > 0 && number < 999999) return number;
  }
  return 0;
}

function isFleetNumberAvailable(db, number, excludeSerial = "") {
  return !Object.values(db.physicalDevices || {}).some((device) =>
    device
    && device.serial !== excludeSerial
    && storedFleetDeviceNumber(device) === number
  );
}

function nextAvailableFleetNumber(db, start, endExclusive, excludeSerial = "") {
  const used = new Set(
    Object.values(db.physicalDevices || {})
      .filter((device) => device && device.serial !== excludeSerial)
      .map(storedFleetDeviceNumber)
      .filter((number) => Number.isInteger(number) && number >= start && number < endExclusive)
  );
  let candidate = start;
  while (candidate < endExclusive && used.has(candidate)) candidate += 1;
  if (candidate >= endExclusive) throw new Error("available device number not found");
  return candidate;
}

function updateFleetDbDeviceOrder(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const existing = new Map();
  for (const device of Object.values(db.physicalDevices || {})) {
    if (!device || !device.serial || device.retiredAt) continue;
    existing.set(cleanText(device.serial, 80), device);
    if (device.managementId) existing.set(cleanText(device.managementId, 80), device);
  }
  const requested = Array.isArray(body && body.order) ? body.order : [];
  const source = cleanText(body && body.source, 40) || "manual";
  const numberingMode = cleanText(body && body.numberingMode, 20) === "day" || source === "day-order-resequence"
    ? "day"
    : "model";
  const seen = new Set();
  const order = [];
  for (const value of requested) {
    const id = cleanText(value, 80);
    const device = existing.get(id);
    const serial = cleanText(device && device.serial, 80);
    if (!serial || seen.has(serial)) continue;
    seen.add(serial);
    order.push(serial);
  }
  const activeCyclesBySerial = activeFleetCyclesBySerial(db);
  const requestedBands = partitionFleetDevicesByBand(
    order.map((serial) => existing.get(serial)).filter(Boolean),
    activeCyclesBySerial
  );
  const canonicalOrder = [...requestedBands.active, ...requestedBands.inactive]
    .map((device) => String(device.serial));
  const numberAssignments = normalizeFleetNumberAssignments(body && body.numbers, existing, activeCyclesBySerial);
  const backup = backupFleetDb();
  const now = new Date().toISOString();
  const reconciliation = applyCanonicalFleetDeviceOrder(db, canonicalOrder, now, { numberAssignments, numberingMode });
  db.settings = {
    ...normalizeFleetDbSettings(db.settings),
    customDeviceOrder: canonicalOrder,
    updatedAt: now,
  };
  db.updatedAt = now;
  writeJsonFile(dbPath, db);
  let tagBoard = null;
  let tagBoardWarning = "";
  try {
    tagBoard = regenerateTagBoard();
  } catch (error) {
    tagBoardWarning = error.message;
  }
  appendAuditLog({
    type: "fleet_db_device_order_updated",
    title: order.length ? "Custom device order updated" : "Custom device order reset",
    details: {
      source,
      numberingMode,
      count: canonicalOrder.length,
      fixedNumbers: numberAssignments.size,
      changedDevices: reconciliation.changedDevices,
      numberChanges: reconciliation.numberChanges.length,
      codeChanges: reconciliation.codeChanges.length,
    },
  });
  return {
    ok: true,
    order: canonicalOrder,
    count: canonicalOrder.length,
    fixedNumbers: numberAssignments.size,
    mode: canonicalOrder.length ? "custom" : "default",
    source,
    numberingMode,
    backup,
    tagBoard,
    tagBoardWarning,
    ...reconciliation,
  };
}

function updateFleetDbDeviceNumbers(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const existing = new Map();
  const devices = Object.values(db.physicalDevices || {})
    .filter((device) => device && device.serial && !device.retiredAt);
  for (const device of devices) {
    existing.set(cleanText(device.serial, 80), device);
    if (device.managementId) existing.set(cleanText(device.managementId, 80), device);
  }
  const activeCyclesBySerial = activeFleetCyclesBySerial(db);
  const numberAssignments = normalizeFleetNumberAssignments(body && body.numbers, existing, activeCyclesBySerial);
  if (!numberAssignments.size) throw new Error("変更するXiaoWei番号がありません");

  const assignedSerials = new Set(numberAssignments.keys());
  const finalOwners = new Map();
  for (const device of devices) {
    const serial = String(device.serial);
    if (assignedSerials.has(serial)) continue;
    const number = storedFleetDeviceNumber(device);
    if (Number.isInteger(number) && number > 0) finalOwners.set(number, serial);
  }
  for (const [serial, number] of numberAssignments) {
    const owner = finalOwners.get(number);
    if (owner && owner !== serial) throw new Error(`XiaoWei番号 ${number} は別の端末が使用しています`);
    finalOwners.set(number, serial);
  }

  const backup = backupFleetDb();
  const now = new Date().toISOString();
  const numberChanges = [];
  for (const [serial, number] of numberAssignments) {
    const device = db.physicalDevices[serial];
    if (!device) continue;
    const beforeNumber = storedFleetDeviceNumber(device);
    device.xiaoweiSort = number;
    device.laixiNumberOverride = number;
    if (beforeNumber !== number) {
      device.updatedAt = now;
      numberChanges.push({
        serial,
        managementId: device.managementId || "",
        beforeNumber,
        afterNumber: number,
        band: fleetDeviceNumberBand(device, activeCyclesBySerial),
      });
    }
  }

  const settings = normalizeFleetDbSettings(db.settings);
  const customOrderCleared = settings.customDeviceOrder.length;
  db.settings = {
    ...settings,
    customDeviceOrder: [],
    updatedAt: now,
  };
  if (numberChanges.length || customOrderCleared) {
    db.updatedAt = now;
    writeJsonFile(dbPath, db);
  }

  let tagBoard = null;
  let tagBoardWarning = "";
  try {
    tagBoard = regenerateTagBoard();
  } catch (error) {
    tagBoardWarning = error.message;
  }
  appendAuditLog({
    type: "fleet_db_device_numbers_updated",
    title: "Device numbers updated independently",
    details: {
      requested: numberAssignments.size,
      changedDevices: numberChanges.length,
      customOrderCleared,
    },
  });
  return {
    ok: true,
    count: numberAssignments.size,
    fixedNumbers: numberAssignments.size,
    changedDevices: numberChanges.length,
    numberChanges,
    customOrderCleared,
    backup,
    tagBoard,
    tagBoardWarning,
  };
}

function updateFleetDbDeviceNameSequences(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const devices = Object.values(db.physicalDevices || {})
    .filter((device) => device && device.serial && !device.retiredAt);
  const existing = new Map();
  for (const device of devices) {
    existing.set(cleanText(device.serial, 80), device);
    if (device.managementId) existing.set(cleanText(device.managementId, 80), device);
  }

  const requested = Array.isArray(body && body.changes) ? body.changes : [];
  if (!requested.length) throw new Error("変更するXiaoWei名連番がありません");

  const changesBySerial = new Map();
  for (const item of requested) {
    const id = cleanText(item && (item.device || item.serial || item.managementId), 80);
    const device = existing.get(id);
    if (!device) throw new Error(`端末が見つかりません: ${id || "未指定"}`);
    const sequence = Number(item && item.sequence);
    if (!Number.isInteger(sequence) || sequence < 1 || sequence > MAX_DEVICE_NAME_SEQUENCE) {
      throw new Error(`${fixedDeviceLabel(device) || device.serial} の表示名連番は1〜${MAX_DEVICE_NAME_SEQUENCE}で入力してください`);
    }
    changesBySerial.set(String(device.serial), sequence);
  }

  const plannedBySerial = new Map(buildDeviceCodePlan(db).map((item) => [String(item.serial), item]));
  const ownersByGroup = new Map();
  const retiredReservations = retiredDeviceCodeReservations(db);
  for (const [group, sequences] of retiredReservations) {
    const owners = new Map();
    for (const sequence of sequences) owners.set(Number(sequence), "retired");
    ownersByGroup.set(group, owners);
  }

  for (const device of devices) {
    const group = `${deviceCodeBase(device)}::${deviceCarrierCode(device)}`;
    if (!ownersByGroup.has(group)) ownersByGroup.set(group, new Map());
    const owners = ownersByGroup.get(group);
    const planned = plannedBySerial.get(String(device.serial));
    const parsed = planned && parseDeviceCode(planned.code, planned.base, planned.carrier);
    const sequence = changesBySerial.has(String(device.serial))
      ? changesBySerial.get(String(device.serial))
      : Number(parsed && parsed.sequence || 0);
    if (!Number.isInteger(sequence) || sequence < 1 || sequence > MAX_DEVICE_NAME_SEQUENCE) {
      throw new Error(`${fixedDeviceLabel(device) || device.serial} の表示名連番を確定できません`);
    }
    const owner = owners.get(sequence);
    if (owner && owner !== String(device.serial)) {
      const label = owner === "retired" ? "管理対象外端末" : fixedDeviceLabel(db.physicalDevices[owner]) || owner;
      throw new Error(`${deviceCodeBase(device)} ${deviceCarrierCode(device)} の連番 ${String(sequence).padStart(2, "0")} は${label}が使用しています`);
    }
    owners.set(sequence, String(device.serial));
  }

  const backup = backupFleetDb();
  const now = new Date().toISOString();
  const sequenceChanges = [];
  const changedSerials = new Set();
  for (const [serial, sequence] of changesBySerial) {
    const device = db.physicalDevices[serial];
    if (!device) continue;
    const base = deviceCodeBase(device);
    const carrier = deviceCarrierCode(device);
    const beforeCode = fixedDeviceCode(device);
    const beforeLabel = fixedDeviceLabel(device);
    const beforeParsed = parseDeviceCode(beforeCode, base, carrier) || parseDeviceCode(beforeCode);
    const beforeSequence = Number(beforeParsed && beforeParsed.sequence || 0);
    const beforeOverride = validDeviceNameSequence(device.deviceNameSequenceOverride);
    device.deviceNameSequenceOverride = sequence;
    device.deviceCode = `${base}-${carrier}-${String(sequence).padStart(2, "0")}`;
    device.uiNameOverride = fixedDeviceLabel(device);
    if (beforeCode !== device.deviceCode || beforeOverride !== sequence) {
      device.updatedAt = now;
      changedSerials.add(serial);
    }
    sequenceChanges.push({
      serial,
      managementId: device.managementId || "",
      mainNumber: storedFleetDeviceNumber(device),
      beforeSequence,
      afterSequence: sequence,
      beforeLabel,
      afterLabel: fixedDeviceLabel(device),
    });
  }

  let changedWithdrawals = 0;
  for (const row of db.withdrawals || []) {
    if (!row || !changedSerials.has(String(row.serial))) continue;
    const device = db.physicalDevices[row.serial];
    const desiredName = fixedDeviceLabel(device) || device.name || row.deviceName || "";
    if (row.deviceName === desiredName) continue;
    row.deviceName = desiredName;
    row.updatedAt = now;
    changedWithdrawals += 1;
  }

  if (changedSerials.size || changedWithdrawals) {
    db.updatedAt = now;
    writeJsonFile(dbPath, db);
  }

  let tagBoard = null;
  let tagBoardWarning = "";
  try {
    tagBoard = regenerateTagBoard();
  } catch (error) {
    tagBoardWarning = error.message;
  }
  appendAuditLog({
    type: "fleet_db_device_name_sequences_updated",
    title: "XiaoWei display-name sequences updated independently",
    details: {
      requested: changesBySerial.size,
      changedDevices: changedSerials.size,
      changedWithdrawals,
      mainNumbersChanged: 0,
    },
  });
  return {
    ok: true,
    count: changesBySerial.size,
    changedDevices: changedSerials.size,
    changedWithdrawals,
    mainNumbersChanged: 0,
    sequenceChanges,
    backup,
    tagBoard,
    tagBoardWarning,
  };
}

function normalizeFleetNumberAssignments(value, existing, activeCyclesBySerial) {
  const entries = value && typeof value === "object" && !Array.isArray(value)
    ? Object.entries(value)
    : [];
  const assignments = new Map();
  const numberOwners = new Map();
  for (const [rawId, rawNumber] of entries) {
    if (rawNumber === "" || rawNumber === null || rawNumber === undefined) continue;
    const id = cleanText(rawId, 80);
    const device = existing.get(id);
    const serial = cleanText(device && device.serial, 80);
    if (!serial) continue;
    const number = Number(rawNumber);
    if (!Number.isInteger(number)) throw new Error(`${id} のXiaoWei番号は整数で入力してください`);
    const band = fleetDeviceNumberBand(device, activeCyclesBySerial);
    const valid = band === "active"
      ? number >= 1 && number < INACTIVE_NUMBER_START
      : number >= INACTIVE_NUMBER_START && number < RETIRED_NUMBER_START;
    if (!valid) {
      const range = band === "active" ? `1〜${INACTIVE_NUMBER_START - 1}` : `${INACTIVE_NUMBER_START}〜${RETIRED_NUMBER_START - 1}`;
      throw new Error(`${id} は${band === "active" ? "稼働" : "非稼働"}端末のため、XiaoWei番号は${range}で入力してください`);
    }
    const owner = numberOwners.get(number);
    if (owner && owner !== serial) throw new Error(`XiaoWei番号 ${number} が重複しています`);
    numberOwners.set(number, serial);
    assignments.set(serial, number);
  }
  return assignments;
}

function applyCanonicalFleetDeviceOrder(db, customOrder = [], now = new Date().toISOString(), options = {}) {
  const devices = Object.values(db.physicalDevices || {})
    .filter((device) => device && device.serial && !device.retiredAt);
  const bySerial = new Map(devices.map((device) => [String(device.serial), device]));
  const activeCyclesBySerial = activeFleetCyclesBySerial(db);
  const selected = [];
  const selectedIds = new Set();
  for (const value of customOrder) {
    const serial = String(value || "");
    const device = bySerial.get(serial);
    if (!device || selectedIds.has(serial)) continue;
    selected.push(device);
    selectedIds.add(serial);
  }
  const numberingMode = options.numberingMode === "day" ? "day" : "model";
  const automaticComparator = numberingMode === "day"
    ? (a, b) => compareOriginalFleetDevices(a, b, activeCyclesBySerial)
    : compareNaturalFleetDevices;
  const remaining = devices
    .filter((device) => !selectedIds.has(String(device.serial)))
    .sort(automaticComparator);
  const selectedBands = partitionFleetDevicesByBand(selected, activeCyclesBySerial);
  const remainingBands = partitionFleetDevicesByBand(remaining, activeCyclesBySerial);
  const ordered = [
    ...selectedBands.active,
    ...remainingBands.active,
    ...selectedBands.inactive,
    ...remainingBands.inactive,
  ];
  const changedSerials = new Set();
  const numberChanges = [];
  const codeChanges = [];
  const numberAssignments = options.numberAssignments instanceof Map
    ? options.numberAssignments
    : new Map();

  for (const band of [
    { key: "active", start: 1, end: INACTIVE_NUMBER_START },
    { key: "inactive", start: INACTIVE_NUMBER_START, end: RETIRED_NUMBER_START },
  ]) {
    const reservedNumbers = new Set();
    for (const device of ordered) {
      if (fleetDeviceNumberBand(device, activeCyclesBySerial) !== band.key) continue;
      const assigned = numberAssignments.get(String(device.serial));
      if (Number.isInteger(assigned)) reservedNumbers.add(assigned);
    }
    const allocatedNumbers = new Set();
    let nextAutomaticNumber = band.start;
    for (const device of ordered) {
      if (fleetDeviceNumberBand(device, activeCyclesBySerial) !== band.key) continue;
      let desiredNumber = numberAssignments.get(String(device.serial));
      if (!Number.isInteger(desiredNumber)) {
        while (nextAutomaticNumber < band.end && (reservedNumbers.has(nextAutomaticNumber) || allocatedNumbers.has(nextAutomaticNumber))) {
          nextAutomaticNumber += 1;
        }
        desiredNumber = nextAutomaticNumber;
        nextAutomaticNumber += 1;
      }
      if (desiredNumber >= band.end) throw new Error(`${band.key} device number range is full`);
      if (allocatedNumbers.has(desiredNumber)) throw new Error(`XiaoWei番号 ${desiredNumber} が重複しています`);
      allocatedNumbers.add(desiredNumber);
      const beforeNumber = storedFleetDeviceNumber(device);
      device.xiaoweiSort = desiredNumber;
      device.laixiNumberOverride = desiredNumber;
      if (beforeNumber !== desiredNumber) {
        device.updatedAt = now;
        changedSerials.add(String(device.serial));
        numberChanges.push({
          serial: device.serial,
          managementId: device.managementId || "",
          beforeNumber,
          afterNumber: desiredNumber,
          band: band.key,
        });
      }
    }
  }

  const bandCounts = { active: 0, inactive: 0 };
  for (const device of ordered) {
    const band = fleetDeviceNumberBand(device, activeCyclesBySerial);
    const number = Number(device.laixiNumberOverride || device.xiaoweiSort || 0);
    bandCounts[band] += 1;
    const valid = band === "active"
      ? Number.isInteger(number) && number >= 1 && number < INACTIVE_NUMBER_START
      : Number.isInteger(number) && number >= INACTIVE_NUMBER_START && number < RETIRED_NUMBER_START;
    if (!valid) {
      throw new Error(`XiaoWei番号帯の検査に失敗しました: ${device.serial} / ${band} / ${number}`);
    }
  }

  const usedSequences = cloneDeviceCodeReservations(retiredDeviceCodeReservations(db));
  const manualSequences = new Map();
  for (const device of ordered) {
    const sequence = validDeviceNameSequence(device.deviceNameSequenceOverride);
    if (!sequence) continue;
    const key = `${deviceCodeBase(device)}::${deviceCarrierCode(device)}`;
    if (!usedSequences.has(key)) usedSequences.set(key, new Set());
    const used = usedSequences.get(key);
    if (used.has(sequence)) {
      throw new Error(`${deviceCodeBase(device)} ${deviceCarrierCode(device)} の表示名連番 ${String(sequence).padStart(2, "0")} は予約済みです`);
    }
    used.add(sequence);
    manualSequences.set(String(device.serial), sequence);
  }
  for (const device of ordered) {
    const base = deviceCodeBase(device);
    const carrier = deviceCarrierCode(device);
    const key = `${base}::${carrier}`;
    if (!usedSequences.has(key)) usedSequences.set(key, new Set());
    const used = usedSequences.get(key);
    let sequence = manualSequences.get(String(device.serial)) || 0;
    if (!sequence) {
      sequence = 1;
      while (used.has(sequence)) sequence += 1;
      if (sequence > MAX_DEVICE_NAME_SEQUENCE) throw new Error(`${base} ${carrier} の機種内連番が${MAX_DEVICE_NAME_SEQUENCE}台を超えています`);
      used.add(sequence);
    }
    const beforeCode = device.deviceCode || "";
    const beforeLabel = device.uiNameOverride || "";
    device.deviceCode = `${base}-${carrier}-${String(sequence).padStart(2, "0")}`;
    device.uiNameOverride = fixedDeviceLabel(device);
    if (beforeCode !== device.deviceCode || beforeLabel !== device.uiNameOverride) {
      device.updatedAt = now;
      changedSerials.add(String(device.serial));
      codeChanges.push({
        serial: device.serial,
        managementId: device.managementId || "",
        xiaoweiNumber: device.laixiNumberOverride || device.xiaoweiSort || "",
        beforeCode,
        afterCode: device.deviceCode,
        beforeLabel,
        afterLabel: device.uiNameOverride,
      });
    }
  }

  let changedWithdrawals = 0;
  for (const row of db.withdrawals || []) {
    const device = row && row.serial ? bySerial.get(String(row.serial)) : null;
    if (!device) continue;
    const desiredName = fixedDeviceLabel(device) || device.name || row.deviceName || "";
    if (row.deviceName === desiredName) continue;
    row.deviceName = desiredName;
    row.updatedAt = now;
    changedWithdrawals += 1;
  }

  return {
    orderedIds: ordered.map((device) => String(device.serial)),
    changedDevices: changedSerials.size,
    changedWithdrawals,
    numberChanges,
    codeChanges,
    bandCounts,
  };
}

function fleetDeviceNumberBand(device, activeCyclesBySerial) {
  const cycle = activeCyclesBySerial.get(String(device.serial)) || null;
  const tags = canonicalizeTags(Array.isArray(cycle && cycle.tags) ? cycle.tags : []);
  const waiting = tags.includes("WAITING") || tags.includes("GROUP_REST") || tags.includes("GROUP_INACTIVE");
  const status = waiting ? "INACTIVE" : cycle ? "ACTIVE" : "NO CYCLE";
  const day = extractDay(tags) || Number(cycle && cycle.economics && cycle.economics.elapsedDay || 0);
  return laixiNumberBand({ tags, status, day });
}

function activeFleetCyclesBySerial(db) {
  return new Map(
    Object.values(db.cycles || {})
      .filter((cycle) => cycle && cycle.status === "active" && cycle.physicalSerial)
      .map((cycle) => [String(cycle.physicalSerial), cycle])
  );
}

function partitionFleetDevicesByBand(devices, activeCyclesBySerial) {
  const active = [];
  const inactive = [];
  for (const device of devices) {
    if (fleetDeviceNumberBand(device, activeCyclesBySerial) === "active") active.push(device);
    else inactive.push(device);
  }
  return { active, inactive };
}

function compareNaturalFleetDevices(a, b) {
  const baseA = deviceCodeBase(a);
  const baseB = deviceCodeBase(b);
  const rank = naturalFleetNameRank(baseA) - naturalFleetNameRank(baseB);
  if (rank) return rank;
  const base = String(baseA).localeCompare(String(baseB), "en", { numeric: true, sensitivity: "base" });
  if (base) return base;
  const carrier = carrierSortValue(deviceCarrierCode(a)) - carrierSortValue(deviceCarrierCode(b))
    || String(deviceCarrierCode(a)).localeCompare(String(deviceCarrierCode(b)), "en", { numeric: true });
  if (carrier) return carrier;
  const parsedA = parseDeviceCode(fixedDeviceCode(a));
  const parsedB = parseDeviceCode(fixedDeviceCode(b));
  const sequence = Number(parsedA && parsedA.sequence || 9999) - Number(parsedB && parsedB.sequence || 9999);
  if (sequence) return sequence;
  const number = storedFleetDeviceNumber(a) - storedFleetDeviceNumber(b);
  if (number) return number;
  return String(a.serial || "").localeCompare(String(b.serial || ""), "en", { numeric: true });
}

function compareOriginalFleetDevices(a, b, activeCyclesBySerial) {
  const bandA = fleetDeviceNumberBand(a, activeCyclesBySerial);
  const bandB = fleetDeviceNumberBand(b, activeCyclesBySerial);
  if (bandA !== bandB) return bandA === "active" ? -1 : 1;
  if (bandA === "active") {
    const day = fleetDeviceDay(b, activeCyclesBySerial) - fleetDeviceDay(a, activeCyclesBySerial);
    if (day) return day;
  }
  return compareNaturalFleetDevices(a, b);
}

function fleetDeviceDay(device, activeCyclesBySerial) {
  const cycle = activeCyclesBySerial.get(String(device && device.serial || "")) || null;
  const tags = canonicalizeTags(Array.isArray(cycle && cycle.tags) ? cycle.tags : []);
  return extractDay(tags) || Number(cycle && cycle.economics && cycle.economics.elapsedDay || 0);
}

function naturalFleetNameRank(value) {
  const first = String(value || "").trim().charAt(0);
  if (/\d/.test(first)) return 0;
  if (/[A-Za-z]/.test(first)) return 1;
  return 2;
}

function retiredDeviceCodeReservations(db) {
  const reservations = new Map();
  for (const device of Object.values(db.physicalDevices || {})) {
    if (!device || !device.retiredAt) continue;
    const parsed = parseDeviceCode(fixedDeviceCode(device));
    const sequence = Number(parsed && parsed.sequence || 0);
    if (!Number.isInteger(sequence) || sequence <= 0) continue;
    const key = `${deviceCodeBase(device)}::${deviceCarrierCode(device)}`;
    if (!reservations.has(key)) reservations.set(key, new Set());
    reservations.get(key).add(sequence);
  }
  return reservations;
}

function cloneDeviceCodeReservations(source) {
  return new Map([...source.entries()].map(([key, values]) => [key, new Set(values)]));
}

const INVITE_PRODUCTS = Object.freeze(["lite", "main"]);
const INVITE_PROFILE_FIELDS = Object.freeze([
  "inviteType",
  "inviteRole",
  "inviteResult",
  "invitePartner",
  "ttlRegisterMethod",
  "inviteOpsNote",
]);
const INVITE_PROFILE_FIELD_LIMITS = Object.freeze({
  inviteType: 40,
  inviteRole: 40,
  inviteResult: 40,
  invitePartner: 80,
  ttlRegisterMethod: 40,
  inviteOpsNote: 800,
});

function normalizeInviteProduct(value) {
  const product = cleanText(value, 20).toLowerCase();
  return INVITE_PRODUCTS.includes(product) ? product : "lite";
}

function inviteProductFromPayload(payload = {}) {
  if (!Object.prototype.hasOwnProperty.call(payload, "inviteProduct") || !cleanText(payload.inviteProduct, 20)) return "lite";
  const product = cleanText(payload.inviteProduct, 20).toLowerCase();
  if (!INVITE_PRODUCTS.includes(product)) throw new Error("inviteProduct must be lite or main");
  return product;
}

function normalizeInviteProfile(value, fallback = {}) {
  const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  const legacy = fallback && typeof fallback === "object" && !Array.isArray(fallback) ? fallback : {};
  const profile = {};
  for (const field of INVITE_PROFILE_FIELDS) {
    const raw = Object.prototype.hasOwnProperty.call(source, field) ? source[field] : legacy[field];
    profile[field] = cleanText(raw, INVITE_PROFILE_FIELD_LIMITS[field]);
  }
  return profile;
}

function emptyInviteProfiles() {
  return {
    lite: normalizeInviteProfile({}),
    main: normalizeInviteProfile({}),
  };
}

function normalizeInviteProfiles(device = {}) {
  const source = device && device.inviteProfiles && typeof device.inviteProfiles === "object" && !Array.isArray(device.inviteProfiles)
    ? device.inviteProfiles
    : {};
  const legacyLite = Object.fromEntries(INVITE_PROFILE_FIELDS.map((field) => [field, device && device[field]]));
  return {
    lite: normalizeInviteProfile(source.lite, legacyLite),
    main: normalizeInviteProfile(source.main),
  };
}

function persistInviteProfiles(device, profiles) {
  const normalized = {
    lite: normalizeInviteProfile(profiles && profiles.lite),
    main: normalizeInviteProfile(profiles && profiles.main),
  };
  device.inviteProfiles = normalized;
  for (const field of INVITE_PROFILE_FIELDS) device[field] = normalized.lite[field];
  return normalized;
}

function applyInviteProfilePayload(device, product, payload = {}) {
  const selectedProduct = normalizeInviteProduct(product);
  const profiles = normalizeInviteProfiles(device);
  const profile = { ...profiles[selectedProduct] };
  for (const field of INVITE_PROFILE_FIELDS) {
    if (!Object.prototype.hasOwnProperty.call(payload, field)) continue;
    profile[field] = cleanText(payload[field], INVITE_PROFILE_FIELD_LIMITS[field]);
  }
  profiles[selectedProduct] = profile;
  return persistInviteProfiles(device, profiles)[selectedProduct];
}

function persistInviteVerificationFromAction(serial, body = {}, actionResult = {}) {
  const result = actionResult && actionResult.result || {};
  const verification = body.action === "verify_invite_outcome"
    ? result
    : result.inviteVerification;
  const outcome = cleanText(verification && verification.outcome, 20);
  if (!verification || verification.accepted !== true || !["success", "failure"].includes(outcome)) return null;

  const { dbPath, db } = readFleetDbForWrite();
  const device = db.physicalDevices[cleanText(serial, 80)];
  if (!device) return null;
  const now = new Date().toISOString();
  const kind = cleanText(verification.kind || body.inviteTaskKind, 20);
  const resultLabel = outcome === "success" ? "OK" : "NG";
  const profiles = normalizeInviteProfiles(device);
  const profile = { ...profiles.lite };
  profile.inviteType = profile.inviteType || (kind === "qr" ? "QR" : "");
  profile.inviteResult = resultLabel;
  profiles.lite = profile;
  persistInviteProfiles(device, profiles);
  device.inviteHistory = sanitizeInviteHistory(device.inviteHistory);
  device.inviteHistory.push({
    at: now,
    product: "lite",
    type: profile.inviteType,
    role: profile.inviteRole,
    result: resultLabel,
    partner: profile.invitePartner,
    simStatus: device.simStatus || "",
    networkType: device.networkType || "",
    networkSwitchedDay: device.networkSwitchedDay || "",
    ttlRegisterMethod: profile.ttlRegisterMethod,
    osVersion: device.osVersion || "",
    uptimeSeconds: historyUptimeSeconds(device.adbLastUptimeSeconds),
    uptimeSource: "adb",
    note: cleanText(verification.reason, 200),
  });
  device.inviteHistory = device.inviteHistory.slice(-100);
  device.updatedAt = now;
  db.updatedAt = now;
  writeJsonFile(dbPath, db);
  return { saved: true, result: resultLabel, outcome, count: device.inviteHistory.length };
}

function sanitizeInviteHistory(value) {
  return (Array.isArray(value) ? value : []).map((entry) => ({
    at: cleanText(entry && entry.at, 40),
    finalizedAt: cleanText(entry && entry.finalizedAt, 40),
    product: normalizeInviteProduct(entry && entry.product),
    type: cleanText(entry && entry.type, 40),
    role: cleanText(entry && entry.role, 40),
    result: cleanText(entry && entry.result, 40),
    partner: cleanText(entry && entry.partner, 80),
    simStatus: cleanText(entry && entry.simStatus, 40),
    networkType: cleanText(entry && entry.networkType, 40),
    networkSwitchedDay: cleanText(entry && entry.networkSwitchedDay, 8),
    ttlRegisterMethod: cleanText(entry && entry.ttlRegisterMethod, 40),
    osVersion: cleanText(entry && entry.osVersion, 40),
    uptimeSeconds: historyUptimeSeconds(entry && entry.uptimeSeconds),
    uptimeSource: cleanText(entry && entry.uptimeSource, 20),
    note: cleanText(entry && entry.note, 800),
  })).filter((entry) => entry.at || entry.result);
}

const INACTIVE_INVITE_RESET_FIELDS = Object.freeze([
  "networkSwitchedDay",
]);

function archiveAndResetInviteVerification(device, at = new Date().toISOString(), options = {}) {
  if (!device) return { archived: false, historyCount: 0 };
  const selectedUptimeSeconds = historyUptimeSeconds(options.uptimeSeconds);
  const profiles = normalizeInviteProfiles(device);
  const history = sanitizeInviteHistory(device.inviteHistory);
  let archived = false;
  for (const product of INVITE_PRODUCTS) {
    const profile = profiles[product];
    const snapshot = {
      at,
      finalizedAt: at,
      product,
      type: profile.inviteType,
      role: profile.inviteRole,
      result: profile.inviteResult,
      partner: profile.invitePartner,
      simStatus: cleanText(device.simStatus, 40),
      networkType: cleanText(device.networkType, 40),
      networkSwitchedDay: cleanText(device.networkSwitchedDay, 8),
      ttlRegisterMethod: profile.ttlRegisterMethod,
      osVersion: cleanText(device.osVersion, 40),
      uptimeSeconds: selectedUptimeSeconds === null
        ? historyUptimeSeconds(device.adbLastUptimeSeconds)
        : selectedUptimeSeconds,
      uptimeSource: cleanText(options.uptimeSource, 20) || "adb",
      note: profile.inviteOpsNote,
    };
    const hasVerification = [
      snapshot.type,
      snapshot.role,
      snapshot.result,
      snapshot.partner,
      snapshot.ttlRegisterMethod,
      snapshot.note,
    ].some(Boolean);
    if (!hasVerification) continue;
    archived = true;
    const hasIdentity = [snapshot.type, snapshot.role, snapshot.result, snapshot.partner].some(Boolean);
    let matchingIndex = -1;
    if (hasIdentity) {
      for (let index = history.length - 1; index >= 0; index -= 1) {
        const entry = history[index];
        if (
          entry.product === snapshot.product &&
          entry.type === snapshot.type &&
          entry.role === snapshot.role &&
          entry.result === snapshot.result &&
          entry.partner === snapshot.partner
        ) {
          matchingIndex = index;
          break;
        }
      }
    }
    if (matchingIndex >= 0) {
      const existing = history[matchingIndex];
      history[matchingIndex] = {
        ...existing,
        ...snapshot,
        at: existing.at || at,
      };
    } else {
      history.push(snapshot);
    }
  }
  device.inviteHistory = sanitizeInviteHistory(history).slice(-100);
  persistInviteProfiles(device, emptyInviteProfiles());
  for (const field of INACTIVE_INVITE_RESET_FIELDS) device[field] = "";
  device.inviteVerificationResetAt = at;
  device.updatedAt = at;
  return { archived, historyCount: device.inviteHistory.length };
}

function historyUptimeSeconds(value) {
  if (value === null || value === undefined || value === "") return null;
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds >= 0 ? Math.floor(seconds) : null;
}

function historyAmountYenText(value) {
  if (value === null || value === undefined || value === "") return "";
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount < 0) return "";
  return `${amount.toLocaleString("ja-JP")}円`;
}

function lastNonEmptyLine(value) {
  return String(value || "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean).pop() || "";
}

function hasDevicesMissingDeviceCodes(db) {
  return Object.values(db.physicalDevices || {}).some((device) => {
    if (!device || !device.serial || device.retiredAt) return false;
    const base = deviceCodeBase(device);
    const carrier = deviceCarrierCode(device);
    return !parseDeviceCode(fixedDeviceCode(device), base, carrier);
  });
}

function buildDeviceCodePlan(db) {
  const devices = Object.values(db.physicalDevices || {})
    .filter((device) => device && device.serial && !device.retiredAt)
    .map((device) => {
      const base = deviceCodeBase(device);
      const carrier = deviceCarrierCode(device);
      const existing = parseDeviceCode(fixedDeviceCode(device), base, carrier);
      return {
        serial: device.serial,
        base,
        carrier,
        firstSeenAt: device.firstSeenAt || "",
        managementId: device.managementId || "",
        existing,
        manualSequence: validDeviceNameSequence(device.deviceNameSequenceOverride),
      };
    });

  const usedByBase = cloneDeviceCodeReservations(retiredDeviceCodeReservations(db));
  const planned = [];
  const pending = [];
  const sortedDevices = devices.slice().sort((a, b) =>
    a.base.localeCompare(b.base, "en") ||
    carrierSortValue(a.carrier) - carrierSortValue(b.carrier) ||
    String(a.firstSeenAt).localeCompare(String(b.firstSeenAt)) ||
    String(a.managementId).localeCompare(String(b.managementId), "en") ||
    String(a.serial).localeCompare(String(b.serial), "en")
  );

  for (const item of sortedDevices.filter((row) => row.manualSequence)) {
    const counterKey = `${item.base}::${item.carrier}`;
    if (!usedByBase.has(counterKey)) usedByBase.set(counterKey, new Set());
    const used = usedByBase.get(counterKey);
    if (used.has(item.manualSequence)) {
      throw new Error(`${item.base} ${item.carrier} の表示名連番 ${String(item.manualSequence).padStart(2, "0")} は予約済みです`);
    }
    used.add(item.manualSequence);
    planned.push({
      ...item,
      sequence: item.manualSequence,
      code: `${item.base}-${item.carrier}-${String(item.manualSequence).padStart(2, "0")}`,
    });
  }

  for (const item of sortedDevices.filter((row) => !row.manualSequence)) {
    const counterKey = `${item.base}::${item.carrier}`;
    if (!usedByBase.has(counterKey)) usedByBase.set(counterKey, new Set());
    const used = usedByBase.get(counterKey);
    const existingSequence = Number(item.existing && item.existing.sequence || 0);
    if (existingSequence >= 1 && existingSequence <= MAX_DEVICE_NAME_SEQUENCE && !used.has(existingSequence)) {
      used.add(existingSequence);
      planned.push({
        ...item,
        sequence: existingSequence,
        code: item.existing.code,
      });
      continue;
    }
    pending.push(item);
  }

  for (const item of pending) {
    const counterKey = `${item.base}::${item.carrier}`;
    if (!usedByBase.has(counterKey)) usedByBase.set(counterKey, new Set());
    const used = usedByBase.get(counterKey);
    let next = 1;
    while (next <= MAX_DEVICE_NAME_SEQUENCE && used.has(next)) next += 1;
    if (next > MAX_DEVICE_NAME_SEQUENCE) throw new Error(`${item.base} ${item.carrier} の表示名連番が${MAX_DEVICE_NAME_SEQUENCE}台を超えています`);
    used.add(next);
    planned.push({
      ...item,
      sequence: next,
      code: `${item.base}-${item.carrier}-${String(next).padStart(2, "0")}`,
    });
  }

  return planned.sort((a, b) =>
    a.base.localeCompare(b.base, "en") ||
    carrierSortValue(a.carrier) - carrierSortValue(b.carrier) ||
    Number(a.sequence || 0) - Number(b.sequence || 0) ||
    String(a.managementId).localeCompare(String(b.managementId), "en") ||
    String(a.serial).localeCompare(String(b.serial), "en")
  );
}

function validDeviceNameSequence(value) {
  const sequence = Number(value || 0);
  return Number.isInteger(sequence) && sequence >= 1 && sequence <= MAX_DEVICE_NAME_SEQUENCE ? sequence : 0;
}

function fixedDeviceCode(device) {
  return cleanText(device && device.deviceCode, 32) || cleanText(device && device.uiNameOverride, 32);
}

function fixedDeviceLabel(device) {
  const displayCode = fixedDeviceDisplayCode(device);
  if (displayCode) return `${displayCode} ${deviceCarrierCode(device)}`;
  return "";
}

function fixedDeviceDisplayCode(device) {
  const code = fixedDeviceCode(device);
  if (!code) return "";
  const parsed = parseDeviceCode(code);
  if (parsed) {
    const base = deviceCodeBase(device) || parsed.base;
    return `${base}-${String(parsed.sequence).padStart(2, "0")}`;
  }
  return displayDeviceCode(code);
}

function displayDeviceCode(value) {
  const parsed = parseDeviceCode(value);
  if (parsed) return `${parsed.base}-${String(parsed.sequence).padStart(2, "0")}`;
  const legacy = cleanText(value, 32).match(/^([A-Za-z0-9]{1,12})-(\d{2,3})$/);
  if (legacy) return `${legacy[1]}-${legacy[2]}`;
  return cleanText(value, 32);
}

function carrierFromDeviceCode(value) {
  const parsed = parseDeviceCode(value);
  return parsed ? parsed.carrier : "";
}

function parseDeviceCode(value, expectedBase = "", expectedCarrier = "") {
  const text = cleanText(value, 32);
  if (!text) return null;
  let match = text.match(/^([ A-Za-z0-9]{1,24})-([A-Z]+)-(\d{2,3})$/);
  if (match) {
    const base = cleanShortName(match[1]);
    if (expectedBase && base.toLowerCase() !== cleanShortName(expectedBase).toLowerCase()) return null;
    if (expectedCarrier && match[2] !== expectedCarrier) return null;
    return {
      code: text,
      base,
      carrier: match[2],
      sequence: Number(match[3]),
    };
  }
  match = text.match(/^([ A-Za-z0-9]{1,24})-(\d{2,3})$/);
  if (expectedCarrier) return null;
  if (!match) return null;
  const base = cleanShortName(match[1]);
  if (expectedBase && base.toLowerCase() !== cleanShortName(expectedBase).toLowerCase()) return null;
  return {
    code: text,
    base,
    carrier: expectedCarrier || "",
    sequence: Number(match[2]),
  };
}

function managedDisplayIdentityForDevice(device) {
  if (!device) return null;
  for (const value of [device.xiaoweiName, device.uiNameOverride, device.name]) {
    const identity = parseManagedDisplayName(value);
    if (identity) return identity;
  }
  return null;
}

function deviceCodeBase(device) {
  const override = cleanShortName(device && device.shortNameOverride);
  if (override) return override;
  const masterShortName = deviceMasterShortNameForDevice(device);
  if (masterShortName) return masterShortName;
  const displayIdentity = managedDisplayIdentityForDevice(device);
  if (displayIdentity && displayIdentity.shortName) return cleanShortName(displayIdentity.shortName);
  const resolved = resolveModelName({
    knownName: device && device.name,
    adbModel: device && device.model,
    xiaoweiModel: device && device.xiaoweiModel,
    product: device && device.product,
    device: device && device.device,
    uiName: device && device.uiNameOverride,
    xiaoweiName: device && device.xiaoweiName,
    serial: device && device.serial,
  });
  const raw = shortModelName(resolved || device.name || device.xiaoweiName || device.xiaoweiModel || device.model || "DEV");
  return cleanShortName(raw) || "DEV";
}

function deviceMasterShortNameForDevice(device) {
  const match = bestDeviceMasterMatchForDevice(device);
  return match ? match.shortName : "";
}

function deviceMasterDisplayNameForDevice(device) {
  const match = bestDeviceMasterMatchForDevice(device);
  const salesName = match && match.entry ? normalizeDeviceSalesName(match.entry.salesName) : "";
  return salesName;
}

function deviceMasterRegistrationIssueForDevice(device) {
  if (!device || bestDeviceMasterMatchForDevice(device)) return null;
  const displayIdentity = managedDisplayIdentityForDevice(device);
  const rawModel = [device.model, device.xiaoweiModel, device.product, device.device]
    .map((value) => cleanText(value, 80))
    .find((value) => value && !isGenericModelName(value)) || "";
  const inferredCarrier = inferredDeviceCarrierCode(device);
  const carrierCode = inferredCarrier && inferredCarrier !== "UNKNOWN"
    ? inferredCarrier
    : cleanText(displayIdentity && displayIdentity.carrier, 20).toUpperCase() || "UNKNOWN";
  return {
    serial: cleanText(device.serial, 120),
    managementId: cleanText(device.managementId, 40),
    xiaoweiNumber: device.laixiNumberOverride || device.xiaoweiSort || device.number || "",
    currentName: cleanText(device.name, 80),
    xiaoweiName: cleanText(device.xiaoweiName, 80),
    modelCode: rawModel,
    carrierCode,
  };
}

function bestDeviceMasterMatchForDevice(device) {
  if (!device) return "";
  const { master } = readDeviceMaster();
  const entries = Array.isArray(master.entries) ? master.entries : [];
  if (!entries.length) return "";
  const carrierCode = inferredDeviceCarrierCode(device);
  const fingerprint = [
    deviceMasterCache.key,
    device.serial,
    device.name,
    device.model,
    device.xiaoweiModel,
    device.product,
    device.device,
    device.uiNameOverride,
    device.xiaoweiName,
    carrierCode,
  ].map((value) => String(value || "")).join("\u0000");
  const cached = deviceMasterMatchCache.get(device);
  if (cached && cached.fingerprint === fingerprint) return cached.match;
  const match = bestDeviceMasterMatch({
    device,
    entries,
    carrierCode,
  });
  deviceMasterMatchCache.set(device, { fingerprint, match: match || "" });
  return match || "";
}

function updateDeviceMasterShortNameForDevice(device, shortName) {
  if (!device || !shortName) return { updated: false };
  const match = bestDeviceMasterMatchForDevice(device);
  if (!match || !match.entry || !match.entry.id) return { updated: false };
  const { master } = readDeviceMaster();
  const entry = (master.entries || []).find((item) => item && item.id === match.entry.id);
  if (!entry) return { updated: false };
  const nextShortName = cleanShortName(shortName);
  if (!nextShortName) return { updated: false };
  if (entry.shortName === nextShortName) return { updated: true, entry };
  entry.shortName = nextShortName;
  entry.source = "device db shortName edit";
  entry.updatedAt = new Date().toISOString();
  master.entries.sort(compareDeviceMasterEntries);
  writeDeviceMaster(master);
  return { updated: true, entry };
}

function uniqueStrings(values) {
  return [...new Set((values || []).filter(Boolean))];
}

function cleanShortName(value) {
  return String(value || "")
    .trim()
    .replace(/[^ A-Za-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .slice(0, 24)
    .trim();
}

function deviceCarrierCode(device) {
  const masterMatch = bestDeviceMasterMatchForDevice(device);
  if (masterMatch && masterMatch.modelMatched && masterMatch.entryCarrier && masterMatch.entryCarrier !== "UNKNOWN") {
    return masterMatch.entryCarrier;
  }
  const inferred = inferredDeviceCarrierCode(device);
  if (inferred && inferred !== "UNKNOWN") return inferred;
  const displayIdentity = managedDisplayIdentityForDevice(device);
  if (displayIdentity && displayIdentity.carrier) return displayIdentity.carrier;
  const fromCode = carrierFromDeviceCode(device && device.deviceCode);
  if (fromCode && fromCode !== "UNKNOWN") return fromCode;
  if (masterMatch && masterMatch.entryCarrier && masterMatch.entryCarrier !== "UNKNOWN") return masterMatch.entryCarrier;
  return "UNKNOWN";
}

function inferredDeviceCarrierCode(device) {
  const displayIdentity = managedDisplayIdentityForDevice(device);
  const displayCarrier = normalizeCarrierCode(displayIdentity && displayIdentity.carrier);
  if (displayCarrier !== "UNKNOWN") return displayCarrier;

  const models = uniqueStrings([
    device && device.model,
    device && device.xiaoweiModel,
    device && device.product,
    device && device.device,
  ].map(cleanModelCode).filter((model) => model && !isGenericModelName(model)));
  for (const model of models) {
    if (/^(SC|SO|SH|F|L|KY|DM)-?\d/.test(model)) return "DOCOMO";
    if (/^(SCG|SOG|SHG|FCG|XIG|KYV|KYG)/.test(model)) return "KDDI";
    if (/^SM-[A-Z0-9]+Z(?:-|$)/.test(model)) return "SBM";
    if (/^(A\d{3}(OP|XM|SH|SO|FC)|A\d{3}[A-Z]{2})(?:-|$)/.test(model)) return "SBM";
    if (/^SM-A253C(?:-|$)/.test(model)) return "RAKUTEN";
    if (/^(CPH|M\d|REDMI|PIXEL)/i.test(model)) return "SIMFREE";
  }
  return "UNKNOWN";
}

function cleanModelCode(value) {
  return cleanText(value, 40)
    .replace(/_/g, "-")
    .replace(/\s+/g, "")
    .toUpperCase();
}

async function syncLegacyMirrorNumbersFromFleetDb(options = {}) {
  const plan = await buildLegacyMirrorNumberSyncPlan();
  if (!plan.ok || options.apply === false) return plan;

  const results = [];
  const safePlan = buildSafeLegacyMirrorNumberUpdatePlan(plan.updates);
  for (const update of safePlan.steps) {
    const result = await legacyMirrorWsapi.editDeviceNo(update.deviceId, update.desiredNumber);
    results.push({
      ...update,
      ok: Boolean(result.ok),
      statusCode: result.statusCode,
      message: result.message || result.warning || "",
    });
  }

  const failed = results.filter((row) => !row.ok);
  return {
    ...plan,
    ok: failed.length === 0,
    requested: safePlan.steps.length,
    logicalRequested: plan.updates.length,
    succeeded: results.length - failed.length,
    failed: failed.length,
    tempSteps: safePlan.tempSteps,
    finalSteps: safePlan.finalSteps,
    results,
    failedResults: failed,
  };
}

async function syncXiaoweiNumbersFromFleetDb(options = {}) {
  const plan = await buildXiaoweiNumberSyncPlan();
  if (!plan.ok || options.apply === false) return plan;

  const xiaoweiRunning = isWindowsProcessRunning("xiaowei.exe");
  const strategy = buildXiaoweiNumberSyncStrategy(plan.updates, {
    apiAvailable: plan.xiaoweiApiAvailable,
    processRunning: xiaoweiRunning,
  });
  if (!strategy.ok) {
    const disconnectedRequested = plan.updates.filter((row) => row.disconnected).length;
    return {
      ...plan,
      ok: false,
      error: strategy.error,
      requested: 0,
      logicalRequested: plan.updates.length,
      succeeded: 0,
      failed: plan.updates.length,
      apiFailed: 0,
      disconnectedRequested,
      disconnectedSucceeded: 0,
      disconnectedFailed: disconnectedRequested,
      localDbRequested: 0,
      localDbUpdated: 0,
      xiaoweiRunning,
      syncBlocked: true,
      results: [],
      failedResults: [],
    };
  }

  const localDbUpdates = strategy.localDbUpdates;
  const localPersistence = plan.xiaoweiDbAvailable && localDbUpdates.length
    ? await xiaoweiIntegration.updateDeviceNumbers(localDbUpdates)
    : {
        ok: true,
        available: Boolean(plan.xiaoweiDbAvailable),
        requested: 0,
        updated: 0,
        backup: null,
        verification: { ok: true, checked: 0, failed: 0 },
      };
  if (!localPersistence.ok) {
    return {
      ...plan,
      ok: false,
      error: localPersistence.error || "XiaoWeiローカルDBの番号保存に失敗しました。",
      requested: 0,
      logicalRequested: plan.updates.length,
      succeeded: 0,
      failed: localDbUpdates.length || plan.updates.length,
      disconnectedRequested: plan.updates.filter((row) => row.disconnected).length,
      disconnectedSucceeded: 0,
      disconnectedFailed: plan.updates.filter((row) => row.disconnected).length,
      localPersistence,
      results: [],
      failedResults: [],
    };
  }

  const results = [];
  // The running app keeps its own cached sort values. Send every update through
  // the API, including DB-only/offline rows, so app shutdown cannot restore stale numbers.
  const apiUpdates = strategy.apiUpdates;
  const safeSteps = buildSafeXiaoweiNumberUpdateSteps(apiUpdates);
  for (const update of safeSteps) {
    try {
      const response = await xiaoweiApi.request({
        action: "updatedevices",
        devices: update.serial,
        data: { sort: Number(update.desiredNumber) },
      }, { timeout: 8000 });
      const ok = Number(response && response.code) === 10000;
      results.push({
        ...update,
        ok,
        code: response && response.code,
        message: cleanText(response && response.message, 200),
      });
    } catch (error) {
      results.push({
        ...update,
        ok: false,
        code: "XIAOWEI_NUMBER_SYNC_FAILED",
        message: error.message,
      });
    }
  }

  const apiFailedResults = results.filter((row) => !row.ok);
  const verification = await verifyAppliedXiaoweiNumberUpdates(plan.updates);
  const failedSerials = new Set([
    ...apiFailedResults.map((row) => String(row.serial || "")),
    ...(verification.failedRows || []).map((row) => String(row.serial || "")),
  ].filter(Boolean));
  const offlineSerials = new Set(plan.updates.filter((row) => row.disconnected).map((row) => String(row.serial)));
  const offlineFailed = [...failedSerials].filter((serial) => offlineSerials.has(serial)).length;
  const ok = apiFailedResults.length === 0 && verification.ok;
  const projectedPersisted = ok ? persistProjectedFleetNumbers() : null;
  const persisted = ok && plan.xiaoweiApiAvailable
    ? await syncXiaoweiLiveStateToFleetDb()
    : ok
      ? { ok: true, skipped: true, reason: "xiaowei_api_unavailable_local_db_updated" }
      : null;
  return {
    ...plan,
    ok,
    error: ok
      ? ""
      : apiFailedResults.length
        ? `XiaoWei番号更新APIで${apiFailedResults.length}件失敗しました。`
        : `XiaoWei番号の保存確認で${verification.failed || 0}件失敗しました。`,
    requested: results.length,
    logicalRequested: plan.updates.length,
    succeeded: plan.updates.length - failedSerials.size,
    failed: failedSerials.size,
    apiFailed: apiFailedResults.length,
    disconnectedRequested: offlineSerials.size,
    disconnectedSucceeded: offlineSerials.size - offlineFailed,
    disconnectedFailed: offlineFailed,
    localDbRequested: localPersistence.requested || 0,
    localDbUpdated: localPersistence.updated || 0,
    xiaoweiRunning,
    xiaoweiCacheProtected: strategy.cacheProtectedUpdates > 0,
    xiaoweiCacheProtectedUpdates: strategy.cacheProtectedUpdates,
    xiaoweiRestartRecommended: plan.updates.some((row) => row.xiaoweiSource === "db"),
    tempSteps: safeSteps.filter((step) => step.phase === "temp").length,
    finalSteps: safeSteps.filter((step) => step.phase === "final").length,
    results,
    failedResults: apiFailedResults,
    localPersistence,
    verification,
    projectedPersisted,
    persisted,
  };
}

function isWindowsProcessRunning(imageName) {
  if (process.platform !== "win32") return false;
  const target = cleanText(imageName, 120).toLowerCase();
  if (!target) return false;
  const result = spawnSync("tasklist.exe", ["/FI", `IMAGENAME eq ${target}`, "/FO", "CSV", "/NH"], {
    encoding: "utf8",
    windowsHide: true,
  });
  if (result.status !== 0) return false;
  return String(result.stdout || "").toLowerCase().includes(`"${target}"`);
}

async function verifyAppliedXiaoweiNumberUpdates(updates = []) {
  if (!updates.length) {
    return { ok: true, checked: 0, succeeded: 0, failed: 0, rows: [], failedRows: [] };
  }

  let verification = null;
  let sourceWarning = "";
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    const xiaowei = await readXiaoweiSources();
    sourceWarning = xiaowei.warning || "";
    verification = verifyXiaoweiNumberUpdates(updates, xiaowei.devices || []);
    verification.attempt = attempt;
    verification.xiaoweiCount = xiaowei.count || 0;
    verification.xiaoweiApiCount = (xiaowei.apiDevices || []).length;
    verification.xiaoweiDbCount = (xiaowei.dbDevices || []).length;
    verification.warning = sourceWarning;
    if (verification.ok) return verification;
    if (attempt < 3) await sleep(200);
  }

  return verification || {
    ok: false,
    checked: updates.length,
    succeeded: 0,
    failed: updates.length,
    rows: [],
    failedRows: updates.map((row) => ({
      serial: row.serial || "",
      expectedNumber: Number(row.desiredNumber || 0),
      actualNumber: 0,
      disconnected: Boolean(row.disconnected),
      error: "xiaowei_state_unavailable_after_update",
    })),
    warning: sourceWarning,
  };
}

async function syncXiaoweiLiveStateToFleetDb() {
  const xiaowei = await xiaoweiApi.listDevices();
  if (!xiaowei.available) {
    return {
      ok: false,
      changed: 0,
      matched: 0,
      error: xiaowei.apiTranslatedMessage || xiaowei.apiWarning || xiaowei.warning || "XiaoWei API is not available",
    };
  }

  const { dbPath, db } = readFleetDbForWrite();
  let matched = 0;
  let changed = 0;
  for (const live of xiaowei.devices || []) {
    const serial = cleanText(live && live.serial, 80);
    if (!serial || !db.physicalDevices[serial]) continue;
    matched += 1;
    const device = db.physicalDevices[serial];
    if (device.retiredAt) continue;
    const before = JSON.stringify({
      xiaoweiSort: device.xiaoweiSort || "",
      laixiNumberOverride: device.laixiNumberOverride || "",
      xiaoweiName: device.xiaoweiName || "",
    });
    const sort = Number(live.sort || 0);
    if (Number.isInteger(sort) && sort > 0) {
      device.xiaoweiSort = sort;
      device.laixiNumberOverride = sort;
    }
    device.xiaoweiName = cleanText(live.name, 120) || device.xiaoweiName || "";
    device.xiaoweiModel = cleanText(live.model, 120) || device.xiaoweiModel || "";
    const after = JSON.stringify({
      xiaoweiSort: device.xiaoweiSort || "",
      laixiNumberOverride: device.laixiNumberOverride || "",
      xiaoweiName: device.xiaoweiName || "",
    });
    if (before !== after) changed += 1;
  }

  if (changed) {
    db.updatedAt = new Date().toISOString();
    writeJsonFile(dbPath, db);
  }

  return {
    ok: true,
    xiaoweiCount: xiaowei.count || 0,
    matched,
    changed,
  };
}

function buildSafeXiaoweiNumberUpdateSteps(updates = []) {
  const cleanUpdates = (updates || []).filter((update) => update && update.serial && update.desiredNumber);
  if (!cleanUpdates.length) return [];
  const currentSet = new Set(cleanUpdates.map((update) => String(update.currentNumber || "")).filter(Boolean));
  const needsTemp = cleanUpdates.some((update) => currentSet.has(String(update.desiredNumber || "")));
  if (!needsTemp) return cleanUpdates.map((update) => ({ ...update, phase: "final" }));
  const tempBase = 700;
  const tempSteps = cleanUpdates.map((update, index) => ({
    ...update,
    phase: "temp",
    desiredNumber: String(tempBase + index + 1),
    finalDesiredNumber: String(update.desiredNumber),
  }));
  const finalSteps = cleanUpdates.map((update) => ({
    ...update,
    phase: "final",
  }));
  return [...tempSteps, ...finalSteps];
}

async function buildXiaoweiNumberSyncPlan() {
  const summary = buildFleetDbSummaryCached();
  if (!summary.ok) return summary;

  const xiaowei = await readXiaoweiSources();
  if (!xiaowei.available) {
    return {
      ok: false,
      error: xiaowei.apiTranslatedMessage || xiaowei.apiWarning || xiaowei.warning || "XiaoWeiのローカルDBとAPIを利用できません。",
      xiaoweiCount: xiaowei.count || 0,
      xiaoweiApiCount: (xiaowei.apiDevices || []).length,
      xiaoweiDbCount: (xiaowei.dbDevices || []).length,
      xiaoweiApiAvailable: Boolean(xiaowei.apiAvailable),
      xiaoweiDbAvailable: Boolean(xiaowei.dbAvailable),
      updates: [],
      requested: 0,
      succeeded: 0,
      failed: 0,
      unmatched: 0,
      unmatchedRows: [],
    };
  }

  const ordered = (summary.devices || [])
    .filter((row) => row && row.serial)
    .sort(compareLegacyMirrorNumberRows);
  const plan = buildXiaoweiNumberUpdatePlan(ordered, xiaowei.devices || []);

  return {
    ok: true,
    generatedAt: new Date().toISOString(),
    xiaoweiCount: xiaowei.count || 0,
    xiaoweiApiCount: (xiaowei.apiDevices || []).length,
    xiaoweiDbCount: (xiaowei.dbDevices || []).length,
    xiaoweiApiAvailable: Boolean(xiaowei.apiAvailable),
    xiaoweiDbAvailable: Boolean(xiaowei.dbAvailable),
    dbCount: (summary.devices || []).length,
    ...plan,
    requested: plan.updates.length,
    succeeded: 0,
    failed: 0,
  };
}

function buildSafeLegacyMirrorNumberUpdatePlan(updates = []) {
  const cleanUpdates = (updates || []).filter((update) => update && update.deviceId && update.desiredNumber);
  if (!cleanUpdates.length) {
    return { steps: [], tempSteps: 0, finalSteps: 0 };
  }

  const desiredSet = new Set(cleanUpdates.map((update) => String(update.desiredNumber)));
  const tempBase = 700;
  const tempSteps = cleanUpdates
    .filter((update) => desiredSet.has(String(update.currentNumber || "")))
    .map((update, index) => ({
      ...update,
      phase: "temp",
      desiredNumber: String(tempBase + index + 1),
      finalDesiredNumber: String(update.desiredNumber),
    }));

  const finalSteps = cleanUpdates.map((update) => ({
    ...update,
    phase: "final",
  }));

  return {
    steps: [...tempSteps, ...finalSteps],
    tempSteps: tempSteps.length,
    finalSteps: finalSteps.length,
  };
}

async function buildLegacyMirrorNumberSyncPlan() {
  const summary = buildFleetDbSummary();
  if (!summary.ok) return summary;

  const legacyMirror = await legacyMirrorWsapi.listDevices();
  if (!legacyMirror.ok) {
    return {
      ok: false,
      error: legacyMirror.warning || legacyMirror.message || "Legacy WSAPI is not available",
      legacyMirror,
    };
  }

  const ordered = (summary.devices || [])
    .map((row) => ({ row, device: findLegacyMirrorDeviceForFleetRow(legacyMirror.devices || [], row) }))
    .filter((item) => item.row.serial && item.device)
    .sort((a, b) => compareLegacyMirrorNumberRows(a.row, b.row));

  const updates = [];
  ordered.forEach(({ row, device }) => {
    if (!row.laixiNumber) return;
    const desiredNumber = String(row.laixiNumber);
    if (String(device.number || device.sort || "") === desiredNumber) return;
    updates.push({
      deviceId: device.deviceId || device.serial || "",
      serial: row.serial,
      currentNumber: device.number || device.sort || "",
      desiredNumber,
      deviceCode: row.deviceCode || row.uiName || "",
      deviceLabel: row.deviceLabel || "",
      modelGroup: row.modelGroup || "",
      carrierCode: row.carrierCode || "",
      day: row.day || "",
      status: row.status || "",
    });
  });

  return {
    ok: true,
    generatedAt: new Date().toISOString(),
    matched: ordered.length,
    updates,
    requested: updates.length,
    succeeded: 0,
    failed: 0,
  };
}

function compareLegacyMirrorNumberRows(a, b) {
  const groupA = laixiNumberBandRank(a);
  const groupB = laixiNumberBandRank(b);
  if (groupA !== groupB) return groupA - groupB;
  const dayA = Number(a.day || 0);
  const dayB = Number(b.day || 0);
  if (dayA !== dayB) return dayB - dayA;
  const model = String(a.modelGroup || "").localeCompare(String(b.modelGroup || ""), "en", { numeric: true });
  if (model !== 0) return model;
  const carrier = carrierSortValue(a.carrierCode) - carrierSortValue(b.carrierCode)
    || String(a.carrierCode || "").localeCompare(String(b.carrierCode || ""), "en", { numeric: true });
  if (carrier !== 0) return carrier;
  return String(a.deviceCode || a.uiName || a.managementId).localeCompare(String(b.deviceCode || b.uiName || b.managementId), "en", { numeric: true });
}

function laixiNumberBandRank(row) {
  return {
    active: 0,
    inactive: 8,
    rest: 9,
  }[laixiNumberBand(row)] ?? 8;
}

function carrierSortValue(value) {
  return {
    DOCOMO: 10,
    KDDI: 20,
    SBM: 30,
    RAKUTEN: 40,
    SIMFREE: 50,
    UNKNOWN: 90,
  }[String(value || "UNKNOWN").toUpperCase()] || 80;
}

function rememberDeviceNameAliases(device, canonicalName) {
  const name = cleanText(canonicalName, 80);
  if (!name || name === UNRESOLVED_MODEL_NAME || isGenericModelName(name)) return;
  const aliases = [
    device.xiaoweiName,
    device.xiaoweiModel,
    device.model,
  ].map((value) => cleanText(value, 80)).filter((value) => value && !isGenericModelName(value));
  if (!aliases.length) return;

  const map = readJsonFile(DEVICE_NAME_MAP_PATH, { version: 1, exact: {}, prefix: [], short: {} });
  if (!map.exact || typeof map.exact !== "object") map.exact = {};
  if (!Array.isArray(map.prefix)) map.prefix = [];
  if (!map.short || typeof map.short !== "object") map.short = {};

  let changed = false;
  for (const alias of aliases) {
    for (const key of aliasKeys(alias)) {
      if (!key || map.exact[key] === name) continue;
      map.exact[key] = name;
      changed = true;
    }
  }
  const short = shortModelName(name);
  if (short && short !== "UNK" && map.short[name] !== short) {
    map.short[name] = short;
    changed = true;
  }
  if (changed) {
    map.updatedAt = new Date().toISOString();
    writeJsonFile(DEVICE_NAME_MAP_PATH, map);
    clearModelNameCache();
  }
}

function aliasKeys(value) {
  const text = cleanText(value, 80);
  if (!text) return [];
  return [...new Set([
    text,
    text.toUpperCase(),
    text.replace(/_/g, "-"),
    text.replace(/-/g, "_"),
    text.replace(/[_-]/g, ""),
    text.replace(/_/g, "-").toUpperCase(),
    text.replace(/-/g, "_").toUpperCase(),
    text.replace(/[_-]/g, "").toUpperCase(),
  ].filter(Boolean))];
}

function importBranchReport(body) {
  const { dbPath, db } = readFleetDbForWrite();
  const analysis = analyzeBranchReport(db, body);
  const now = new Date().toISOString();
  for (const item of analysis.toImport) {
    const row = item.row;
    db.withdrawals.push({
      withdrawalId: item.withdrawalId,
      recordedAt: cleanText(row.recordedAt, 40) || now,
      importedAt: now,
      withdrawalDate: item.withdrawalDate,
      subjectKind: item.subjectKind,
      subjectId: item.subjectId,
      managementId: item.managementId,
      serial: item.serial,
      cycleId: item.cycleId,
      sequence: item.sequence,
      deviceName: item.deviceName,
      amountYen: item.amountYen,
      amountPoints: item.amountYen * 100,
      finalCurrentPoints: row.finalCurrentPoints || "",
      finalCurrentYen: row.finalCurrentYen || "",
      day: item.day,
      source: "branch_report_import",
      siteName: item.siteName,
      memo: cleanText(row.memo, 160) || "branch report import",
      resetDone: Boolean(row.resetDone),
      resetDoneAt: cleanText(row.resetDoneAt, 40),
    });
  }
  db.updatedAt = now;
  writeJsonFile(dbPath, db);
  appendAuditLog({
    type: "branch_report_imported",
    title: "Branch report imported",
    details: {
      siteName: cleanText(body && body.siteName, 40),
      imported: analysis.toImport.length,
      skipped: analysis.duplicateRows.length + analysis.invalidRows.length,
    },
  });
  return {
    ok: true,
    imported: analysis.toImport.length,
    skipped: analysis.duplicateRows.length + analysis.invalidRows.length,
    duplicate: analysis.duplicateRows.length,
    invalid: analysis.invalidRows.length,
  };
}

function previewBranchReport(body) {
  const { db } = readFleetDbForWrite();
  const analysis = analyzeBranchReport(db, body);
  return {
    ok: true,
    siteName: analysis.siteName,
    total: analysis.total,
    importable: analysis.toImport.length,
    duplicate: analysis.duplicateRows.length,
    invalid: analysis.invalidRows.length,
    samples: {
      importable: previewBranchRows(analysis.toImport),
      duplicate: previewBranchRows(analysis.duplicateRows),
      invalid: previewBranchRows(analysis.invalidRows),
    },
  };
}

function analyzeBranchReport(db, body) {
  const rows = Array.isArray(body && body.withdrawals) ? body.withdrawals : [];
  if (!rows.length) throw new Error("Invalid input");
  const defaultSiteName = normalizeFleetDbSettings(db.settings).siteName;
  const bodySiteName = cleanText(body && body.siteName, 40) || defaultSiteName || "default";
  const existingIds = new Set(db.withdrawals.map((row) => row && row.withdrawalId).filter(Boolean));
  const existingNaturalKeys = new Set(
    db.withdrawals
      .map((row) => withdrawalNaturalKey(row, withdrawalSiteName(row, defaultSiteName)))
      .filter(Boolean),
  );
  const seenIds = new Set();
  const seenNaturalKeys = new Set();
  const toImport = [];
  const duplicateRows = [];
  const invalidRows = [];

  rows.forEach((row, index) => {
    const amountYen = Number(row && row.amountYen);
    const withdrawalDate = cleanText(row && row.withdrawalDate, 10);
    const siteName = cleanText(row && row.siteName, 40) || bodySiteName;
    const managementId = cleanText(row && row.managementId, 20);
    const serial = cleanText(row && row.serial, 80);
    let subjectKind = cleanText(row && row.subjectKind, 20).toLowerCase();
    let subjectId = cleanText(row && row.subjectId, 100).toLowerCase();
    let deviceName = cleanText(row && row.deviceName, 80);
    const cycleId = cleanText(row && row.cycleId, 120);
    const sequence = cleanText(row && row.sequence, 80);
    const day = cleanText(row && row.day, 20);
    if (!Number.isInteger(amountYen) || amountYen <= 0 || !/^\d{4}-\d{2}-\d{2}$/.test(withdrawalDate)) {
      invalidRows.push({ row, index, reason: "invalid" });
      return;
    }
    if (subjectKind === "custom") {
      const identity = createCustomWithdrawalSubject(deviceName);
      if (serial || managementId || cycleId || sequence || day || !identity || identity.subjectId !== subjectId) {
        invalidRows.push({ row, index, reason: "custom_identity_mismatch" });
        return;
      }
      subjectId = identity.subjectId;
      deviceName = identity.deviceName;
    }
    if (!hasStableWithdrawalIdentity({ serial, subjectKind, subjectId, deviceName })) {
      invalidRows.push({ row, index, reason: "device_identity_required" });
      return;
    }
    const withdrawalId = cleanText(row.withdrawalId, 180) || `import:${withdrawalDate}:${managementId || serial || subjectId}:${amountYen}:${index}`;
    if (subjectKind === "custom" && withdrawalId.toLowerCase().startsWith("checklist:")) {
      invalidRows.push({ row, index, reason: "custom_reserved_withdrawal_id" });
      return;
    }
    const item = {
      row,
      index,
      withdrawalId,
      withdrawalDate,
      managementId,
      serial,
      subjectKind,
      subjectId,
      deviceName,
      cycleId,
      sequence,
      day,
      amountYen,
      siteName,
    };
    const naturalKey = withdrawalNaturalKey(item, siteName);
    const duplicated = existingIds.has(withdrawalId) ||
      existingNaturalKeys.has(naturalKey) ||
      seenIds.has(withdrawalId) ||
      seenNaturalKeys.has(naturalKey);
    if (duplicated) {
      duplicateRows.push({ ...item, reason: "duplicate" });
      return;
    }
    seenIds.add(withdrawalId);
    if (naturalKey) seenNaturalKeys.add(naturalKey);
    toImport.push(item);
  });

  return {
    siteName: bodySiteName,
    total: rows.length,
    toImport,
    duplicateRows,
    invalidRows,
  };
}

function previewBranchRows(rows) {
  return rows.slice(0, 5).map((item) => {
    const row = item.row || {};
    return {
      date: item.withdrawalDate || cleanText(row.withdrawalDate, 10),
      siteName: item.siteName || cleanText(row.siteName, 40),
      managementId: item.managementId || cleanText(row.managementId, 20),
      deviceName: cleanText(row.deviceName, 80),
      amountYen: item.amountYen || Number(row.amountYen) || "",
      reason: item.reason || "",
    };
  });
}

function withdrawalNaturalKey(row, siteName) {
  const withdrawalDate = cleanText(row && row.withdrawalDate, 10);
  const managementId = cleanText(row && row.managementId, 20);
  const serial = cleanText(row && row.serial, 80);
  const stableSubjectId = stableWithdrawalSubjectId(row);
  const amountYen = Number(row && row.amountYen);
  if (!withdrawalDate || !Number.isInteger(amountYen) || amountYen <= 0 || !stableSubjectId) return "";
  return [
    cleanText(siteName, 40),
    withdrawalDate,
    managementId || serial || stableSubjectId,
    stableSubjectId,
    amountYen,
  ].join("::");
}

function readFleetDbForWrite() {
  const dbPath = path.join(paths.dataDir, "fleet-db", "fleet-db.json");
  const db = readJsonFile(dbPath, null);
  if (!db) throw new Error("fleet-db.json not found");
  db.physicalDevices = recordMapFromLegacyValue(db.physicalDevices, ["serial", "managementId"]);
  db.cycles = recordMapFromLegacyValue(db.cycles, ["cycleId"]);
  db.offlineDevices = normalizeOfflineDevices(db.offlineDevices);
  for (const [key, device] of Object.entries(db.physicalDevices)) {
    if (!device || typeof device !== "object") continue;
    device.serial = cleanText(device.serial || key, 80);
    device.cycleIds = Array.isArray(device.cycleIds) ? device.cycleIds : [];
  }
  db.withdrawals = Array.isArray(db.withdrawals) ? db.withdrawals : [];
  db.operationGroups = normalizeOperationGroups(db.operationGroups, {
    canonicalSerials: Object.values(db.physicalDevices).map((device) => device && device.serial).filter(Boolean),
  });
  return { dbPath, db };
}

function operationGroupCanonicalSerials(db) {
  return Object.values(db && db.physicalDevices || {})
    .map((device) => cleanText(device && device.serial, 180))
    .filter(Boolean);
}

function upsertFleetOperationGroup(input = {}) {
  try {
    const { dbPath, db } = readFleetDbForWrite();
    const now = new Date().toISOString();
    const result = upsertOperationGroup(db.operationGroups, input, {
      canonicalSerials: operationGroupCanonicalSerials(db),
      now,
      generateId: () => `group-${crypto.randomUUID()}`,
    });
    db.operationGroups = result.groups;
    db.updatedAt = now;
    writeJsonFile(dbPath, db);
    appendAuditLog({
      type: "fleet_operation_group_saved",
      title: "Fleet operation group saved",
      level: "info",
      details: {
        groupId: result.group.groupId,
        name: result.group.name,
        memberCount: result.group.memberSerials.length,
      },
    });
    return { ok: true, group: result.group, operationGroups: operationGroupList(result.groups) };
  } catch (error) {
    const statusCode = error.code === "OPERATION_GROUP_NOT_FOUND"
      ? 404
      : error.code === "OPERATION_GROUP_INVALID"
        ? 400
        : 500;
    return {
      ok: false,
      code: error.code || "OPERATION_GROUP_WRITE_FAILED",
      error: statusCode === 500 ? "グループを保存できませんでした" : error.message,
      statusCode,
    };
  }
}

function deleteFleetOperationGroup(input = {}) {
  const { dbPath, db } = readFleetDbForWrite();
  const groupId = cleanText(input.groupId || input.id, 80);
  const result = deleteOperationGroup(db.operationGroups, groupId, {
    canonicalSerials: operationGroupCanonicalSerials(db),
  });
  if (!result.deleted) return { ok: false, error: "対象グループが見つかりません" };
  db.operationGroups = result.groups;
  db.updatedAt = new Date().toISOString();
  writeJsonFile(dbPath, db);
  appendAuditLog({
    type: "fleet_operation_group_deleted",
    title: "Fleet operation group deleted",
    level: "info",
    details: {
      groupId: result.deleted.groupId,
      name: result.deleted.name,
      memberCount: result.deleted.memberSerials.length,
    },
  });
  return { ok: true, deleted: result.deleted, operationGroups: operationGroupList(result.groups) };
}

function recordMapFromLegacyValue(value, identityFields = []) {
  if (value && typeof value === "object" && !Array.isArray(value)) return value;
  const result = {};
  for (const item of Array.isArray(value) ? value : []) {
    if (!item || typeof item !== "object") continue;
    const key = identityFields.map((field) => cleanText(item[field], 180)).find(Boolean);
    if (key) result[key] = item;
  }
  return result;
}

function normalizeDeviceSettings(settings) {
  const source = settings && typeof settings === "object" ? settings : {};
  const normalized = {};
  for (const setting of BASELINE_DEVICE_SETTINGS) {
    const value = source[setting.key];
    if (value === true) {
      normalized[setting.key] = { appliedAt: "", source: "legacy", action: "" };
    } else if (value && typeof value === "object") {
      normalized[setting.key] = {
        appliedAt: cleanText(value.appliedAt, 40),
        checkedAt: cleanText(value.checkedAt, 40),
        source: cleanText(value.source, 40),
        action: cleanText(value.action, 80),
        lastError: cleanText(value.lastError || value.error, 240),
        observed: value.observed === false ? false : value.observed === true ? true : undefined,
      };
    }
  }
  return normalized;
}

function deviceSettingApplied(device, key) {
  if (!device || !key) return false;
  const value = normalizeDeviceSettings(device.deviceSettings)[key];
  return Boolean(value && (value.appliedAt || value.source === "legacy"));
}

function baselineDeviceSettingsComplete(device) {
  return BASELINE_DEVICE_SETTINGS.every((setting) => deviceSettingApplied(device, setting.key));
}

function persistDeviceSettingResults(settingKey, action, results = []) {
  if (!settingKey) return { ok: true, changed: 0 };
  const attemptedBySerial = new Map();
  for (const result of results || []) {
    if (!result || result.skipped || !result.serial) continue;
    attemptedBySerial.set(String(result.serial), result);
  }
  if (!attemptedBySerial.size) return { ok: true, changed: 0 };

  const { dbPath, db } = readFleetDbForWrite();
  const now = new Date().toISOString();
  let changed = 0;
  for (const [serial, result] of attemptedBySerial) {
    const device = db.physicalDevices[serial];
    if (!device) continue;
    device.deviceSettings = device.deviceSettings && typeof device.deviceSettings === "object" ? device.deviceSettings : {};
    device.deviceSettings[settingKey] = result.ok
      ? {
        appliedAt: now,
        checkedAt: now,
        source: "adb",
        action,
        observed: true,
        lastError: "",
      }
      : {
        checkedAt: now,
        source: "adb",
        action,
        observed: false,
        lastError: cleanText(result.message || result.code || "設定後の状態を確認できませんでした。", 240),
      };
    device.updatedAt = now;
    changed += 1;
  }
  if (changed) {
    db.updatedAt = now;
    writeJsonFile(dbPath, db);
  }
  return { ok: true, changed };
}

function persistBaselineSettingsRefreshResults(results = []) {
  const readable = (results || [])
    .filter((result) => result && result.ok && result.serial && result.rawResult && result.rawResult.states);
  if (!readable.length) return { ok: true, changed: 0 };

  const { dbPath, db } = readFleetDbForWrite();
  const now = new Date().toISOString();
  let changed = 0;
  for (const result of readable) {
    const device = db.physicalDevices[String(result.serial)];
    if (!device) continue;
    device.deviceSettings = device.deviceSettings && typeof device.deviceSettings === "object" ? device.deviceSettings : {};
    for (const setting of BASELINE_DEVICE_SETTINGS) {
      const observed = result.rawResult.states[setting.key] === true;
      const previous = device.deviceSettings[setting.key] && typeof device.deviceSettings[setting.key] === "object"
        ? device.deviceSettings[setting.key]
        : {};
      device.deviceSettings[setting.key] = observed
        ? {
          appliedAt: previous.appliedAt || now,
          checkedAt: now,
          source: previous.source || "adb-read",
          action: setting.action,
          observed: true,
          lastError: "",
        }
        : {
          checkedAt: now,
          source: "adb-read",
          action: setting.action,
          observed: false,
          lastError: previous.lastError || `${setting.label}を端末で確認できませんでした。`,
        };
    }
    for (const app of BASELINE_APP_SETTINGS) {
      const observed = result.rawResult.states[app.key] === true;
      const observedApp = Array.isArray(result.rawResult.apps)
        ? result.rawResult.apps.find((item) => item && item.key === app.packageKey)
        : null;
      device[app.key] = observed;
      device[app.key === "ttlInstalled" ? "ttlCheckedAt" : "lineCheckedAt"] = now;
      device[app.key === "ttlInstalled" ? "ttlPackageName" : "linePackageName"] = cleanText(observedApp?.packageName || app.packageName, 120);
      device[app.key === "ttlInstalled" ? "ttlInstallStatus" : "lineInstallStatus"] = observed ? "installed" : "missing";
      const lastErrorKey = app.key === "ttlInstalled" ? "ttlInstallLastError" : "lineInstallLastError";
      device[lastErrorKey] = observed ? "" : (device[lastErrorKey] || `${app.label}が端末に見つかりません。`);
    }
    device.updatedAt = now;
    changed += 1;
  }
  if (changed) {
    db.updatedAt = now;
    writeJsonFile(dbPath, db);
  }
  return { ok: true, changed };
}

function deviceMasterPath() {
  return path.join(paths.dataDir, "fleet-db", "device-master.json");
}

const FLEET_SYNC_LOG_LIMIT = 5000;

function fleetSyncLogPath() {
  return path.join(paths.dataDir, "fleet-db", "sync-log.json");
}

function normalizeFleetSyncLogEntry(value) {
  const entry = value || {};
  return {
    id: cleanText(entry.id, 80) || `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
    at: cleanText(entry.at, 40) || new Date().toISOString(),
    level: ["success", "failure", "info"].includes(entry.level) ? entry.level : "info",
    category: entry.category === "sync" ? "sync" : "operation",
    message: cleanText(entry.message, 1000),
  };
}

function readFleetSyncLog() {
  const stored = readJsonFile(fleetSyncLogPath(), {});
  const entries = (Array.isArray(stored.entries) ? stored.entries : [])
    .map(normalizeFleetSyncLogEntry)
    .filter((entry) => entry.message)
    .slice(-FLEET_SYNC_LOG_LIMIT);
  return { ok: true, entries, count: entries.length, limit: FLEET_SYNC_LOG_LIMIT, updatedAt: stored.updatedAt || "" };
}

function appendFleetSyncLog(body) {
  const current = readFleetSyncLog();
  const incoming = (Array.isArray(body && body.entries) ? body.entries : [body && body.entry || body])
    .map(normalizeFleetSyncLogEntry)
    .filter((entry) => entry.message);
  const byId = new Map(current.entries.map((entry) => [entry.id, entry]));
  for (const entry of incoming) byId.set(entry.id, entry);
  const entries = [...byId.values()]
    .sort((a, b) => String(a.at).localeCompare(String(b.at)) || String(a.id).localeCompare(String(b.id)))
    .slice(-FLEET_SYNC_LOG_LIMIT);
  const updatedAt = new Date().toISOString();
  fs.mkdirSync(path.dirname(fleetSyncLogPath()), { recursive: true });
  writeJsonFile(fleetSyncLogPath(), { version: 1, updatedAt, entries });
  return { ok: true, added: incoming.length, count: entries.length, limit: FLEET_SYNC_LOG_LIMIT, updatedAt };
}

function clearFleetSyncLog() {
  const updatedAt = new Date().toISOString();
  fs.mkdirSync(path.dirname(fleetSyncLogPath()), { recursive: true });
  writeJsonFile(fleetSyncLogPath(), { version: 1, updatedAt, entries: [] });
  return { ok: true, count: 0, limit: FLEET_SYNC_LOG_LIMIT, updatedAt };
}

function readDeviceMaster() {
  const filePath = deviceMasterPath();
  let key = "missing";
  try {
    const stat = fs.statSync(filePath);
    key = `${stat.mtimeMs}:${stat.size}`;
  } catch {
    // A missing master file is represented by an empty normalized structure.
  }
  if (deviceMasterCache.key === key && deviceMasterCache.master) {
    return { filePath, master: deviceMasterCache.master };
  }
  const master = readJsonFile(filePath, null) || {};
  master.version = Number(master.version || 1);
  master.entries = Array.isArray(master.entries) ? master.entries : [];
  master.excluded = Array.isArray(master.excluded) ? master.excluded : [];
  master.source = master.source && typeof master.source === "object" ? master.source : {};
  deviceMasterCache.key = key;
  deviceMasterCache.master = master;
  return { filePath, master };
}

function writeDeviceMaster(master) {
  master.updatedAt = new Date().toISOString();
  fs.mkdirSync(path.dirname(deviceMasterPath()), { recursive: true });
  writeJsonFile(deviceMasterPath(), master);
  deviceMasterCache.key = "";
  deviceMasterCache.master = null;
  clearFleetDbSummaryCache();
}

function readDeviceMasterSummary() {
  const { master } = readDeviceMaster();
  const carrierCounts = {};
  for (const entry of master.entries) {
    const code = entry.carrierCode || "UNKNOWN";
    carrierCounts[code] = (carrierCounts[code] || 0) + 1;
  }
  return {
    ok: true,
    updatedAt: master.updatedAt || "",
    source: master.source || {},
    entries: master.entries,
    excluded: master.excluded,
    counts: {
      entries: master.entries.length,
      excluded: master.excluded.length,
      carriers: carrierCounts,
    },
  };
}

function upsertDeviceMasterEntry(body) {
  const { master } = readDeviceMaster();
  const rawEntry = body && body.entry || body;
  const entry = normalizeDeviceMasterEntry(rawEntry);
  if (!entry.modelCode && !entry.salesName) throw new Error("modelCode or salesName is required");
  const index = master.entries.findIndex((item) => item && item.id === entry.id);
  const now = new Date().toISOString();
  if (index >= 0) {
    if (!Object.prototype.hasOwnProperty.call(rawEntry || {}, "disabled") && master.entries[index].disabled === true) {
      entry.disabled = true;
    }
    entry.createdAt = master.entries[index].createdAt || now;
    entry.updatedAt = now;
    master.entries[index] = entry;
  } else {
    entry.createdAt = now;
    entry.updatedAt = now;
    master.entries.push(entry);
  }
  master.entries.sort(compareDeviceMasterEntries);
  writeDeviceMaster(master);
  const refresh = refreshDeviceCodesAfterMasterChange();
  return { ok: true, entry, counts: { entries: master.entries.length, excluded: master.excluded.length }, refresh };
}

function deleteDeviceMasterEntry(body) {
  const { master } = readDeviceMaster();
  const id = masterText(body && body.id, 120);
  const before = master.entries.length;
  master.entries = master.entries.filter((entry) => entry && entry.id !== id);
  writeDeviceMaster(master);
  const refresh = refreshDeviceCodesAfterMasterChange();
  return { ok: true, deleted: before - master.entries.length, counts: { entries: master.entries.length, excluded: master.excluded.length }, refresh };
}

function importDeviceMasterCsv(body) {
  const csv = String(body && body.csv || "").replace(/^\uFEFF/, "");
  if (!csv.trim()) throw new Error("CSV is empty");
  const rows = parseDeviceMasterCsv(csv).slice(1);
  const { master } = readDeviceMaster();
  const byId = new Map((master.entries || []).map((entry) => [entry.id, entry]));
  let imported = 0;
  let excluded = 0;

  for (const row of rows) {
    const route = masterText(row[0], 80);
    const modelCode = masterText(row[1], 40);
    const salesName = normalizeDeviceSalesName(masterText(row[2], 120));
    if (!route && !modelCode && !salesName) continue;
    if (/iphone|apple/i.test(`${modelCode} ${salesName}`)) {
      excluded += 1;
      continue;
    }
    const entry = normalizeDeviceMasterEntry({ route, modelCode, salesName, source: "CSV import" });
    byId.set(entry.id, { ...(byId.get(entry.id) || {}), ...entry, updatedAt: new Date().toISOString() });
    imported += 1;
  }

  master.entries = [...byId.values()].sort(compareDeviceMasterEntries);
  master.source = {
    ...(master.source || {}),
    lastManualImportAt: new Date().toISOString(),
    lastManualImportRows: rows.length,
    lastManualImportExcluded: excluded,
  };
  writeDeviceMaster(master);
  const refresh = refreshDeviceCodesAfterMasterChange();
  return { ok: true, imported, excluded, counts: { entries: master.entries.length, excluded: master.excluded.length }, refresh };
}

function refreshDeviceCodesAfterMasterChange() {
  const codeSync = syncFleetDeviceCodes({ force: false });
  const tagBoard = codeSync.changedDevices || codeSync.changedWithdrawals ? regenerateTagBoard() : null;
  return {
    codeSync: {
      ok: codeSync.ok,
      changedDevices: codeSync.changedDevices,
      changedWithdrawals: codeSync.changedWithdrawals,
    },
    tagBoard,
  };
}

function normalizeDeviceMasterEntry(value) {
  const input = value || {};
  const route = masterText(input.route, 80);
  const modelCode = masterText(input.modelCode || input.model || input.code, 40);
  const salesName = normalizeDeviceSalesName(masterText(input.salesName || input.name, 120));
  const carrierCode = masterCarrierCode(input.carrierCode || "", route, modelCode);
  const shortName = cleanShortName(input.shortName || suggestedDeviceMasterShortName(salesName));
  const entry = {
    id: masterText(input.id, 120) || deviceMasterStableId(route, modelCode, salesName),
    shortName,
    modelCode,
    salesName,
    maker: masterText(input.maker || masterMakerName(salesName, modelCode), 40),
    carrierCode,
    route,
    notes: masterText(input.notes, 240),
    source: masterText(input.source, 120) || "manual",
    createdAt: masterText(input.createdAt, 40),
    updatedAt: masterText(input.updatedAt, 40),
  };
  if (input.disabled === true) entry.disabled = true;
  return entry;
}

function normalizeDeviceSalesName(value) {
  return String(value || "")
    .replace(/\(\s*\)/g, "")
    .replace(/\s{2,}/g, " ")
    .trim();
}

function parseDeviceMasterCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];
    if (quoted) {
      if (char === '"' && next === '"') {
        cell += '"';
        index += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        cell += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(cell);
      cell = "";
    } else if (char === "\n") {
      row.push(cell.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }
  if (cell || row.length) {
    row.push(cell.replace(/\r$/, ""));
    rows.push(row);
  }
  return rows;
}

function suggestedDeviceMasterShortName(salesName) {
  const name = String(salesName || "").replace(/\([^)]*\)/g, "").replace(/\s+/g, " ").trim();
  const rules = [
    [/Samsung\s+Galaxy\s+A(\d+)/i, "A$1"],
    [/Samsung\s+Galaxy\s+Z\s+Fold\s*(\d*)/i, (_match, number) => `Z Fold${number ? ` ${number}` : ""}`],
    [/Samsung\s+Galaxy\s+Z\s+Flip\s*(\d*)/i, (_match, number) => `Z Flip${number ? ` ${number}` : ""}`],
    [/Samsung\s+Galaxy\s+Note\s*(\d+)/i, "NOTE$1"],
    [/Samsung\s+Galaxy\s+S(\d+)\s+Ultra/i, "S$1U"],
    [/Samsung\s+Galaxy\s+S(\d+)\s*\+/i, "S$1P"],
    [/Samsung\s+Galaxy\s+S(\d+)/i, "S$1"],
    [/Galaxy\s+A(\d+)\s*5G/i, "A$1"],
    [/Galaxy\s+A(\d+)/i, "A$1"],
    [/Galaxy\s+Z\s+Fold\s*(\d*)/i, (_match, number) => `Z Fold${number ? ` ${number}` : ""}`],
    [/Galaxy\s+Z\s+Flip\s*(\d*)/i, (_match, number) => `Z Flip${number ? ` ${number}` : ""}`],
    [/Galaxy\s+Note\s*(\d+)/i, "NOTE$1"],
    [/Galaxy\s+S(\d+)\s+Ultra/i, "S$1U"],
    [/Galaxy\s+S(\d+)\s*\+/i, "S$1P"],
    [/Galaxy\s+S(\d+)/i, "S$1"],
    [/Xperia\s+10\s+([IVX]+)/i, "X10$1"],
    [/Xperia\s+Ace\s+([IVX]+)/i, "ACE$1"],
    [/Xperia\s+(\d+)\s+([IVX]+)/i, "X$1$2"],
    [/AQUOS\s+sense(\d+)/i, "sense$1"],
    [/AQUOS\s+sense/i, "sense"],
    [/AQUOS\s+wish(\d*)/i, (_match, number) => `wish${number || ""}`],
    [/Redmi\s+Note\s+10\s+JE/i, "10JE"],
    [/Redmi\s+Note\s+(\d+)/i, "RN$1"],
    [/Redmi\s+(\d+)/i, "REDMI$1"],
    [/arrows\s+We2/i, "We2"],
    [/arrows\s+We/i, "We"],
    [/OPPO\s+Reno(\d+)/i, "RENO$1"],
    [/AQUOS\s+R(\d+)/i, "AQUOS R$1"],
    [/arrows\s+Alpha(\d+)/i, "ALPHA$1"],
    [/motorola\s+razr\s+(\d+)d/i, "RAZR$1D"],
    [/Natural\s+AI\s+Phone/i, "NAI"],
    [/nubia\s+Flip\s+(\d+)/i, "NUBIAF$1"],
    [/HUAWEI\s+P(\d+)/i, "P$1"],
    [/HUAWEI\s+Nova\s+lite\s+(\d+)/i, "NL$1"],
    [/Rakuten\s+Hand\s*(\d*)/i, (_match, number) => `Hand${number || ""}`],
    [/Rakuten\s+Big\s+s/i, "Big s"],
    [/Rakuten\s+Big/i, "Big"],
    [/Rakuten\s+Mini/i, "Mini"],
    [/Google\s+Pixel\s+(\d+)a/i, "PIXEL$1A"],
    [/Google\s+Pixel\s+(\d+)/i, "PIXEL$1"],
  ];
  for (const [pattern, replacement] of rules) {
    const normalizedName = normalizeDeviceSalesName(name);
    const replaced = normalizedName.replace(pattern, replacement);
    if (replaced !== normalizedName) return replaced;
  }
  return normalizeDeviceSalesName(name).replace(/^(Google|Samsung|Sony|Sharp|OPPO|Xiaomi|motorola|moto)\s+/i, "");
}

function masterCarrierCode(value, route, modelCode) {
  const given = masterText(value, 20).toUpperCase();
  if (given) return given;
  const routeText = String(route || "");
  const model = String(modelCode || "").toUpperCase();
  if (/DOCOMO|NTT/i.test(routeText)) return "DOCOMO";
  if (/KDDI|au|UQ|povo/i.test(routeText)) return "KDDI";
  if (/Y!mobile|Ymobile|SoftBank|LINEMO|SBM/i.test(routeText)) return "SBM";
  if (/Rakuten/i.test(routeText)) return "RAKUTEN";
  if (/Google Store|SIMFREE|MVNO|Amazon|Xiaomi Online|IIJmio|OCN/i.test(routeText)) return "SIMFREE";
  if (/^(SC|SO|SH|F|L)-/.test(model)) return "DOCOMO";
  if (/^(SCG|SOG|SHG|FCG|XIG|KYV|KYG)/.test(model)) return "KDDI";
  if (/^A\d{3}/.test(model)) return "SBM";
  return "UNKNOWN";
}
function masterMakerName(salesName, modelCode) {
  const text = `${salesName || ""} ${modelCode || ""}`.toLowerCase();
  if (text.includes("xperia")) return "Sony";
  if (text.includes("aquos")) return "Sharp";
  if (text.includes("galaxy") || /^sm-|^sc/.test(text)) return "Samsung";
  if (text.includes("pixel")) return "Google";
  if (text.includes("oppo")) return "OPPO";
  if (text.includes("redmi") || text.includes("xiaomi") || text.includes("poco") || text.includes("mi 10")) return "Xiaomi";
  if (text.includes("arrows") || /^f-/.test(text)) return "FCNT";
  if (text.includes("motorola") || text.includes("moto") || text.includes("razr")) return "Motorola";
  if (text.includes("rakuten")) return "Rakuten";
  if (text.includes("huawei")) return "Huawei";
  if (text.includes("lg ") || /^l-/.test(text)) return "LG";
  if (text.includes("libero") || text.includes("zte")) return "ZTE";
  if (text.includes("balmuda")) return "BALMUDA";
  return "";
}

function deviceMasterStableId(route, modelCode, salesName) {
  return `${route}|${modelCode}|${salesName}`
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80) || `manual-${Date.now()}`;
}

function compareDeviceMasterEntries(a, b) {
  return String(a.shortName || "").localeCompare(String(b.shortName || ""), "en") ||
    String(a.carrierCode || "").localeCompare(String(b.carrierCode || ""), "en") ||
    String(a.salesName || "").localeCompare(String(b.salesName || ""), "ja") ||
    String(a.modelCode || "").localeCompare(String(b.modelCode || ""), "en");
}

function masterText(value, maxLength) {
  return String(value === undefined || value === null ? "" : value).trim().slice(0, maxLength);
}

function normalizeFleetDbSettings(settings) {
  return {
    siteName: cleanText(settings && settings.siteName, 40) || "Android Fleet",
    customDeviceOrder: [...new Set((Array.isArray(settings && settings.customDeviceOrder) ? settings.customDeviceOrder : []).map((value) => cleanText(value, 80)).filter(Boolean))],
    updatedAt: settings && settings.updatedAt || "",
  };
}

function cleanText(value, maxLength) {
  return String(value || "").trim().slice(0, maxLength);
}

function findFleetDbDevice(db, value) {
  const target = cleanText(value, 80);
  if (!target) return null;
  const wanted = fleetIdentityKey(target);
  for (const [key, device] of Object.entries(db.physicalDevices || {})) {
    if (!device || typeof device !== "object") continue;
    const candidates = [
      key,
      device.serial,
      device.managementId,
      String(device.number || ""),
      String(device.number || "").padStart(2, "0"),
    ];
    if (!candidates.some((candidate) => fleetIdentityKey(candidate) === wanted)) continue;
    if (!cleanText(device.serial, 80)) device.serial = cleanText(key || target, 80);
    return device;
  }
  return null;
}

function fleetIdentityKey(value) {
  return cleanText(value, 180).toLocaleLowerCase("en-US");
}

function findWithdrawal(db, withdrawalId) {
  const target = cleanText(withdrawalId, 180);
  if (!target) return null;
  return db.withdrawals.find((row) => row && row.withdrawalId === target) || null;
}

function withdrawalIsCycleLinked(db, withdrawal) {
  if (!withdrawal) return false;
  const withdrawalId = cleanText(withdrawal.withdrawalId, 180);
  if (String(withdrawal.source || "") === "checklist_inactive_reset" || withdrawalId.startsWith("checklist:")) return true;
  if (withdrawal.resetDone === true || cleanText(withdrawal.resetDoneAt, 40)) return true;
  return Object.values(db.cycles || {}).some((cycle) => (
    cleanText(cycle && cycle.outcome && cycle.outcome.withdrawalId, 180) === withdrawalId
  ));
}

function latestCycleForDevice(db, device) {
  const cycles = (device.cycleIds || []).map((id) => db.cycles[id]).filter(Boolean);
  return cycles.find((cycle) => cycle.status === "active") ||
    cycles.sort((a, b) => String(b.startedAt || "").localeCompare(String(a.startedAt || "")))[0] ||
    null;
}

function ensureInactiveCurrentCycle(db, device, options = {}) {
  if (!db || !device || !device.serial) return { cycle: null, created: false };
  db.cycles = db.cycles && typeof db.cycles === "object" && !Array.isArray(db.cycles) ? db.cycles : {};
  device.cycleIds = Array.isArray(device.cycleIds) ? device.cycleIds : [];
  const existing = device.cycleIds
    .map((id) => db.cycles[id])
    .find((cycle) => cycle && cycle.status === "active");
  if (existing) return { cycle: existing, created: false };

  const at = options.at || new Date().toISOString();
  let sequence = nextCycleSequence(db, device);
  let cycleId = `${device.serial}-${String(sequence).padStart(3, "0")}`;
  while (db.cycles[cycleId]) {
    sequence += 1;
    cycleId = `${device.serial}-${String(sequence).padStart(3, "0")}`;
  }
  const cycle = {
    cycleId,
    physicalSerial: device.serial,
    managementId: device.managementId || "",
    sequence,
    status: "active",
    startedAt: at,
    endedAt: "",
    startReason: options.startReason || "missing_current_cycle_repair",
    resetConfirmedAt: "",
    waitHours: null,
    tags: ["GROUP_INACTIVE"],
    economics: {},
    snapshots: [],
    outcome: {
      reached3000: null,
      reachedAt: "",
      finalYen: "",
      resetReason: "",
      withdrawalId: "",
      memo: options.memo || "",
    },
    updatedAt: at,
  };
  db.cycles[cycleId] = cycle;
  device.cycleIds.push(cycleId);
  device.updatedAt = at;
  return { cycle, created: true };
}

function closeActiveCycleAndStartWaiting(db, device, options) {
  const at = new Date().toISOString();
  const rawAmountYen = options && options.amountYen;
  const parsedAmountYen = Number(rawAmountYen);
  const amountYen = rawAmountYen === null || rawAmountYen === undefined || rawAmountYen === ""
    ? null
    : Number.isFinite(parsedAmountYen) && parsedAmountYen >= 0 ? parsedAmountYen : null;
  device.cycleIds = Array.isArray(device.cycleIds) ? device.cycleIds : [];
  const activeCycles = device.cycleIds.map((id) => db.cycles[id]).filter((cycle) => cycle && cycle.status === "active");
  const waiting = activeCycles.find((cycle) => hasResetWaitingTags(cycle));
  if (waiting) {
    waiting.resetConfirmedAt = waiting.resetConfirmedAt || at;
    waiting.tags = ["GROUP_INACTIVE"];
    waiting.outcome = {
      ...(waiting.outcome || {}),
      resetReason: options.resetReason,
      withdrawalId: options.withdrawalId || waiting.outcome && waiting.outcome.withdrawalId || "",
      finalYen: amountYen === null ? waiting.outcome && waiting.outcome.finalYen || "" : amountYen,
    };
    return { at, resetReason: options.resetReason, closedCycleId: "", waitingCycleId: waiting.cycleId, alreadyWaiting: true };
  }

  const active = activeCycles[0] || null;
  if (active) {
    finalizeCycleErrorOperation(active, {
      at,
      fallbackTags: Array.isArray(active.tags) ? active.tags : [],
      countNoError: true,
      source: "withdrawal_close",
    });
    active.status = "completed";
    active.endedAt = at;
    active.operationEndedAt = active.operationEndedAt || at;
    active.tags = uniqueStrings([
      ...(active.tags || []).filter((tag) => tag !== "WAITING" && tag !== "RESET_DONE"),
      amountYen >= 5000 ? "WITHDRAW_5000" : amountYen > 0 ? "WITHDRAW_3000" : "RESET_REQUIRED",
      "CYCLE_CLOSED",
    ]);
    active.outcome = {
      ...(active.outcome || {}),
      reached3000: amountYen >= 3000 ? true : active.outcome && active.outcome.reached3000 || null,
      reachedAt: amountYen > 0 ? at : active.outcome && active.outcome.reachedAt || "",
      finalYen: amountYen === null ? active.outcome && active.outcome.finalYen || "" : amountYen,
      resetReason: options.resetReason,
      withdrawalId: options.withdrawalId || "",
      memo: options.memo || "",
    };
  }

  const sequence = nextCycleSequence(db, device);
  const cycleId = `${device.serial}-${String(sequence).padStart(3, "0")}`;
  const waitingCycle = {
    cycleId,
    physicalSerial: device.serial,
    managementId: device.managementId,
    sequence,
    status: "active",
    startedAt: at,
    startReason: options.resetReason,
    resetConfirmedAt: at,
    waitHours: null,
    tags: ["GROUP_INACTIVE"],
    economics: {},
    snapshots: [],
    outcome: {
      reached3000: null,
      reachedAt: "",
      finalYen: amountYen === null ? "" : amountYen,
      resetReason: options.resetReason,
      withdrawalId: options.withdrawalId || "",
      memo: options.memo || "",
    },
  };
  db.cycles[cycleId] = waitingCycle;
  device.cycleIds.push(cycleId);
  return { at, resetReason: options.resetReason, closedCycleId: active && active.cycleId || "", waitingCycleId: cycleId, alreadyWaiting: false };
}

function hasResetWaitingTags(cycle) {
  const tags = Array.isArray(cycle && cycle.tags) ? cycle.tags : [];
  return tags.includes("WAITING") || tags.includes("RESET_DONE") || tags.includes("GROUP_INACTIVE") || tags.includes("GROUP_REST");
}

function nextCycleSequence(db, device) {
  const maxExisting = (device.cycleIds || []).reduce((max, id) => {
    const cycle = db.cycles[id];
    const suffix = /-(\d+)$/.exec(String(id || ""));
    return Math.max(max, Number(cycle && cycle.sequence || 0), suffix ? Number(suffix[1]) : 0);
  }, 0);
  return maxExisting + 1;
}

function uniqueStrings(values) {
  return [...new Set(values.filter(Boolean).map(String))];
}

function clearFleetDbSummaryCache() {
  fleetDbSummaryCache.key = "";
  fleetDbSummaryCache.summary = null;
}

function backupFleetDb() {
  const source = path.join(paths.dataDir, "fleet-db", "fleet-db.json");
  if (!fs.existsSync(source)) return { ok: false, error: "fleet-db.json not found" };
  const backupDir = path.join(paths.root, "backups", "fleet-db");
  fs.mkdirSync(backupDir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const target = path.join(backupDir, `fleet-db-${stamp}.json`);
  fs.copyFileSync(source, target);
  return { ok: true, file: target };
}

function buildFleetDbRecoveryStatus() {
  const dbPath = path.join(paths.dataDir, "fleet-db", "fleet-db.json");
  const current = inspectFleetDbSnapshot(dbPath);
  const tagBoardRows = countTagBoardRows();
  const candidates = collectFleetDbRecoveryCandidates()
    .filter((candidate) => candidate.valid && snapshotProtectedRecords(candidate) > 0)
    .sort((left, right) => right.backupAtMs - left.backupAtMs || snapshotProtectedRecords(right) - snapshotProtectedRecords(left));
  const recoveryNeeded = !current.valid || snapshotProtectedRecords(current) === 0;
  const recommended = recoveryNeeded
    ? candidates.find((candidate) => snapshotProtectedRecords(candidate) > snapshotProtectedRecords(current))
    : null;
  return {
    ok: true,
    recoveryNeeded,
    current: publicFleetDbSnapshot(current),
    tagBoardRows,
    recommendedCandidateId: recommended ? recommended.candidateId : "",
    candidates: candidates.map(publicFleetDbSnapshot),
  };
}

function recoverFleetDbFromBackup(body = {}) {
  const status = buildFleetDbRecoveryStatus();
  const expectedCurrentDevices = Number(body.expectedCurrentDevices);
  if (Number.isInteger(expectedCurrentDevices) && expectedCurrentDevices !== Number(status.current.devices)) {
    throw new Error("端末DBの状態が確認時から変わりました。画面を更新してもう一度確認してください。");
  }
  if (status.current.valid && snapshotProtectedRecords(status.current) > 0) {
    throw new Error(`現在の端末DBには接続端末${status.current.devices}台・未接続端末${status.current.offlineDevices}台・出金履歴${status.current.withdrawals}件あります。自動復旧は実行しません。`);
  }

  const candidateId = cleanText(body.candidateId || status.recommendedCandidateId, 128);
  const candidate = collectFleetDbRecoveryCandidates()
    .find((item) => item.candidateId === candidateId && item.valid && snapshotProtectedRecords(item) > 0);
  if (!candidate) throw new Error("利用できる端末DBバックアップが見つかりません。");

  const dbPath = path.join(paths.dataDir, "fleet-db", "fleet-db.json");
  const safetyDir = path.join(paths.root, "backups", "fleet-db-recovery");
  fs.mkdirSync(safetyDir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  let safetyBackup = "";
  if (fs.existsSync(dbPath)) {
    safetyBackup = path.join(safetyDir, `fleet-db-before-recovery-${stamp}.json`);
    fs.copyFileSync(dbPath, safetyBackup);
  }

  writeJsonFile(dbPath, candidate.data);
  const restored = inspectFleetDbSnapshot(dbPath);
  if (!restored.valid
    || restored.devices !== candidate.devices
    || restored.offlineDevices !== candidate.offlineDevices
    || restored.withdrawals !== candidate.withdrawals) {
    if (safetyBackup && fs.existsSync(safetyBackup)) fs.copyFileSync(safetyBackup, dbPath);
    clearFleetDbSummaryCache();
    throw new Error("バックアップ復旧後の台数確認に失敗したため、復旧前のDBへ戻しました。");
  }

  let tagBoard = null;
  let tagBoardWarning = "";
  try {
    tagBoard = regenerateTagBoard();
  } catch (error) {
    tagBoardWarning = error.message;
  }
  appendAuditLog({
    type: "fleet_db_recovered_from_backup",
    title: "Fleet DB recovered from a local backup",
    details: {
      restoredDevices: restored.devices,
      restoredOfflineDevices: restored.offlineDevices,
      restoredCycles: restored.cycles,
      restoredWithdrawals: restored.withdrawals,
      source: candidate.source,
      sourceLabel: candidate.sourceLabel,
      safetyBackup,
      tagBoardWarning,
    },
  });
  return {
    ok: true,
    restored: publicFleetDbSnapshot(restored),
    source: publicFleetDbSnapshot(candidate),
    safetyBackup,
    tagBoard,
    tagBoardWarning,
  };
}

function collectFleetDbRecoveryCandidates() {
  const packageRoot = path.resolve(paths.root, "..", "..");
  const updateBackupRoot = path.join(packageRoot, "update-backups");
  const appBackupRoot = path.join(paths.root, "backups", "fleet-db");
  const candidates = [];
  const seen = new Set();

  if (fs.existsSync(updateBackupRoot)) {
    for (const entry of fs.readdirSync(updateBackupRoot, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      const filePath = path.join(updateBackupRoot, entry.name, "data", "fleet-db", "fleet-db.json");
      addFleetDbRecoveryCandidate(candidates, seen, {
        filePath,
        allowedRoot: updateBackupRoot,
        source: "update-backup",
        sourceLabel: entry.name,
        backupRoot: path.join(updateBackupRoot, entry.name),
      });
    }
  }

  if (fs.existsSync(appBackupRoot)) {
    for (const entry of fs.readdirSync(appBackupRoot, { withFileTypes: true })) {
      if (!entry.isFile() || !entry.name.toLowerCase().endsWith(".json")) continue;
      addFleetDbRecoveryCandidate(candidates, seen, {
        filePath: path.join(appBackupRoot, entry.name),
        allowedRoot: appBackupRoot,
        source: "app-backup",
        sourceLabel: entry.name,
        backupRoot: appBackupRoot,
      });
    }
  }
  return candidates;
}

function addFleetDbRecoveryCandidate(target, seen, options) {
  const filePath = path.resolve(options.filePath);
  const allowedRoot = path.resolve(options.allowedRoot);
  if (!isPathInsideRoot(filePath, allowedRoot) || seen.has(filePath) || !fs.existsSync(filePath)) return;
  seen.add(filePath);
  const snapshot = inspectFleetDbSnapshot(filePath);
  let backupAtMs = snapshot.modifiedAtMs;
  try {
    backupAtMs = fs.statSync(options.backupRoot).mtimeMs || backupAtMs;
  } catch {
    // Use the file timestamp when the backup folder timestamp is unavailable.
  }
  target.push({
    ...snapshot,
    candidateId: crypto.createHash("sha256").update(filePath.toLowerCase()).digest("hex"),
    source: options.source,
    sourceLabel: options.sourceLabel,
    backupAtMs,
    backupAt: new Date(backupAtMs || Date.now()).toISOString(),
  });
}

function inspectFleetDbSnapshot(filePath) {
  let stat = null;
  try {
    stat = fs.statSync(filePath);
    const data = JSON.parse(fs.readFileSync(filePath, "utf8").replace(/^\uFEFF/, ""));
    if (!data || typeof data !== "object" || Array.isArray(data)) throw new Error("DB root is not an object");
    return {
      valid: true,
      devices: countRecordValues(data.physicalDevices),
      offlineDevices: countRecordValues(data.offlineDevices),
      cycles: countRecordValues(data.cycles),
      withdrawals: Array.isArray(data.withdrawals) ? data.withdrawals.length : 0,
      updatedAt: cleanText(data.updatedAt, 40),
      modifiedAt: stat.mtime.toISOString(),
      modifiedAtMs: stat.mtimeMs,
      sizeBytes: stat.size,
      data,
      filePath,
    };
  } catch (error) {
    return {
      valid: false,
      devices: 0,
      offlineDevices: 0,
      cycles: 0,
      withdrawals: 0,
      updatedAt: "",
      modifiedAt: stat ? stat.mtime.toISOString() : "",
      modifiedAtMs: stat ? stat.mtimeMs : 0,
      sizeBytes: stat ? stat.size : 0,
      error: error.message,
      data: null,
      filePath,
    };
  }
}

function publicFleetDbSnapshot(snapshot) {
  return {
    candidateId: snapshot.candidateId || "",
    valid: Boolean(snapshot.valid),
    devices: Number(snapshot.devices || 0),
    offlineDevices: Number(snapshot.offlineDevices || 0),
    managedRecords: snapshotManagedRecords(snapshot),
    cycles: Number(snapshot.cycles || 0),
    withdrawals: Number(snapshot.withdrawals || 0),
    updatedAt: snapshot.updatedAt || "",
    modifiedAt: snapshot.modifiedAt || "",
    backupAt: snapshot.backupAt || snapshot.modifiedAt || "",
    sizeBytes: Number(snapshot.sizeBytes || 0),
    source: snapshot.source || "current",
    sourceLabel: snapshot.sourceLabel || "",
    error: snapshot.error || "",
  };
}

function snapshotManagedRecords(snapshot) {
  return Number(snapshot && snapshot.devices || 0) + Number(snapshot && snapshot.offlineDevices || 0);
}

function snapshotProtectedRecords(snapshot) {
  return snapshotManagedRecords(snapshot) + Number(snapshot && snapshot.withdrawals || 0);
}

function countRecordValues(value) {
  if (Array.isArray(value)) return value.filter((item) => item && typeof item === "object").length;
  if (!value || typeof value !== "object") return 0;
  return Object.values(value).filter((item) => item && typeof item === "object").length;
}

function countTagBoardRows() {
  const boardPath = path.join(paths.dataDir, "fleet-db", "device-tag-board.json");
  const board = readJsonFile(boardPath, []);
  if (Array.isArray(board)) return board.length;
  return Array.isArray(board && board.rows) ? board.rows.length : 0;
}

function isPathInsideRoot(candidate, root) {
  const normalizedRoot = path.resolve(root).toLowerCase().replace(/[\\/]+$/, "") + path.sep;
  const normalizedCandidate = path.resolve(candidate).toLowerCase();
  return normalizedCandidate.startsWith(normalizedRoot);
}

function exportMigrationData() {
  try {
    removePathInsideRoot(MIGRATION_DIR);
    fs.mkdirSync(MIGRATION_DIR, { recursive: true });
    const dataTarget = path.join(MIGRATION_DIR, "data");
    const configTarget = path.join(MIGRATION_DIR, "config");
    copyDirectoryFiltered(paths.dataDir, dataTarget, shouldCopyMigrationDataPath);
    fs.mkdirSync(configTarget, { recursive: true });
    const copiedConfig = [];
    for (const fileName of MIGRATION_CONFIG_FILES) {
      const source = path.join(paths.root, "config", fileName);
      if (!fs.existsSync(source)) continue;
      fs.copyFileSync(source, path.join(configTarget, fileName));
      copiedConfig.push(fileName);
    }
    const readme = [
      "Android Fleet 移行データ",
      "",
      "旧PCでは、この AndroidFleet-移行データ フォルダを丸ごとコピーしてください。",
      "新PCでは、同じアプリフォルダ内にこのフォルダを置いてから、管理ツールの「移行データ取込」を押してください。",
      "",
      "含まれるもの: ローカルDB、端末履歴、保管リスト、APK、ログ、スクショなどの運用データ。",
      "含まれないもの: PC固定ライセンス、起動済みPCの認証情報。",
      "そのため、新PCでは新PC用のライセンスで起動できます。",
      "",
      `作成日時: ${new Date().toISOString()}`,
    ].join("\r\n");
    fs.writeFileSync(path.join(MIGRATION_DIR, "README-移行.txt"), readme, "utf8");
    return {
      ok: true,
      path: MIGRATION_DIR,
      dataCopied: fs.existsSync(dataTarget),
      configCopied: copiedConfig,
      excluded: ["config/customer-license.json", "config/license-activation.json", "config/package-manifest.json", "data/tmp", "data/server.out.log", "data/server.err.log"],
    };
  } catch (error) {
    return { ok: false, error: error.message, path: MIGRATION_DIR };
  }
}

function importMigrationData() {
  const sourceData = path.join(MIGRATION_DIR, "data");
  const sourceConfig = path.join(MIGRATION_DIR, "config");
  if (!fs.existsSync(sourceData)) {
    return {
      ok: false,
      error: "移行データが見つかりません。AndroidFleet-移行データ フォルダをアプリ内に置いてください。",
      path: MIGRATION_DIR,
    };
  }
  try {
    const currentMaster = readJsonFile(path.join(paths.dataDir, "fleet-db", "device-master.json"), {});
    const currentDeviceNameMap = readJsonFile(DEVICE_NAME_MAP_PATH, {});
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const backupDir = path.join(paths.root, "backups", `migration-before-import-${stamp}`);
    fs.mkdirSync(backupDir, { recursive: true });
    if (fs.existsSync(paths.dataDir)) {
      copyDirectoryFiltered(paths.dataDir, path.join(backupDir, "data"), () => true);
    }
    const configDir = path.join(paths.root, "config");
    const configBackupDir = path.join(backupDir, "config");
    fs.mkdirSync(configBackupDir, { recursive: true });
    for (const fileName of MIGRATION_CONFIG_FILES) {
      const source = path.join(configDir, fileName);
      if (fs.existsSync(source)) fs.copyFileSync(source, path.join(configBackupDir, fileName));
    }

    removePathInsideRoot(paths.dataDir);
    copyDirectoryFiltered(sourceData, paths.dataDir, () => true);
    const importedConfig = [];
    if (fs.existsSync(sourceConfig)) {
      fs.mkdirSync(configDir, { recursive: true });
      for (const fileName of MIGRATION_CONFIG_FILES) {
        const source = path.join(sourceConfig, fileName);
        if (!fs.existsSync(source)) continue;
        fs.copyFileSync(source, path.join(configDir, fileName));
        importedConfig.push(fileName);
      }
    }
    const importedMaster = readJsonFile(path.join(paths.dataDir, "fleet-db", "device-master.json"), {});
    const masterMerge = mergeDeviceMasters(currentMaster, importedMaster);
    writeJsonFile(path.join(paths.dataDir, "fleet-db", "device-master.json"), masterMerge.master);

    const importedDeviceNameMap = readJsonFile(DEVICE_NAME_MAP_PATH, {});
    const nameMapMerge = mergeDeviceNameMaps(currentDeviceNameMap, importedDeviceNameMap);
    writeJsonFile(DEVICE_NAME_MAP_PATH, nameMapMerge.map);
    clearModelNameCache();

    ensureConfigPaths(paths);
    store.ensure();
    clearFleetDbSummaryCache();
    const masterRefresh = refreshDeviceCodesAfterMasterChange();
    return {
      ok: true,
      importedFrom: MIGRATION_DIR,
      backupPath: backupDir,
      configImported: importedConfig,
      licenseCopied: false,
      masterMerge: masterMerge.stats,
      nameMapMerge: nameMapMerge.stats,
      masterRefresh,
    };
  } catch (error) {
    return { ok: false, error: error.message, path: MIGRATION_DIR };
  }
}

function openMigrationFolder() {
  fs.mkdirSync(MIGRATION_DIR, { recursive: true });
  const child = spawn("explorer.exe", [MIGRATION_DIR], {
    detached: true,
    stdio: "ignore",
    windowsHide: false,
  });
  child.unref();
  return { ok: true, path: MIGRATION_DIR, pid: child.pid };
}

function shouldCopyMigrationDataPath(sourcePath) {
  const relative = path.relative(paths.dataDir, sourcePath).replace(/\\/g, "/");
  if (!relative || relative === ".") return true;
  const parts = relative.split("/");
  if (parts.includes("tmp")) return false;
  if (parts[0] === "backups") return false;
  const base = path.basename(sourcePath).toLowerCase();
  if (base === "server.out.log" || base === "server.err.log") return false;
  return true;
}

function copyDirectoryFiltered(source, target, filter) {
  if (!fs.existsSync(source)) return;
  const stat = fs.statSync(source);
  if (stat.isDirectory()) {
    if (filter && !filter(source, stat)) return;
    fs.mkdirSync(target, { recursive: true });
    for (const entry of fs.readdirSync(source)) {
      copyDirectoryFiltered(path.join(source, entry), path.join(target, entry), filter);
    }
    return;
  }
  if (stat.isFile()) {
    if (filter && !filter(source, stat)) return;
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(source, target);
  }
}

function removePathInsideRoot(targetPath) {
  const resolvedTarget = path.resolve(targetPath);
  const resolvedRoot = path.resolve(paths.root);
  if (resolvedTarget !== resolvedRoot && !resolvedTarget.startsWith(resolvedRoot + path.sep)) {
    throw new Error(`Refusing to remove outside app root: ${resolvedTarget}`);
  }
  if (fs.existsSync(resolvedTarget)) {
    fs.rmSync(resolvedTarget, { recursive: true, force: true });
  }
}

function compareWithdrawalRows(a, b) {
  return String(a.withdrawalDate || "").localeCompare(String(b.withdrawalDate || ""))
    || String(a.managementId || "").localeCompare(String(b.managementId || ""), "en")
    || String(a.withdrawalId || "").localeCompare(String(b.withdrawalId || ""));
}

function monthlyRevenueRows(withdrawals) {
  const byMonth = new Map();
  for (const row of withdrawals) {
    const month = String(row.withdrawalDate || row.recordedAt || "").slice(0, 7) || "unknown";
    const item = byMonth.get(month) || { month, count: 0, totalYen: 0, over5000: 0, yen3000: 0 };
    const amount = Number(row.amountYen || 0);
    item.count += 1;
    item.totalYen += amount;
    if (amount >= 5000) item.over5000 += 1;
    if (amount >= 3000 && amount < 5000) item.yen3000 += 1;
    byMonth.set(month, item);
  }
  return [...byMonth.values()].sort((a, b) => a.month.localeCompare(b.month));
}

function monthlyRevenueBySiteRows(withdrawals, defaultSiteName) {
  const byMonthSite = new Map();
  for (const row of withdrawals) {
    const month = String(row.withdrawalDate || row.recordedAt || "").slice(0, 7) || "unknown";
    const siteName = withdrawalSiteName(row, defaultSiteName);
    const key = `${month}::${siteName}`;
    const item = byMonthSite.get(key) || { month, siteName, count: 0, totalYen: 0, over5000: 0, yen3000: 0 };
    const amount = Number(row.amountYen || 0);
    item.count += 1;
    item.totalYen += amount;
    if (amount >= 5000) item.over5000 += 1;
    if (amount >= 3000 && amount < 5000) item.yen3000 += 1;
    byMonthSite.set(key, item);
  }
  return [...byMonthSite.values()].sort((a, b) =>
    a.month.localeCompare(b.month) || a.siteName.localeCompare(b.siteName, "ja")
  );
}

function siteRevenueRows(withdrawals, defaultSiteName) {
  const bySite = new Map();
  for (const row of withdrawals) {
    const siteName = withdrawalSiteName(row, defaultSiteName);
    const item = bySite.get(siteName) || { siteName, count: 0, totalYen: 0, monthYen: 0, over5000: 0, yen3000: 0 };
    const amount = Number(row.amountYen || 0);
    item.count += 1;
    item.totalYen += amount;
    if (String(row.withdrawalDate || "").slice(0, 7) === localMonth(new Date())) item.monthYen += amount;
    if (amount >= 5000) item.over5000 += 1;
    if (amount >= 3000 && amount < 5000) item.yen3000 += 1;
    bySite.set(siteName, item);
  }
  return [...bySite.values()].sort((a, b) => b.totalYen - a.totalYen || a.siteName.localeCompare(b.siteName, "ja"));
}

function deviceRevenueRows(withdrawals, db, defaultSiteName, deviceNumberBySerial = new Map()) {
  const byId = new Map();
  for (const row of withdrawals) {
    const siteName = withdrawalSiteName(row, defaultSiteName);
    const device = row.serial ? db.physicalDevices && db.physicalDevices[row.serial] : null;
    const offlineDevice = row.serial ? db.offlineDevices && db.offlineDevices[row.serial] : null;
    const id = device && device.managementId || offlineDevice && offlineDevice.number || row.managementId || "";
    const deviceNumber = row.serial && deviceNumberBySerial.get(row.serial)
      || device && (device.laixiNumberOverride || device.xiaoweiSort || device.number)
      || offlineDevice && offlineDevice.number
      || managementNumberFromId(id)
      || "";
    const deviceCode = device && fixedDeviceLabel(device)
      || offlineDevice && (offlineDevice.name || offlineDevice.model || offlineDevice.offlineId)
      || row.deviceName
      || deviceNameBySerial(db, row.serial)
      || "";
    const subjectId = stableWithdrawalSubjectId(row) || id;
    const key = `${siteName}::${subjectId}`;
    const item = byId.get(key) || {
      siteName,
      managementId: id,
      deviceNumber,
      deviceCode,
      deviceName: deviceCode,
      serial: row.serial || "",
      subjectKind: row.subjectKind || "",
      subjectId: row.subjectId || "",
      count: 0,
      totalYen: 0,
      monthYen: 0,
      averageYen: 0,
      lastWithdrawalDate: "",
    };
    const amount = Number(row.amountYen || 0);
    item.count += 1;
    item.totalYen += amount;
    if (String(row.withdrawalDate || "").slice(0, 7) === localMonth(new Date())) item.monthYen += amount;
    if (String(row.withdrawalDate || "") > String(item.lastWithdrawalDate || "")) item.lastWithdrawalDate = row.withdrawalDate || "";
    if (device && device.managementId) item.managementId = device.managementId;
    if (offlineDevice && offlineDevice.number) item.managementId = offlineDevice.number;
    if (deviceNumber) item.deviceNumber = deviceNumber;
    if (!item.deviceName) item.deviceName = deviceCode;
    byId.set(key, item);
  }
  return [...byId.values()]
    .map((item) => ({ ...item, averageYen: item.count ? Math.round(item.totalYen / item.count) : 0 }))
    .sort((a, b) => a.siteName.localeCompare(b.siteName, "ja") || Number(a.deviceNumber || 9999) - Number(b.deviceNumber || 9999) || managementNumberFromId(a.managementId) - managementNumberFromId(b.managementId));
}

function withdrawalSiteName(row, defaultSiteName) {
  return cleanText(row && row.siteName, 40) || defaultSiteName || "default";
}

function rewardLabel(tag, type) {
  const text = String(tag || "").trim();
  if (!text) return "";
  if (type === "ci") {
    const yen = checkinYenFromTag(text) || numberFromText(text);
    return yen ? `チェックイン ${yen}円` : text;
  }
  if (type === "v180") {
    const points = video180PointsFromTag(text) || VIDEO_180_TAG_POINTS_PER_DAY[text] || numberFromText(text);
    return points ? `動画180分 ${points}P` : text;
  }
  if (type === "v10") {
    const yen = video10YenFromTag(text) || VIDEO_10_TAG_YEN[text] || numberFromText(text);
    return yen ? `追加視聴 ${yen}円` : text;
  }
  return text;
}

function numberFromText(value) {
  const match = /(\d{3,6})/.exec(String(value || "").replace(/,/g, ""));
  return match ? Number(match[1]) : 0;
}

function taskHistoryForDevice(db, device) {
  const cycles = (Array.isArray(device && device.cycleIds) ? device.cycleIds : [])
    .map((id) => db.cycles && db.cycles[id])
    .filter(Boolean)
    .filter(hasMeaningfulTaskHistory)
    .sort((a, b) => String(b.startedAt || "").localeCompare(String(a.startedAt || "")));
  const items = cycles.map((cycle) => {
    const tags = canonicalizeTags(Array.isArray(cycle.tags) ? cycle.tags : []);
    const economics = cycle.economics || {};
    const resetHistory = Array.isArray(cycle.resetHistory) ? cycle.resetHistory : [];
    const latestReset = resetHistory[resetHistory.length - 1] || null;
    const resetCompleted = Boolean(latestReset && tags.some((tag) => ["GROUP_INACTIVE", "GROUP_REST", "WAITING"].includes(tag)));
    const day = extractDay(tags) || economics.elapsedDay || economics.day || "";
    const ciTag = findCheckinAmountTag(tags) || economics.ciTag || "";
    const v180Tag = findVideo180AmountTag(tags) || economics.video180Tag || "";
    const v10Tag = findVideo10AmountTag(tags) || economics.video10Tag || "";
    const status = resetCompleted ? "completed" : cycle.status || "";
    const outcome = cycle.outcome || {};
    const finalYen = Number(outcome.finalYen || cycle.currentYen || economics.projectedGrossYen || 0);
    const ci = ciTag ? rewardLabel(ciTag, "ci") : tags.includes("CI_ERR") ? "チェックイン ERROR" : "";
    const video180 = v180Tag ? rewardLabel(v180Tag, "v180") : tags.includes("V180_DONE") ? "動画180分 完了" : "";
    const video10 = v10Tag ? rewardLabel(v10Tag, "v10") : tags.includes("V10_DONE") ? "追加視聴 完了" : "";
    const errorOutcomes = collectCycleErrorOutcomes(cycle);
    const latestResetUptimeSeconds = historyUptimeSeconds(latestReset && latestReset.uptimeSeconds);
    const parts = latestReset ? [
      cycle.sequence ? `#${cycle.sequence}` : "",
      "リセット",
      latestReset.reason || "",
      historyAmountYenText(latestReset.amountYen),
      latestResetUptimeSeconds === null ? "" : `UPTIME ${(latestResetUptimeSeconds / 3600).toFixed(1)}h${latestReset.uptimeSource === "manual" ? " 手入力" : ""}`,
      latestReset.summary || "",
    ] : [
      cycle.sequence ? `#${cycle.sequence}` : "",
      status === "active" ? "実行中" : status === "completed" ? "完了" : status,
      day ? `DAY${day}` : "",
      ci,
      video180,
      video10,
      finalYen ? `${finalYen.toLocaleString("ja-JP")}円` : "",
    ].filter(Boolean);
    return {
      cycleId: cycle.cycleId || "",
      sequence: cycle.sequence || "",
      status,
      startedAt: cycle.startedAt || "",
      endedAt: resetCompleted ? latestReset.at || cycle.endedAt || "" : cycle.endedAt || "",
      operationStartedAt: cycle.operationStartedAt || cycle.startedAt || "",
      operationEndedAt: status === "active"
        ? ""
        : resetCompleted ? latestReset.at || cycle.operationEndedAt || cycle.endedAt || cycle.resetConfirmedAt || "" : cycle.operationEndedAt || cycle.endedAt || cycle.resetConfirmedAt || "",
      day,
      ci,
      video180,
      video10,
      finalYen,
      tags,
      resetHistory,
      errorOutcomes,
      text: parts.join(" ・ "),
    };
  });
  const errorOutcomes = collectDeviceErrorOutcomes(db, device);
  return {
    count: cycles.length,
    completedCount: cycles.filter((cycle) => {
      const resetHistory = Array.isArray(cycle.resetHistory) ? cycle.resetHistory : [];
      if (resetHistory.length > 0 || cycle.endedAt || cycle.operationEndedAt) return true;
      return cycle.status === "completed";
    }).length,
    latest: items[0] || null,
    items,
    errorStats: summarizeErrorOutcomes(errorOutcomes),
    errorOutcomes,
  };
}

function hasMeaningfulTaskHistory(cycle) {
  if (!cycle) return false;
  const tags = canonicalizeTags(Array.isArray(cycle.tags) ? cycle.tags : []);
  const resetHistory = Array.isArray(cycle.resetHistory) ? cycle.resetHistory : [];
  const taskTags = tags.filter((tag) => !/^GROUP_/.test(tag) && tag !== "WAITING");
  if (collectCycleErrorOutcomes(cycle).length > 0) return true;
  if (!taskTags.length && !resetHistory.length && cycle.status === "active") return false;
  return taskTags.length > 0 ||
    resetHistory.length > 0 ||
    cycle.status === "completed" ||
    Boolean(cycle.endedAt || cycle.operationEndedAt);
}

function extractDay(tags) {
  const found = (tags || []).find((tag) => /^DAY_\d{2}$/.test(tag));
  return found ? Number(found.slice(4)) : "";
}

function deviceNameBySerial(db, serial) {
  const device = db && db.physicalDevices && db.physicalDevices[serial];
  return device && device.name || "";
}

function managementNumberFromId(id) {
  const match = /^A-(\d+)$/.exec(String(id || ""));
  return match ? Number(match[1]) : 9999;
}

function nextManagementNumber(db) {
  const maxNumber = Object.values(db && db.physicalDevices || {}).reduce((max, device) => {
    const candidates = [
      Number(device && device.number),
      Number(device && device.xiaoweiSort),
      managementNumberFromId(device && device.managementId),
    ].filter((value) => Number.isFinite(value) && value > 0 && value < 9000);
    return Math.max(max, ...candidates, 0);
  }, 0);
  return maxNumber + 1;
}

function localMonth(date) {
  return new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
  }).format(date);
}

function sanitizeTagBoardResetConfirmations(value) {
  return normalizeInactiveResetConfirmations(value);
}

function resolveTagBoardDeviceIdentity(db, value) {
  const serial = cleanText(value && value.serial, 80);
  const managementId = cleanText(value && value.managementId, 80);
  const serialDevice = serial ? findFleetDbDevice(db, serial) : null;
  const managementDevice = managementId ? findFleetDbDevice(db, managementId) : null;
  const errors = [];
  if (serial && !serialDevice) errors.push(`${serial}: 端末DBに見つかりません`);
  if (managementId && !managementDevice) errors.push(`${managementId}: 端末DBに見つかりません`);
  if (serialDevice && managementDevice && serialDevice !== managementDevice) {
    errors.push(`${serial} / ${managementId}: 端末IDと管理IDが別の端末を指しています`);
  }
  const device = serialDevice || managementDevice;
  const key = device ? fleetIdentityKey(device.serial || device.managementId) : "";
  if (!key && !errors.length) errors.push("端末DBに見つかりません");
  return { ok: errors.length === 0, device, key, errors };
}

function findTagBoardResetConfirmation(index, change) {
  return index instanceof Map
    ? index.get(tagBoardResetTargetKey(change)) || null
    : null;
}

function tagBoardResetTargetKey(change) {
  const serial = fleetIdentityKey(change && change.serial);
  const managementId = fleetIdentityKey(change && change.managementId);
  return serial ? `serial:${serial}` : managementId ? `management:${managementId}` : "";
}

function matchesExpectedInactiveResetReplay(db, device, currentCycle, expectedCycleId, confirmation) {
  const expectedCycle = db.cycles && db.cycles[expectedCycleId];
  if (!expectedCycle || expectedCycle.status !== "completed" || !currentCycle || !hasResetWaitingTags(currentCycle)) return false;
  if (fleetIdentityKey(expectedCycle.physicalSerial) !== fleetIdentityKey(device.serial)) return false;
  const amountYen = Number(confirmation && confirmation.amountYen || 0);
  if (Number(expectedCycle.outcome && expectedCycle.outcome.finalYen) !== amountYen) return false;
  if (Number(currentCycle.outcome && currentCycle.outcome.finalYen) !== amountYen) return false;
  const expectedWithdrawalId = cleanText(expectedCycle.outcome && expectedCycle.outcome.withdrawalId, 180);
  const currentWithdrawalId = cleanText(currentCycle.outcome && currentCycle.outcome.withdrawalId, 180);
  if (expectedWithdrawalId !== currentWithdrawalId) return false;
  if (amountYen <= 0) return !expectedWithdrawalId;
  const withdrawal = findWithdrawal(db, expectedWithdrawalId);
  return Boolean(withdrawal && Number(withdrawal.amountYen) === amountYen);
}

function resolveTagBoardResetConfirmations(db, changes, confirmationBatch, at) {
  if (!confirmationBatch || !confirmationBatch.ok) {
    const details = (confirmationBatch && confirmationBatch.errors || [])
      .flatMap((item) => item.errors || [])
      .slice(0, 4);
    return {
      ok: false,
      error: `非稼働の確認内容が不正です${details.length ? `: ${details.join(" / ")}` : ""}`,
      confirmations: [],
      errors: details,
    };
  }
  const confirmations = confirmationBatch.rows || [];
  const confirmationByDeviceKey = new Map();
  const confirmationByTargetKey = new Map();
  const targetChanges = [];
  const targetDeviceKeys = new Set();
  const errors = [];
  for (const confirmation of confirmations) {
    const identity = resolveTagBoardDeviceIdentity(db, confirmation);
    if (!identity.ok) {
      errors.push(...identity.errors);
      continue;
    }
    if (confirmationByDeviceKey.has(identity.key)) {
      errors.push(`${confirmation.serial || confirmation.managementId}: 同じ端末の確認が重複しています`);
      continue;
    }
    confirmationByDeviceKey.set(identity.key, confirmation);
  }
  for (const change of changes || []) {
    if (change.tag !== "GROUP_INACTIVE" || !change.checked) continue;
    const identity = resolveTagBoardDeviceIdentity(db, change);
    const label = change.serial || change.managementId || "端末";
    if (!identity.ok) {
      errors.push(...identity.errors.map((error) => `${label}: ${error}`));
      continue;
    }
    if (targetDeviceKeys.has(identity.key)) {
      errors.push(`${label}: 非稼働変更が重複しています`);
      continue;
    }
    targetDeviceKeys.add(identity.key);
    targetChanges.push({ change, identity });
  }
  const usedConfirmations = new Set();
  for (const target of targetChanges) {
    const change = target.change;
    const confirmation = confirmationByDeviceKey.get(target.identity.key) || null;
    const label = change.serial || change.managementId || "端末";
    if (!confirmation) {
      errors.push(`${label}: 確認内容がありません`);
      continue;
    }
    usedConfirmations.add(confirmation);
    confirmationByTargetKey.set(tagBoardResetTargetKey(change), confirmation);
    const device = target.identity.device;
    if (confirmation.expectedCycleId) {
      const currentCycle = (device.cycleIds || [])
        .map((cycleId) => db.cycles && db.cycles[cycleId])
        .find((cycle) => cycle && cycle.status === "active") || null;
      if (
        !currentCycle
        || (
          cleanText(currentCycle.cycleId, 120) !== confirmation.expectedCycleId
          && !matchesExpectedInactiveResetReplay(db, device, currentCycle, confirmation.expectedCycleId, confirmation)
        )
      ) {
        errors.push(`${label}: 確認後に稼働サイクルが変わりました。画面を再読み込みしてください`);
        continue;
      }
    }
    const displayedUptimeSeconds = effectiveDeviceUptimeSeconds(
      device.adbLastUptimeSeconds,
      device.adbLastUptimeCheckedAt,
      Date.parse(at)
    );
    const selectedUptimeSeconds = confirmation.uptimeMode === "manual"
      ? historyUptimeSeconds(confirmation.manualUptimeSeconds)
      : displayedUptimeSeconds;
    if (selectedUptimeSeconds === null) {
      errors.push(`${label}: 表示UPTIMEが未取得です。手入力してください`);
      continue;
    }
    confirmation.uptimeSeconds = selectedUptimeSeconds;
    confirmation.uptimeSource = confirmation.uptimeMode;
    confirmation.uptimeBeforeSeconds = displayedUptimeSeconds;
    confirmation.uptimeRecordedAt = at;
  }
  for (const confirmation of confirmations) {
    if (!usedConfirmations.has(confirmation)) {
      errors.push(`${confirmation.serial || confirmation.managementId || "端末"}: 非稼働対象にない確認内容です`);
    }
  }
  return {
    ok: errors.length === 0,
    error: errors.length ? `非稼働の確認を完了できません: ${errors.slice(0, 4).join(" / ")}` : "",
    confirmations,
    confirmationByTargetKey,
    errors,
  };
}

function inactiveResetTagsForHistoryReset(beforeTags, resetConfirmation) {
  const next = new Set(["GROUP_INACTIVE"]);
  return canonicalizeTags([...next]);
}

function inactiveResetHistoryBeforeTags(originalTags, finalTags) {
  const original = canonicalizeTags(Array.isArray(originalTags) ? originalTags : []);
  const final = canonicalizeTags(Array.isArray(finalTags) ? finalTags : []);
  const originalState = original.filter((tag) => isFleetGroupTag(tag) || tag === "WAITING");
  const finalChecklist = final.filter((tag) => !isFleetGroupTag(tag) && tag !== "WAITING");
  return canonicalizeTags([...originalState, ...finalChecklist]);
}

function summarizeResetChecklistTags(tags) {
  const list = canonicalizeTags(Array.isArray(tags) ? tags : []);
  const day = extractDay(list);
  const ciTag = findCheckinAmountTag(list);
  const v180Tag = findVideo180AmountTag(list) || (list.includes("V180_DONE") ? "V180_DONE" : "");
  const v10Tag = findVideo10AmountTag(list) || (list.includes("V10_DONE") ? "V10_DONE" : "");
  return [
    day ? `DAY${String(day).padStart(2, "0")}` : "",
    ciTag ? rewardLabel(ciTag, "ci") : "",
    v180Tag ? rewardLabel(v180Tag, "v180") : "",
    v10Tag ? rewardLabel(v10Tag, "v10") : "",
    list.includes("STATE_ERROR") ? "ERROR中" : list.includes("STATE_ERROR_HISTORY") ? "ERROR歴あり" : "",
  ].filter(Boolean).join(" / ");
}

function planChecklistResetWithdrawal(db, device, cycle, resetConfirmation, at) {
  const amountYen = Number(resetConfirmation && resetConfirmation.amountYen || 0);
  const cycleId = cleanText(cycle && cycle.cycleId, 120);
  const automaticWithdrawalId = cycleId ? `checklist:${cycleId}` : "";
  const existingRows = (db.withdrawals || []).filter((row) => row && (
    cleanText(row.cycleId, 120) === cycleId
    || cleanText(row.withdrawalId, 180) === automaticWithdrawalId
  ));
  if (existingRows.length) {
    if (existingRows.length !== 1) {
      return {
        ok: false,
        error: `${device.serial || device.managementId}: 同じ稼働サイクルに出金履歴が複数あります。出金履歴を確認してください。`,
      };
    }
    const mismatched = existingRows.find((row) => {
      const rowSerial = cleanText(row.serial, 80);
      return Number(row.amountYen) !== amountYen
        || cleanText(row.subjectKind, 20).toLowerCase() === "custom"
        || (cleanText(row.cycleId, 120) && cleanText(row.cycleId, 120) !== cycleId)
        || !rowSerial
        || fleetIdentityKey(rowSerial) !== fleetIdentityKey(device.serial);
    });
    if (amountYen <= 0 || mismatched) {
      const existingAmounts = [...new Set(existingRows.map((row) => Number(row.amountYen || 0)))].join(" / ");
      return {
        ok: false,
        error: `${device.serial || device.managementId}: 同じ稼働サイクルに出金履歴（${existingAmounts}円）があるため、${amountYen}円では非稼働にできません。出金履歴を確認してください。`,
      };
    }
    return {
      ok: true,
      withdrawalId: cleanText(existingRows[0].withdrawalId, 180),
      existing: existingRows[0],
      withdrawal: null,
    };
  }
  if (amountYen <= 0) return { ok: true, withdrawalId: "", existing: null, withdrawal: null };

  return {
    ok: true,
    withdrawalId: automaticWithdrawalId,
    existing: null,
    amountYen,
  };
}

function validateChecklistResetReplay(db, device, cycle, resetConfirmation) {
  const amountYen = Number(resetConfirmation && resetConfirmation.amountYen || 0);
  if (!cycle) {
    return amountYen === 0
      ? { ok: true }
      : { ok: false, error: `${device.serial || device.managementId}: 既に非稼働で元の稼働サイクルがないため、出金は自動登録できません。` };
  }
  const outcome = cycle.outcome && typeof cycle.outcome === "object" ? cycle.outcome : {};
  const withdrawalId = cleanText(outcome.withdrawalId, 180);
  const linked = withdrawalId ? findWithdrawal(db, withdrawalId) : null;
  if (withdrawalId && !linked) {
    return { ok: false, error: `${device.serial || device.managementId}: 非稼働履歴の出金IDに対応する出金履歴がありません。` };
  }
  if (linked && Number(linked.amountYen) !== amountYen) {
    return { ok: false, error: `${device.serial || device.managementId}: 既に反映済みの出金額（${Number(linked.amountYen || 0)}円）と一致しません。` };
  }
  const hasFinalYen = outcome.finalYen !== null && outcome.finalYen !== undefined && outcome.finalYen !== "";
  if (hasFinalYen && Number(outcome.finalYen) !== amountYen) {
    return { ok: false, error: `${device.serial || device.managementId}: 既に反映済みのリセット金額（${Number(outcome.finalYen || 0)}円）と一致しません。` };
  }
  if (amountYen > 0 && !linked) {
    return { ok: false, error: `${device.serial || device.managementId}: 既に非稼働のため、新しい出金は登録できません。` };
  }
  return { ok: true };
}

function applyChecklistResetWithdrawalPlan(db, plan, device, cycle, sourceTags, at) {
  if (!plan || !plan.withdrawalId) return { withdrawalId: "", created: false, reused: false };
  if (plan.existing) {
    plan.existing.resetDone = true;
    plan.existing.resetDoneAt = plan.existing.resetDoneAt || at;
    plan.existing.updatedAt = at;
    return { withdrawalId: plan.withdrawalId, created: false, reused: true };
  }
  const tags = canonicalizeTags(Array.isArray(sourceTags) ? sourceTags : []);
  const economics = cycle.economics && typeof cycle.economics === "object" ? cycle.economics : {};
  const firstFinite = (...values) => {
    for (const value of values) {
      if (value === null || value === undefined || value === "") continue;
      const number = Number(value);
      if (Number.isFinite(number)) return number;
    }
    return "";
  };
  const finalCurrentPoints = firstFinite(cycle.currentPoints, economics.currentPoints);
  const finalCurrentYen = firstFinite(
    cycle.currentYen,
    economics.currentYen,
    finalCurrentPoints === "" ? "" : finalCurrentPoints / 100
  );
  const siteName = normalizeFleetDbSettings(db.settings).siteName;
  const amountYen = plan.amountYen;
  db.withdrawals.push({
    withdrawalId: plan.withdrawalId,
    recordedAt: at,
    withdrawalDate: localDateStamp(new Date(at)),
    managementId: cycle.managementId || device.managementId || "",
    serial: device.serial,
    cycleId: cycle.cycleId,
    sequence: cycle.sequence || "",
    deviceName: fixedDeviceLabel(device) || device.name || device.xiaoweiName || device.model || "",
    amountYen,
    amountPoints: amountYen * 100,
    finalCurrentPoints,
    finalCurrentYen,
    day: economics.elapsedDay || economics.day || extractDay(tags) || "",
    ciTag: economics.ciTag || findCheckinAmountTag(tags) || "",
    video180Tag: economics.video180Tag || findVideo180AmountTag(tags) || "",
    video10Tag: economics.video10Tag || findVideo10AmountTag(tags) || "",
    inviteOkTag: tags.find((tag) => tag.startsWith("INV_OK_")) || "",
    inviteNgTag: tags.find((tag) => tag.startsWith("INV_NG_")) || "",
    source: "checklist_inactive_reset",
    siteName,
    sourceSnapshotDate: "",
    sourceTags: tags,
    memo: "チェック一覧で非稼働へ反映した際に自動登録",
    resetDone: true,
    resetDoneAt: at,
  });
  return { withdrawalId: plan.withdrawalId, created: true, reused: false };
}

function normalizeCheckinAmountChange(row) {
  const serial = cleanText(row && row.serial, 80);
  const managementId = cleanText(row && row.managementId, 80);
  const rawAmount = row && row.amountYen;
  const clear = rawAmount === null || rawAmount === "";
  const tag = clear ? "" : checkinTagFromYen(rawAmount);
  if ((!serial && !managementId) || (!clear && !tag)) {
    return {
      ok: false,
      serial,
      managementId,
      amountYen: rawAmount,
      error: `check-in amount must be a whole number from 1 to ${MAX_CHECKIN_YEN}, or blank`,
    };
  }
  return {
    ok: true,
    serial,
    managementId,
    amountYen: tag ? checkinYenFromTag(tag) : 0,
    tag,
  };
}

function taskAmountConfig(kind) {
  const normalizedKind = cleanText(kind, 20).toLowerCase();
  if (normalizedKind === "video180") {
    return {
      kind: normalizedKind,
      max: MAX_VIDEO_180_POINTS,
      unit: "P",
      isAmountTag: isVideo180AmountTag,
      tagFromAmount: video180TagFromPoints,
      amountFromTag: video180PointsFromTag,
    };
  }
  if (normalizedKind === "video10") {
    return {
      kind: normalizedKind,
      max: MAX_VIDEO_10_YEN,
      unit: "円",
      isAmountTag: isVideo10AmountTag,
      tagFromAmount: video10TagFromYen,
      amountFromTag: video10YenFromTag,
    };
  }
  return null;
}

function taskAmountKindForTag(tag) {
  if (isVideo180AmountTag(tag)) return "video180";
  if (isVideo10AmountTag(tag)) return "video10";
  return "";
}

function taskAmountTagValidationError(tag) {
  const text = String(tag || "");
  if (text === "V180_DONE" || text === "V10_DONE") return "";
  if (text.startsWith("V180_") && !isVideo180AmountTag(text)) {
    return `180分は1〜${MAX_VIDEO_180_POINTS}Pの整数で入力してください`;
  }
  if (text.startsWith("V10_") && !isVideo10AmountTag(text)) {
    return `追加視聴は1〜${MAX_VIDEO_10_YEN}円の整数で入力してください`;
  }
  return "";
}

function normalizeTaskAmountChange(row) {
  const serial = cleanText(row && row.serial, 80);
  const managementId = cleanText(row && row.managementId, 80);
  const config = taskAmountConfig(row && row.kind);
  const rawAmount = row && row.amount;
  const clear = rawAmount === null || rawAmount === "";
  const tag = clear || !config ? "" : config.tagFromAmount(rawAmount);
  const errors = [];
  if (!serial && !managementId) errors.push("device is required");
  if (!config) errors.push("task kind must be video180 or video10");
  if (config && !clear && !tag) {
    errors.push(`amount must be a whole number from 1 to ${config.max}${config.unit}, or blank`);
  }
  return {
    ok: errors.length === 0,
    serial,
    managementId,
    kind: config ? config.kind : cleanText(row && row.kind, 20).toLowerCase(),
    amount: tag && config ? config.amountFromTag(tag) : 0,
    tag,
    error: errors.join(" / "),
  };
}

async function applyTagBoardTagChanges(body) {
  const changes = Array.isArray(body && body.changes) ? body.changes : [];
  const normalizedChanges = changes.map((change) => {
    const tag = canonicalizeTag(cleanText(change.tag, 80));
    return {
      serial: cleanText(change.serial, 80),
      managementId: cleanText(change.managementId, 80),
      tag,
      checked: Boolean(change.checked),
      validationError: taskAmountTagValidationError(tag),
    };
  });
  const validTagChange = (change) => Boolean(
    (change.serial || change.managementId)
    && change.tag
    && !change.validationError
  );
  const cleanChanges = normalizedChanges.filter(validTagChange);
  const invalidChanges = normalizedChanges.filter((change) => !validTagChange(change));
  const rawCheckinAmounts = Array.isArray(body && body.checkinAmounts) ? body.checkinAmounts : [];
  const normalizedCheckinAmounts = rawCheckinAmounts.map(normalizeCheckinAmountChange);
  const invalidCheckinAmounts = normalizedCheckinAmounts.filter((item) => !item.ok);
  const rawTaskAmounts = Array.isArray(body && body.taskAmounts) ? body.taskAmounts : [];
  const normalizedTaskAmounts = rawTaskAmounts.map(normalizeTaskAmountChange);
  const invalidTaskAmounts = normalizedTaskAmounts.filter((item) => !item.ok);
  if (invalidChanges.length || invalidCheckinAmounts.length || invalidTaskAmounts.length) {
    const invalidCount = invalidChanges.length + invalidCheckinAmounts.length + invalidTaskAmounts.length;
    return {
      ok: false,
      error: invalidChanges.length
        ? `チェック変更 ${invalidChanges.length}件が不正です。端末とチェック項目を確認してください。`
        : invalidCheckinAmounts.length
          ? `チェックイン金額 ${invalidCheckinAmounts.length}件が不正です。1〜${MAX_CHECKIN_YEN}の整数を入力してください。`
          : `タスク金額 ${invalidTaskAmounts.length}件が不正です。入力値を確認してください。`,
      requested: changes.length + rawCheckinAmounts.length + rawTaskAmounts.length,
      applied: 0,
      failed: invalidCount,
      dbApplied: false,
      results: [
        ...invalidChanges.map((item) => ({
          ...item,
          ok: false,
          error: item.validationError || "device and tag are required",
        })),
        ...invalidCheckinAmounts,
        ...invalidTaskAmounts,
      ],
    };
  }
  const cleanCheckinAmounts = normalizedCheckinAmounts;
  const cleanTaskAmounts = normalizedTaskAmounts;
  const resetConfirmationBatch = sanitizeTagBoardResetConfirmations(body && body.resetConfirmations);
  if (!resetConfirmationBatch.ok) {
    const validationErrors = resetConfirmationBatch.errors.flatMap((item) => item.errors || []).slice(0, 4);
    return {
      ok: false,
      error: `非稼働の確認内容が不正です${validationErrors.length ? `: ${validationErrors.join(" / ")}` : ""}`,
      requested: changes.length + rawCheckinAmounts.length + rawTaskAmounts.length,
      applied: 0,
      failed: Math.max(1, resetConfirmationBatch.errors.length),
      dbApplied: false,
      results: resetConfirmationBatch.errors,
    };
  }

  const { dbPath, db } = readFleetDbForWrite();
  const explicitCheckinDeviceKeys = new Set();
  const duplicateCheckinTargets = [];
  for (const amountChange of cleanCheckinAmounts) {
    const identity = resolveTagBoardDeviceIdentity(db, amountChange);
    if (!identity.ok) continue;
    if (explicitCheckinDeviceKeys.has(identity.key)) duplicateCheckinTargets.push(amountChange);
    explicitCheckinDeviceKeys.add(identity.key);
  }
  const mixedCheckinTargets = cleanChanges.filter((change) => {
    if (!isCheckinAmountTag(change.tag)) return false;
    const identity = resolveTagBoardDeviceIdentity(db, change);
    return identity.ok && explicitCheckinDeviceKeys.has(identity.key);
  });
  const explicitTaskTargetKinds = new Set();
  const duplicateTaskTargets = [];
  for (const amountChange of cleanTaskAmounts) {
    const identity = resolveTagBoardDeviceIdentity(db, amountChange);
    if (!identity.ok) continue;
    const targetKey = `${identity.key}:${amountChange.kind}`;
    if (explicitTaskTargetKinds.has(targetKey)) duplicateTaskTargets.push(amountChange);
    explicitTaskTargetKinds.add(targetKey);
  }
  const mixedTaskTargets = cleanChanges.filter((change) => {
    const kind = taskAmountKindForTag(change.tag);
    if (!kind) return false;
    const identity = resolveTagBoardDeviceIdentity(db, change);
    return identity.ok && explicitTaskTargetKinds.has(`${identity.key}:${kind}`);
  });
  if (
    duplicateCheckinTargets.length
    || mixedCheckinTargets.length
    || duplicateTaskTargets.length
    || mixedTaskTargets.length
  ) {
    let error = "";
    if (duplicateCheckinTargets.length) {
      error = "同じ端末のチェックイン金額が重複しています。入力欄を1つにしてください。";
    } else if (mixedCheckinTargets.length) {
      error = "同じ端末に新旧2種類のチェックイン金額が送信されました。画面を再読み込みしてください。";
    } else if (duplicateTaskTargets.length) {
      error = "同じ端末の同じタスク金額が重複しています。入力欄を1つにしてください。";
    } else {
      error = "同じ端末の同じタスクに新旧2種類の金額が送信されました。画面を再読み込みしてください。";
    }
    return {
      ok: false,
      error,
      requested: changes.length + rawCheckinAmounts.length + rawTaskAmounts.length,
      applied: 0,
      failed: duplicateCheckinTargets.length
        + mixedCheckinTargets.length
        + duplicateTaskTargets.length
        + mixedTaskTargets.length,
      dbApplied: false,
      results: [
        ...duplicateCheckinTargets.map((item) => ({ ...item, ok: false, error: "duplicate check-in amount" })),
        ...mixedCheckinTargets.map((item) => ({ ...item, ok: false, error: "mixed legacy and free check-in amount" })),
        ...duplicateTaskTargets.map((item) => ({ ...item, ok: false, error: "duplicate task amount" })),
        ...mixedTaskTargets.map((item) => ({ ...item, ok: false, error: "mixed legacy and free task amount" })),
      ],
    };
  }
  const tagAppliedAt = new Date().toISOString();
  const resetResolution = resolveTagBoardResetConfirmations(db, cleanChanges, resetConfirmationBatch, tagAppliedAt);
  if (!resetResolution.ok) {
    return {
      ok: false,
      error: resetResolution.error,
      requested: changes.length + rawCheckinAmounts.length + rawTaskAmounts.length,
      applied: 0,
      failed: Math.max(1, resetResolution.errors.length),
      dbApplied: false,
      results: resetResolution.errors.map((error) => ({ ok: false, error })),
    };
  }
  const cycleIndex = buildActiveCycleIndex(db);
  const resetConfirmationIndex = resetResolution.confirmationByTargetKey;
  const inactiveReplayDeviceKeys = new Set();
  const withdrawalPlanByCycleId = new Map();
  const withdrawalPlanningErrors = [];
  for (const change of cleanChanges) {
    if (change.tag !== "GROUP_INACTIVE" || !change.checked) continue;
    const identity = resolveTagBoardDeviceIdentity(db, change);
    if (!identity.ok) continue;
    const cycle = findActiveCycleForTagChange(cycleIndex, change);
    if (!cycle || hasResetWaitingTags(cycle)) {
      const confirmation = findTagBoardResetConfirmation(resetConfirmationIndex, change);
      const replayValidation = validateChecklistResetReplay(db, identity.device, cycle, confirmation);
      if (!replayValidation.ok) {
        withdrawalPlanningErrors.push({ ...change, ok: false, error: replayValidation.error });
        continue;
      }
      inactiveReplayDeviceKeys.add(identity.key);
      continue;
    }
    const confirmation = findTagBoardResetConfirmation(resetConfirmationIndex, change);
    const plan = planChecklistResetWithdrawal(db, identity.device, cycle, confirmation, tagAppliedAt);
    if (!plan.ok) {
      withdrawalPlanningErrors.push({ ...change, ok: false, error: plan.error });
      continue;
    }
    withdrawalPlanByCycleId.set(cycle.cycleId, plan);
  }
  if (withdrawalPlanningErrors.length) {
    return {
      ok: false,
      error: `出金履歴との競合により非稼働へ反映できません: ${withdrawalPlanningErrors[0].error}`,
      requested: changes.length + rawCheckinAmounts.length + rawTaskAmounts.length,
      applied: 0,
      failed: withdrawalPlanningErrors.length,
      dbApplied: false,
      results: withdrawalPlanningErrors,
    };
  }
  const isInactiveReplayChange = (change) => {
    const identity = resolveTagBoardDeviceIdentity(db, change);
    return identity.ok && inactiveReplayDeviceKeys.has(identity.key);
  };

  const results = [];
  let changed = false;
  const checkedGroupBySerial = new Map();
  const checkedEvidenceBySerialGroup = new Set();
  const checkedDayBySerial = new Map();
  const checkedErrorBySerial = new Set();
  const checkedActiveBySerial = new Set();
  const changeBySerial = new Map();
  const inactiveResetSnapshots = new Map();
  let repairedMissingCycles = 0;
  const preserveEvidence = !(body && body.preserveEvidence === false);
  for (const change of [...cleanChanges, ...cleanCheckinAmounts, ...cleanTaskAmounts]) {
    if (isInactiveReplayChange(change)) continue;
    if (findActiveCycleForTagChange(cycleIndex, change)) continue;
    const device = findFleetDbDevice(db, change.serial || change.managementId);
    if (!device || device.excluded || device.retiredAt) continue;
    const ensured = ensureInactiveCurrentCycle(db, device, {
      at: tagAppliedAt,
      startReason: "tag_board_missing_cycle_repair",
      memo: "Repaired automatically before checklist apply.",
    });
    if (!ensured.cycle) continue;
    addActiveCycleToIndex(cycleIndex, ensured.cycle);
    if (ensured.created) {
      repairedMissingCycles += 1;
      changed = true;
    }
  }
  for (const change of cleanChanges) {
    if (isInactiveReplayChange(change)) continue;
    const key = tagChangeKey(change);
    changeBySerial.set(key, change);
    if (isFleetGroupTag(change.tag) && change.checked) checkedGroupBySerial.set(key, change.tag);
    if (change.tag === "GROUP_ACTIVE" && change.checked) checkedActiveBySerial.add(key);
    if (/^DAY_\d{2}$/.test(change.tag) && change.checked) checkedDayBySerial.set(key, Number(change.tag.slice(4)));
    if (["STATE_ERROR", "STATE_ERROR_HISTORY"].includes(change.tag) && change.checked) checkedErrorBySerial.add(key);
    const evidenceGroup = evidenceTagGroup(change.tag);
    if (evidenceGroup && change.checked) checkedEvidenceBySerialGroup.add(`${key}:${evidenceGroup}`);
  }
  const errorTrackingKeys = new Set([...checkedDayBySerial.keys(), ...checkedErrorBySerial, ...checkedActiveBySerial]);
  for (const key of errorTrackingKeys) {
    const probe = changeBySerial.get(key);
    const cycle = probe ? findActiveCycleForTagChange(cycleIndex, probe) : null;
    if (!cycle) continue;
    const beforeTracking = JSON.stringify(cycle.errorTracking || null);
    const tags = canonicalizeTags(Array.isArray(cycle.tags) ? cycle.tags : []);
    if (checkedActiveBySerial.has(key) && !tags.includes("GROUP_ACTIVE")) {
      beginCycleErrorOperation(cycle, tagAppliedAt);
    }
    const day = checkedDayBySerial.get(key) || extractDay(tags) || null;
    if (checkedErrorBySerial.has(key)) recordCycleErrorOccurrence(cycle, { day, at: tagAppliedAt });
    else if (day) backfillCycleErrorDay(cycle, day);
    if (beforeTracking !== JSON.stringify(cycle.errorTracking || null)) changed = true;
  }
  for (const amountChange of cleanCheckinAmounts) {
    if (isInactiveReplayChange(amountChange)) {
      results.push({ ...amountChange, ok: true, skipped: "already inactive reset replay" });
      continue;
    }
    const cycle = findActiveCycleForTagChange(cycleIndex, amountChange);
    if (!cycle) {
      results.push({ ...amountChange, ok: false, error: "active cycle not found" });
      continue;
    }
    const before = canonicalizeTags(Array.isArray(cycle.tags) ? cycle.tags : []);
    const tagSet = new Set(before);
    for (const tag of [...tagSet]) {
      if (isCheckinAmountTag(tag)) tagSet.delete(tag);
    }
    if (amountChange.tag) tagSet.add(amountChange.tag);
    const after = canonicalizeTags([...tagSet]);
    cycle.tags = after;
    cycle.economics = estimateCycleEconomics(after, {
      breakEvenYen: db.settings && db.settings.breakEvenYen || 3000,
      currentPoints: cycle.currentPoints || 0,
    });
    changed = changed || before.join("\n") !== after.join("\n");
    results.push({ ...amountChange, ok: true });
  }
  for (const amountChange of cleanTaskAmounts) {
    if (isInactiveReplayChange(amountChange)) {
      results.push({ ...amountChange, ok: true, skipped: "already inactive reset replay" });
      continue;
    }
    const cycle = findActiveCycleForTagChange(cycleIndex, amountChange);
    if (!cycle) {
      results.push({ ...amountChange, ok: false, error: "active cycle not found" });
      continue;
    }
    const config = taskAmountConfig(amountChange.kind);
    const before = canonicalizeTags(Array.isArray(cycle.tags) ? cycle.tags : []);
    const tagSet = new Set(before);
    for (const tag of [...tagSet]) {
      if (config.isAmountTag(tag)) tagSet.delete(tag);
    }
    if (amountChange.tag) tagSet.add(amountChange.tag);
    const after = canonicalizeTags([...tagSet]);
    cycle.tags = after;
    cycle.economics = estimateCycleEconomics(after, {
      breakEvenYen: db.settings && db.settings.breakEvenYen || 3000,
      currentPoints: cycle.currentPoints || 0,
    });
    changed = changed || before.join("\n") !== after.join("\n");
    results.push({ ...amountChange, ok: true });
  }
  for (const change of cleanChanges) {
    const key = tagChangeKey(change);
    if (isInactiveReplayChange(change)) {
      results.push({ ...change, ok: true, skipped: "already inactive reset replay" });
      continue;
    }
    if (isFleetGroupTag(change.tag) && !change.checked && checkedGroupBySerial.has(key)) {
      results.push({ ...change, ok: true, skipped: "superseded by checked group" });
      continue;
    }
    const evidenceGroup = evidenceTagGroup(change.tag);
    if (preserveEvidence && evidenceGroup && !change.checked && !checkedEvidenceBySerialGroup.has(`${key}:${evidenceGroup}`)) {
      results.push({ ...change, ok: true, skipped: "evidence tag preserved" });
      continue;
    }
    const cycle = findActiveCycleForTagChange(cycleIndex, change);
    if (!cycle) {
      results.push({ ...change, ok: false, error: "active cycle not found" });
      continue;
    }

    const before = canonicalizeTags(Array.isArray(cycle.tags) ? cycle.tags : []);
    const reactivatingFromInactive = change.tag === "GROUP_ACTIVE" && change.checked
      && before.some((tag) => ["GROUP_INACTIVE", "GROUP_REST", "WAITING"].includes(tag));
    if (reactivatingFromInactive) {
      cycle.economics = {};
      cycle.currentPoints = "";
      cycle.currentYen = "";
      const device = findFleetDbDevice(db, cycle.physicalSerial || cycle.managementId);
      if (device) archiveAndResetInviteVerification(device, tagAppliedAt);
    }
    const resetConfirmation = change.tag === "GROUP_INACTIVE" && change.checked
      ? findTagBoardResetConfirmation(resetConfirmationIndex, change)
      : null;
    if (resetConfirmation && !hasResetWaitingTags({ tags: before }) && cycle.cycleId && !inactiveResetSnapshots.has(cycle.cycleId)) {
      inactiveResetSnapshots.set(cycle.cycleId, {
        cycle,
        before,
        resetConfirmation,
        withdrawalPlan: withdrawalPlanByCycleId.get(cycle.cycleId) || null,
      });
    }
    const tagSet = new Set(before);
    if (isFleetGroupTag(change.tag)) {
      applyFleetGroupTag(tagSet, change.tag, change.checked);
    } else {
      if (change.checked) applyExclusiveTaskTag(tagSet, change.tag);
      else tagSet.delete(change.tag);
      if (change.tag === "STATE_ERROR" && change.checked) tagSet.add("STATE_ERROR_HISTORY");
    }
    normalizeFleetGroupTagAfterTagChange(tagSet);
    const after = canonicalizeTags([...tagSet]);
    const transitionChanged = recordCycleFleetGroupTransition(cycle, before, after, tagAppliedAt, {
      deferErrorFinalization: Boolean(resetConfirmation),
    });
    cycle.tags = after;
    if (evidenceGroup) {
      cycle.economics = estimateCycleEconomics(after, {
        breakEvenYen: db.settings && db.settings.breakEvenYen || 3000,
        currentPoints: cycle.currentPoints || 0,
      });
    }
    changed = changed || transitionChanged || before.join("\n") !== after.join("\n");
    results.push({ ...change, ok: true });
  }

  let withdrawalsCreated = 0;
  let withdrawalsReused = 0;
  for (const snapshot of inactiveResetSnapshots.values()) {
    const cycle = snapshot.cycle;
    const beforeResetTags = inactiveResetHistoryBeforeTags(snapshot.before, cycle.tags);
    const afterResetTags = inactiveResetTagsForHistoryReset(beforeResetTags, snapshot.resetConfirmation);
    const resetAt = new Date().toISOString();
    const device = findFleetDbDevice(db, cycle.physicalSerial || cycle.managementId);
    const withdrawalResult = applyChecklistResetWithdrawalPlan(
      db,
      snapshot.withdrawalPlan,
      device,
      cycle,
      beforeResetTags,
      resetAt
    );
    const withdrawalId = withdrawalResult.withdrawalId;
    if (withdrawalResult.created) withdrawalsCreated += 1;
    if (withdrawalResult.reused) withdrawalsReused += 1;
    cycle.tags = beforeResetTags;
    const errorOutcome = finalizeCycleErrorOperation(cycle, {
      at: resetAt,
      fallbackTags: beforeResetTags,
      countNoError: beforeResetTags.includes("GROUP_ACTIVE") || Boolean(cycle.errorTracking),
      source: "checklist_reset",
    });
    cycle.tags = afterResetTags;
    cycle.resetHistory = Array.isArray(cycle.resetHistory) ? cycle.resetHistory : [];
    cycle.resetHistory.push({
      at: resetAt,
      reason: snapshot.resetConfirmation.reason,
      amountYen: snapshot.resetConfirmation.amountYen,
      beforeTags: beforeResetTags,
      afterTags: afterResetTags,
      summary: summarizeResetChecklistTags(beforeResetTags),
      uptimeSeconds: historyUptimeSeconds(snapshot.resetConfirmation.uptimeSeconds),
      uptimeSource: snapshot.resetConfirmation.uptimeSource,
      uptimeBeforeSeconds: historyUptimeSeconds(snapshot.resetConfirmation.uptimeBeforeSeconds),
      uptimeRecordedAt: snapshot.resetConfirmation.uptimeRecordedAt || resetAt,
      errorOutcomeId: errorOutcome && errorOutcome.id || "",
      errorCategory: errorOutcome && errorOutcome.category || "",
      hadError: errorOutcome && errorOutcome.hadError === true,
      firstErrorAt: errorOutcome && errorOutcome.firstErrorAt || "",
      firstErrorDay: errorOutcome && errorOutcome.firstErrorDay || "",
      withdrawalId,
    });
    cycle.resetHistory = cycle.resetHistory.slice(-20);
    cycle.resetConfirmedAt = cycle.resetConfirmedAt || cycle.resetHistory[cycle.resetHistory.length - 1].at;
    cycle.outcome = {
      ...(cycle.outcome || {}),
      resetReason: snapshot.resetConfirmation.reason,
      finalYen: snapshot.resetConfirmation.amountYen,
      finalUptimeSeconds: historyUptimeSeconds(snapshot.resetConfirmation.uptimeSeconds),
      finalUptimeSource: snapshot.resetConfirmation.uptimeSource,
      withdrawalId,
      memo: "check-list reset to inactive",
    };
    if (device) {
      archiveAndResetInviteVerification(device, resetAt, {
        uptimeSeconds: snapshot.resetConfirmation.uptimeSeconds,
        uptimeSource: snapshot.resetConfirmation.uptimeSource,
      });
      cycle.tags = beforeResetTags;
      closeActiveCycleAndStartWaiting(db, device, {
        resetReason: snapshot.resetConfirmation.reason,
        withdrawalId,
        amountYen: Number(snapshot.resetConfirmation.amountYen || 0),
        memo: "check-list reset to inactive",
      });
    } else {
      cycle.tags = afterResetTags;
      cycle.economics = {};
      cycle.currentPoints = "";
      cycle.currentYen = "";
    }
    changed = true;
  }

  const applied = results.filter((item) => item.ok).length;
  const failed = results.length - applied;
  const groupTouched = cleanChanges.some((change) => isFleetGroupTag(change.tag));
  let dbCommitted = false;
  // Apply the batch atomically: if any requested checkbox failed validation,
  // keep every mutation in memory only so retrying cannot duplicate side effects.
  if (changed && failed === 0) {
    const now = new Date().toISOString();
    db.updatedAt = now;
    writeJsonFile(dbPath, db);
    dbCommitted = true;
  }

  const numberProjection = dbCommitted && groupTouched ? persistProjectedFleetNumbers() : null;
  const refresh = dbCommitted ? { tagBoard: regenerateTagBoard() } : null;
  const syncLegacyMirror = Boolean(body && body.syncLegacyMirror);
  const syncNumbers = syncLegacyMirror && Boolean(body && body.syncNumbers);
  const groupSync = syncLegacyMirror && dbCommitted && groupTouched ? await syncLegacyMirrorGroupsFromFleetDb() : null;
  const nameSync = syncLegacyMirror && dbCommitted ? await syncLegacyMirrorNamesFromFleetDb() : null;
  const numberSync = syncLegacyMirror && dbCommitted && syncNumbers ? await syncLegacyMirrorNumbersFromFleetDb({ apply: true }) : null;
  // A later refresh/sync failure must not make the client resend changes that
  // were already committed (notably inactive-cycle resets with side effects).
  const dbApplied = failed === 0;
  const refreshFailed = Boolean(refresh && refresh.tagBoard && !refresh.tagBoard.ok);
  const failureReasons = [...new Set(results
    .filter((item) => item && !item.ok && item.error)
    .map((item) => String(item.error)))]
    .slice(0, 3);
  return {
    ok: failed === 0 && !refreshFailed && (!numberProjection || numberProjection.ok) && (!groupSync || groupSync.ok) && (!nameSync || nameSync.ok) && (!numberSync || numberSync.ok),
    error: failed
      ? `${failed}件のDB反映に失敗しました: ${failureReasons.join(" / ") || "原因不明"}`
      : refreshFailed ? "DB反映後のチェック一覧再生成に失敗しました。画面を更新してください。" : "",
    requested: cleanChanges.length + cleanCheckinAmounts.length + cleanTaskAmounts.length,
    applied,
    failed,
    dbApplied,
    repairedMissingCycles,
    withdrawalsCreated,
    withdrawalsReused,
    results,
    refresh,
    numberProjection,
    groupSync,
    nameSync,
    numberSync,
  };
}

function isFleetGroupTag(tag) {
  return /^GROUP_(ACTIVE|INACTIVE|REST)$/.test(String(tag || ""));
}

function evidenceTagGroup(tag) {
  const text = String(tag || "");
  if (/^CI_\d+$/.test(text)) return "ci";
  if (/^V180_\d+$/.test(text)) return "v180";
  if (text === "V180_DONE") return "v180_done";
  if (/^V10_\d+$/.test(text)) return "v10";
  if (text === "V10_DONE") return "v10_done";
  if (/^DAY_\d{2}$/.test(text)) return "day";
  if (text === "STATE_CI_KEEP") return "ci_keep";
  return "";
}

function buildActiveCycleIndex(db) {
  const index = {
    bySerial: new Map(),
    byManagementId: new Map(),
    byCycleId: new Map(),
  };
  for (const cycle of Object.values(db.cycles || {})) {
    if (!cycle || cycle.status !== "active") continue;
    addActiveCycleToIndex(index, cycle);
  }
  return index;
}

function addActiveCycleToIndex(index, cycle) {
  if (!index || !cycle) return;
  if (cycle.physicalSerial) index.bySerial.set(fleetIdentityKey(cycle.physicalSerial), cycle);
  if (cycle.managementId) index.byManagementId.set(fleetIdentityKey(cycle.managementId), cycle);
  if (cycle.cycleId) index.byCycleId.set(fleetIdentityKey(cycle.cycleId), cycle);
}

function findActiveCycleForTagChange(index, change) {
  const serial = fleetIdentityKey(change && change.serial);
  const managementId = fleetIdentityKey(change && change.managementId);
  return index.bySerial.get(serial)
    || index.byManagementId.get(managementId)
    || index.byCycleId.get(serial)
    || index.byCycleId.get(managementId)
    || null;
}

function recordCycleFleetGroupTransition(cycle, beforeTags = [], afterTags = [], at = new Date().toISOString(), options = {}) {
  if (!cycle) return false;
  const beforeActive = beforeTags.includes("GROUP_ACTIVE");
  const afterActive = afterTags.includes("GROUP_ACTIVE");
  const beforeInactive = beforeTags.some((tag) => ["GROUP_INACTIVE", "GROUP_REST", "WAITING"].includes(tag));
  const afterInactive = afterTags.some((tag) => ["GROUP_INACTIVE", "GROUP_REST", "WAITING"].includes(tag));
  let changed = false;
  if (!beforeActive && afterActive) {
    cycle.operationStartedAt = at;
    cycle.operationEndedAt = "";
    beginCycleErrorOperation(cycle, at);
    changed = true;
  }
  if (!beforeInactive && afterInactive) {
    cycle.operationEndedAt = at;
    if (beforeActive && options.deferErrorFinalization !== true) {
      finalizeCycleErrorOperation(cycle, {
        at,
        fallbackTags: beforeTags,
        countNoError: true,
        source: "checklist_transition",
      });
    }
    changed = true;
  }
  return changed;
}

function tagChangeKey(change) {
  return fleetIdentityKey(change && (change.serial || change.managementId));
}

function applyExclusiveTaskTag(tagSet, tag) {
  if (isCheckinAmountTag(tag)) {
    for (const item of [...tagSet]) {
      if (isCheckinAmountTag(item)) tagSet.delete(item);
    }
    tagSet.add(tag);
    return;
  }
  if (isVideo180AmountTag(tag)) {
    for (const item of [...tagSet]) {
      if (isVideo180AmountTag(item)) tagSet.delete(item);
    }
    tagSet.add(tag);
    return;
  }
  if (isVideo10AmountTag(tag)) {
    for (const item of [...tagSet]) {
      if (isVideo10AmountTag(item)) tagSet.delete(item);
    }
    tagSet.add(tag);
    return;
  }
  const exclusiveGroups = [
    [
      "DAY_01", "DAY_02", "DAY_03", "DAY_04", "DAY_05", "DAY_06", "DAY_07",
      "DAY_08", "DAY_09", "DAY_10", "DAY_11", "DAY_12", "DAY_13", "DAY_14",
    ],
  ];
  const group = exclusiveGroups.find((items) => items.includes(tag));
  if (group) {
    for (const item of group) tagSet.delete(item);
  }
  tagSet.add(tag);
}

function applyFleetGroupTag(tagSet, tag, checked) {
  tag = tag === "GROUP_REST" ? "GROUP_INACTIVE" : tag;
  if (!checked) {
    tagSet.delete(tag);
    tagSet.delete("WAITING");
    tagSet.delete("GROUP_REST");
    return;
  }
  for (const groupTag of ["GROUP_ACTIVE", "GROUP_INACTIVE", "GROUP_REST"]) {
    tagSet.delete(groupTag);
  }
  tagSet.delete("WAITING");
  tagSet.add(tag);
}

function normalizeFleetGroupTagAfterTagChange(tagSet) {
  if (!tagSet || tagSet.has("GROUP_ACTIVE") || tagSet.has("GROUP_INACTIVE") || tagSet.has("GROUP_REST") || tagSet.has("WAITING")) return;
  if ([...tagSet].some((tag) => /^DAY_\d{2}$/.test(String(tag || "")))) {
    tagSet.add("GROUP_ACTIVE");
  }
}

async function syncXiaoweiTagBoard(options = {}) {
  const refresh = await refreshXiaoweiFromFleetDb({
    forceDisplayNames: options.forceDisplayNames === true,
  });
  const failedSteps = criticalFleetRefreshFailures(refresh);
  const warningSteps = Object.entries(refresh)
    .filter(([, result]) => !result.ok)
    .map(([name]) => name);
  return {
    ok: failedSteps.length === 0,
    error: failedSteps.length ? describeFleetRefreshFailure(refresh, failedSteps) : "",
    refresh,
    failedSteps,
    warningSteps,
  };
}

function criticalFleetRefreshFailures(refresh) {
  return Object.entries(refresh)
    .filter(([name, result]) => !result.ok && name !== "sheets")
    .map(([name]) => name);
}

function regenerateTagBoard() {
  return runNodeScript("tag-board.js");
}

function resolveBundledXiaoweiSyncScript(fileName) {
  const bundled = path.join(paths.root, "tools", "xiaowei-sync", fileName);
  if (fs.existsSync(bundled)) return bundled;
  return path.join(path.dirname(paths.root), fileName);
}

function xiaoweiDisplayNameScriptArgs(options = {}) {
  const args = [
    "-Apply",
    "-TagBoardPath", path.join(paths.dataDir, "fleet-db", "device-tag-board.json"),
    "-OutputPath", path.join(paths.dataDir, "fleet-db", "xiaowei-display-name-plan.json"),
    "-SqlitePath", path.join(paths.root, "tools", "platform-tools", "sqlite3.exe"),
  ];
  if (options.forceUpdate === true) args.push("-ForceUpdate");
  return args;
}

function xiaoweiNormalizeScriptArgs() {
  return [
    "-Apply",
    "-ApiScript", resolveBundledXiaoweiSyncScript("xiaowei-tag-api.ps1"),
  ];
}

function xiaoweiInventoryScriptArgs() {
  return [
    "-OutputPath", path.join(paths.dataDir, "fleet-db", "xiaowei-inventory.json"),
    "-NameMapPath", resolveBundledXiaoweiSyncScript("xiaowei-device-names.json"),
    "-ApiScript", resolveBundledXiaoweiSyncScript("xiaowei-tag-api.ps1"),
    "-SqlitePath", path.join(paths.root, "tools", "platform-tools", "sqlite3.exe"),
  ];
}

async function refreshXiaoweiFromFleetDb(options = {}) {
  const steps = {};
  const runStep = async (name, action) => {
    const startedAt = Date.now();
    const result = await action();
    steps[name] = {
      ...(result && typeof result === "object" ? result : { ok: true, result }),
      durationMs: Date.now() - startedAt,
    };
    return steps[name];
  };

  await runStep("backupBeforeRefresh", () => backupFleetDb());
  await runStep("deviceCodeSync", () => syncFleetDeviceCodes({ force: false, backup: false }));
  await runStep("tagBoard", () => runNodeScript("tag-board.js"));
  await runStep("displayNames", () => runPowerShellScript(
    resolveBundledXiaoweiSyncScript("update-xiaowei-display-names.ps1"),
    xiaoweiDisplayNameScriptArgs({ forceUpdate: options.forceDisplayNames === true })
  ));
  await runStep("numbers", () => syncXiaoweiNumbersFromFleetDb({ apply: true }));
  await runStep("tagBoardAfterDisplayNames", () => runNodeScript("tag-board.js"));
  await runStep("sheets", () => runNodeScript("sync-google-sheets.js"));

  for (const [name, result] of Object.entries(steps)) {
    if (!result.ok) {
      appendAuditLog({
        type: "xiaowei_from_db_step_failed",
        level: "warn",
        title: `XiaoWei from DB refresh failed: ${name}`,
        details: result,
      });
    }
  }

  return steps;
}

function chunk(items, size) {
  const chunks = [];
  for (let index = 0; index < items.length; index += size) {
    chunks.push(items.slice(index, index + size));
  }
  return chunks;
}

function refreshAfterLocalWaitingReset() {
  const steps = {
    syncLocalWaitingTags: runNodeScript("sync-local-waiting-tags.js"),
    updateFleetDb: runNodeScript("update-fleet-db.js", ["--quiet"]),
    tagBoard: runNodeScript("tag-board.js"),
  };

  for (const [name, result] of Object.entries(steps)) {
    if (!result.ok) {
      appendAuditLog({
        type: "waiting_reset_refresh_step_failed",
        level: "warn",
        title: `Waiting reset refresh failed: ${name}`,
        details: result,
      });
    }
  }

  return steps;
}

function refreshFleetViewsAndSheets() {
  const steps = {
    backupBeforeRefresh: backupFleetDb(),
    syncLocalWaitingTags: runNodeScript("sync-local-waiting-tags.js"),
    normalizeResetTags: runPowerShellScript(resolveBundledXiaoweiSyncScript("normalize-xiaowei-reset-tags.ps1"), xiaoweiNormalizeScriptArgs()),
    exportInventory: runPowerShellScript(resolveBundledXiaoweiSyncScript("export-xiaowei-inventory.ps1"), xiaoweiInventoryScriptArgs()),
    updateFleetDb: runNodeScript("update-fleet-db.js", ["--quiet"]),
    advanceDayTags: runNodeScript("advance-day-tags.js", ["--quiet", "--local-only"]),
    tagBoard: runNodeScript("tag-board.js"),
    displayNames: runPowerShellScript(resolveBundledXiaoweiSyncScript("update-xiaowei-display-names.ps1"), xiaoweiDisplayNameScriptArgs()),
    tagBoardAfterDisplayNames: runNodeScript("tag-board.js"),
    sheets: runNodeScript("sync-google-sheets.js"),
  };

  for (const [name, result] of Object.entries(steps)) {
    if (!result.ok) {
      appendAuditLog({
        type: "fleet_refresh_step_failed",
        level: "warn",
        title: `Fleet refresh failed: ${name}`,
        details: result,
      });
    }
  }

  return steps;
}

function refreshDisplayNamesOnly(options = {}) {
  const steps = {};
  steps.backupBeforeRefresh = backupFleetDb();
  steps.deviceCodeSync = syncFleetDeviceCodes({ force: false });
  steps.tagBoard = runNodeScript("tag-board.js");
  steps.displayNames = runPowerShellScript(
    resolveBundledXiaoweiSyncScript("update-xiaowei-display-names.ps1"),
    xiaoweiDisplayNameScriptArgs({ forceUpdate: options.forceUpdate === true })
  );
  if (steps.displayNames.ok) {
    steps.persistDisplayNames = persistSuccessfulXiaoweiDisplayNames();
  }
  steps.tagBoardAfterDisplayNames = runNodeScript("tag-board.js");

  for (const [name, result] of Object.entries(steps)) {
    if (!result.ok) {
      appendAuditLog({
        type: "fleet_display_name_step_failed",
        level: "warn",
        title: `Fleet display name update failed: ${name}`,
        details: result,
      });
    }
  }

  return steps;
}

function persistSuccessfulXiaoweiDisplayNames() {
  const planPath = path.join(paths.dataDir, "fleet-db", "xiaowei-display-name-plan.json");
  const plans = readJsonFile(planPath, []);
  if (!Array.isArray(plans)) return { ok: false, error: "xiaowei-display-name-plan.json is invalid" };
  const { dbPath, db } = readFleetDbForWrite();
  let changed = 0;
  const now = new Date().toISOString();
  for (const plan of plans) {
    const serial = cleanText(plan && plan.serial, 80);
    const displayName = cleanText(plan && plan.displayName, 120);
    if (!serial || !displayName || !db.physicalDevices[serial]) continue;
    const device = db.physicalDevices[serial];
    if (device.xiaoweiName === displayName) continue;
    device.xiaoweiName = displayName;
    device.updatedAt = now;
    changed += 1;
  }
  if (changed) {
    db.updatedAt = now;
    writeJsonFile(dbPath, db);
  }
  return { ok: true, changed };
}

async function runDayRollover(options = {}) {
  const dbDir = path.join(paths.dataDir, "fleet-db");
  const result = await advanceDayTagsOnce({
    dbPath: path.join(dbDir, "fleet-db.json"),
    statePath: path.join(dbDir, "day-rollover-state.json"),
    eventsPath: path.join(dbDir, "events.jsonl"),
    force: options.force === true,
  });
  if (result.ok) {
    if (!result.skipped && result.changed) {
      result.refresh = { tagBoard: regenerateTagBoard() };
    }
    const shouldSyncXiaowei = XIAOWEI_WRITE_SYNC_ENABLED
      && options.syncXiaowei !== false && (
      (!result.skipped && result.changed)
      || (
        options.source === "scheduler"
        && result.skipped
        && result.date !== lastSuccessfulXiaoweiDaySyncDate
      )
    );
    if (shouldSyncXiaowei) {
      const steps = refreshDisplayNamesOnly();
      const failedSteps = criticalFleetRefreshFailures(steps);
      result.xiaoweiNames = {
        ok: failedSteps.length === 0,
        refresh: steps,
        failedSteps,
        error: failedSteps.length ? describeFleetRefreshFailure(steps, failedSteps) : "",
      };
      if (result.xiaoweiNames.ok) {
        lastSuccessfulXiaoweiDaySyncDate = result.date;
      } else {
        result.dayAdvanceOk = true;
        result.ok = false;
        result.error = result.xiaoweiNames.error;
      }
    }
    if (options.syncLegacyMirror === true) {
      result.laixiNames = await syncLegacyMirrorNamesFromFleetDb();
    }
  }
  const suppressSchedulerNoop = options.source === "scheduler"
    && result.skipped
    && !result.xiaoweiNames;
  if (!suppressSchedulerNoop) {
    appendAuditLog({
      type: options.source === "scheduler" ? "day_tags_advance_auto" : "day_tags_advance",
      title: options.source === "scheduler" ? "DAY tags advanced by daily scheduler" : "DAY tags advanced",
      level: result.ok ? "info" : "warn",
      details: {
        ok: result.ok,
        skipped: result.skipped,
        changed: result.changed,
        failed: result.failed,
        xiaoweiNames: result.xiaoweiNames && { ok: result.xiaoweiNames.ok, failedSteps: result.xiaoweiNames.failedSteps },
        laixiNames: result.laixiNames && { succeeded: result.laixiNames.succeeded, failed: result.laixiNames.failed },
      },
    });
  }
  return result;
}

function startDayRolloverScheduler() {
  const run = () => {
    runDayRollover({
      source: "scheduler",
      syncXiaowei: DAY_ROLLOVER_XIAOWEI_SYNC_ENABLED,
      syncLegacyMirror: false,
    }).catch((error) => {
      appendAuditLog({
        type: "day_tags_advance_auto",
        title: "DAY tag scheduler failed",
        level: "warn",
        details: { error: error.message },
      });
    });
  };
  setTimeout(run, 3000);
  return setInterval(run, DAY_ROLLOVER_INTERVAL_MS);
}

function runNodeScript(scriptName, args = []) {
  const nodePath = resolveNodeRuntimePath();
  const scriptPath = path.join(paths.root, scriptName);
  const electronAsNode = Boolean(process.versions.electron && path.resolve(nodePath) === path.resolve(process.execPath));
  const result = spawnSync(nodePath, [scriptPath, ...args], {
    cwd: paths.root,
    encoding: "utf8",
    windowsHide: true,
    timeout: 30000,
    env: electronAsNode
      ? { ...process.env, ELECTRON_RUN_AS_NODE: "1" }
      : process.env,
  });

  const parsed = parseLastJson(result.stdout);
  const ok = result.status === 0 && !(parsed && parsed.ok === false);
  return {
    ok,
    status: result.status,
    script: scriptName,
    stdout: result.stdout || "",
    stderr: result.stderr || "",
    error: result.error ? result.error.message : undefined,
    json: parsed,
  };
}

function resolveNodeRuntimePath() {
  if (process.env.ANDROID_FLEET_FORCE_BUNDLED_NODE === "1") return process.execPath;
  const candidates = [
    process.env.npm_node_execpath,
    process.env.NODE,
    "C:\\Program Files\\nodejs\\node.exe",
    "node",
  ].filter(Boolean);

  for (const candidate of candidates) {
    const probe = spawnSync(candidate, ["--version"], {
      encoding: "utf8",
      windowsHide: true,
      timeout: 5000,
    });
    if (probe.status === 0) return candidate;
  }

  return process.execPath;
}

function runPowerShellScript(scriptPath, args = [], options = {}) {
  const timeout = Number(options.timeout || 180000);
  const result = spawnSync("powershell.exe", [
    "-NoProfile",
    "-ExecutionPolicy",
    "Bypass",
    "-File",
    scriptPath,
    ...args,
  ], {
    cwd: path.dirname(scriptPath),
    encoding: "utf8",
    windowsHide: true,
    timeout,
  });

  return {
    ok: result.status === 0,
    status: result.status,
    script: scriptPath,
    stdout: result.stdout || "",
    stderr: result.stderr || "",
    error: result.error ? result.error.message : undefined,
    timedOut: Boolean(result.error && result.error.code === "ETIMEDOUT"),
  };
}

function restartAdbServer() {
  const adbPath = resolveAdbPath();
  const kill = runAdbServerCommand(adbPath, ["-P", "5038", "kill-server"]);
  const start = runAdbServerCommand(adbPath, ["-P", "5038", "start-server"]);
  const devices = runAdbServerCommand(adbPath, ["-P", "5038", "devices"]);
  const ok = kill.ok && start.ok && devices.ok;
  return {
    ok,
    adbPath,
    kill,
    start,
    devices,
    connectedAfter: countAdbDevices(devices.stdout),
  };
}

function describeFleetRefreshFailure(refresh, failedSteps) {
  const details = failedSteps.map((name) => {
    const result = refresh[name] || {};
    return [result.error, result.message, result.stderr, result.stdout]
      .map((value) => String(value || "").trim())
      .find(Boolean) || "詳細なし";
  }).join(" / ");
  if (/10001|活会员后使用|activate.*member/i.test(details)) {
    return "XiaoWei会員/APIが未有効です。XiaoWeiで会員コードを有効化してから同期してください。";
  }
  return `同期失敗工程: ${failedSteps.join(", ")} / ${details}`;
}

function runFirstSetup() {
  const adbPath = resolveAdbPath();
  const scanDevices = spawnSync("pnputil", ["/scan-devices"], {
    encoding: "utf8",
    windowsHide: true,
    timeout: 60000,
  });
  const xiaoweiStart = runAdbServerCommand(adbPath, ["-P", "5038", "start-server"]);
  const xiaoweiDevices = xiaoweiStart.ok ? runAdbServerCommand(adbPath, ["-P", "5038", "devices", "-l"]) : { ok: false, stdout: "", stderr: "", error: "adb -P 5038 start-server failed" };
  const connectedXiaowei = countAdbDevices(xiaoweiDevices.stdout);
  return {
    ok: Boolean(xiaoweiStart.ok),
    adbPath,
    bundledAdb: adbPath === path.join(__dirname, "tools", "platform-tools", "adb.exe"),
    xiaoweiRoot: resolveXiaoweiRoot(),
    usbScan: {
      ok: scanDevices.status === 0,
      status: scanDevices.status,
      stdout: scanDevices.stdout || "",
      stderr: scanDevices.stderr || "",
      error: scanDevices.error ? scanDevices.error.message : "",
    },
    defaultPort: {
      port: 5037,
      stopped: false,
      note: "既存の5037は停止せず、Fleetが両ポートを読み取ります。",
    },
    xiaoweiPort: {
      port: 5038,
      start: xiaoweiStart,
      devices: xiaoweiDevices,
      connected: connectedXiaowei,
    },
    connectedAfter: connectedXiaowei,
    next: [
      "スマホ側にUSBデバッグ許可が出たらOKを押す",
      "XiaoWeiを起動してデバイスをリフレッシュする",
      "管理ツールで端末トラブル診断を押す",
      "問題なければ新規端末取込を押す",
    ],
  };
}

function ensureAdbServerStarted() {
  const adbPath = resolveAdbPath();
  const start = runAdbServerCommand(adbPath, ["-P", "5038", "start-server"]);
  const devices = start.ok ? runAdbServerCommand(adbPath, ["-P", "5038", "devices"]) : { ok: false, stdout: "", stderr: "", error: "adb -P 5038 start-server failed" };
  console.log(`ADB server startup ${start.ok ? "OK" : "NG"}: ${adbPath} / devices=${countAdbDevices(devices.stdout)}${start.error || start.stderr ? " / " + (start.error || start.stderr).trim() : ""}`);
  return {
    ok: start.ok,
    adbPath,
    start,
    devices,
    connectedAfter: countAdbDevices(devices.stdout),
  };
}

function isLocalPortListening(port, timeoutMs = 500) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ host: "127.0.0.1", port });
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve(value);
    };
    socket.setTimeout(timeoutMs, () => finish(false));
    socket.once("connect", () => finish(true));
    socket.once("error", () => finish(false));
  });
}

async function resolveActiveAdbPorts() {
  const ports = [XIAOWEI_ADB_PORT];
  if (await isLocalPortListening(5037)) ports.push(5037);
  return ports;
}

async function scanActiveAdbDevices(options = {}) {
  const ports = await resolveActiveAdbPorts();
  return scanAdbDevicePorts({ ...options, ports });
}

function resolveAdbPath() {
  const xiaoweiRoot = resolveXiaoweiRoot();
  const candidates = [
    process.env.ADB_PATH,
    path.join(__dirname, "tools", "platform-tools", "adb.exe"),
    xiaoweiRoot ? path.join(xiaoweiRoot, "tools", "adb.exe") : "",
    path.join(XIAOWEI_DEFAULT_ROOT, "tools", "adb.exe"),
    "C:\\platform-tools\\adb.exe",
    "C:\\Android\\platform-tools\\adb.exe",
    "C:\\tools\\platform-tools\\adb.exe",
    path.join(os.homedir(), "Downloads", "platform-tools", "adb.exe"),
    path.join(os.homedir(), "Documents", "platform-tools", "adb.exe"),
    "adb",
  ].filter(Boolean);
  return candidates.find((candidate) => candidate === "adb" || fs.existsSync(candidate)) || "adb";
}

function resolveXiaoweiRoot() {
  const candidates = uniqueStrings([
    process.env.XIAOWEI_ROOT,
    XIAOWEI_DEFAULT_ROOT,
    path.join(os.homedir(), "Documents", "xiaowei_android"),
    path.join(os.homedir(), "Downloads", "xiaowei_android"),
    path.join(os.homedir(), "Desktop", "xiaowei_android"),
    "C:\\xiaowei_android",
    "C:\\XiaoWei\\xiaowei_android",
  ]);
  return candidates.find((candidate) => candidate && fs.existsSync(candidate)) || XIAOWEI_DEFAULT_ROOT;
}

function resolveXiaoweiScriptDir() {
  return process.env.XIAOWEI_SCRIPT_DIR || path.join(resolveXiaoweiRoot(), "script");
}

function resolveXiaoweiLogDir() {
  return process.env.XIAOWEI_LOG_DIR || path.join(resolveXiaoweiRoot(), "logs");
}

function runAdbServerCommand(adbPath, args) {
  const result = spawnSync(adbPath, args, {
    cwd: paths.root,
    encoding: "utf8",
    windowsHide: true,
    timeout: 15000,
  });
  return {
    ok: result.status === 0,
    status: result.status,
    command: [adbPath, ...args].join(" "),
    stdout: result.stdout || "",
    stderr: result.stderr || "",
    error: result.error && result.error.message || "",
  };
}

function countAdbDevices(stdout) {
  return parseAdbDevices(stdout).filter((device) => device.connected).length;
}

function inspectXiaoweiScriptDir() {
  const dir = resolveXiaoweiScriptDir();
  const exists = fs.existsSync(dir);
  const result = {
    ok: exists,
    dir,
    exists,
    writable: false,
    writeError: "",
    files: [],
    expectedTestScripts: [],
  };

  if (!exists) {
    result.error = "XiaoWei script folder was not found.";
    return result;
  }

  try {
    result.files = fs.readdirSync(dir, { withFileTypes: true })
      .filter((entry) => entry.isFile() && /\.js$/i.test(entry.name))
      .map((entry) => {
        const filePath = path.join(dir, entry.name);
        const stat = fs.statSync(filePath);
        return {
          name: entry.name,
          sizeBytes: stat.size,
          modifiedAt: stat.mtime.toISOString(),
        };
      })
      .sort((a, b) => b.modifiedAt.localeCompare(a.modifiedAt));
  } catch (error) {
    result.ok = false;
    result.error = "Failed to list XiaoWei script folder.";
    result.listError = error.message;
  }

  const fileNames = new Set(result.files.map((file) => file.name));
  result.expectedTestScripts = XIAOWEI_TEST_SCRIPT_FILES.map((name) => ({
    name,
    present: fileNames.has(name),
  }));

  const probePath = path.join(dir, ".android-fleet-write-test.tmp");
  try {
    fs.writeFileSync(probePath, `write test ${new Date().toISOString()}\n`, { flag: "wx" });
    fs.unlinkSync(probePath);
    result.writable = true;
  } catch (error) {
    result.writable = false;
    result.writeError = error.message;
    try {
      if (fs.existsSync(probePath)) fs.unlinkSync(probePath);
    } catch {
      // Ignore cleanup failures; the write status is already captured.
    }
  }

  return result;
}

function installXiaoweiTestScripts() {
  const targetDir = resolveXiaoweiScriptDir();
  const sourceDir = path.join(PUBLIC_DIR);
  const files = XIAOWEI_TEST_SCRIPT_FILES;
  const result = {
    ok: false,
    targetDir,
    copied: [],
    failed: [],
  };

  try {
    if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
    for (const name of files) {
      const source = path.join(sourceDir, name);
      const target = path.join(targetDir, name);
      try {
        fs.copyFileSync(source, target);
        result.copied.push(name);
      } catch (error) {
        result.failed.push({ name, error: error.message });
      }
    }
    result.ok = result.failed.length === 0;
    result.scripts = inspectXiaoweiScriptDir();
    return result;
  } catch (error) {
    result.error = error.message;
    result.scripts = inspectXiaoweiScriptDir();
    return result;
  }
}

function inspectLegacyMirrorScriptDir() {
  return inspectScriptDir({
    dir: resolveXiaoweiScriptDir(),
    files: XIAOWEI_TEST_SCRIPT_FILES,
    label: "XiaoWei",
  });
}

function installLegacyMirrorTestScripts() {
  return installTestScripts({
    targetDir: resolveXiaoweiScriptDir(),
    files: XIAOWEI_TEST_SCRIPT_FILES,
    inspect: inspectLegacyMirrorScriptDir,
  });
}

function inspectScriptDir({ dir, files, label }) {
  const exists = fs.existsSync(dir);
  const result = {
    ok: exists,
    dir,
    exists,
    writable: false,
    writeError: "",
    files: [],
    expectedTestScripts: [],
  };

  if (!exists) {
    result.error = `${label} script folder was not found.`;
    return result;
  }

  try {
    result.files = fs.readdirSync(dir, { withFileTypes: true })
      .filter((entry) => entry.isFile() && /\.js$/i.test(entry.name))
      .map((entry) => {
        const filePath = path.join(dir, entry.name);
        const stat = fs.statSync(filePath);
        return {
          name: entry.name,
          sizeBytes: stat.size,
          modifiedAt: stat.mtime.toISOString(),
        };
      })
      .sort((a, b) => b.modifiedAt.localeCompare(a.modifiedAt));
  } catch (error) {
    result.ok = false;
    result.error = `Failed to list ${label} script folder.`;
    result.listError = error.message;
  }

  const fileNames = new Set(result.files.map((file) => file.name));
  result.expectedTestScripts = files.map((name) => ({
    name,
    present: fileNames.has(name),
  }));

  const probePath = path.join(dir, ".android-fleet-write-test.tmp");
  try {
    fs.writeFileSync(probePath, `write test ${new Date().toISOString()}\n`, { flag: "wx" });
    fs.unlinkSync(probePath);
    result.writable = true;
  } catch (error) {
    result.writable = false;
    result.writeError = error.message;
    try {
      if (fs.existsSync(probePath)) fs.unlinkSync(probePath);
    } catch {
      // Ignore cleanup failures; the write status is already captured.
    }
  }

  return result;
}

function installTestScripts({ targetDir, files, inspect }) {
  const sourceDir = path.join(PUBLIC_DIR);
  const result = {
    ok: false,
    targetDir,
    copied: [],
    failed: [],
  };

  try {
    if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
    for (const name of files) {
      const source = path.join(sourceDir, name);
      const target = path.join(targetDir, name);
      try {
        fs.copyFileSync(source, target);
        result.copied.push(name);
      } catch (error) {
        result.failed.push({ name, error: error.message });
      }
    }
    result.ok = result.failed.length === 0;
    result.scripts = inspect();
    return result;
  } catch (error) {
    result.error = error.message;
    result.scripts = inspect();
    return result;
  }
}

function readXiaoweiLogTail(limit = 120) {
  const dir = resolveXiaoweiLogDir();
  const exists = fs.existsSync(dir);
  const result = {
    ok: exists,
    dir,
    exists,
    file: "",
    modifiedAt: "",
    lineCount: 0,
    sizeBytes: 0,
    lines: [],
  };
  if (!exists) {
    result.error = "XiaoWei log folder was not found.";
    return result;
  }

  const files = fs.readdirSync(dir, { withFileTypes: true })
    .filter((entry) => entry.isFile() && /\.log$/i.test(entry.name))
    .map((entry) => {
      const filePath = path.join(dir, entry.name);
      const stat = fs.statSync(filePath);
      return { filePath, name: entry.name, modifiedAt: stat.mtime, sizeBytes: stat.size };
    })
    .sort((a, b) => b.modifiedAt - a.modifiedAt);

  const latest = files[0];
  if (!latest) {
    result.error = "No XiaoWei log files were found.";
    return result;
  }

  result.file = latest.name;
  result.modifiedAt = latest.modifiedAt.toISOString();
  result.sizeBytes = latest.sizeBytes;
  const text = fs.readFileSync(latest.filePath, "utf8");
  const lines = text.split(/\r?\n/).filter(Boolean);
  result.lineCount = lines.length;
  result.lines = lines.slice(-Math.max(1, Math.min(500, Number(limit) || 120)));
  return result;
}

function readLegacyMirrorLogTail(limit = 120) {
  return readLogTail({
    dir: LEGACY_MIRROR_LOG_DIR,
    label: "XiaoWei",
    limit,
  });
}

function readLogTail({ dir, label, limit = 120 }) {
  const exists = fs.existsSync(dir);
  const result = {
    ok: exists,
    dir,
    exists,
    file: "",
    modifiedAt: "",
    lineCount: 0,
    sizeBytes: 0,
    lines: [],
  };
  if (!exists) {
    result.error = `${label} log folder was not found.`;
    return result;
  }

  const files = fs.readdirSync(dir, { withFileTypes: true })
    .filter((entry) => entry.isFile() && /\.(log|txt)$/i.test(entry.name))
    .map((entry) => {
      const filePath = path.join(dir, entry.name);
      const stat = fs.statSync(filePath);
      return { filePath, name: entry.name, modifiedAt: stat.mtime, sizeBytes: stat.size };
    })
    .sort((a, b) => b.modifiedAt - a.modifiedAt);

  const latest = files[0];
  if (!latest) {
    result.error = `No ${label} log files were found.`;
    return result;
  }

  result.file = latest.name;
  result.modifiedAt = latest.modifiedAt.toISOString();
  result.sizeBytes = latest.sizeBytes;
  const text = fs.readFileSync(latest.filePath, "utf8");
  const lines = text.split(/\r?\n/).filter(Boolean);
  result.lineCount = lines.length;
  result.lines = lines.slice(-Math.max(1, Math.min(500, Number(limit) || 120)));
  return result;
}

function parseLastJson(text) {
  const trimmed = String(text || "").trim();
  if (!trimmed) return null;
  try {
    return JSON.parse(trimmed);
  } catch {
    const lines = trimmed.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
    for (let index = lines.length - 1; index >= 0; index--) {
      if (!lines[index].startsWith("{")) continue;
      try {
        return JSON.parse(lines.slice(index).join("\n"));
      } catch {
        // Keep looking for a complete JSON object.
      }
    }
    return null;
  }
}

function setPcClipboardText(value) {
  const text = String(value === undefined || value === null ? "" : value);
  if (!text) {
    return { ok: false, error: "clipboard text is empty" };
  }
  const tempDir = path.join(paths.dataDir, "tmp");
  fs.mkdirSync(tempDir, { recursive: true });
  const tempPath = path.join(tempDir, `pc-clipboard-${Date.now()}-${Math.random().toString(16).slice(2)}.txt`);
  fs.writeFileSync(tempPath, text, "utf8");
  const quotedPath = tempPath.replace(/'/g, "''");
  const result = spawnSync("powershell.exe", [
    "-NoProfile",
    "-Command",
    `$p='${quotedPath}'; Set-Clipboard -Value (Get-Content -Raw -Encoding UTF8 -LiteralPath $p)`,
  ], {
    encoding: "utf8",
    windowsHide: true,
    timeout: 10000,
    maxBuffer: 1024 * 1024,
  });
  try {
    fs.unlinkSync(tempPath);
  } catch (_) {
    // Temporary clipboard source cleanup is best effort.
  }
  if (result.error) return { ok: false, error: result.error.message };
  if (result.status !== 0) {
    return {
      ok: false,
      error: String(result.stderr || result.stdout || `Set-Clipboard exited with ${result.status}`).trim(),
    };
  }
  return { ok: true, length: text.length };
}

async function maybeAdvanceDayTags() {
  const dbDir = path.join(paths.dataDir, "fleet-db");
  const result = await advanceDayTagsOnce({
    dbPath: path.join(dbDir, "fleet-db.json"),
    statePath: path.join(dbDir, "day-rollover-state.json"),
    eventsPath: path.join(dbDir, "events.jsonl"),
  });
  if (!result.skipped && result.changed) {
    regenerateTagBoard();
    appendAuditLog({
      type: "day_tags_advanced_local",
      level: "info",
      title: "DAY tags advanced in local fleet DB",
      details: {
        date: result.date,
        changed: result.changed,
      },
    });
  }
  return result;
}

function cleanText(value, maxLength) {
  const text = String(value === undefined || value === null ? "" : value).trim();
  return Number.isFinite(Number(maxLength)) ? text.slice(0, Number(maxLength)) : text;
}

function serveStatic(requestPath, res) {
  const normalizedPath = requestPath === "/" ? "/index.html" : requestPath;
  const filePath = path.normalize(path.join(PUBLIC_DIR, normalizedPath));

  if (!filePath.startsWith(PUBLIC_DIR)) {
    return sendText(res, 403, "Forbidden");
  }

  fs.readFile(filePath, (error, content) => {
    if (error) return sendText(res, 404, "Not found");
    res.writeHead(200, {
      "content-type": contentType(filePath),
      "cache-control": "no-store",
    });
    res.end(content);
  });
}

function serveScreenshot(requestPath, res) {
  const fileName = decodeURIComponent(requestPath.replace("/screenshots/", ""));
  const filePath = path.normalize(path.join(paths.screenshotsDir, fileName));

  if (!filePath.startsWith(paths.screenshotsDir)) {
    return sendText(res, 403, "Forbidden");
  }

  fs.readFile(filePath, (error, content) => {
    if (error) return sendText(res, 404, "Not found");
    res.writeHead(200, { "content-type": "image/png" });
    res.end(content);
  });
}

function serveDataFile(filePath, res) {
  const normalizedPath = path.normalize(filePath);
  if (!normalizedPath.startsWith(paths.dataDir)) {
    return sendText(res, 403, "Forbidden");
  }

  fs.readFile(normalizedPath, (error, content) => {
    if (error) return sendText(res, 404, "Not found");
    res.writeHead(200, {
      "content-type": contentType(normalizedPath),
      "cache-control": "no-store",
      "access-control-allow-origin": "*",
    });
    res.end(content);
  });
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return (
    {
      ".html": "text/html; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".json": "application/json; charset=utf-8",
      ".svg": "image/svg+xml",
    }[ext] || "application/octet-stream"
  );
}

function readJson(req, maxBytes = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const byteLimit = Number.isSafeInteger(maxBytes) && maxBytes > 0
      ? Math.min(maxBytes, 1024 * 1024)
      : 1024 * 1024;
    const chunks = [];
    let receivedBytes = 0;
    let settled = false;
    let tooLarge = false;
    const fail = (error) => {
      if (settled) return;
      settled = true;
      reject(error);
    };
    const declaredLength = Number(req.headers && req.headers["content-length"]);
    if (Number.isFinite(declaredLength) && declaredLength > byteLimit) {
      tooLarge = true;
      fail(new Error("Request too large"));
    }
    req.on("data", (chunk) => {
      if (tooLarge) return;
      receivedBytes += Buffer.byteLength(chunk);
      if (receivedBytes > byteLimit) {
        tooLarge = true;
        chunks.length = 0;
        fail(new Error("Request too large"));
        return;
      }
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    });
    req.on("end", () => {
      if (settled || tooLarge) return;
      try {
        const raw = new TextDecoder("utf-8", { fatal: true }).decode(Buffer.concat(chunks, receivedBytes));
        const parsed = raw ? JSON.parse(raw.replace(/^\uFEFF/, "")) : {};
        settled = true;
        resolve(parsed);
      } catch {
        fail(new Error("Invalid JSON"));
      }
    });
    req.on("error", fail);
  });
}

function sendJson(res, payload, status = 200) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,OPTIONS",
    "access-control-allow-headers": "content-type",
  });
  res.end(JSON.stringify(payload));
}

function sendPrivateJson(res, payload, status = 200) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store, private, max-age=0",
    pragma: "no-cache",
    expires: "0",
  });
  res.end(JSON.stringify(payload));
}

function sendText(res, status, text) {
  res.writeHead(status, {
    "content-type": "text/plain; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,OPTIONS",
    "access-control-allow-headers": "content-type",
  });
  res.end(text);
}

function sendNoContent(res) {
  res.writeHead(204, {
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,OPTIONS",
    "access-control-allow-headers": "content-type",
  });
  res.end();
}
