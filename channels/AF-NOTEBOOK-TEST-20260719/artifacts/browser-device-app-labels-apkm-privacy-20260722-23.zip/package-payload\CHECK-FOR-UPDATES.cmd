@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0FleetAgent\scripts\auto-update-browser-agent.ps1" -AgentRoot "%~dp0FleetAgent" -Force -FailOnError
if errorlevel 1 goto update_failed
echo.
echo Update check completed. Android Fleet can be started.
pause
exit /b 0

:update_failed
echo.
echo Update check failed. Review the rollback result above and the persistent update log before starting Android Fleet.
pause
exit /b 1
