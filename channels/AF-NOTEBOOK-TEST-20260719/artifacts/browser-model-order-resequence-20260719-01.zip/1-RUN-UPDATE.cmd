@echo off
setlocal
title Android Fleet Update
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0apply-update.ps1"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%EXIT_CODE%"=="0" echo Update failed. Send a screenshot of this window.
pause
exit /b %EXIT_CODE%