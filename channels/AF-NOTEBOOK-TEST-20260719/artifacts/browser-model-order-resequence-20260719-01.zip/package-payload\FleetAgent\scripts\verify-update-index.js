"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");

const [indexPath, publicKeyPath, expectedCustomerId = "", expectedPackageId = ""] = process.argv.slice(2);
if (!indexPath || !publicKeyPath) {
  console.error("Usage: node verify-update-index.js <index.json> <public.pem> [customerId] [packageId]");
  process.exit(2);
}

try {
  const index = readJson(indexPath);
  const signature = String(index.signature || "").trim();
  if (!signature) throw new Error("Update index signature is missing.");
  const unsigned = { ...index };
  delete unsigned.signature;
  const payload = Buffer.from(canonicalJson(unsigned), "utf8");
  const publicKey = fs.readFileSync(publicKeyPath, "utf8");
  if (!crypto.verify(null, payload, publicKey, Buffer.from(signature, "base64"))) {
    throw new Error("Update index signature is invalid.");
  }

  if (Number(index.schemaVersion) !== 1) throw new Error("Unsupported update index schema.");
  if (!String(index.updateId || "").trim()) throw new Error("Update ID is missing.");
  if (expectedCustomerId && String(index.customerId || "") !== expectedCustomerId) {
    throw new Error("Update customer does not match this package.");
  }
  if (expectedPackageId && String(index.packageId || "") !== expectedPackageId) {
    throw new Error("Update package type does not match this package.");
  }
  const artifact = index.artifact || {};
  if (!/^https:\/\//i.test(String(artifact.url || "")) && !/^http:\/\/127\.0\.0\.1(?::\d+)?\//i.test(String(artifact.url || ""))) {
    throw new Error("Update artifact URL must use HTTPS.");
  }
  if (!/^[0-9a-f]{64}$/i.test(String(artifact.sha256 || ""))) throw new Error("Update artifact SHA256 is invalid.");
  if (!(Number(artifact.bytes) > 0)) throw new Error("Update artifact size is invalid.");

  console.log(asciiJson({
    ok: true,
    updateId: String(index.updateId),
    displayName: String(index.displayName || index.updateId),
    customerId: String(index.customerId || ""),
    packageId: String(index.packageId || ""),
    publishedAt: String(index.publishedAt || ""),
    artifact: {
      url: String(artifact.url),
      sha256: String(artifact.sha256).toLowerCase(),
      bytes: Number(artifact.bytes),
    },
  }));
} catch (error) {
  console.error(error.message || String(error));
  process.exit(1);
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8").replace(/^\uFEFF/, ""));
}

function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

function asciiJson(value) {
  return JSON.stringify(value).replace(/[^\x00-\x7F]/g, (character) =>
    `\\u${character.charCodeAt(0).toString(16).padStart(4, "0")}`);
}

module.exports = { asciiJson, canonicalJson };
