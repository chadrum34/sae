﻿param(
    [int]$Port = 8787,
    [switch]$NoBrowser
)

$ErrorActionPreference = "Stop"

$AgentRoot = Split-Path -Parent $PSScriptRoot
$AppRoot = Join-Path $AgentRoot "app"
$NodePath = Join-Path $AgentRoot "runtime\node.exe"
$DataRoot = Join-Path $AppRoot "data"
$LicensePath = Join-Path $AppRoot "config\customer-license.json"
$PidPath = Join-Path $DataRoot "server.pid"
$StdoutPath = Join-Path $DataRoot "server.out.log"
$StderrPath = Join-Path $DataRoot "server.err.log"
$AutoUpdatePath = Join-Path $AgentRoot "scripts\auto-update-browser-agent.ps1"
$Url = "http://127.0.0.1:$Port/app"
$HealthUrl = "http://127.0.0.1:$Port/api/config"

function Read-FleetHealth {
    try {
        $result = Invoke-RestMethod -Uri $HealthUrl -TimeoutSec 2
        if ($result -and $result.ok) { return $result }
    } catch {
        return $null
    }
    return $null
}

function Test-ExpectedFleetReady {
    param([object]$Health)
    if (-not $Health -or -not $Health.license) { return $false }
    if ([string]$Health.license.customerId -ne [string]$ExpectedLicense.customerId) { return $false }
    if ([string]$Health.license.packageId -ne [string]$ExpectedLicense.packageId) { return $false }
    try {
        $actualDataRoot = [System.IO.Path]::GetFullPath([string]$Health.dataDir)
        return $actualDataRoot.Equals($ExpectedDataRoot, [System.StringComparison]::OrdinalIgnoreCase)
    } catch {
        return $false
    }
}

function Stop-ForeignFleetListener {
    param([object]$Health)
    $listeners = @(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)
    if (-not $listeners.Count) { return }
    foreach ($listener in $listeners) {
        $ownerId = [int]$listener.OwningProcess
        if ($ownerId -le 0 -or $ownerId -eq $PID) { continue }
        $process = Get-CimInstance Win32_Process -Filter "ProcessId = $ownerId" -ErrorAction SilentlyContinue
        if (-not $process) { continue }
        $commandLine = [string]$process.CommandLine
        $processName = [string]$process.Name
        $looksLikeFleet = $commandLine -match '(?i)server[.]js' -and
            ($processName -ieq 'node.exe' -or $processName -match '(?i)^Android Fleet')
        if (-not $looksLikeFleet) {
            throw "Port $Port is already used by another application (PID $ownerId). Nothing was stopped."
        }
        $runningCustomer = if ($Health -and $Health.license) { [string]$Health.license.customerId } else { "unknown" }
        Write-Warning "別のAndroid Fleetを停止します。customerId=$runningCustomer PID=$ownerId"
        Stop-Process -Id $ownerId -Force -ErrorAction Stop
        Wait-Process -Id $ownerId -Timeout 10 -ErrorAction SilentlyContinue
    }
}

function Read-OwnedProcess {
    if (-not (Test-Path -LiteralPath $PidPath)) { return $null }
    $savedPid = 0
    if (-not [int]::TryParse((Get-Content -LiteralPath $PidPath -Raw -ErrorAction SilentlyContinue).Trim(), [ref]$savedPid)) {
        return $null
    }
    $process = Get-CimInstance Win32_Process -Filter "ProcessId = $savedPid" -ErrorAction SilentlyContinue
    if (-not $process) { return $null }
    $expectedNode = [System.IO.Path]::GetFullPath($NodePath)
    $actualNode = if ($process.ExecutablePath) { [System.IO.Path]::GetFullPath($process.ExecutablePath) } else { "" }
    if (-not $actualNode.Equals($expectedNode, [System.StringComparison]::OrdinalIgnoreCase)) { return $null }
    if (-not $process.CommandLine -or $process.CommandLine.IndexOf("server.js", [System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
        return $null
    }
    return $process
}

if (-not (Test-Path -LiteralPath $NodePath)) { throw "Bundled Node.js runtime was not found: $NodePath" }
if (-not (Test-Path -LiteralPath (Join-Path $AppRoot "server.js"))) { throw "Fleet Agent files were not found: $AppRoot" }
if (-not (Test-Path -LiteralPath $LicensePath)) { throw "Customer license was not found: $LicensePath" }
$ExpectedLicense = Get-Content -LiteralPath $LicensePath -Raw -Encoding UTF8 | ConvertFrom-Json
$ExpectedDataRoot = [System.IO.Path]::GetFullPath($DataRoot)
New-Item -ItemType Directory -Force -Path $DataRoot | Out-Null

$existingHealth = Read-FleetHealth
if (Test-ExpectedFleetReady $existingHealth) {
    if ($NoBrowser) {
        Write-Host "Android Fleet is already running."
    } else {
        Start-Process $Url
        Write-Host "Android Fleet is already running. The browser was opened."
    }
    exit 0
}
if ($existingHealth -or @(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue).Count) {
    Stop-ForeignFleetListener -Health $existingHealth
}

$owned = Read-OwnedProcess
if ($owned) {
    Stop-Process -Id $owned.ProcessId -Force -ErrorAction SilentlyContinue
    Wait-Process -Id $owned.ProcessId -Timeout 5 -ErrorAction SilentlyContinue
}
Remove-Item -LiteralPath $PidPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $StdoutPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $StderrPath -Force -ErrorAction SilentlyContinue

if (Test-Path -LiteralPath $AutoUpdatePath) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $AutoUpdatePath -AgentRoot $AgentRoot
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "自動更新を確認できませんでした。現在版を起動します。"
    }
}

$previousPort = $env:PORT
$previousBrowserAgentMode = $env:ANDROID_FLEET_BROWSER_AGENT
$previousRemoteHttpsPort = $env:ANDROID_FLEET_REMOTE_HTTPS_PORT
$env:PORT = [string]$Port
$env:ANDROID_FLEET_BROWSER_AGENT = "1"
$env:ANDROID_FLEET_REMOTE_HTTPS_PORT = "8443"
try {
    $process = Start-Process -FilePath $NodePath -ArgumentList @("server.js") -WorkingDirectory $AppRoot `
        -WindowStyle Hidden -RedirectStandardOutput $StdoutPath -RedirectStandardError $StderrPath -PassThru
} finally {
    if ($null -eq $previousPort) { Remove-Item Env:PORT -ErrorAction SilentlyContinue }
    else { $env:PORT = $previousPort }
    if ($null -eq $previousBrowserAgentMode) { Remove-Item Env:ANDROID_FLEET_BROWSER_AGENT -ErrorAction SilentlyContinue }
    else { $env:ANDROID_FLEET_BROWSER_AGENT = $previousBrowserAgentMode }
    if ($null -eq $previousRemoteHttpsPort) { Remove-Item Env:ANDROID_FLEET_REMOTE_HTTPS_PORT -ErrorAction SilentlyContinue }
    else { $env:ANDROID_FLEET_REMOTE_HTTPS_PORT = $previousRemoteHttpsPort }
}
$process.Id | Set-Content -LiteralPath $PidPath -Encoding ASCII

for ($attempt = 0; $attempt -lt 60; $attempt += 1) {
    Start-Sleep -Milliseconds 500
    if ($process.HasExited) { break }
    $health = Read-FleetHealth
    if (Test-ExpectedFleetReady $health) {
        if ($NoBrowser) {
            Write-Host "Android Fleet started."
        } else {
            Start-Process $Url
            Write-Host "Android Fleet started. The browser was opened."
        }
        exit 0
    }
}

$errorText = Get-Content -LiteralPath $StderrPath -Raw -ErrorAction SilentlyContinue
throw "Android Fleet did not start. $errorText"
