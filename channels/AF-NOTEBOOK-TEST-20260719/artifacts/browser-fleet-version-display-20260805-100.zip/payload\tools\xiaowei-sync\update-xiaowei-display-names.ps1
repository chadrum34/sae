param(
    [switch]$Apply,
    [switch]$ForceUpdate,
    [string]$NameMapPath = "$PSScriptRoot\xiaowei-device-names.json",
    [string]$TagBoardPath = "$PSScriptRoot\android-fleet-os\data\fleet-db\device-tag-board.json",
    [string]$OutputPath = "$PSScriptRoot\android-fleet-os\data\fleet-db\xiaowei-display-name-plan.json",
    [int]$MaxLength = 28,
    [string]$DeviceDbPath = "$env:APPDATA\WECAN88888\device.db",
    [string]$SqlitePath = "C:\tools\platform-tools\sqlite3.exe",
    [string]$ApiScriptPath = "",
    [ValidateRange(0, 3)]
    [int]$RetryCount = 1,
    [ValidateRange(0, 5000)]
    [int]$RetryDelayMilliseconds = 250
)

$ErrorActionPreference = 'Stop'
$apiScript = if ($ApiScriptPath) { $ApiScriptPath } else { Join-Path $PSScriptRoot 'xiaowei-tag-api.ps1' }
$MarkGood = [string][char]0x25CB
$MarkMaybe = [string][char]0x25B3
$MarkUnknown = '?'
$MarkBad = 'x'
$MarkError = '!'
$MarkDone = [string][char]0x2713
$MarkTodo = [string][char]0x25CB
$LabelMinute = [string][char]0x5206
$LabelAdditional = [string]::Concat([char]0x8FFD, [char]0x52A0)

function Get-PropValue {
    param($Object, [string]$Name, $Default = '')
    $prop = $Object.PSObject.Properties[$Name]
    if ($prop) { return $prop.Value }
    $Default
}

function Short-BaseName {
    param([string]$Name)
    $text = $Name.Trim()
    if (-not $text) { return 'UNK' }
    if ($text -match '^[A-Fa-f0-9]{8,}$') { return 'UNK' }
    if ($text -match '^[A-Za-z0-9]{8,}$' -and $text -match '\d') { return 'UNK' }
    if ($text -match 'Galaxy A25') { return 'A25' }
    if ($text -match 'Galaxy A06') { return 'A06' }
    if ($text -match 'Galaxy S26 Ultra') { return 'S26U' }
    if ($text -match 'Galaxy S20') { return 'S20' }
    if ($text -match 'Redmi Note 10 JE') { return '10JE' }
    if ($text -match 'Redmi Note 10T') { return '10T' }
    if ($text -match 'Redmi Note 9T') { return '9T' }
    if ($text -match 'Redmi 9T') { return '9T' }
    if ($text -match 'Reno13 A') { return '13A' }
    if ($text -match 'Pixel 9a') { return '9a' }
    if ($text -match 'Pixel 9 Pro XL') { return '9PXL' }
    if ($text -match 'P20 lite') { return 'P20L' }
    if ($text -match 'nova lite 3') { return 'NL3' }
    if ($text -match 'AQUOS sense3') { return 'S3' }
    if ($text -match 'arrows We2') { return 'We2' }
    if ($text -match 'arrows We') { return 'We' }
    if ($text -match 'OPPO A5 2020') { return 'A5' }
    if ($text -match '^SM-([A-Z0-9]+)$') { return $Matches[1] }
    $text = $text -replace '^Galaxy ', ''
    $text = $text -replace '^Redmi Note ', ''
    $text = $text -replace '^Redmi ', ''
    $text = $text -replace '^OPPO ', ''
    $text = $text -replace '^HUAWEI ', ''
    $text = $text -replace ' 5G$', ''
    $text = $text -replace ' lite$', 'L'
    $text
}

function Get-DayLabel {
    param([string]$Day, [string]$AllTags, [string]$Status)
    if (Test-InactiveDevice -AllTags $AllTags -Status $Status) { return '' }
    if ($Day -match '^DAY_(\d{2})$') { return ('D{0}' -f [int]$Matches[1]) }
    if ($Day -eq 'DAY_UNK') { return 'D?' }
    ''
}

function Test-InactiveDevice {
    param([string]$AllTags, [string]$Status)
    if ($Status -eq 'WAITING' -or $Status -eq 'INACTIVE' -or $Status -eq 'NO CYCLE') { return $true }
    if ($AllTags -match '(^| / )(GROUP_INACTIVE|GROUP_REST|WAITING)( / |$)') { return $true }
    return $false
}

function Get-TaskLabel {
    param([string]$Video180, [string]$Video10, [string]$AllTags, [string]$Decision, [string]$Status)
    if ($Decision -eq 'DEC_RESET' -or $AllTags -match '(^| / )DEC_RESET( / |$)') { return '' }
    if ($Decision -eq 'DEC_WITHDRAW' -or $AllTags -match '(^| / )(DEC_WITHDRAW|WITHDRAW_3000)( / |$)') { return '' }
    if (Test-InactiveDevice -AllTags $AllTags -Status $Status) { return '' }

    $v180Done = $AllTags -match '(^| / )V180_DONE( / |$)' -or $Video180 -eq 'V180_DONE'
    $v10Done = $AllTags -match '(^| / )V10_DONE( / |$)' -or $Video10 -eq 'V10_DONE'
    $parts = New-Object System.Collections.Generic.List[string]

    if (-not $v180Done) {
        if ($Video180 -match '^V180_') {
            $parts.Add(('180{0}{1}' -f $script:LabelMinute, $script:MarkTodo))
        }
    }

    if (-not $v10Done -and $Video10 -match '^V10_') {
        $parts.Add(('{0}{1}' -f $script:LabelAdditional, $script:MarkTodo))
    }

    $parts.ToArray() -join ' '
}

function Get-JudgmentMark {
    param($Row)
    $tags = [string](Get-PropValue $Row 'allTags')
    $status = [string](Get-PropValue $Row 'status')
    $decision = [string](Get-PropValue $Row 'decision')
    $currentYen = [double]0
    [void][double]::TryParse([string](Get-PropValue $Row 'currentYen' '0'), [ref]$currentYen)
    $projectedYen = [double]0
    [void][double]::TryParse([string](Get-PropValue $Row 'projectedGrossYen' '0'), [ref]$projectedYen)

    if ($decision -eq 'DEC_RESET' -or $tags -match 'DEC_RESET|NG_3000') { return $script:MarkBad }
    if ($status -eq 'WAITING' -or $tags -match 'WAITING') { return $script:MarkUnknown }
    if ($tags -match 'CI_ERR|STATE_ERROR') { return $script:MarkError }
    if ($currentYen -ge 3000 -or $decision -eq 'DEC_3000' -or $decision -eq 'DEC_5000' -or $tags -match 'OK_3000|WITHDRAW_3000|DEC_3000|DEC_5000') { return $script:MarkGood }
    if ($projectedYen -ge 3000) { return $script:MarkMaybe }
    if ($projectedYen -gt 0 -and $projectedYen -lt 3000) { return $script:MarkBad }
    $script:MarkUnknown
}

function Get-StateLabel {
    param([string]$AllTags, [string]$Decision, [string]$Status)
    if ($Decision -eq 'DEC_RESET' -or $AllTags -match '(^| / )DEC_RESET( / |$)') { return 'RST' }
    if ($Status -eq 'WAITING' -or $AllTags -match '(^| / )WAITING( / |$)') { return '' }
    if ($AllTags -match '(^| / )LOCAL_ONLY( / |$)') { return 'LOC' }
    ''
}

function Trim-DisplayName {
    param([string]$Name, [int]$Limit)
    if ($Name.Length -le $Limit) { return $Name }
    $Name.Substring(0, [Math]::Max(1, $Limit - 3)) + '...'
}

function Remove-LeadingJudgmentMark {
    param([string]$Name)
    $text = ([string]$Name).TrimStart()
    $marks = @(
        [string][char]0x25CB,
        [string][char]0x25EF,
        [string][char]0x25B3,
        [string][char]0x25A1,
        [string][char]0x00D7,
        'x',
        '?',
        '!',
        [string][char]0x2713
    )
    foreach ($mark in $marks) {
        if ($text -eq $mark) { return '' }
        if ($text.StartsWith($mark + ' ')) {
            return $text.Substring(($mark + ' ').Length)
        }
    }
    $text
}

function Normalize-ComparableName {
    param([string]$Name)
    $text = ([string]$Name).Trim()
    if ($text -match '^uffffff81uffffff9b D\d+') {
        return $script:MarkGood + $text.Substring('uffffff81uffffff9b'.Length)
    }
    $text
}

function Escape-SqlText {
    param([string]$Text)
    ([string]$Text) -replace "'", "''"
}

function Set-LocalDeviceName {
    param([string]$Serial, [string]$Name)
    if (-not (Test-Path $DeviceDbPath)) { return $false }
    if (-not (Test-Path $SqlitePath)) { return $false }
    $safeSerial = Escape-SqlText $Serial
    $safeName = Escape-SqlText $Name
    & $SqlitePath $DeviceDbPath "update device set name = '$safeName' where onlySerial = '$safeSerial';" | Out-Null
    return $true
}

function Get-SafeSyncTarget {
    param($Plan)
    $managementId = ([string](Get-PropValue $Plan 'managementId' '')).Trim()
    if ($managementId) {
        $safeManagementId = $managementId -replace '[\x00-\x1F\x7F]', ''
        if ($safeManagementId) {
            return $safeManagementId.Substring(0, [Math]::Min(40, $safeManagementId.Length))
        }
    }
    $serial = ([string](Get-PropValue $Plan 'serial' '')).Trim()
    if (-not $serial) { return 'unknown-device' }
    $suffixLength = [Math]::Min(4, $serial.Length)
    return '***' + $serial.Substring($serial.Length - $suffixLength)
}

function Get-SyncFailureCode {
    param([string]$Message)
    $text = [string]$Message
    if ($text -match '(?i)websocket|remote server|connect|connection|timed?\s*out|timeout') {
        return 'transport_error'
    }
    if ($text -match '(?i)convertfrom-json|json|response') { return 'invalid_response' }
    if ($text -match '(?i)xiaowei api error|api error|code') { return 'api_rejected' }
    return 'api_invocation_failed'
}

function Invoke-XiaoweiDisplayNameUpdate {
    param($Plan)
    try {
        $rawResponse = @(& $script:apiScript `
            -Action UpdateDevice `
            -Device $Plan.serial `
            -Name $Plan.displayName `
            -ErrorAction Stop)
        $responseText = (($rawResponse | ForEach-Object { [string]$_ }) -join "`n").Trim()
        if (-not $responseText) { throw 'XiaoWei API returned an empty response.' }
        $response = $responseText | ConvertFrom-Json -ErrorAction Stop
        if ([string]$response.code -ne '10000') {
            throw "XiaoWei API error code $($response.code)"
        }
        return [pscustomobject]@{ ok = $true; code = '' }
    }
    catch {
        return [pscustomobject]@{
            ok = $false
            code = Get-SyncFailureCode ([string]$_.Exception.Message)
        }
    }
}

if (-not (Test-Path $NameMapPath)) {
    throw "Name map not found: $NameMapPath"
}
if (-not (Test-Path $TagBoardPath)) {
    throw "Tag Board JSON not found: $TagBoardPath"
}

$nameMap = Get-Content -Raw -Encoding UTF8 $NameMapPath | ConvertFrom-Json
$rowsRaw = Get-Content -Raw -Encoding UTF8 $TagBoardPath | ConvertFrom-Json
$rows = @($rowsRaw)
if ($rows.Count -eq 1 -and $rows[0] -is [array]) {
    $rows = @($rows[0])
}

$plans = @(
foreach ($row in $rows) {
    $serial = [string]$row.serial
    $baseName = [string](Get-PropValue $nameMap $serial ([string]$row.name))
    $uiNameOverride = [string](Get-PropValue $row 'uiNameOverride' '')
    $deviceDisplayCode = [string](Get-PropValue $row 'deviceDisplayCode' '')
    $carrierCode = [string](Get-PropValue $row 'carrierCode' '')
    $shortName = if ($deviceDisplayCode.Trim()) {
        $deviceDisplayCode.Trim()
    } elseif ($uiNameOverride.Trim()) {
        $uiNameOverride.Trim()
    } else {
        Short-BaseName $baseName
    }
    $dayLabel = Get-DayLabel `
        -Day ([string](Get-PropValue $row 'day' '')) `
        -AllTags ([string](Get-PropValue $row 'allTags' '')) `
        -Status ([string](Get-PropValue $row 'status' ''))
    $taskLabel = Get-TaskLabel `
        -Video180 ([string](Get-PropValue $row 'video180' '')) `
        -Video10 ([string](Get-PropValue $row 'video10' '')) `
        -AllTags ([string](Get-PropValue $row 'allTags' '')) `
        -Decision ([string](Get-PropValue $row 'decision' '')) `
        -Status ([string](Get-PropValue $row 'status' ''))
    $displayName = Trim-DisplayName ((@($dayLabel, $taskLabel, $shortName, $carrierCode) | Where-Object { ([string]$_).Trim() }) -join ' ') $MaxLength

    [pscustomobject]@{
        managementId = $row.managementId
        serial = $serial
        baseName = $baseName
        currentXiaoweiName = [string](Get-PropValue $row 'xiaoweiName' ([string]$row.name))
        displayName = $displayName
        uiNameOverride = $uiNameOverride
        mark = ''
        day = $dayLabel
        state = ''
        video180 = $row.video180
        video10 = $row.video10
        decision = $row.decision
        status = $row.status
        currentYen = $row.currentYen
        projectedGrossYen = $row.projectedGrossYen
        allTags = $row.allTags
    }
}
)

New-Item -ItemType Directory -Force -Path (Split-Path -Parent $OutputPath) | Out-Null
$plans | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 $OutputPath

$changedPlans = @($plans | Where-Object { (Normalize-ComparableName $_.currentXiaoweiName) -ne (Normalize-ComparableName $_.displayName) })
$targetPlans = @()
$skipped = 0
foreach ($plan in $plans) {
    if (-not $ForceUpdate -and (Normalize-ComparableName $plan.currentXiaoweiName) -eq (Normalize-ComparableName $plan.displayName)) {
        $skipped++
    } else {
        $targetPlans += $plan
    }
}

$applied = 0
$attempted = 0
$localDbUpdated = 0
$localDbSkipped = 0
$localDbFailed = 0
$xiaoweiRunning = [bool](Get-Process -Name xiaowei -ErrorAction SilentlyContinue)
$pending = @($targetPlans | ForEach-Object {
    [pscustomobject]@{ plan = $_; code = ''; attempts = 0 }
})

if ($Apply) {
    for ($pass = 0; $pass -le $RetryCount -and $pending.Count -gt 0; $pass++) {
        if ($pass -gt 0 -and $RetryDelayMilliseconds -gt 0) {
            Start-Sleep -Milliseconds $RetryDelayMilliseconds
        }
        $nextPending = @()
        foreach ($item in $pending) {
            $attempted++
            $attempt = Invoke-XiaoweiDisplayNameUpdate -Plan $item.plan
            $item.attempts = [int]$item.attempts + 1
            if (-not $attempt.ok) {
                $item.code = $attempt.code
                $nextPending += $item
                continue
            }

            if ($xiaoweiRunning) {
                $localDbSkipped++
            } else {
                try {
                    if (Set-LocalDeviceName -Serial $item.plan.serial -Name $item.plan.displayName) {
                        $localDbUpdated++
                    }
                }
                catch {
                    $localDbFailed++
                }
            }
            $applied++
        }
        $pending = @($nextPending)
    }
}

$failures = @(if ($Apply) {
    $pending | ForEach-Object {
        [pscustomobject]@{
            target = Get-SafeSyncTarget $_.plan
            code = $_.code
            attempts = $_.attempts
        }
    }
})
$warningParts = @()
if ($Apply -and $xiaoweiRunning -and $localDbSkipped -gt 0) {
    $warningParts += 'XiaoWei is running; local device.db name updates were skipped. Close XiaoWei, rerun display-name sync, then start XiaoWei.'
}
if ($localDbFailed -gt 0) {
    $warningParts += 'Some local device.db name updates failed after the XiaoWei API accepted them.'
}
if ($failures.Count -gt 0) {
    $warningParts += "XiaoWei display-name updates failed for $($failures.Count) device(s) after retry."
}

$result = [pscustomobject]@{
    ok = -not $Apply -or $failures.Count -eq 0
    apply = [bool]$Apply
    forceUpdate = [bool]$ForceUpdate
    count = $plans.Count
    changed = $changedPlans.Count
    requested = if ($Apply) { $targetPlans.Count } else { 0 }
    attempted = $attempted
    retryCount = $RetryCount
    retryAttempts = [Math]::Max(0, $attempted - $targetPlans.Count)
    applied = $applied
    failed = $failures.Count
    skipped = $skipped
    failures = $failures
    localDbUpdated = $localDbUpdated
    localDbSkipped = $localDbSkipped
    localDbFailed = $localDbFailed
    xiaoweiRunning = $xiaoweiRunning
    warning = $warningParts -join ' '
    outputPath = $OutputPath
    legend = [ordered]@{
        good = '3000 yen reached, OK_3000, or withdrawal candidate'
        maybe = 'projected 3000 yen possible'
        unknown = 'waiting, unknown, or undecided'
        bad = 'projected below 3000 yen'
        error = 'error tag exists'
        task180Done = 'V180_DONE'
        task180Todo = 'V180 tag exists, not done'
        task180Unknown = 'no V180 tag'
        task10Todo = 'V10 tag exists'
        task10Absent = 'no V10 tag, no display'
    }
    sample = @($plans | Select-Object -First 12 managementId, displayName, day, status)
}

$result | ConvertTo-Json -Depth 8 -Compress
if ($Apply -and $failures.Count -gt 0) { exit 1 }
