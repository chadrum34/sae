﻿param(
    [string]$AppRoot = "",
    [string]$NodePath = "",
    [string]$RunLogPath = "",
    [switch]$NoLaunch,
    [switch]$NoStop,
    [switch]$NonInteractive
)

$ErrorActionPreference = "Stop"
$PatchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ManifestPath = Join-Path $PatchRoot "update-manifest.json"
$MergePath = Join-Path $PatchRoot "data-merge.json"
$PayloadRoot = Join-Path $PatchRoot "payload"
$PackagePayloadRoot = Join-Path $PatchRoot "package-payload"
$requestedRunLogPath = $RunLogPath
$RunLogPath = ""
$RunLogLines = New-Object System.Collections.Generic.List[string]

function Get-Sha256 {
    param([string]$Path)
    $stream = $null
    $sha = $null
    try {
        $stream = [System.IO.File]::Open(
            $Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            [System.IO.FileShare]::ReadWrite
        )
        $sha = [System.Security.Cryptography.SHA256]::Create()
        ([System.BitConverter]::ToString($sha.ComputeHash($stream))).Replace("-", "").ToLowerInvariant()
    } finally {
        if ($stream) { $stream.Dispose() }
        if ($sha) { $sha.Dispose() }
    }
}

function Get-AppliedUpdateSummary {
    param([string]$Root)
    $appliedPath = Join-Path $Root "config\applied-updates.json"
    if (-not (Test-Path -LiteralPath $appliedPath)) { return "(記録なし)" }
    try {
        $entries = @(Read-Json $appliedPath)
        $ids = @($entries | ForEach-Object { [string]$_.updateId } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        if (-not $ids.Count) { return "(記録なし)" }
        if ($ids.Count -gt 8) { $ids = @($ids | Select-Object -Last 8); return "... / $($ids -join ' / ')" }
        return ($ids -join " / ")
    } catch {
        return "(読取不可: $($_.Exception.Message))"
    }
}

function New-VersionMismatchMessage {
    param(
        [string]$DiagnosticCode,
        [string]$RelativePath,
        [bool]$TargetExists,
        [string]$CurrentHash,
        [string[]]$AcceptedOldHashes,
        [string]$NewHash,
        [object]$UpdateManifest,
        [string]$AppliedUpdateSummary
    )
    $currentDisplay = if ($TargetExists) { $CurrentHash } else { "(ファイルなし)" }
    $acceptedDisplay = if (@($AcceptedOldHashes).Count) { @($AcceptedOldHashes) -join "`n  - " } else { "(許可された旧版なし)" }
    @(
        "本体の版が想定と異なります: $RelativePath",
        "診断コード: $DiagnosticCode",
        "更新ID: $([string]$UpdateManifest.updateId)",
        "顧客ID: $([string]$UpdateManifest.customerId)",
        "失敗ファイル: $RelativePath",
        "現在SHA256: $currentDisplay",
        "許可旧版SHA256:",
        "  - $acceptedDisplay",
        "更新後SHA256: $NewHash",
        "適用済み更新ID: $AppliedUpdateSummary",
        "全体版を使うか、現在の版に合う差分を作り直してください。"
    ) -join "`n"
}

function Get-ShortHash {
    param([string]$Hash)
    if ([string]::IsNullOrWhiteSpace($Hash)) { return "missing" }
    if ($Hash.Length -le 12) { return $Hash }
    return $Hash.Substring(0, 12)
}

function Add-PreflightIssue {
    param(
        [object]$Issues,
        [object]$Summaries,
        [string]$Code,
        [string]$RelativePath,
        [string]$CurrentHash,
        [string]$NewHash,
        [int]$AcceptedCount,
        [string]$Detail
    )
    $Issues.Add($Detail)
    $Summaries.Add("$Code | $RelativePath | cur=$(Get-ShortHash $CurrentHash) | new=$(Get-ShortHash $NewHash) | accepted=$AcceptedCount")
}

function Protect-RunLogText {
    param([string]$Text)
    $safe = [string]$Text
    if ([string]::IsNullOrWhiteSpace($safe)) { return $safe }
    $safe = [regex]::Replace($safe, '(?i)[a-z]:\\Users\\[^\\\r\n]+', '<USERPROFILE>')
    $safe = [regex]::Replace($safe, '(?i)\\\\[^\\\r\n]+\\Users\\[^\\\r\n]+', '<USERPROFILE>')
    if (-not [string]::IsNullOrWhiteSpace($env:COMPUTERNAME)) {
        $safe = $safe.Replace($env:COMPUTERNAME, '<COMPUTER>')
    }
    return $safe
}

function Add-RunLogLine {
    param([string]$Text)
    $RunLogLines.Add((Protect-RunLogText $Text))
}

function Save-RunLog {
    if ([string]::IsNullOrWhiteSpace($RunLogPath)) { return }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $RunLogPath) | Out-Null
    $lines = @(
        "Android Fleet update result",
        "generatedAtUtc: $((Get-Date).ToUniversalTime().ToString('o'))",
        "privacy: Windows user name, computer name, and absolute user-profile paths are not recorded."
    ) + @($RunLogLines)
    [System.IO.File]::WriteAllLines($RunLogPath, $lines, [System.Text.UTF8Encoding]::new($true))
}

function Convert-ToAppRoot {
    param([string]$Candidate)
    if ([string]::IsNullOrWhiteSpace($Candidate)) { return "" }
    $candidatePath = [System.IO.Path]::GetFullPath($Candidate)
    foreach ($path in @(
        $candidatePath,
        (Join-Path $candidatePath "FleetAgent\app"),
        (Join-Path $candidatePath "resources\app"),
        (Join-Path $candidatePath "Android Fleet-win32-x64\resources\app")
    )) {
        if ((Test-Path -LiteralPath (Join-Path $path "server.js")) -and
            (Test-Path -LiteralPath (Join-Path $path "config\customer-license.json"))) {
            return [System.IO.Path]::GetFullPath($path)
        }
    }
    return ""
}

function Resolve-AppRoot {
    param(
        [string]$Requested,
        [string]$ExpectedCustomerId = "",
        [string]$ExpectedPackageId = ""
    )
    $resolved = Convert-ToAppRoot $Requested
    if ($resolved) { return $resolved }

    $parent = Split-Path -Parent $PatchRoot
    foreach ($candidate in @($PatchRoot, $parent, (Split-Path -Parent $parent))) {
        $resolved = Convert-ToAppRoot $candidate
        if ($resolved -and (Test-AppRootIdentity -Root $resolved -ExpectedCustomerId $ExpectedCustomerId -ExpectedPackageId $ExpectedPackageId)) {
            return $resolved
        }
    }

    # A common delivery layout is Downloads\AndroidFleet-Test-Latest\Android Fleet-win32-x64
    # with this patch extracted directly under Downloads. Search only one nearby
    # folder level and require the customer/package identity to match.
    foreach ($searchRoot in @($parent, (Split-Path -Parent $parent)) | Select-Object -Unique) {
        if (-not (Test-Path -LiteralPath $searchRoot)) { continue }
        foreach ($folder in @(Get-ChildItem -LiteralPath $searchRoot -Directory -ErrorAction SilentlyContinue)) {
            $resolved = Convert-ToAppRoot $folder.FullName
            if ($resolved -and (Test-AppRootIdentity -Root $resolved -ExpectedCustomerId $ExpectedCustomerId -ExpectedPackageId $ExpectedPackageId)) {
                return $resolved
            }
        }
    }

    if ($NonInteractive) { throw "Android Fleet本体が見つかりません。-AppRoot で resources\\app を指定してください。" }

    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = "Android Fleet-win32-x64 フォルダを選択してください"
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        throw "更新をキャンセルしました。"
    }
    $resolved = Convert-ToAppRoot $dialog.SelectedPath
    if (-not $resolved) { throw "選択した場所にAndroid Fleet本体がありません。" }
    return $resolved
}

function Test-AppRootIdentity {
    param(
        [string]$Root,
        [string]$ExpectedCustomerId = "",
        [string]$ExpectedPackageId = ""
    )
    try {
        $candidate = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $Root "config\customer-license.json") | ConvertFrom-Json
        if ($ExpectedCustomerId -and ([string]$candidate.customerId -ne $ExpectedCustomerId)) { return $false }
        if ($ExpectedPackageId -and ([string]$candidate.packageId -ne $ExpectedPackageId)) { return $false }
        return $true
    } catch {
        return $false
    }
}

function Stop-AppProcesses {
    param([string]$Root)
    $installRoot = [System.IO.Path]::GetFullPath((Join-Path $Root "..\.."))
    $escaped = [regex]::Escape($installRoot)
    $targets = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        $commandLine = [string]$_.CommandLine
        [int]$_.ProcessId -ne $PID -and
        $commandLine -notmatch '(?i)(apply-update[.]ps1|1-[^\\/]*[.]bat|1-RUN-UPDATE[.]cmd)' -and
        (([string]$_.ExecutablePath -match "^$escaped") -or $commandLine -match $escaped)
    })
    foreach ($process in $targets) {
        try { Stop-Process -Id $process.ProcessId -Force -ErrorAction Stop } catch {
            throw "Android Fleetを終了できませんでした。画面を閉じて、もう一度更新してください。"
        }
    }

    # Also stop a stale Android Fleet server that owns 8787 but was launched by
    # node.exe with a relative "server.js" command line. Such a process is not
    # necessarily discoverable from the installation path above.
    $knownIds = @($targets | ForEach-Object { [int]$_.ProcessId })
    foreach ($listener in @(Get-NetTCPConnection -LocalPort 8787 -State Listen -ErrorAction SilentlyContinue)) {
        $ownerId = [int]$listener.OwningProcess
        if ($ownerId -le 0 -or $ownerId -eq $PID -or $knownIds -contains $ownerId) { continue }
        $owner = Get-CimInstance Win32_Process -Filter "ProcessId=$ownerId" -ErrorAction SilentlyContinue
        $looksLikeFleet = ([string]$owner.Name -match '^Android Fleet') -or ([string]$owner.CommandLine -match '(?i)server[.]js|Android Fleet')
        if (-not $looksLikeFleet) { continue }
        try { Stop-Process -Id $ownerId -Force -ErrorAction Stop } catch {
            throw "古いAndroid Fleetサーバーを終了できませんでした。タスクマネージャーでAndroid Fleetを閉じてください。"
        }
    }
    if ($targets.Count) { Start-Sleep -Milliseconds 1200 }
}

function Backup-File {
    param([string]$Root, [string]$RelativePath, [string]$BackupRoot)
    $source = Join-Path $Root $RelativePath
    if (-not (Test-Path -LiteralPath $source)) { return $false }
    $destination = Join-Path $BackupRoot $RelativePath
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination) | Out-Null
    Copy-Item -LiteralPath $source -Destination $destination -Force
    return $true
}

function Restore-Backup {
    param([string]$Root, [string]$BackupRoot, [object[]]$Touched)
    foreach ($item in @($Touched)) {
        $target = Join-Path $Root $item.path
        $backup = Join-Path $BackupRoot $item.path
        if ($item.existed -and (Test-Path -LiteralPath $backup)) {
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
            Copy-Item -LiteralPath $backup -Destination $target -Force
        } elseif (-not $item.existed -and (Test-Path -LiteralPath $target)) {
            Remove-Item -LiteralPath $target -Force
        }
    }
}

function Test-RestoreBackup {
    param([string]$Root, [string]$BackupRoot, [object[]]$Touched)
    $errors = New-Object System.Collections.Generic.List[string]
    foreach ($item in @($Touched)) {
        try {
            $target = Join-Path $Root $item.path
            $backup = Join-Path $BackupRoot $item.path
            if ($item.existed) {
                if (-not (Test-Path -LiteralPath $target)) {
                    $errors.Add("復元後にファイルがありません: $($item.path)")
                    continue
                }
                if (-not (Test-Path -LiteralPath $backup)) {
                    $errors.Add("バックアップがありません: $($item.path)")
                    continue
                }
                $expectedHash = if ($item.originalSha256) { [string]$item.originalSha256 } else { Get-Sha256 $backup }
                if ((Get-Sha256 $target) -ne $expectedHash) { $errors.Add("復元後SHA256が一致しません: $($item.path)") }
            } elseif (Test-Path -LiteralPath $target) {
                $errors.Add("更新で新規作成したファイルが残っています: $($item.path)")
            }
        } catch {
            $errors.Add("復元検証を実行できません: $($item.path) / $($_.Exception.Message)")
        }
    }
    return @($errors)
}

function Read-Json {
    param([string]$Path)
    Get-Content -Raw -Encoding UTF8 -LiteralPath $Path | ConvertFrom-Json
}

function Write-Json {
    param([string]$Path, [object]$Value, [int]$Depth = 20)
    $Value | ConvertTo-Json -Depth $Depth | Set-Content -Encoding UTF8 -LiteralPath $Path
}

function Find-Property {
    param([object]$Object, [string]$Name)
    if ($null -eq $Object) { return $null }
    $Object.PSObject.Properties | Where-Object { $_.Name -ieq $Name } | Select-Object -First 1
}

if (-not (Test-Path -LiteralPath $ManifestPath)) { throw "update-manifest.json がありません。" }
if (-not (Test-Path -LiteralPath $PayloadRoot)) { throw "payload フォルダがありません。" }

$manifest = Read-Json $ManifestPath
$packageFiles = @()
if ($manifest.PSObject.Properties.Name -contains "packageFiles") {
    $packageFiles = @($manifest.packageFiles | Where-Object { $null -ne $_ })
}
$resolvedAppRoot = Resolve-AppRoot -Requested $AppRoot -ExpectedCustomerId ([string]$manifest.customerId) -ExpectedPackageId ([string]$manifest.packageId)
$resolvedPackageRoot = [System.IO.Path]::GetFullPath((Join-Path $resolvedAppRoot "..\.."))
$RunLogPath = if ([string]::IsNullOrWhiteSpace($requestedRunLogPath)) {
    [System.IO.Path]::GetFullPath((Join-Path $resolvedAppRoot "..\update\last-update-result.log"))
} else {
    [System.IO.Path]::GetFullPath($requestedRunLogPath)
}
$licensePath = Join-Path $resolvedAppRoot "config\customer-license.json"
$license = Read-Json $licensePath
$appliedUpdateSummary = Get-AppliedUpdateSummary $resolvedAppRoot
if ($manifest.customerId -and ([string]$license.customerId -ne [string]$manifest.customerId)) {
    throw "この更新は別のお客様用です。対象: $($manifest.customerName) / 検出: $($license.customerName)"
}
if ($manifest.packageId -and ([string]$license.packageId -ne [string]$manifest.packageId)) {
    throw "Android Fleetの種類が一致しないため更新を中止しました。"
}

Write-Host "Android Fleet 差分更新" -ForegroundColor Cyan
Write-Host "対象: $($license.customerName)"
Write-Host "更新: $($manifest.displayName)"
Write-Host "更新ID: $($manifest.updateId)"
Write-Host "顧客ID: $($manifest.customerId)"
Write-Host "適用済み更新ID: $appliedUpdateSummary"
Write-Host "本体: 選択済みAndroid Fleet"
Write-Host "DB: data\fleet-db\fleet-db.json"
Write-Host "ログ: FleetAgent\update\last-update-result.log"
Write-Host "DB・チェック・履歴は保持します。" -ForegroundColor Green
Add-RunLogLine "更新ID: $($manifest.updateId)"
Add-RunLogLine "顧客ID: $($manifest.customerId)"
Add-RunLogLine "適用済み更新ID: $appliedUpdateSummary"
Add-RunLogLine "DB・チェック・履歴は保持対象です。"

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupRoot = Join-Path ([System.IO.Path]::GetFullPath((Join-Path $resolvedAppRoot "..\.."))) "update-backups\$($manifest.updateId)-$stamp"
$touched = New-Object System.Collections.Generic.List[object]
$packageTouched = New-Object System.Collections.Generic.List[object]
$preflightIssues = New-Object System.Collections.Generic.List[string]
$diagnosticSummaries = New-Object System.Collections.Generic.List[string]
$allowedPackageTargets = @(
    "README-FIRST.md",
    "CHECK-FOR-UPDATES.cmd",
    "FleetAgent\config\update-client.json",
    "FleetAgent\scripts\auto-update-browser-agent.ps1",
    "FleetAgent\scripts\start-browser-agent.ps1",
    "FleetAgent\scripts\verify-update-index.js"
)

try {
    foreach ($file in @($manifest.files)) {
        $relative = ([string]$file.path).Replace("/", "\")
        $newHash = ([string]$file.newSha256).ToLowerInvariant()
        $acceptedOldHashes = @($file.acceptedOldSha256 | ForEach-Object { ([string]$_).ToLowerInvariant() })
        if (-not $acceptedOldHashes.Count -and $file.oldSha256) { $acceptedOldHashes = @(([string]$file.oldSha256).ToLowerInvariant()) }
        if ([string]::IsNullOrWhiteSpace($relative) -or [System.IO.Path]::IsPathRooted($relative) -or $relative.Contains("..")) {
            Add-PreflightIssue $preflightIssues $diagnosticSummaries "APP_INVALID_PATH" $relative "" $newHash $acceptedOldHashes.Count "不正な更新パスです: $relative"
            continue
        }
        $source = Join-Path $PayloadRoot $relative
        if (-not (Test-Path -LiteralPath $source)) {
            Add-PreflightIssue $preflightIssues $diagnosticSummaries "APP_PAYLOAD_MISSING" $relative "" $newHash $acceptedOldHashes.Count "更新ファイルがありません: $relative"
            continue
        }
        $payloadHash = Get-Sha256 $source
        if ($payloadHash -ne $newHash) {
            $detail = "更新ファイルが破損しています: $relative`n診断コード: APP_PAYLOAD_HASH_MISMATCH`n実ファイルSHA256: $payloadHash`n期待SHA256: $newHash"
            Add-PreflightIssue $preflightIssues $diagnosticSummaries "APP_PAYLOAD_HASH_MISMATCH" $relative $payloadHash $newHash $acceptedOldHashes.Count $detail
            continue
        }
        $target = Join-Path $resolvedAppRoot $relative
        $targetExists = Test-Path -LiteralPath $target
        $currentHash = if ($targetExists) { Get-Sha256 $target } else { "" }
        $allowCreate = $file.allowCreate -eq $true
        if ($currentHash -ne $newHash -and
            ((-not $targetExists -and -not $allowCreate) -or
             ($targetExists -and (-not $acceptedOldHashes.Count -or $acceptedOldHashes -notcontains $currentHash)))) {
            $detail = New-VersionMismatchMessage `
                -DiagnosticCode "APP_VERSION_MISMATCH" `
                -RelativePath $relative `
                -TargetExists $targetExists `
                -CurrentHash $currentHash `
                -AcceptedOldHashes $acceptedOldHashes `
                -NewHash $newHash `
                -UpdateManifest $manifest `
                -AppliedUpdateSummary $appliedUpdateSummary
            Add-PreflightIssue $preflightIssues $diagnosticSummaries "APP_VERSION_MISMATCH" $relative $currentHash $newHash $acceptedOldHashes.Count $detail
        }
    }

    foreach ($file in $packageFiles) {
        $relative = ([string]$file.path).Replace("/", "\")
        $newHash = ([string]$file.newSha256).ToLowerInvariant()
        $acceptedOldHashes = @($file.acceptedOldSha256 | ForEach-Object { ([string]$_).ToLowerInvariant() })
        if (-not $acceptedOldHashes.Count -and $file.oldSha256) { $acceptedOldHashes = @(([string]$file.oldSha256).ToLowerInvariant()) }
        if ([string]::IsNullOrWhiteSpace($relative) -or [System.IO.Path]::IsPathRooted($relative) -or
            $relative.Contains("..") -or $allowedPackageTargets -notcontains $relative) {
            Add-PreflightIssue $preflightIssues $diagnosticSummaries "PACKAGE_INVALID_PATH" $relative "" $newHash $acceptedOldHashes.Count "不正な配布フォルダ更新パスです: $relative"
            continue
        }
        $source = Join-Path $PackagePayloadRoot $relative
        if (-not (Test-Path -LiteralPath $source)) {
            Add-PreflightIssue $preflightIssues $diagnosticSummaries "PACKAGE_PAYLOAD_MISSING" $relative "" $newHash $acceptedOldHashes.Count "配布フォルダ用の更新ファイルがありません: $relative"
            continue
        }
        $payloadHash = Get-Sha256 $source
        if ($payloadHash -ne $newHash) {
            $detail = "配布フォルダ用の更新ファイルが破損しています: $relative`n診断コード: PACKAGE_PAYLOAD_HASH_MISMATCH`n実ファイルSHA256: $payloadHash`n期待SHA256: $newHash"
            Add-PreflightIssue $preflightIssues $diagnosticSummaries "PACKAGE_PAYLOAD_HASH_MISMATCH" $relative $payloadHash $newHash $acceptedOldHashes.Count $detail
            continue
        }
        $target = Join-Path $resolvedPackageRoot $relative
        $targetExists = Test-Path -LiteralPath $target
        $currentHash = if ($targetExists) { Get-Sha256 $target } else { "" }
        if ($currentHash -ne $newHash -and $acceptedOldHashes.Count -and $acceptedOldHashes -notcontains $currentHash) {
            $detail = New-VersionMismatchMessage `
                -DiagnosticCode "PACKAGE_VERSION_MISMATCH" `
                -RelativePath $relative `
                -TargetExists $targetExists `
                -CurrentHash $currentHash `
                -AcceptedOldHashes $acceptedOldHashes `
                -NewHash $newHash `
                -UpdateManifest $manifest `
                -AppliedUpdateSummary $appliedUpdateSummary
            Add-PreflightIssue $preflightIssues $diagnosticSummaries "PACKAGE_VERSION_MISMATCH" $relative $currentHash $newHash $acceptedOldHashes.Count $detail
        }
    }

    if ($preflightIssues.Count) {
        Write-Host "事前診断: 失敗（$($preflightIssues.Count)件）" -ForegroundColor Red
        Add-RunLogLine "事前診断: 失敗（$($preflightIssues.Count)件）"
        for ($index = 0; $index -lt $preflightIssues.Count; $index += 1) {
            Write-Host "--- 問題 $($index + 1) / $($preflightIssues.Count) ---" -ForegroundColor Red
            Write-Host $preflightIssues[$index] -ForegroundColor Red
            Add-RunLogLine "--- 問題 $($index + 1) / $($preflightIssues.Count) ---"
            Add-RunLogLine $preflightIssues[$index]
        }
        throw "事前診断で互換性問題を$($preflightIssues.Count)件検出しました。"
    }
    Write-Host "事前診断: 成功（全$(@($manifest.files).Count + $packageFiles.Count)ファイル互換）" -ForegroundColor Green
    Add-RunLogLine "事前診断: 成功（全$(@($manifest.files).Count + $packageFiles.Count)ファイル互換）"

    if (-not $NoStop) { Stop-AppProcesses $resolvedAppRoot }
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null

    foreach ($file in @($manifest.files)) {
        $relative = ([string]$file.path).Replace("/", "\")
        if ($relative.Contains("..")) { throw "不正な更新パスです: $relative" }
        $source = Join-Path $PayloadRoot $relative
        $target = Join-Path $resolvedAppRoot $relative
        if (-not (Test-Path -LiteralPath $source)) { throw "更新ファイルがありません: $relative" }
        if ((Get-Sha256 $source) -ne [string]$file.newSha256) { throw "更新ファイルが破損しています: $relative" }

        $targetExists = Test-Path -LiteralPath $target
        $currentHash = if ($targetExists) { Get-Sha256 $target } else { "" }
        if ($currentHash -eq [string]$file.newSha256) {
            Write-Host "適用済み: $relative"
            Add-RunLogLine "適用済み: $relative"
            continue
        }
        $acceptedOldHashes = @($file.acceptedOldSha256 | ForEach-Object { ([string]$_).ToLowerInvariant() })
        if (-not $acceptedOldHashes.Count -and $file.oldSha256) { $acceptedOldHashes = @(([string]$file.oldSha256).ToLowerInvariant()) }
        $allowCreate = $file.allowCreate -eq $true
        if ((-not $targetExists -and -not $allowCreate) -or
            ($targetExists -and (-not $acceptedOldHashes.Count -or $acceptedOldHashes -notcontains $currentHash))) {
            throw (New-VersionMismatchMessage `
                -DiagnosticCode "APP_VERSION_MISMATCH" `
                -RelativePath $relative `
                -TargetExists $targetExists `
                -CurrentHash $currentHash `
                -AcceptedOldHashes $acceptedOldHashes `
                -NewHash ([string]$file.newSha256) `
                -UpdateManifest $manifest `
                -AppliedUpdateSummary $appliedUpdateSummary)
        }

        $existed = Backup-File $resolvedAppRoot $relative $backupRoot
        $touched.Add([pscustomobject]@{ path = $relative; existed = $existed; originalSha256 = $currentHash })
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
        Copy-Item -LiteralPath $source -Destination $target -Force
        if ((Get-Sha256 $target) -ne [string]$file.newSha256) { throw "更新後の確認に失敗しました: $relative" }
        Write-Host "更新: $relative" -ForegroundColor Green
        Add-RunLogLine "更新: $relative"
    }

    foreach ($file in $packageFiles) {
        $relative = ([string]$file.path).Replace("/", "\")
        if ([string]::IsNullOrWhiteSpace($relative) -or
            [System.IO.Path]::IsPathRooted($relative) -or
            $relative.Contains("..") -or
            $allowedPackageTargets -notcontains $relative) {
            throw "不正な配布フォルダ更新パスです: $relative"
        }
        if (-not (Test-Path -LiteralPath $PackagePayloadRoot)) { throw "package-payload フォルダがありません。" }
        $source = Join-Path $PackagePayloadRoot $relative
        $target = Join-Path $resolvedPackageRoot $relative
        if (-not (Test-Path -LiteralPath $source)) { throw "配布フォルダ用の更新ファイルがありません: $relative" }
        if ((Get-Sha256 $source) -ne [string]$file.newSha256) { throw "配布フォルダ用の更新ファイルが破損しています: $relative" }

        $targetExists = Test-Path -LiteralPath $target
        $currentHash = if ($targetExists) { Get-Sha256 $target } else { "" }
        if ($currentHash -eq [string]$file.newSha256) {
            Write-Host "適用済み: $relative"
            Add-RunLogLine "適用済み: $relative"
            continue
        }
        $acceptedOldHashes = @($file.acceptedOldSha256 | ForEach-Object { ([string]$_).ToLowerInvariant() })
        if (-not $acceptedOldHashes.Count -and $file.oldSha256) { $acceptedOldHashes = @(([string]$file.oldSha256).ToLowerInvariant()) }
        if ($acceptedOldHashes.Count -and $acceptedOldHashes -notcontains $currentHash) {
            throw (New-VersionMismatchMessage `
                -DiagnosticCode "PACKAGE_VERSION_MISMATCH" `
                -RelativePath $relative `
                -TargetExists $targetExists `
                -CurrentHash $currentHash `
                -AcceptedOldHashes $acceptedOldHashes `
                -NewHash ([string]$file.newSha256) `
                -UpdateManifest $manifest `
                -AppliedUpdateSummary $appliedUpdateSummary)
        }

        $packageBackupRoot = Join-Path $backupRoot "package-root"
        $existed = Backup-File $resolvedPackageRoot $relative $packageBackupRoot
        $packageTouched.Add([pscustomobject]@{ path = $relative; existed = $existed; originalSha256 = $currentHash })
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
        Copy-Item -LiteralPath $source -Destination $target -Force
        if ((Get-Sha256 $target) -ne [string]$file.newSha256) { throw "配布フォルダ更新後の確認に失敗しました: $relative" }
        Write-Host "更新: $relative" -ForegroundColor Green
        Add-RunLogLine "更新: $relative"
    }

    if (Test-Path -LiteralPath $MergePath) {
        foreach ($relative in @(
            "data\fleet-db\fleet-db.json",
            "data\fleet-db\device-master.json",
            "config\device-name-map.json",
            "config\applied-updates.json"
        )) {
            $mergeTarget = Join-Path $resolvedAppRoot $relative
            $mergeTargetExists = Test-Path -LiteralPath $mergeTarget
            $mergeOriginalHash = if ($mergeTargetExists) { Get-Sha256 $mergeTarget } else { "" }
            $existed = Backup-File $resolvedAppRoot $relative $backupRoot
            $touched.Add([pscustomobject]@{ path = $relative; existed = $existed; originalSha256 = $mergeOriginalHash })
        }

        $mergeScript = Join-Path $PatchRoot "apply-data-merge.js"
        if (-not (Test-Path -LiteralPath $mergeScript)) { throw "apply-data-merge.js がありません。" }
        $electronNode = [System.IO.Path]::GetFullPath((Join-Path $resolvedAppRoot "..\..\Android Fleet.exe"))
        $browserNode = [System.IO.Path]::GetFullPath((Join-Path $resolvedAppRoot "..\runtime\node.exe"))
        $runtime = if ($NodePath) { $NodePath } elseif (Test-Path -LiteralPath $browserNode) { $browserNode } else { $electronNode }
        if (-not (Test-Path -LiteralPath $runtime)) { throw "マスタ更新用の実行環境が見つかりません。" }
        $usingElectronRuntime = [System.IO.Path]::GetFullPath($runtime) -eq $electronNode

        $previousElectronRunAsNode = $env:ELECTRON_RUN_AS_NODE
        try {
            if ($usingElectronRuntime) { $env:ELECTRON_RUN_AS_NODE = "1" }
            $mergeOutput = @(& $runtime $mergeScript --app-root $resolvedAppRoot --merge $MergePath --manifest $ManifestPath 2>&1)
            $mergeExitCode = $LASTEXITCODE
            $mergeOutput | ForEach-Object { Write-Host ([string]$_) }
            if ($mergeExitCode -ne 0) { throw "DB・端末マスタの差分合流に失敗しました。" }
        } finally {
            $env:ELECTRON_RUN_AS_NODE = $previousElectronRunAsNode
        }
    }

    Write-Host "更新完了。DB・チェック・履歴はそのままです。" -ForegroundColor Green
    Add-RunLogLine "更新完了。DB・チェック・履歴はそのままです。"
    if ($touched.Count -or $packageTouched.Count -or (Test-Path -LiteralPath $backupRoot)) {
        $backupDisplay = "update-backups\$(Split-Path -Leaf $backupRoot)"
        Write-Host "バックアップ: $backupDisplay"
        Add-RunLogLine "バックアップ: $backupDisplay"
    } else {
        Write-Host "バックアップ: 未作成（ファイル変更なし）"
        Add-RunLogLine "バックアップ: 未作成（ファイル変更なし）"
    }
    Write-Host "更新ログ: FleetAgent\update\last-update-result.log"
    Save-RunLog
} catch {
    $originalError = $_
    $rollbackErrors = New-Object System.Collections.Generic.List[string]
    if ($touched.Count -or $packageTouched.Count) {
        try { Restore-Backup $resolvedAppRoot $backupRoot $touched } catch { $rollbackErrors.Add("本体復元処理: $($_.Exception.Message)") }
        try { Restore-Backup $resolvedPackageRoot (Join-Path $backupRoot "package-root") $packageTouched } catch { $rollbackErrors.Add("配布フォルダ復元処理: $($_.Exception.Message)") }
        @(Test-RestoreBackup $resolvedAppRoot $backupRoot $touched) | ForEach-Object { $rollbackErrors.Add("本体検証: $_") }
        @(Test-RestoreBackup $resolvedPackageRoot (Join-Path $backupRoot "package-root") $packageTouched) | ForEach-Object { $rollbackErrors.Add("配布フォルダ検証: $_") }
    }
    $safeOriginalError = Protect-RunLogText $originalError.Exception.Message
    Write-Host "更新失敗: $safeOriginalError" -ForegroundColor Red
    Add-RunLogLine "更新失敗: $safeOriginalError"
    if ($rollbackErrors.Count) {
        $rollbackStatus = "失敗"
        Write-Host "ロールバック: 失敗" -ForegroundColor Red
        Add-RunLogLine "ロールバック: 失敗"
        $rollbackErrors | ForEach-Object {
            $safeRollbackError = Protect-RunLogText $_
            Write-Host "  $safeRollbackError" -ForegroundColor Red
            Add-RunLogLine "  $safeRollbackError"
        }
    } elseif ($touched.Count -or $packageTouched.Count) {
        $rollbackStatus = "完了（SHA256再検証済み）"
        Write-Host "ロールバック: 完了（SHA256再検証済み）" -ForegroundColor Green
        Add-RunLogLine "ロールバック: 完了（SHA256再検証済み）"
    } else {
        $rollbackStatus = "不要（ファイル変更前に停止）"
        Write-Host "ロールバック: 不要（ファイル変更前に停止）" -ForegroundColor Green
        Add-RunLogLine "ロールバック: 不要（ファイル変更前に停止）"
    }
    if ($diagnosticSummaries.Count) {
        Write-Host "診断サマリー（写真用）: $($diagnosticSummaries.Count)件" -ForegroundColor Yellow
        Add-RunLogLine "診断サマリー（写真用）: $($diagnosticSummaries.Count)件"
        for ($index = 0; $index -lt $diagnosticSummaries.Count; $index += 1) {
            $summaryLine = "M{0:D2} {1}" -f ($index + 1), $diagnosticSummaries[$index]
            Write-Host $summaryLine -ForegroundColor Yellow
            Add-RunLogLine $summaryLine
        }
    }
    if ($touched.Count -or $packageTouched.Count -or (Test-Path -LiteralPath $backupRoot)) {
        $backupDisplay = "update-backups\$(Split-Path -Leaf $backupRoot)"
        Write-Host "バックアップ: $backupDisplay"
        Add-RunLogLine "バックアップ: $backupDisplay"
    } else {
        Write-Host "バックアップ: 未作成（ファイル変更なし）"
        Add-RunLogLine "バックアップ: 未作成（ファイル変更なし）"
    }
    Write-Host "--- 写真用フッター ---" -ForegroundColor Yellow
    Write-Host "更新ID: $($manifest.updateId)" -ForegroundColor Yellow
    Write-Host "顧客ID: $($manifest.customerId)" -ForegroundColor Yellow
    Write-Host "適用済み更新ID: $appliedUpdateSummary" -ForegroundColor Yellow
    Write-Host "ロールバック: $rollbackStatus" -ForegroundColor Yellow
    Write-Host "更新ログ: FleetAgent\update\last-update-result.log"
    Add-RunLogLine "--- 写真用フッター ---"
    Add-RunLogLine "更新ID: $($manifest.updateId)"
    Add-RunLogLine "顧客ID: $($manifest.customerId)"
    Add-RunLogLine "適用済み更新ID: $appliedUpdateSummary"
    Add-RunLogLine "ロールバック: $rollbackStatus"
    try { Save-RunLog } catch { Write-Warning "匿名化更新ログを書き込めませんでした。" }
    if ($rollbackErrors.Count) {
        exit 3
    }
    exit 2
}

if (-not $NoLaunch) {
    $exePath = [System.IO.Path]::GetFullPath((Join-Path $resolvedAppRoot "..\..\Android Fleet.exe"))
    $browserStartPath = [System.IO.Path]::GetFullPath((Join-Path $resolvedAppRoot "..\..\START-ANDROID-FLEET.cmd"))
    if (Test-Path -LiteralPath $exePath) {
        Start-Process -FilePath $exePath -WorkingDirectory (Split-Path -Parent $exePath)
    } elseif (Test-Path -LiteralPath $browserStartPath) {
        Start-Process -FilePath $browserStartPath -WorkingDirectory (Split-Path -Parent $browserStartPath)
    } else {
        Write-Warning "更新は完了しましたが、Android Fleetの起動ファイルが見つからないため自動起動しませんでした。"
    }
}

exit 0


