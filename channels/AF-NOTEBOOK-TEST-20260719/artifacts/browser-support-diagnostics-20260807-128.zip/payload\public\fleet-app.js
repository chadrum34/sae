﻿const state = {
  summary: null,
  deviceMaster: null,
  clipboardItems: [],
  clipboardEditingId: "",
  offlineEditingId: "",
  clipboardTargetSerials: new Set(),
  apnTargetSerials: new Set(),
  operationGroupEditor: {
    groupId: "",
    memberSerials: new Set(),
    activeGroupId: "",
    triggerButton: null,
  },
  workspaceTool: {
    panelId: "",
    triggerButton: null,
  },
  adbDevices: null,
  adbMissingSerials: new Set(),
  busy: false,
  apkInstallBusy: false,
  swipeStopBusy: false,
  adbSwipe: {
    jobId: "",
    pollTimer: 0,
    selected: new Set(),
    minutesBySerial: {},
    currentJob: null,
  },
  swipeAgent: {
    jobId: "",
    pollTimer: 0,
    selected: new Set(),
    minutesBySerial: {},
    currentJob: null,
    errorToggleBusy: false,
  },
  uptimeTickTimer: 0,
  adbConnectionMonitorTimer: 0,
  adbConnectionMonitorBusy: false,
  deviceFactsAutoTimer: 0,
  deviceFactsAutoBusy: false,
  deviceSimInfo: {
    status: "idle",
    devices: [],
    fetchedAt: 0,
    error: "",
  },
  deviceSimInfoFlight: null,
  deviceDbSimRequested: false,
  apnSetup: {
    targetKey: "",
    serial: "",
    selectedProfileId: "",
    candidateProfileIds: [],
    selectionSource: "",
    plan: [],
    unresolved: [],
    results: [],
    running: false,
  },
  remoteAccess: null,
  pendingDeviceRows: null,
  deviceRenderFlushTimer: 0,
  fleetDbRecoveryChecked: false,
  fleetDbRecoveryPrompted: false,
  syncLogs: [],
  syncLogPending: [],
  syncLogFlushTimer: 0,
  scriptBuilder: {
    steps: [],
    latestScreenshotUrl: "",
    autoRefreshTimer: 0,
    logBaseline: null,
  },
  rootPseudoReset: {
    phase: "idle",
    previewBusy: false,
    executeBusy: false,
    requestId: 0,
    preview: null,
    target: null,
    triggerButton: null,
  },
  inviteProductView: "lite",
  withdrawalDeviceOptions: [],
  withdrawalDeviceSelection: null,
};

const el = (id) => document.getElementById(id);
const FLEET_UI_JS_BUILD_ID = "20260807-support-diagnostics2";
const LOG_STORAGE_KEY = "androidFleetUiLogLines";
const LOG_STORAGE_LIMIT = 300;
const ADB_CONNECTED_COUNT_KEY = "androidFleetLastAdbConnectedCount";
const ADB_CONNECTED_SERIALS_KEY = "androidFleetLastAdbConnectedSerials";
const ADB_DROP_ALERT_KEY = "androidFleetLastAdbDropAlert";
const ADB_LAST_SEEN_KEY = "androidFleetAdbLastSeenBySerial";
const ALERT_SUPPRESS_KEY_PREFIX = "androidFleetSuppressAlert:";
const ALERT_ADB_DROP = "adbDrop";
const ADB_CONNECTION_MONITOR_INTERVAL_MS = 45 * 1000;
const DEVICE_FACTS_AUTO_INTERVAL_MS = 10 * 60 * 1000;
const DEVICE_FACTS_AUTO_START_DELAY_MS = 8 * 1000;
const SWIPE_JOB_MERGE_GRACE_MS = 60 * 60 * 1000;
const MAX_DEVICE_NAME_SEQUENCE = 999;
const INVITE_PRODUCTS = Object.freeze([
  { value: "lite", label: "Lite" },
  { value: "main", label: "本家" },
]);
const INVITE_TYPE_ORDER = Object.freeze([
  "豚箱",
  "QR",
  "相互",
  "ルーレット",
  "ポイントゲッター",
  "キックリワード",
]);
const INVITE_FACTOR_OPTIONS = Object.freeze({
  simStatus: [["", "SIM?"], ["SIMあり", "SIMあり"], ["SIMなし", "SIMなし"], ["SIMエラー", "SIMエラー"], ["解約済みSIM（手動）", "解約済み（手動）"], ["不明", "不明"]],
  networkType: [["", "通信?"], ["Wi-Fi", "Wi-Fi"], ["SIM通信", "SIM通信"], ["併用", "併用"], ["不明", "不明"]],
  ttlRegisterMethod: [["", "導入方法"], ["Google Play", "Google Play"], ["APK自動", "APK自動"]],
  inviteType: [["", "招待"], ...INVITE_TYPE_ORDER.map((value) => [value, value])],
  inviteRole: [["", "親 or 子"], ["親", "親"], ["子", "子"]],
  inviteResult: [["", "OK or NG"], ["OK", "OK"], ["NG", "NG"]],
});
const INVITE_EDIT_FIELDS = new Set([
  "simStatus",
  "networkType",
  "ttlRegisterMethod",
  "networkSwitchedDay",
  "osVersion",
  "inviteType",
  "inviteRole",
  "inviteResult",
  "invitePartner",
  "inviteOpsNote",
]);
const CI_MULTIPLIERS = Object.freeze([3, 3, 3, 1, 1, 1, 5, 1, 1, 2, 3, 5, 6, 10]);
const CI_MULTIPLIER_TOTAL = CI_MULTIPLIERS.reduce((sum, value) => sum + value, 0);
const VIDEO_TASK_DAYS = 10;
const CALC_OPTIONS = Object.freeze({
  ci: [
    { label: "チェックイン 未設定", yen: 0 },
    { label: "チェックイン 1350円", yen: 1350 },
    { label: "チェックイン 1971円", yen: 1971 },
    { label: "チェックイン 2565円", yen: 2565 },
    { label: "チェックイン 2700円", yen: 2700 },
    { label: "チェックイン 3847円", yen: 3847 },
  ],
  video180: [
    { label: "動画180分 未設定", points: 0 },
    { label: "動画180分 7500P/日", points: 7500 },
    { label: "動画180分 15000P/日", points: 15000 },
    { label: "動画180分 22500P/日", points: 22500 },
  ],
  video10: [
    { label: "追加視聴 未設定", yen: 0 },
    { label: "追加視聴 1190円", yen: 1190 },
    { label: "追加視聴 1438円", yen: 1438 },
    { label: "追加視聴 2262円", yen: 2262 },
    { label: "手入力", yen: "custom" },
  ],
});
const DEVICE_TASK_SELECTS = Object.freeze({
  ci: {
    tags: ["CI_1350", "CI_1971", "CI_2565", "CI_2700", "CI_3847"],
    options: [["", "?"], ["CI_1350", "1350"], ["CI_1971", "1971"], ["CI_2565", "2565"], ["CI_2700", "2700"], ["CI_3847", "3847"]],
  },
  video180: {
    tags: ["V180_7500", "V180_15000", "V180_22500"],
    options: [["", "?"], ["V180_7500", "7500P"], ["V180_15000", "15000P"], ["V180_22500", "22500P"]],
  },
  video10: {
    tags: ["V10_1190", "V10_1438", "V10_2262"],
    options: [["", "?"], ["V10_1190", "1190"], ["V10_1438", "1438"], ["V10_2262", "2262"]],
  },
});
const SCRIPT_PACKAGE_OPTIONS = Object.freeze([
  { label: "Chrome", packageName: "com.android.chrome", appName: "Chrome", launchUrl: "https://www.google.com/" },
  { label: "TikTok", packageName: "com.zhiliaoapp.musically", appName: "TikTok" },
  { label: "TikTok Lite", packageName: "com.zhiliaoapp.musically.go", appName: "TikTok-Lite" },
  { label: "設定", packageName: "com.android.settings", appName: "設定" },
  { label: "Play Store", packageName: "com.android.vending", appName: "Play Store" },
  { label: "Files", packageName: "com.google.android.apps.nbu.files", appName: "Files" },
  { label: "Gmail", packageName: "com.google.android.gm", appName: "Gmail" },
  { label: "YouTube", packageName: "com.google.android.youtube", appName: "YouTube" },
  { label: "手入力", packageName: "custom" },
]);
const APN_FIELD_LABELS = Object.freeze({
  name: "名前",
  apn: "APN",
  username: "ユーザー",
  password: "パス",
  auth: "認証",
  apnType: "タイプ",
  protocol: "プロトコル",
  roamingProtocol: "ローミング",
  mcc: "MCC",
  mnc: "MNC",
});
const APN_PRESETS = Object.freeze([
  { id: "docomo", carrier: "docomo / ahamo / irumo", profile: "spモード", note: "多くは自動設定", fields: { name: "spmode", apn: "spmode.ne.jp", auth: "未設定", protocol: "IPv4/IPv6" } },
  { id: "rakuten", carrier: "Rakuten Mobile", profile: "楽天モバイル", note: "MNO", fields: { name: "Rakuten", apn: "rakuten.jp", apnType: "default,supl", protocol: "IPv4/IPv6", roamingProtocol: "IPv4/IPv6", mcc: "440", mnc: "11" } },
  { id: "povo", carrier: "povo 2.0", profile: "KDDI", note: "au系", fields: { name: "povo2.0", apn: "povo.jp", auth: "未設定", apnType: "default,supl", protocol: "IPv4/IPv6" } },
  { id: "uq", carrier: "UQ mobile", profile: "KDDI", note: "au系", fields: { name: "UQ mobile", apn: "uqmobile.jp", username: "uq@uqmobile.jp", password: "uq", auth: "CHAP", apnType: "default,mms,supl,hipri,dun", protocol: "IPv4/IPv6" } },
  { id: "linemo", carrier: "LINEMO", profile: "SoftBank", note: "SB系", fields: { name: "LINEMO", apn: "plus.acs.jp.v6", username: "lm", password: "lm", auth: "CHAP", apnType: "default,ia,mms,supl,hipri", protocol: "IPv4/IPv6" } },
  { id: "ymobile", carrier: "Y!mobile", profile: "SoftBank", note: "SB系", fields: { name: "Y!mobile", apn: "plus.acs.jp.v6", username: "ym", password: "ym", auth: "CHAP", apnType: "default,ia,mms,supl,hipri", protocol: "IPv4/IPv6" } },
  { id: "softbank", carrier: "SoftBank", profile: "4G/5G", note: "端末差あり", fields: { name: "SoftBank 4G", apn: "plus.4g", username: "plus", password: "4g", auth: "CHAP", apnType: "default,mms,supl,hipri", protocol: "IPv4/IPv6" } },
  { id: "mineo-d", carrier: "mineo D", profile: "docomo回線", note: "MVNO", fields: { name: "mineo-d", apn: "mineo-d.jp", username: "mineo@k-opti.com", password: "mineo", auth: "CHAP" } },
  { id: "mineo-a", carrier: "mineo A", profile: "au回線", note: "MVNO", fields: { name: "mineo-a", apn: "mineo.jp", username: "mineo@k-opti.com", password: "mineo", auth: "CHAP" } },
  { id: "mineo-s", carrier: "mineo S", profile: "SoftBank回線", note: "MVNO", fields: { name: "mineo-s", apn: "mineo-s.jp", username: "mineo@k-opti.com", password: "mineo", auth: "CHAP" } },
  { id: "iijmio", carrier: "IIJmio", profile: "D/A共通", note: "MVNO", fields: { name: "IIJmio", apn: "iijmio.jp", username: "mio@iij", password: "iij", auth: "PAPまたはCHAP" } },
  { id: "ocn", carrier: "OCN モバイル ONE", profile: "docomo回線", note: "新旧要確認", fields: { name: "OCN", apn: "lte.ocn.ne.jp", username: "mobileid@ocn", password: "mobile", auth: "CHAP" } },
  { id: "biglobe", carrier: "BIGLOBEモバイル", profile: "D/A", note: "MVNO", fields: { name: "BIGLOBE", apn: "biglobe.jp", username: "user", password: "0000", auth: "PAPまたはCHAP" } },
  { id: "nuro", carrier: "NUROモバイル", profile: "D/A/S", note: "プラン差確認", fields: { name: "nuro mobile", apn: "so-net.jp", username: "nuro", password: "nuro", auth: "PAPまたはCHAP" } },
  { id: "aeon-type1", carrier: "イオンモバイル type1", profile: "docomo回線", note: "MVNO", fields: { name: "AEON mobile", apn: "i-aeonmobile.com", username: "user", password: "0000", auth: "PAPまたはCHAP" } },
  { id: "aeon-type2", carrier: "イオンモバイル type2", profile: "docomo回線", note: "MVNO", fields: { name: "AEON mobile type2", apn: "n-aeonmobile.com", username: "user", password: "0000", auth: "PAPまたはCHAP" } },
  { id: "bmobile", carrier: "日本通信SIM / b-mobile", profile: "docomo回線", note: "MVNO", fields: { name: "b-mobile", apn: "bmobile.ne.jp", username: "bmobile@4g", password: "bmobile", auth: "PAPまたはCHAP" } },
  { id: "his", carrier: "HISモバイル", profile: "docomo回線", note: "MVNO", fields: { name: "HIS Mobile", apn: "dm.jplat.net", username: "his@his", password: "his", auth: "PAPまたはCHAP" } },
  { id: "linksmate", carrier: "LinksMate", profile: "docomo回線", note: "MVNO", fields: { name: "LinksMate", apn: "linksmate.jp", username: "usermate", password: "lms", auth: "CHAP" } },
  { id: "libmo", carrier: "LIBMO", profile: "docomo回線", note: "MVNO", fields: { name: "LIBMO", apn: "libmo.jp", username: "user@libmo", password: "libmo", auth: "PAPまたはCHAP" } },
  { id: "qt-d", carrier: "QTモバイル D", profile: "docomo回線", note: "MVNO", fields: { name: "QTmobile D", apn: "vmobile.jp", username: "qtnet@bbiq.jp", password: "qtnet", auth: "CHAP" } },
  { id: "yu", carrier: "y.u mobile", profile: "docomo回線", note: "要確認", fields: { name: "y.u mobile", apn: "yumobile.jp", username: "yumobile@yumobile.jp", password: "yumobile", auth: "PAPまたはCHAP" } },
]);
const BUTTON_HELP = Object.freeze({
  saveSiteNameBtn: "",
  firstRunSetupBtn: "ADB起動、USB再スキャン、接続確認、新規端末取込をまとめて行います。スマホ画面のUSBデバッグ許可だけは手動でOKしてください。",
  tagSyncBtn: "チェック一覧の変更をDBへ反映してから、必要に応じてXiaoWeiへ名前と番号を同期します。チェック情報そのものはローカルDBで管理します。",
  dayAdvanceBtn: "",
  deviceCodeSyncBtn: "端末マスタを元に、未設定や古い端末名をDB内で再取得します。XiaoWeiへ反映する時は別途XiaoWei名同期を押します。",
  deviceUptimeRefreshBtn: "",
  deviceNavigationBtn: "端末下部の「戻る・ホーム・履歴」の順番を確認し、対応機種だけ戻るボタンを左右へ変更します。",
  adbMissingListBtn: "",
  usbAdbDiagnosisBtn: "端末が見えない/動かない原因を確認し、対象だけ自動復旧します。",
  supportDiagnosticsBtn: "現在版・更新状態・ADB・XiaoWei・Fleet件数を、氏名・端末名・シリアルを含まない1個の診断JSONにまとめます。",
  xiaoweiMissingListBtn: "",
  deviceCodeAuditBtn: "",
  retiredDevicesBtn: "管理対象から外した端末を確認し、必要なら一覧へ戻します。",
  deviceNameSequenceEditBtn: "A25-01などの末尾連番を01〜999で変更します。メイン番号とXiaoWeiの機種順は変わりません。",
  deviceDayOrderBtn: "元の採番方式です。稼働端末はDAYが大きい順、非稼働端末は機種・キャリア順にメイン番号を振り直し、XiaoWeiへ反映します。",
  deviceModelOrderBtn: "メイン番号を機種・キャリア・名前連番の順に振り直し、XiaoWeiへ反映します。DAY順とチェック状態は変わりません。",
  deviceMasterReloadBtn: "",
  deviceMasterSaveBtn: "",
  deviceMasterCancelBtn: "",
  deviceMasterImportBtn: "",
  xiaoweiNameSyncBtn: "",
  xiaoweiNumberSyncBtn: "",
  importAdbNewBtn: "ADB/XiaoWeiで見えていてDBに未登録の端末を取り込みます。取り込み後にDB側で名前とXiaoWei番号を整え、同期ボタンでXiaoWeiへ反映します。",
  saveDeviceNamesBtn: "",
  saveInviteFactorsBtn: "招待検証欄で選んだ内容をDBへ保存します。",
  adbSwipeApplyBulkBtn: "",
  adbSwipeSelectAllBtn: "",
  adbSwipeSelectActiveBtn: "",
  adbSwipeClearSelectionBtn: "",
  adbSwipeRefreshBtn: "",
  adbSwipeRestartTtlBtn: "",
  adbSwipeStartBtn: "",
  adbSwipeStopBtn: "",
  swipeAgentApplyBulkBtn: "",
  swipeAgentSelectAllBtn: "",
  swipeAgentSelectActiveBtn: "",
  swipeAgentClearSelectionBtn: "",
  swipeAgentRefreshBtn: "",
  swipeAgentStatusBtn: "",
  swipeAgentInstallBtn: "",
  swipeRecoveryTestBtn: "",
  swipeLiveRecoveryTestBtn: "",
  swipeAgentStartBtn: "",
  swipeAgentStopBtn: "",
  clipboardSaveBtn: "",
  clipboardCaptureBtn: "",
  clipboardClearBtn: "",
  clipboardReloadBtn: "",
  clipboardSelectActiveBtn: "",
  clipboardSelectAllBtn: "",
  clipboardManualSelectBtn: "",
  clipboardClearTargetsBtn: "",
  clipboardBatteryProtectionBtn: "選択した端末の電池状態と機種を確認し、公式のバッテリー画面を開きます。充電上限はメーカーごとに異なるため、ADBから推測値を直接書き込みません。",
  clipboardRootPseudoResetBtn: "ADB接続中の選択端末1台だけを対象に、root・Magisk・ADB状態を確認してから、選んだ許可アプリのデータだけを消去します。完全初期化やFleet DB更新は行いません。",
  clipboardInstallApkBtn: "APKフォルダ内のAPK/APKM/XAPKを一覧表示し、選んだ複数アプリをチェック済み端末へまとめてインストールします。splitや大容量APKにも対応します。",
  clipboardTtlInviteDiagnosticsBtn: "チェック済み端末で、TikTok Liteが招待URLの受け皿としてAndroidに認識されているか確認します。",
  clipboardTtlCleanupBtn: "APKフォルダ内のTikTok Liteと一致するパッケージを残し、重複したTTL候補を確認付きで整理します。",
  clipboardOpenApkFolderBtn: "APKを置くdata/apkフォルダを開きます。",
  clipboardExtractAppBtn: "チェックしたスマホ1台からインストール済みアプリ一覧を出し、選んだアプリをsplit込みでdata/apkへ吸い出します。",
  clipboardLaunchTtlBtn: "チェック済み端末でTikTok Liteを起動します。",
  clipboardLaunchLineBtn: "チェック済み端末でLINEを起動します。",
  clipboardOpenApkLinksBtn: "APKの入手先メモを開きます。",
  apnOpenSettingsBtn: "",
  emergencyOffBtn: "",
  autoRotateOffBtn: "",
  dataSaverBtn: "",
  nfcOffBtn: "",
  soundOffBtn: "",
  baselineSettingsBtn: "DBの初期設定状態を元に接続中端末へ実行します。稼働中端末も対象です。緊急メールOFF、画面回転OFF、データセーバーON、NFC OFF、サイレントONの完了済み項目はスキップし、ユーザーアプリ通知の非表示だけは新規アプリを拾うため毎回再確認します。通知非表示はAndroid 12以降・管理アプリ除くです。Android 11以前は完了扱いにしません。APKは端末操作から別に導入し、導入後は端末初期設定をもう一度実行してください。",
  xiaomiMiuiOptimizeBtn: "接続中のXiaomi/Redmi/POCO端末だけに、MIUI広告・解析・フィードバック系の無効化を実行します。稼働中も対象です。",
  remoteAccessBtn: "許可したノートPCやタブレットから、Tailscale経由でFleetだけを安全に操作します。XiaoWeiの画面共有は行いません。",
  baselineSettingsRefreshBtn: "接続中の端末を読み込んで、初期設定6項目の完了状態をDBへ更新します。ユーザーアプリ通知の非表示はAndroid 12以降のみ完了対象で、管理アプリは除きます。普段の初期設定ボタンはDBを元にスキップするため、状態確認したい時だけ使います。",
  pageReloadBtn: "画面全体を読み直します。表示が固まった時や真っ暗に見える時に使います。F5 / Ctrl+R でも実行できます。",
  reloadBtn: "",
  exportSheetsBtn: "",
  saveDbBtn: "",
  backupBtn: "",
  migrationExportBtn: "PC移行用の AndroidFleet-移行データ フォルダを作ります。ローカルDB、履歴、保管リスト、APKなどを入れ、PC固定ライセンス情報は入れません。",
  migrationOpenBtn: "移行データをコピーするためのフォルダを開きます。旧PCではこのフォルダを丸ごとコピーし、新PCでは同じ場所へ置きます。",
  migrationImportBtn: "新PC側で AndroidFleet-移行データ を取り込みます。現在のデータはバックアップしてから上書きし、PC固定ライセンス情報は取り込みません。",
  addWithdrawalBtn: "",
  cancelWithdrawalEditBtn: "",
  exportBranchReportBtn: "",
  importBranchReportBtn: "",
  scriptRefreshShotBtn: "",
  scriptCopyScreenTextBtn: "",
  scriptCopyDeviceClipboardBtn: "",
  scriptAdbChromeTestBtn: "",
  scriptMinimalPresetBtn: "",
  scriptDebugPresetBtn: "",
  scriptChromePresetBtn: "",
  scriptAddLaunchBtn: "",
  scriptAddWaitBtn: "",
  scriptAddTextBtn: "",
  scriptAddBackBtn: "",
  scriptAddHomeBtn: "",
  scriptClearBtn: "",
  scriptInstallTestsBtn: "",
  scriptFolderCheckBtn: "",
  scriptLogTailBtn: "",
  scriptLogMarkBtn: "",
  scriptLogDeltaBtn: "",
  scriptCopyAdminInstallBtn: "",
  scriptCopyBtn: "",
  scriptDownloadBtn: "",
  scriptRunXiaoweiBtn: "",
});
const BUTTON_CLASS_HELP = Object.freeze({
  "edit-withdrawal-btn": "",
  "delete-withdrawal-btn": "",
  "reset-action": "",
  "clipboard-task-run-btn": "",
  "clipboard-send-btn": "",
  "clipboard-copy-btn": "",
  "clipboard-number-step-btn": "",
  "clipboard-move-up-btn": "",
  "clipboard-move-down-btn": "",
  "clipboard-edit-btn": "",
  "clipboard-delete-btn": "",
  "apn-paste-btn": "",
  "script-step-delete": "",
});

document.addEventListener("DOMContentLoaded", () => {
  restoreLogLines();
  bindTabs();
  bindManualTabs();
  bindButtonHelp();
  bindActions();
  clearOfflineDeviceForm();
  bindPageReloadShortcut();
  window.addEventListener("message", handleAppMessage);
  setupRewardCalculator();
  renderApnPalette();
  loadClipboardItems();
  loadPersistentSyncLogs();
  loadAppVersion();
  loadSummary({ includeAdb: true, includeUptime: false });
  refreshRunningSwipeJobs();
  startUptimeTicker();
  startAdbConnectionMonitor();
  startDeviceFactsAutoRefresh();
  initializeRemoteAccess();
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) refreshAdbConnectionSnapshot();
  });
  window.addEventListener("focus", refreshAdbConnectionSnapshot);
});

async function loadAppVersion() {
  try {
    const config = await fetchJson("/api/config");
    renderAppVersion(config.appVersion);
  } catch {
    // Summary rendering will retry the same value during normal startup.
  }
}

async function handleAppMessage(event) {
  if (!event || !event.data || event.data.type !== "tag-board-db-updated") return;
  try {
    await loadLocalSummaryOnly();
    logLine("チェック一覧の変更をDBへ反映しました");
  } catch (error) {
    logLine("チェック一覧変更後のDB再読込 NG: " + error.message);
  }
}

function bindTabs() {
  for (const button of document.querySelectorAll(".tab")) {
    button.addEventListener("click", () => activateMainPanel(button.dataset.tab || "", button));
  }
  for (const button of document.querySelectorAll(".auto-op-tab")) {
    button.addEventListener("click", () => switchAutoOperationPanel(button.dataset.autoOp || "autoSwipe"));
  }
  const active = document.querySelector(".tab.active");
  document.body.dataset.activeTab = active?.dataset.tab || "";
  if (active?.dataset.tab === "deviceDb") requestDeviceDbSimInfo();
}

function activateMainPanel(tabId, sourceButton = null) {
  const targetId = String(tabId || "");
  for (const item of document.querySelectorAll(".tab")) {
    item.classList.toggle("active", item === sourceButton || (!sourceButton && item.dataset.tab === targetId));
  }
  for (const panel of document.querySelectorAll(".panel")) panel.classList.toggle("active", panel.id === targetId);
  document.body.dataset.activeTab = targetId;
  if (targetId === "deviceDb") requestDeviceDbSimInfo();
}

function switchAutoOperationPanel(panelId) {
  for (const button of document.querySelectorAll(".auto-op-tab")) {
    button.classList.toggle("active", button.dataset.autoOp === panelId);
  }
  for (const panel of document.querySelectorAll(".auto-op-panel")) {
    panel.classList.toggle("active", panel.id === panelId);
  }
}

function switchToTab(tabId) {
  const button = document.querySelector(`.tab[data-tab="${tabId}"]`);
  activateMainPanel(tabId, button || null);
}

function openWorkspaceToolDialog(panelId, triggerButton = null, options = {}) {
  const panel = el(panelId);
  const modal = el("workspaceToolModal");
  const body = el("workspaceToolDialogBody");
  if (!panel || !modal || !body) return;
  closeOperationGroupDialog();
  const current = body.querySelector(".workspace-tool-panel");
  if (current && current !== panel) {
    current.hidden = true;
    el("workspaceToolStorage").appendChild(current);
  }
  state.workspaceTool.panelId = panelId;
  state.workspaceTool.triggerButton = triggerButton || document.activeElement;
  body.appendChild(panel);
  panel.hidden = false;
  el("workspaceToolTitle").textContent = panel.dataset.workspaceTitle || (panelId === "deviceMaster" ? "端末マスタ" : "端末操作");
  el("workspaceToolContext").textContent = String(options.context || "");
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("workspace-tool-open");
  syncWorkspaceBackgroundInert();
  if (panelId === "autoOperation") {
    applyOperationWorkspaceTargets(options.serials || []);
    switchAutoOperationPanel(options.panel || "autoTask");
  }
  window.requestAnimationFrame(() => el("workspaceToolCloseBtn")?.focus());
}

function closeWorkspaceToolDialog() {
  const modal = el("workspaceToolModal");
  if (!modal || modal.classList.contains("hidden")) return;
  if (state.busy || state.apnSetup.running) return;
  const panel = el("workspaceToolDialogBody")?.querySelector(".workspace-tool-panel");
  if (panel) {
    panel.hidden = true;
    el("workspaceToolStorage").appendChild(panel);
  }
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
  document.body.classList.remove("workspace-tool-open");
  const panelId = state.workspaceTool.panelId;
  const trigger = resolveWorkspaceReturnFocus(state.workspaceTool.triggerButton, panelId);
  state.workspaceTool.panelId = "";
  state.workspaceTool.triggerButton = null;
  syncWorkspaceBackgroundInert();
  if (trigger && !trigger.disabled) trigger.focus({ preventScroll: true });
}

function resolveWorkspaceReturnFocus(trigger, panelId = "") {
  if (trigger && document.contains(trigger)) return trigger;
  if (panelId === "deviceMaster") return el("deviceMasterOpenBtn") || document.querySelector('[data-tab="deviceDb"]');
  if (panelId === "autoOperation") return el("deviceOperationOpenBtn") || document.querySelector('[data-tab="deviceDb"]');
  if (panelId === "apnSetup") return el("apnSetupOpenBtn") || document.querySelector('[data-tab="deviceDb"]');
  return document.querySelector('[data-tab="deviceDb"]');
}

function resolveOperationGroupReturnFocus(trigger) {
  if (trigger && document.contains(trigger)) return trigger;
  const groupId = String(trigger?.dataset?.operationGroupEdit || "");
  if (groupId) {
    const current = [...document.querySelectorAll("[data-operation-group-edit]")]
      .find((button) => String(button.dataset.operationGroupEdit || "") === groupId);
    if (current) return current;
  }
  return el("operationGroupOpenBtn") || document.querySelector('[data-tab="deviceDb"]');
}

function syncWorkspaceBackgroundInert() {
  const modalOpen = !el("workspaceToolModal")?.classList.contains("hidden")
    || !el("operationGroupModal")?.classList.contains("hidden");
  for (const node of document.querySelectorAll("body > header, body > nav, body > main")) {
    node.inert = modalOpen;
  }
}

function visibleOverlayAboveWorkspace() {
  const workspaceNodes = new Set([el("workspaceToolModal"), el("operationGroupModal")]);
  return [...document.body.children].some((node) => {
    if (!node || workspaceNodes.has(node) || node.hidden || node.classList.contains("hidden")) return false;
    const containsDialog = node.matches?.("[role='dialog'], [role='alertdialog']")
      || node.querySelector?.("[role='dialog'], [role='alertdialog']");
    if (!containsDialog) return false;
    const style = window.getComputedStyle(node);
    const zIndex = Number(style.zIndex);
    return style.position === "fixed" && Number.isFinite(zIndex) && zIndex > 1500 && node.getClientRects().length > 0;
  });
}

function trapWorkspaceDialogFocus(event, dialog) {
  if (event.key !== "Tab" || !dialog) return;
  const focusable = [...dialog.querySelectorAll("button, input, select, textarea, [tabindex]")]
    .filter((node) => !node.disabled && node.tabIndex >= 0 && !node.hidden && node.getClientRects().length > 0);
  if (!focusable.length) {
    event.preventDefault();
    return;
  }
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  const active = document.activeElement;
  if (event.shiftKey && (active === first || !dialog.contains(active))) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && (active === last || !dialog.contains(active))) {
    event.preventDefault();
    first.focus();
  }
}

function handleWorkspaceDialogKeydown(event) {
  const groupOpen = !el("operationGroupModal")?.classList.contains("hidden");
  const workspaceOpen = !el("workspaceToolModal")?.classList.contains("hidden");
  if (!groupOpen && !workspaceOpen) return;
  if (visibleOverlayAboveWorkspace()) return;
  const dialog = groupOpen
    ? el("operationGroupModal")?.querySelector(".operation-group-dialog")
    : el("workspaceToolModal")?.querySelector(".workspace-tool-dialog");
  if (event.key === "Tab") return trapWorkspaceDialogFocus(event, dialog);
  if (event.key !== "Escape") return;
  if (groupOpen) {
    closeOperationGroupDialog();
    return;
  }
  if (workspaceOpen) closeWorkspaceToolDialog();
}

function applyOperationWorkspaceTargets(serials = []) {
  const requested = new Set((Array.isArray(serials) ? serials : []).map((value) => String(value || "")).filter(Boolean));
  if (!requested.size) return;
  state.clipboardTargetSerials = requested;
  if (el("clipboardActiveOnlyInput")) el("clipboardActiveOnlyInput").checked = false;
  renderClipboardTargets(state.summary?.devices || []);
  const live = new Set([...requested].filter((serial) => liveAdbDeviceBySerial(serial)));
  state.adbSwipe.selected = new Set(live);
  state.swipeAgent.selected = new Set(live);
  renderAdbSwipePanel(state.summary?.devices || [], state.adbDevices?.devices || []);
  renderSwipeAgentPanel(state.summary?.devices || [], state.adbDevices?.devices || []);
}

function uiSerialKey(value) {
  return String(value || "")
    .normalize("NFKC")
    .replace(/\s+/g, "")
    .toUpperCase();
}

function operationGroups() {
  return Array.isArray(state.summary?.operationGroups) ? state.summary.operationGroups : [];
}

function operationGroupById(groupId) {
  const key = String(groupId || "");
  return operationGroups().find((group) => String(group?.groupId || "") === key) || null;
}

function operationGroupTaskSummary(row = {}) {
  const tags = Array.isArray(row.tags) ? row.tags.map((tag) => String(tag)) : [];
  const parts = [];
  const ci = tags.find((tag) => /^CI_/.test(tag));
  const video180 = tags.find((tag) => /^V180_/.test(tag));
  const video10 = tags.find((tag) => /^V10_/.test(tag));
  if (ci) parts.push(`CI ${ci.replace(/^CI_/, "")}`);
  if (tags.includes("V180_DONE")) parts.push("180○");
  else if (video180) parts.push(`180 ${video180.replace(/^V180_/, "")}`);
  if (tags.includes("V10_DONE")) parts.push("追加○");
  else if (video10) parts.push(`追加 ${video10.replace(/^V10_/, "")}`);
  return parts.join(" ") || "タスク未設定";
}

function operationGroupDeviceView(serial) {
  const key = uiSerialKey(serial);
  const row = (state.summary?.devices || []).find((item) => uiSerialKey(item?.serial) === key);
  if (!row) {
    return {
      serial: String(serial || ""),
      row: null,
      number: "-",
      day: "D-",
      name: "DBに見つかりません",
      task: "所属は保持中",
      active: false,
      connected: Boolean(liveAdbDeviceBySerial(serial)),
    };
  }
  return {
    serial: String(row.serial || serial || ""),
    row,
    number: String(row.laixiNumber || row.managementId || "-"),
    day: Number(row.day || 0) ? `D${Number(row.day)}` : "D-",
    name: String(row.deviceLabel || row.deviceName || row.laixiName || row.serial || "端末"),
    task: operationGroupTaskSummary(row),
    active: isClipboardTargetActive(row),
    connected: Boolean(liveAdbDeviceBySerial(row.serial)),
  };
}

function operationGroupDeviceRowMarkup(view, options = {}) {
  const control = options.selected
    ? `<button type="button" data-operation-group-remove="${esc(view.serial)}" aria-label="選択解除">×</button>`
    : `<input type="checkbox" value="${esc(view.serial)}" ${options.checked ? "checked" : ""}>`;
  const tagName = options.selected ? "div" : "label";
  return `
    <${tagName} class="operation-group-device-row ${view.connected ? "connected" : "disconnected"} ${view.active ? "active" : "inactive"}">
      ${control}
      <b>${esc(view.number)}</b>
      <span><strong>${esc(view.day)}｜${esc(view.name)}</strong><small>${esc(view.task)}</small></span>
      <em>${view.connected ? "ADB接続" : "ADB未接続"}</em>
    </${tagName}>
  `;
}

function renderOperationGroupSavedList() {
  const wrap = el("operationGroupSavedList");
  if (!wrap) return;
  const groups = operationGroups();
  if (!groups.length) {
    wrap.innerHTML = `<div class="operation-group-empty">保存済みグループはありません。新規作成してください。</div>`;
    return;
  }
  wrap.innerHTML = groups.map((group) => {
    const views = (group.memberSerials || []).map(operationGroupDeviceView);
    const connected = views.filter((view) => view.connected).length;
    const active = views.filter((view) => view.active).length;
    const activeRow = state.operationGroupEditor.activeGroupId === group.groupId ? "active" : "";
    return `
      <div class="operation-group-saved-row ${activeRow}" data-operation-group-id="${esc(group.groupId)}">
        <button class="operation-group-name-button" type="button" data-operation-group-action="edit" data-group-id="${esc(group.groupId)}">${esc(group.name)}</button>
        <span>総数 <b>${views.length}</b></span>
        <span>接続 <b>${connected}</b></span>
        <span>稼働 <b>${active}</b></span>
        <button type="button" data-operation-group-action="use" data-group-id="${esc(group.groupId)}">操作へ</button>
        <button type="button" data-operation-group-action="edit" data-group-id="${esc(group.groupId)}">編集</button>
      </div>
    `;
  }).join("");
}

function renderOperationGroupPicker() {
  const availableWrap = el("operationGroupAvailableList");
  const selectedWrap = el("operationGroupSelectedList");
  if (!availableWrap || !selectedWrap) return;
  const selected = state.operationGroupEditor.memberSerials;
  const query = String(el("operationGroupSearchInput")?.value || "").trim().toLowerCase();
  const includeInactive = Boolean(el("operationGroupIncludeInactiveInput")?.checked);
  const rows = (state.summary?.devices || [])
    .filter((row) => row?.serial && liveAdbDeviceBySerial(row.serial))
    .filter((row) => includeInactive || isClipboardTargetActive(row))
    .filter((row) => !query || apnTargetSearchText(row).includes(query))
    .sort((left, right) => managementNumber(left) - managementNumber(right));
  availableWrap.innerHTML = rows.length
    ? rows.map((row) => operationGroupDeviceRowMarkup(operationGroupDeviceView(row.serial), { checked: selected.has(String(row.serial)) })).join("")
    : `<div class="operation-group-empty">条件に一致するADB接続端末がありません。</div>`;
  const selectedViews = [...selected].map(operationGroupDeviceView).sort((left, right) => Number(left.number || 999999) - Number(right.number || 999999));
  selectedWrap.innerHTML = selectedViews.length
    ? selectedViews.map((view) => operationGroupDeviceRowMarkup(view, { selected: true })).join("")
    : `<div class="operation-group-empty">左の一覧から端末を選んでください。</div>`;
  el("operationGroupSelectionCount").textContent = `選択 ${selected.size}台`;
}

function startOperationGroupEdit(groupId = "") {
  const group = operationGroupById(groupId);
  state.operationGroupEditor.groupId = group?.groupId || "";
  state.operationGroupEditor.memberSerials = new Set((group?.memberSerials || []).map((value) => String(value)));
  el("operationGroupIdInput").value = group?.groupId || "";
  el("operationGroupNameInput").value = group?.name || "";
  el("operationGroupDeleteBtn").classList.toggle("hidden", !group);
  el("operationGroupSaveBtn").textContent = group ? "更新" : "保存";
  renderOperationGroupSavedList();
  renderOperationGroupPicker();
}

function openOperationGroupDialog(groupId = "", triggerButton = null) {
  closeWorkspaceToolDialog();
  state.operationGroupEditor.triggerButton = triggerButton || document.activeElement;
  const modal = el("operationGroupModal");
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("operation-group-open");
  syncWorkspaceBackgroundInert();
  startOperationGroupEdit(groupId);
  window.requestAnimationFrame(() => el("operationGroupNameInput")?.focus());
}

function closeOperationGroupDialog() {
  const modal = el("operationGroupModal");
  if (!modal || modal.classList.contains("hidden")) return;
  if (state.busy) return;
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
  document.body.classList.remove("operation-group-open");
  const trigger = resolveOperationGroupReturnFocus(state.operationGroupEditor.triggerButton);
  state.operationGroupEditor.triggerButton = null;
  syncWorkspaceBackgroundInert();
  if (trigger && !trigger.disabled) trigger.focus({ preventScroll: true });
}

function handleOperationGroupAvailableChange(event) {
  if (state.busy) return;
  const input = event.target.closest("input[type='checkbox']");
  if (!input) return;
  if (input.checked) state.operationGroupEditor.memberSerials.add(input.value);
  else state.operationGroupEditor.memberSerials.delete(input.value);
  renderOperationGroupPicker();
}

function handleOperationGroupSelectedClick(event) {
  if (state.busy) return;
  const button = event.target.closest("[data-operation-group-remove]");
  if (!button) return;
  state.operationGroupEditor.memberSerials.delete(button.dataset.operationGroupRemove || "");
  renderOperationGroupPicker();
}

function handleOperationGroupSavedAction(event) {
  if (state.busy) return;
  const button = event.target.closest("[data-operation-group-action]");
  if (!button) return;
  const groupId = button.dataset.groupId || "";
  if (button.dataset.operationGroupAction === "use") return useOperationGroup(groupId, button);
  startOperationGroupEdit(groupId);
}

function useOperationGroup(groupId, triggerButton = null) {
  const group = operationGroupById(groupId);
  if (!group) return logLine("グループ操作 NG: グループが見つかりません");
  const views = (group.memberSerials || []).map(operationGroupDeviceView);
  const connected = views.filter((view) => view.connected && view.row).map((view) => view.serial);
  const missing = views.filter((view) => !view.connected || !view.row);
  if (!connected.length) {
    window.alert(`${group.name} に現在操作できるADB接続端末がありません。`);
    return;
  }
  if (missing.length) {
    const ok = window.confirm(
      `${group.name}: 総数${views.length}台のうち接続中${connected.length}台です。\n`
      + `未接続・DB不明${missing.length}台を除外し、接続中だけ操作画面へ読み込みますか？`
    );
    if (!ok) return;
  }
  state.operationGroupEditor.activeGroupId = group.groupId;
  const returnFocus = state.operationGroupEditor.triggerButton || el("operationGroupOpenBtn") || triggerButton;
  closeOperationGroupDialog();
  openWorkspaceToolDialog("autoOperation", returnFocus, {
    serials: connected,
    panel: "autoTask",
    context: `${group.name}｜総数 ${views.length}台｜操作対象 ${connected.length}台${missing.length ? `｜対象外 ${missing.length}台` : ""}`,
  });
  logLine(`グループ操作 読込: ${group.name} / 接続中 ${connected.length}/${views.length}台`);
}

async function saveOperationGroup(event) {
  event.preventDefault();
  if (state.busy) return;
  const name = el("operationGroupNameInput").value.trim();
  const memberSerials = [...state.operationGroupEditor.memberSerials];
  const button = el("operationGroupSaveBtn");
  setOperationGroupEditorBusy(true);
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/fleet-db/operation-groups/upsert", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        groupId: state.operationGroupEditor.groupId,
        name,
        memberSerials,
      }),
    });
    await loadLocalSummaryOnly();
    startOperationGroupEdit(result.group?.groupId || "");
    logLine(`操作グループ保存 OK: ${result.group?.name || name} / ${memberSerials.length}台`);
    flashButtonResult(button, "保存済み", "ok");
  } catch (error) {
    logLine(`操作グループ保存 NG: ${error.message}`);
    window.alert(error.message);
  } finally {
    setBusy(false);
    setOperationGroupEditorBusy(false);
  }
}

async function deleteCurrentOperationGroup() {
  if (state.busy) return;
  const group = operationGroupById(state.operationGroupEditor.groupId);
  if (!group) return;
  if (!window.confirm(`${group.name} を削除しますか？端末DBや履歴は削除しません。`)) return;
  const button = el("operationGroupDeleteBtn");
  setOperationGroupEditorBusy(true);
  setBusy(true, button);
  try {
    await fetchJson("/api/fleet-db/operation-groups/delete", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ groupId: group.groupId }),
    });
    if (state.operationGroupEditor.activeGroupId === group.groupId) state.operationGroupEditor.activeGroupId = "";
    await loadLocalSummaryOnly();
    startOperationGroupEdit();
    logLine(`操作グループ削除 OK: ${group.name}`);
  } catch (error) {
    logLine(`操作グループ削除 NG: ${error.message}`);
    window.alert(error.message);
  } finally {
    setBusy(false);
    setOperationGroupEditorBusy(false);
  }
}

function setOperationGroupEditorBusy(busy) {
  for (const control of el("operationGroupForm")?.querySelectorAll("input, button") || []) {
    control.disabled = Boolean(busy);
  }
}

function bindManualTabs() {
  const buttons = [...document.querySelectorAll(".manual-tab")];
  const pages = [...document.querySelectorAll(".manual-page")];
  for (const button of buttons) {
    button.addEventListener("click", () => {
      const target = button.dataset.manualPage;
      for (const item of buttons) item.classList.toggle("active", item === button);
      for (const page of pages) page.classList.toggle("active", page.dataset.manualPage === target);
    });
  }
}

function bindButtonHelp() {
  const popup = document.createElement("div");
  popup.id = "buttonHelpPopup";
  popup.className = "button-help-popover";
  popup.setAttribute("role", "tooltip");
  popup.hidden = true;
  document.body.appendChild(popup);
  let activeButton = null;

  const show = (button) => {
    const text = buttonHelpText(button);
    if (!text) return;
    activeButton = button;
    popup.textContent = text;
    popup.hidden = false;
    popup.classList.add("visible");
    positionButtonHelp(button, popup);
  };
  const hide = () => {
    activeButton = null;
    popup.classList.remove("visible");
    popup.hidden = true;
  };

  document.addEventListener("pointerover", (event) => {
    const button = event.target.closest("button");
    if (button) show(button);
  });
  document.addEventListener("pointerout", (event) => {
    if (!activeButton) return;
    const next = event.relatedTarget;
    if (next && activeButton.contains(next)) return;
    hide();
  });
  document.addEventListener("focusin", (event) => {
    const button = event.target.closest("button");
    if (button) show(button);
  });
  document.addEventListener("focusout", hide);
  document.addEventListener("click", hide);
  window.addEventListener("scroll", hide, true);
  window.addEventListener("resize", hide);
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") hide();
  });
}

function buttonHelpText(button) {
  if (!button) return "";
  if (button.classList.contains("tab") || button.classList.contains("manual-tab")) return "";
  if (button.dataset.help) return button.dataset.help;
  if (button.id && Object.prototype.hasOwnProperty.call(BUTTON_HELP, button.id)) return BUTTON_HELP[button.id] || "";
  for (const [className, text] of Object.entries(BUTTON_CLASS_HELP)) {
    if (button.classList.contains(className)) return text;
  }
  const label = button.textContent.trim();
  if (!label) return "";
  return `${label}を実行します`;
}

function positionButtonHelp(button, popup) {
  const rect = button.getBoundingClientRect();
  const gap = 8;
  const maxWidth = Math.min(360, window.innerWidth - 18);
  popup.style.maxWidth = `${maxWidth}px`;
  popup.style.left = "0px";
  popup.style.top = "0px";
  const width = popup.offsetWidth;
  const height = popup.offsetHeight;
  let left = rect.left + rect.width / 2 - width / 2;
  left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
  let top = rect.bottom + gap;
  let arrowBottom = false;
  if (top + height > window.innerHeight - 8) {
    top = rect.top - height - gap;
    arrowBottom = true;
  }
  const arrowLeft = Math.max(14, Math.min(width - 14, rect.left + rect.width / 2 - left));
  popup.style.left = `${left}px`;
  popup.style.top = `${Math.max(8, top)}px`;
  popup.style.setProperty("--arrow-left", `${arrowLeft}px`);
  popup.classList.toggle("arrow-bottom", arrowBottom);
}

function bindActions() {
  el("remoteAccessBtn")?.addEventListener("click", (event) => showRemoteAccessDialog(event.currentTarget));
  el("supportDiagnosticsBtn")?.addEventListener("click", (event) => generateSupportDiagnostics(event.currentTarget));
  el("pageReloadBtn").addEventListener("click", reloadWholePage);
  el("firstRunSetupBtn").addEventListener("click", (event) => runFirstSetup(event.currentTarget));
  el("reloadBtn").addEventListener("click", () => loadSummary({ includeAdb: true, includeUptime: false }));
  el("saveSiteNameBtn").addEventListener("click", saveSiteName);
  el("siteNameInput").addEventListener("keydown", (event) => {
    if (event.key === "Enter") saveSiteName();
  });
  el("withdrawalForm").addEventListener("submit", addManualWithdrawal);
  el("withdrawalDeviceSelect").addEventListener("input", handleWithdrawalDeviceInput);
  el("cancelWithdrawalEditBtn").addEventListener("click", clearWithdrawalForm);
  el("withdrawalRows").addEventListener("click", handleWithdrawalRowAction);
  el("offlineDeviceForm").addEventListener("submit", saveOfflineDevice);
  el("offlineDeviceCancelBtn").addEventListener("click", clearOfflineDeviceForm);
  el("offlineInviteProductToggle").addEventListener("click", handleOfflineInviteProductToggle);
  el("offlineDeviceRegisterMethodInput").addEventListener("change", () => updateOfflineInviteProductAppearance());
  el("offlineDeviceRows").addEventListener("click", handleOfflineDeviceRowAction);
  el("offlineDeviceRows").addEventListener("change", handleOfflineDeviceTaskChange);
  el("deviceRows").addEventListener("click", handleDeviceRowAction);
  el("deviceRows").addEventListener("input", handleDeviceNameInput);
  el("deviceRows").addEventListener("change", handleDeviceTaskSelectChange);
  el("deviceRows").addEventListener("focusout", schedulePendingDeviceRender);
  el("inviteProductGlobalToggle").addEventListener("click", handleInviteProductGlobalToggle);
  el("saveDeviceNamesBtn").addEventListener("click", saveChangedDeviceNames);
  el("saveInviteFactorsBtn").addEventListener("click", saveChangedDeviceNames);
  el("deviceNameSequenceEditBtn").addEventListener("click", openDeviceNameSequenceDialog);
  el("deviceDayOrderBtn").addEventListener("click", (event) => runDeviceNumberResequence(event.currentTarget, "day"));
  el("deviceModelOrderBtn").addEventListener("click", (event) => runDeviceNumberResequence(event.currentTarget, "model"));
  el("deviceUptimeRefreshBtn").addEventListener("click", (event) => refreshDeviceUptime(event.currentTarget));
  el("deviceMasterOpenBtn").addEventListener("click", (event) => openWorkspaceToolDialog("deviceMaster", event.currentTarget));
  el("operationGroupOpenBtn").addEventListener("click", (event) => openOperationGroupDialog("", event.currentTarget));
  el("deviceOperationOpenBtn").addEventListener("click", (event) => openWorkspaceToolDialog("autoOperation", event.currentTarget, { panel: "autoTask" }));
  el("apnSetupOpenBtn").addEventListener("click", (event) => focusApnSetup(event.currentTarget));
  el("inviteAnalyticsBtn")?.addEventListener("click", () => showInviteAnalyticsDialog());
  el("deviceNavigationBtn").addEventListener("click", (event) => showNavigationLayoutDialog(event.currentTarget));
  el("usbAdbDiagnosisBtn").addEventListener("click", (event) => showUsbAdbDiagnosisDialog(event.currentTarget));
  el("deviceCodeAuditBtn").addEventListener("click", (event) => showDeviceCodeAuditDialog(event.currentTarget));
  el("retiredDevicesBtn").addEventListener("click", (event) => showRetiredDevicesDialog(event.currentTarget));
  el("deviceMasterReloadBtn").addEventListener("click", loadDeviceMaster);
  el("deviceMasterSearchInput").addEventListener("input", () => renderDeviceMaster(state.deviceMaster));
  el("deviceMasterForm").addEventListener("submit", saveDeviceMasterEntry);
  el("deviceMasterCancelBtn").addEventListener("click", clearDeviceMasterForm);
  el("deviceMasterRows").addEventListener("click", handleDeviceMasterRowAction);
  el("deviceMasterRows").addEventListener("change", handleDeviceMasterInlineChange);
  el("deviceMasterRows").addEventListener("keydown", handleDeviceMasterInlineKeydown);
  el("deviceMasterImportBtn").addEventListener("click", importDeviceMasterCsv);
  el("syncLogFilter").addEventListener("change", renderSyncLogs);
  el("syncLogSearch").addEventListener("input", renderSyncLogs);
  el("syncLogSaveBtn").addEventListener("click", downloadSyncLogs);
  el("syncLogClearBtn").addEventListener("click", clearSyncLogs);
  el("exportBranchReportBtn").addEventListener("click", exportBranchReport);
  el("importBranchReportBtn").addEventListener("click", () => el("branchReportFileInput").click());
  el("branchReportFileInput").addEventListener("change", importBranchReportFile);
  el("tagSyncBtn").addEventListener("click", (event) => runXiaoweiFullSync(event.currentTarget));
  el("dayAdvanceBtn").addEventListener("click", (event) => runDayAdvance(event.currentTarget));
  el("deviceCodeSyncBtn").addEventListener("click", (event) => runDeviceCodeSync(event.currentTarget));
  el("xiaoweiNameSyncBtn").addEventListener("click", (event) => runXiaoweiNameSync(event.currentTarget));
  el("xiaoweiNumberSyncBtn").addEventListener("click", (event) => runXiaoweiNumberSync(event.currentTarget));
  el("importAdbNewBtn").addEventListener("click", (event) => importNewAdbDevices(event.currentTarget));
  setupAdbSwipeControls();
  el("adbSwipeApplyBulkBtn").addEventListener("click", applyAdbSwipeBulkMinutes);
  el("adbSwipeSelectAllBtn").addEventListener("click", () => setAdbSwipeSelection("all"));
  el("adbSwipeSelectActiveBtn").addEventListener("click", () => setAdbSwipeSelection("active"));
  el("adbSwipeClearSelectionBtn").addEventListener("click", () => setAdbSwipeSelection("none"));
  el("adbSwipeRefreshBtn").addEventListener("click", refreshAdbSwipeDevices);
  el("adbSwipeRestartTtlBtn").addEventListener("click", (event) => restartTtlForSelectedAdbSwipeDevices(event.currentTarget));
  el("adbSwipeStartBtn").addEventListener("click", (event) => startAdbSwipeJobFromPanel(event.currentTarget));
  el("adbSwipeStopBtn").addEventListener("click", (event) => stopAllSwipeJobs(event.currentTarget));
  el("adbSwipeDeviceGrid").addEventListener("change", handleAdbSwipeGridChange);
  setupSwipeAgentControls();
  el("swipeAgentApplyBulkBtn").addEventListener("click", applySwipeAgentBulkMinutes);
  el("swipeAgentSelectAllBtn").addEventListener("click", () => setSwipeAgentSelection("all"));
  el("swipeAgentSelectActiveBtn").addEventListener("click", () => setSwipeAgentSelection("active"));
  el("swipeAgentClearSelectionBtn").addEventListener("click", () => setSwipeAgentSelection("none"));
  el("swipeAgentRefreshBtn").addEventListener("click", refreshSwipeAgentDevices);
  el("swipeAgentStatusBtn").addEventListener("click", (event) => runSwipeAgentInstallAction("", "/api/swipe-agent/install-status", event.currentTarget));
  el("swipeAgentInstallBtn").addEventListener("click", (event) => runSwipeAgentInstallAction("Agent準備", "/api/swipe-agent/install", event.currentTarget));
  el("swipeRecoveryTestBtn").addEventListener("click", (event) => runSwipeRecoveryTest(event.currentTarget));
  el("swipeLiveRecoveryTestBtn").addEventListener("click", (event) => runSwipeRecoveryTest(event.currentTarget, { stopAgent: false }));
  el("swipeAgentStartBtn").addEventListener("click", (event) => startSwipeAgentJobFromPanel(event.currentTarget));
  el("swipeAgentStopBtn").addEventListener("click", (event) => stopAllSwipeJobs(event.currentTarget));
  el("swipeAgentDeviceGrid").addEventListener("click", handleSwipeAgentGridClick, true);
  el("swipeAgentDeviceGrid").addEventListener("change", handleSwipeAgentGridChange);
  el("swipeAgentJobPanel").addEventListener("click", handleSwipeJobPanelClick);
  el("swipePastLogsModal").addEventListener("click", handleSwipePastLogsModalClick);
  document.addEventListener("keydown", handleSwipePastLogsKeydown);
  el("clipboardForm").addEventListener("submit", saveClipboardForm);
  el("clipboardTitlePreset").addEventListener("change", syncClipboardTitleInputVisibility);
  syncClipboardTitleInputVisibility();
  el("clipboardCaptureBtn").addEventListener("click", captureSelectedDeviceClipboardToVault);
  el("clipboardClearBtn").addEventListener("click", clearClipboardForm);
  el("clipboardReloadBtn").addEventListener("click", loadClipboardItems);
  el("clipboardItems").addEventListener("click", handleClipboardItemAction);
  el("clipboardTargetGrid").addEventListener("change", handleClipboardTargetChange);
  el("clipboardSelectActiveBtn").addEventListener("click", () => selectClipboardTargets("active"));
  el("clipboardSelectAllBtn").addEventListener("click", () => selectClipboardTargets("all"));
  el("clipboardManualSelectBtn").addEventListener("click", () => selectClipboardTargets("manual"));
  el("clipboardClearTargetsBtn").addEventListener("click", () => selectClipboardTargets("clear"));
  el("clipboardApnSetupBtn").addEventListener("click", () => focusApnSetup(el("apnSetupOpenBtn")));
  el("clipboardBatteryProtectionBtn").addEventListener("click", (event) => showBatteryProtectionDialog(event.currentTarget));
  el("clipboardCloseTtlBtn").addEventListener("click", (event) => closeTtlForSelectedClipboardTargets(event.currentTarget));
  el("clipboardLaunchTtlBtn").addEventListener("click", (event) => launchAppForSelectedClipboardTargets("ttl", "", event.currentTarget));
  el("clipboardLaunchLineBtn").addEventListener("click", (event) => launchAppForSelectedClipboardTargets("line", "", event.currentTarget));
  el("clipboardRootPseudoResetBtn").addEventListener("click", (event) => openRootPseudoResetDialog(event.currentTarget));
  el("clipboardInstallApkBtn").addEventListener("click", (event) => installApksForSelectedClipboardTargets(event.currentTarget));
  el("clipboardExtractAppBtn").addEventListener("click", (event) => extractAppBundleFromSelectedClipboardTarget(event.currentTarget));
  el("clipboardTtlInviteDiagnosticsBtn").addEventListener("click", (event) => diagnoseTtlInviteForSelectedClipboardTargets(event.currentTarget));
  el("clipboardTtlCleanupBtn").addEventListener("click", (event) => cleanupTtlInviteForSelectedClipboardTargets(event.currentTarget));
  el("clipboardOpenApkFolderBtn").addEventListener("click", (event) => openApkFolder(event.currentTarget));
  el("clipboardOpenApkLinksBtn").addEventListener("click", () => window.open("/apk-download-links.html", "_blank", "noopener"));
  el("rootPseudoResetCloseBtn").addEventListener("click", closeRootPseudoResetDialog);
  el("rootPseudoResetCancelBtn").addEventListener("click", closeRootPseudoResetDialog);
  el("rootPseudoResetExecuteBtn").addEventListener("click", executeRootPseudoReset);
  el("rootPseudoResetConfirmationInput").addEventListener("input", updateRootPseudoResetExecuteState);
  el("rootPseudoResetPackages").addEventListener("change", updateRootPseudoResetExecuteState);
  document.addEventListener("keydown", handleRootPseudoResetKeydown);
  el("clipboardActiveOnlyInput").addEventListener("change", () => {
    renderClipboardTargets(state.summary?.devices || []);
  });
  el("clipboardExcludeSourceInput").addEventListener("change", () => renderClipboardTargets(state.summary?.devices || []));
  el("apnTargetGrid").addEventListener("change", handleApnTargetChange);
  el("apnTargetSearchInput").addEventListener("input", () => renderApnTargets());
  el("apnSelectConnectedBtn").addEventListener("click", () => selectApnTargets("connected"));
  el("apnClearTargetsBtn").addEventListener("click", () => selectApnTargets("clear"));
  el("apnRefreshTargetsBtn").addEventListener("click", (event) => refreshApnTargets(event.currentTarget));
  el("apnDetectBtn").addEventListener("click", (event) => suggestApnForSelectedDevices(event.currentTarget));
  el("apnStartBtn").addEventListener("click", (event) => prepareSelectedApnOnDevices(event.currentTarget));
  el("apnOpenSettingsBtn").addEventListener("click", (event) => openApnSettingsForSelectedDevice(event.currentTarget));
  el("apnBatchSummary").addEventListener("click", handleApnBatchSummaryAction);
  el("apnPalette").addEventListener("click", handleApnPaletteAction);
  el("workspaceToolCloseBtn").addEventListener("click", closeWorkspaceToolDialog);
  el("workspaceToolModal").addEventListener("click", (event) => {
    if (event.target === el("workspaceToolModal")) closeWorkspaceToolDialog();
  });
  el("operationGroupCloseBtn").addEventListener("click", closeOperationGroupDialog);
  el("operationGroupNewBtn").addEventListener("click", () => startOperationGroupEdit());
  el("operationGroupCancelBtn").addEventListener("click", () => startOperationGroupEdit(state.operationGroupEditor.groupId));
  el("operationGroupDeleteBtn").addEventListener("click", deleteCurrentOperationGroup);
  el("operationGroupForm").addEventListener("submit", saveOperationGroup);
  el("operationGroupSearchInput").addEventListener("input", renderOperationGroupPicker);
  el("operationGroupIncludeInactiveInput").addEventListener("change", renderOperationGroupPicker);
  el("operationGroupAvailableList").addEventListener("change", handleOperationGroupAvailableChange);
  el("operationGroupSelectedList").addEventListener("click", handleOperationGroupSelectedClick);
  el("operationGroupSavedList").addEventListener("click", handleOperationGroupSavedAction);
  el("operationGroupModal").addEventListener("click", (event) => {
    if (event.target === el("operationGroupModal")) closeOperationGroupDialog();
  });
  document.addEventListener("keydown", handleWorkspaceDialogKeydown, true);
  el("baselineSettingsBtn").addEventListener("click", (event) => {
    const ok = window.confirm("端末初期設定6項目を接続中端末へ実行します。稼働中端末も対象です。DBで完了済みの5項目はスキップし、ユーザーアプリ通知の非表示だけは毎回再確認します。通知非表示はAndroid 12以降が対象で、管理アプリは除きます。よろしいですか？");
    if (!ok) return;
    runDeviceSettingAction("端末初期設定", "/api/adb/baseline-device-settings", event.currentTarget);
  });
  el("xiaomiMiuiOptimizeBtn").addEventListener("click", (event) => {
    const ok = window.confirm("接続中のXiaomi/Redmi/POCO端末だけにMIUI広告・解析・フィードバック無効化を実行します。稼働中端末も対象です。よろしいですか？");
    if (!ok) return;
    runDeviceSettingAction("Xiaomi最適化", "/api/adb/xiaomi-miui-optimize", event.currentTarget);
  });
  el("baselineSettingsRefreshBtn").addEventListener("click", (event) =>
    refreshBaselineSettings(event.currentTarget)
  );
  el("exportSheetsBtn").addEventListener("click", (event) =>
    runAction("", "/api/fleet-db/export-sheets", event.currentTarget)
  );
  el("saveDbBtn").addEventListener("click", (event) => saveDbFile(event.currentTarget));
  el("backupBtn").addEventListener("click", (event) => runAction("DBバックアップ", "/api/fleet-db/backup", event.currentTarget));
  el("migrationExportBtn").addEventListener("click", (event) => runAction("移行データ作成", "/api/migration/export", event.currentTarget));
  el("migrationOpenBtn").addEventListener("click", (event) => runAction("移行フォルダ", "/api/migration/open", event.currentTarget));
  el("migrationImportBtn").addEventListener("click", (event) => importMigrationDataFromFolder(event.currentTarget));
  bindScriptBuilderActions();
}

async function initializeRemoteAccess() {
  const button = el("remoteAccessBtn");
  if (!button) return;
  try {
    const status = await fetchJson("/api/remote-access/status");
    if (!status.available) return;
    state.remoteAccess = status;
    button.classList.remove("hidden");
    updateRemoteAccessButton(status);
  } catch {
    button.classList.add("hidden");
  }
}

function updateRemoteAccessButton(status) {
  const button = el("remoteAccessBtn");
  if (!button) return;
  button.textContent = status?.enabled ? "リモートON" : "リモート接続";
  button.classList.toggle("is-active", Boolean(status?.enabled));
}

async function showRemoteAccessDialog(button = null) {
  if (button) setBusy(true, button, "確認中...");
  try {
    const status = await fetchJson("/api/remote-access/status");
    state.remoteAccess = status;
    updateRemoteAccessButton(status);
    renderRemoteAccessDialog(status);
  } catch (error) {
    logLine("リモート接続 状態確認NG: " + error.message);
    window.alert("リモート接続の状態を確認できませんでした。\n" + error.message);
  } finally {
    if (button) setBusy(false);
  }
}

function renderRemoteAccessDialog(status) {
  document.querySelector(".remote-access-dialog-backdrop")?.remove();
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop remote-access-dialog-backdrop";
  const installedLabel = status.installed ? "インストール済み" : "未インストール";
  const connectedLabel = status.connected ? "ログイン済み" : "未接続";
  const sharingLabel = status.enabled ? "リモートON" : "リモートOFF";
  const viewerLabel = status.viewer?.remote
    ? `リモート接続中${status.viewer.name || status.viewer.login ? `: ${status.viewer.name || status.viewer.login}` : ""}`
    : "このWindows PCから表示中";
  const remoteUrl = status.remoteUrl || "開始後に表示されます";
  const startDisabled = !status.installed || !status.connected || status.enabled;
  const stopDisabled = !status.enabled;
  const installNotice = !status.installed
    ? `<div class="remote-access-notice warn"><strong>最初にTailscaleをインストール</strong><span>このWindows PCと、外から使うノートPC・タブレットの両方へ入れ、同じアカウントでログインします。</span></div>`
    : !status.connected
      ? `<div class="remote-access-notice warn"><strong>Tailscaleへログインしてください</strong><span>WindowsのTailscaleを起動し、外から使う端末と同じネットワークへ接続します。</span></div>`
      : "";
  const consentNotice = status.consentUrl
    ? `<div class="remote-access-notice warn"><strong>初回の許可が必要です</strong><span>Tailscaleの確認画面を開き、HTTPS公開を許可してから再度開始してください。</span><a class="remote-access-link" href="${esc(status.consentUrl)}" target="_blank" rel="noopener">確認画面を開く</a></div>`
    : "";
  overlay.innerHTML = `
    <div class="adb-drop-dialog remote-access-dialog" role="dialog" aria-modal="true" aria-labelledby="remoteAccessDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="remoteAccessDialogTitle">Fleetリモート接続</h3>
          <p>許可した端末からFleetだけを操作します。インターネットへ一般公開はしません。</p>
        </div>
        <button class="adb-drop-close remote-access-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="remote-access-dialog-body">
        <div class="remote-access-status-grid">
          <div><span>Tailscale</span><strong class="${status.installed ? "ok" : "warn"}">${installedLabel}</strong></div>
          <div><span>接続状態</span><strong class="${status.connected ? "ok" : "warn"}">${connectedLabel}</strong></div>
          <div><span>Fleet公開</span><strong class="${status.enabled ? "ok" : "muted"}">${sharingLabel}</strong></div>
          <div><span>現在の表示</span><strong>${esc(viewerLabel)}</strong></div>
        </div>
        ${installNotice}
        ${consentNotice}
        <div class="remote-access-url-panel">
          <span>このPC</span>
          <code>${esc(status.localUrl || "http://127.0.0.1:8787/app")}</code>
          <span>出先用URL</span>
          <code class="remote-access-url-value">${esc(remoteUrl)}</code>
        </div>
        <div class="remote-access-rules">
          <p>・Windows PC、XiaoWei、Fleet Agentは起動したままにします。</p>
          <p>・外から使う端末もTailscaleへログインして、このURLをブラウザで開きます。</p>
          <p>・接続は標準HTTPS ${Number(status.httpsPort || 443)}を使用します。ルーターのポート開放は不要です。</p>
        </div>
      </div>
      <div class="remote-access-dialog-actions">
        <a class="remote-access-link button-like" href="${esc(status.installUrl || "https://tailscale.com/download/windows")}" target="_blank" rel="noopener">Tailscale公式</a>
        <button class="remote-access-refresh" type="button">状態更新</button>
        <button class="remote-access-copy" type="button" ${status.enabled && status.remoteUrl ? "" : "disabled"}>URLコピー</button>
        <button class="remote-access-open" type="button" ${status.enabled && status.remoteUrl ? "" : "disabled"}>URLを開く</button>
        <button class="remote-access-start primary-action" type="button" ${startDisabled ? "disabled" : ""}>リモート開始</button>
        <button class="remote-access-stop danger-action" type="button" ${stopDisabled ? "disabled" : ""}>リモート停止</button>
        <button class="adb-drop-close-action remote-access-close" type="button">閉じる</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);

  overlay.querySelectorAll(".remote-access-close").forEach((closeButton) => {
    closeButton.addEventListener("click", () => overlay.remove());
  });
  overlay.querySelector(".remote-access-refresh")?.addEventListener("click", (event) => refreshRemoteAccessDialog(event.currentTarget));
  overlay.querySelector(".remote-access-start")?.addEventListener("click", (event) => changeRemoteAccess("start", event.currentTarget));
  overlay.querySelector(".remote-access-stop")?.addEventListener("click", (event) => changeRemoteAccess("stop", event.currentTarget));
  overlay.querySelector(".remote-access-copy")?.addEventListener("click", (event) => copyRemoteAccessUrl(status.remoteUrl, event.currentTarget));
  overlay.querySelector(".remote-access-open")?.addEventListener("click", () => window.open(status.remoteUrl, "_blank", "noopener"));
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) overlay.remove();
  });
}

async function refreshRemoteAccessDialog(button) {
  button.disabled = true;
  button.textContent = "確認中...";
  try {
    const status = await fetchJson("/api/remote-access/status");
    state.remoteAccess = status;
    updateRemoteAccessButton(status);
    renderRemoteAccessDialog(status);
  } catch (error) {
    window.alert("状態を更新できませんでした。\n" + error.message);
    button.disabled = false;
    button.textContent = "状態更新";
  }
}

async function changeRemoteAccess(action, button) {
  const isStart = action === "start";
  button.disabled = true;
  button.textContent = isStart ? "開始中..." : "停止中...";
  try {
    const response = await fetch(`/api/remote-access/${action}`, { method: "POST" });
    const status = await response.json();
    state.remoteAccess = status;
    updateRemoteAccessButton(status);
    logLine(`リモート接続 ${status.enabled ? "ON" : "OFF"}: ${status.remoteUrl || status.code || ""}`);
    renderRemoteAccessDialog(status);
  } catch (error) {
    window.alert(`リモート接続を${isStart ? "開始" : "停止"}できませんでした。\n${error.message}`);
    await showRemoteAccessDialog();
  }
}

async function copyRemoteAccessUrl(url, button) {
  if (!url) return;
  try {
    await navigator.clipboard.writeText(url);
  } catch {
    const input = document.createElement("textarea");
    input.value = url;
    document.body.appendChild(input);
    input.select();
    document.execCommand("copy");
    input.remove();
  }
  flashButtonResult(button, "コピー済み");
}

function bindPageReloadShortcut() {
  document.addEventListener("keydown", (event) => {
    const key = String(event.key || "").toLowerCase();
    if (event.key === "F5" || ((event.ctrlKey || event.metaKey) && key === "r")) {
      event.preventDefault();
      reloadWholePage();
    }
  });
}

function reloadWholePage() {
  window.location.reload();
}

function announceUnregisteredDeviceMaster(result, contextLabel = "端末確認") {
  const rows = Array.isArray(result?.masterUnregisteredDevices)
    ? result.masterUnregisteredDevices
    : Array.isArray(result?.identityRefresh?.masterUnregisteredDevices)
      ? result.identityRefresh.masterUnregisteredDevices
      : [];
  if (!rows.length) return 0;

  for (const row of rows) {
    const number = row.xiaoweiNumber ? `No.${row.xiaoweiNumber}` : row.managementId || "番号未定";
    logLine(`端末マスタ未登録: ${number} / 型番 ${row.modelCode || "不明"} / XiaoWei名 ${row.xiaoweiName || "不明"} / キャリア ${row.carrierCode || "UNKNOWN"}`);
  }
  const visibleRows = rows.slice(0, 12).map((row) => {
    const number = row.xiaoweiNumber ? `No.${row.xiaoweiNumber}` : row.managementId || "番号未定";
    return `・${number} / 型番 ${row.modelCode || "不明"} / XiaoWei名 ${row.xiaoweiName || "不明"} / キャリア ${row.carrierCode || "UNKNOWN"}`;
  });
  if (rows.length > visibleRows.length) visibleRows.push(`・ほか ${rows.length - visibleRows.length}台（全件は同期ログに表示）`);
  window.alert([
    `端末マスタに登録されていない機種があります（${rows.length}台）`,
    "",
    ...visibleRows,
    "",
    "端末マスタへ登録した後、「端末名を再取得」を押してください。",
  ].join("\n"));
  logLine(`${contextLabel} 要確認: 端末マスタ未登録 ${rows.length}台`);
  return rows.length;
}

function waitForMs(delayMs) {
  return new Promise((resolve) => window.setTimeout(resolve, Math.max(0, Number(delayMs) || 0)));
}

function mergeNewDeviceImportResults(results = []) {
  const rows = results.filter(Boolean);
  const latest = rows[rows.length - 1] || {};
  const importedBySerial = new Map();
  const masterIssueBySerial = new Map();
  for (const result of rows) {
    for (const device of result.devices || []) {
      const key = String(device.serial || device.managementId || importedBySerial.size);
      importedBySerial.set(key, device);
    }
    for (const issue of result.masterUnregisteredDevices || []) {
      const key = String(issue.serial || issue.xiaoweiNumber || issue.managementId || masterIssueBySerial.size);
      masterIssueBySerial.set(key, issue);
    }
  }
  const devices = [...importedBySerial.values()];
  const masterUnregisteredDevices = [...masterIssueBySerial.values()];
  return {
    ...latest,
    ok: rows.length > 0 && rows.every((result) => result.ok !== false),
    passes: rows.length,
    scanned: Math.max(0, ...rows.map((result) => Number(result.scanned || 0))),
    adbScanned: Math.max(0, ...rows.map((result) => Number(result.adbScanned || 0))),
    xiaoweiScanned: Math.max(0, ...rows.map((result) => Number(result.xiaoweiScanned || 0))),
    windowsUsbSeen: Math.max(0, ...rows.map((result) => Number(result.windowsUsbSeen || 0))),
    xiaoweiUsbConfirmed: Math.max(0, ...rows.map((result) => Number(result.xiaoweiUsbConfirmed || 0))),
    imported: devices.length,
    devices,
    masterUnregisteredCount: masterUnregisteredDevices.length,
    masterUnregisteredDevices,
  };
}

async function importNewDevicesUntilStable(options = {}) {
  const label = options.label || "新規端末取込";
  const minPasses = Math.max(1, Number(options.minPasses || 3));
  const maxPasses = Math.max(minPasses, Number(options.maxPasses || 5));
  const initialDelayMs = Math.max(0, Number(options.initialDelayMs ?? 0));
  const intervalMs = Math.max(0, Number(options.intervalMs ?? 3000));
  const results = [];
  let consecutiveNoNew = 0;

  if (initialDelayMs) {
    logLine(`${label}: 接続が揃うまで${Math.ceil(initialDelayMs / 1000)}秒待機`);
    await waitForMs(initialDelayMs);
  }
  for (let pass = 1; pass <= maxPasses; pass += 1) {
    const result = await fetchJson("/api/fleet-db/import-adb-new", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    results.push(result);
    const imported = Number(result.imported || 0);
    consecutiveNoNew = imported > 0 ? 0 : consecutiveNoNew + 1;
    logLine(`${label} 自動確認 ${pass}/${maxPasses}: 現在検出 ${result.scanned || 0}台 / 追加 ${imported}台`);
    if (pass >= minPasses && consecutiveNoNew >= 2) break;
    if (pass < maxPasses) await waitForMs(intervalMs);
  }
  return mergeNewDeviceImportResults(results);
}

async function launchUsbOnlyAutoRepair() {
  const diagnosis = await fetchJson("/api/adb/usb-diagnosis?all=1&xiaoweiOnly=1");
  const rows = (diagnosis.rows || []).filter((row) => row.diagnosis === "usb_only" && row.serial);
  if (!rows.length) return { launched: false, count: 0, rows: [] };
  const serials = [...new Set(rows.map((row) => String(row.serial)).filter(Boolean))];
  logLine(`接続準備: USBだけ見えている端末 ${serials.length}台を自動復旧します`);
  const result = await fetchJson("/api/adb/usb-repair", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ serials, allowXiaoweiKnown: true, deep: false }),
  });
  logLine(`USB自動復旧 起動: ${serials.length}台 / UACが表示されたら「はい」を押してください`);
  return { ...result, launched: true, count: serials.length, rows };
}

async function runFirstSetup(button = null) {
  const ok = window.confirm("接続準備と新規端末取込を実行します。\nADB起動、USB再スキャン、接続確認、DB未登録端末の取込をまとめて行います。\nスマホ側にUSBデバッグ許可が出たらOKを押してください。");
  if (!ok) return;
  setBusy(true, button);
  logLine("接続準備・新規取込 実行中: ADB起動 / USB再スキャン / 接続確認");
  let flash = { message: "完了", type: "ok" };
  try {
    const setup = await fetchJson("/api/setup/first-run", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    const adbKind = setup.bundledAdb ? "同梱ADB" : "外部ADB";
    const xiaoweiCount = setup.xiaoweiPort?.connected ?? 0;
    logLine(`接続準備 OK: ${adbKind} / XiaoWei接続 ${xiaoweiCount}台 / ${setup.adbPath || ""}`);
    let imported = await importNewDevicesUntilStable({
      label: "接続準備・新規取込",
      initialDelayMs: 2500,
      minPasses: 3,
      maxPasses: 5,
      intervalMs: 3000,
    });
    try {
      const repair = await launchUsbOnlyAutoRepair();
      if (repair.launched) {
        logLine("USB自動復旧 完了待ち: 18秒後に接続と新規端末を再確認します");
        await waitForMs(18000);
        const afterRepair = await importNewDevicesUntilStable({
          label: "USB復旧後の新規取込",
          minPasses: 3,
          maxPasses: 4,
          intervalMs: 3000,
        });
        const totalPasses = Number(imported.passes || 0) + Number(afterRepair.passes || 0);
        imported = mergeNewDeviceImportResults([imported, afterRepair]);
        imported.passes = totalPasses;
        const recheck = await fetchJson("/api/adb/usb-diagnosis?all=1&xiaoweiOnly=1");
        const remainingUsbOnly = (recheck.rows || []).filter((row) => row.diagnosis === "usb_only").length;
        if (remainingUsbOnly) {
          flash = { message: "復旧確認", type: "warn" };
          logLine(`USB自動復旧 要確認: USBだけ見えている端末が残り${remainingUsbOnly}台あります。UAC許可後、必要なら抜き差ししてください`);
        } else {
          logLine("USB自動復旧 確認OK: USBだけ見えている端末は残っていません");
        }
      }
    } catch (repairError) {
      flash = { message: "復旧確認", type: "warn" };
      logLine(`USB自動復旧 要確認: ${repairError.message}`);
    }
    const labels = (imported.devices || []).slice(0, 5).map((device) => `${device.managementId} ${device.name || device.model || device.serial}`).join(" / ");
    logLine(`新規端末取込 OK: 自動確認 ${imported.passes || 0}回 / 検出 ${imported.scanned || 0}台（ADB ${imported.adbScanned || 0}台 / XiaoWei現役 ${imported.xiaoweiScanned || 0}台） / 新規 ${imported.imported || 0}台 / 登録済 ${imported.skipped || 0}台${labels ? " / " + labels : ""}`);
    if (Number(imported.xiaoweiHistorySkipped || 0) > 0) {
      logLine(`新規端末取込 除外: XiaoWeiの未接続保存履歴 ${imported.xiaoweiHistorySkipped}台`);
    }
    if (announceUnregisteredDeviceMaster(imported, "接続準備・新規取込")) {
      flash = { message: "マスタ未登録", type: "warn" };
    }
    if (!Number(imported.scanned || 0)) {
      flash = { message: "要確認", type: "warn" };
      logLine("接続準備・新規取込 要確認: 端末を検出できません。USBデバッグを許可して、同じボタンをもう一度押してください");
    }
    await loadSummary({ includeAdb: true, includeUptime: false });
    reloadTagBoardFrame();
  } catch (error) {
    flash = { message: "失敗", type: "error" };
    logLine("接続準備・新規取込 NG: " + error.message);
    window.alert("接続準備・新規端末取込に失敗しました。\n" + error.message);
  } finally {
    setBusy(false, button);
    flashButtonResult(button, flash.message, flash.type);
  }
}

function setupRewardCalculator() {
  fillSelect(el("calcCiSelect"), CALC_OPTIONS.ci, "yen");
  fillSelect(el("calc180Select"), CALC_OPTIONS.video180, "points");
  fillSelect(el("calc10Select"), CALC_OPTIONS.video10, "yen");
  el("calcCiSelect").value = "0";
  el("calc180Select").value = "0";
  el("calc10Select").value = "0";
  for (const id of ["calcCiSelect", "calc180Select", "calc10Select", "calc10CustomInput"]) {
    el(id).addEventListener("input", renderRewardCalculator);
    el(id).addEventListener("change", renderRewardCalculator);
  }
  renderRewardCalculator();
}

function fillSelect(select, options, valueKey) {
  select.innerHTML = options.map((option) => {
    const value = option[valueKey];
    return `<option value="${esc(value)}">${esc(option.label)}</option>`;
  }).join("");
}

function rowXiaoweiNumber(row) {
  return row?.xiaoweiNumber || row?.laixiNumber || row?.managementId || row?.xiaoweiSort || "";
}

async function loadSummary(options = {}) {
  const includeAdb = Boolean(options.includeAdb);
  const includeUptime = options.includeUptime !== false;
  setBusy(true);
  try {
    const [result, master, adbDevices, xiaoweiMissing] = await Promise.all([
      fetchJson("/api/fleet-db/summary"),
      fetchJson("/api/device-master").catch((error) => ({ ok: false, error: error.message, entries: [] })),
      includeAdb
        ? fetchJson(`/api/adb/devices${includeUptime ? "" : "?uptime=0"}`).catch((error) => ({ ok: false, error: error.message, devices: [] }))
        : Promise.resolve(state.adbDevices || { ok: true, skipped: true, devices: [] }),
      includeAdb
        ? fetchJson("/api/xiaowei/missing-from-xiaowei").catch((error) => ({ ok: false, error: error.message, rows: [] }))
        : Promise.resolve(null),
    ]);
    state.summary = result;
    state.deviceMaster = master;
    if (includeAdb || !state.adbDevices) storeAdbDevices(adbDevices);
    renderAll(result);
    renderDeviceMaster(master);
    const adbRows = state.adbDevices?.devices || [];
    renderAdbSwipePanel(result.devices || [], adbRows);
    renderSwipeAgentPanel(result.devices || [], adbRows);
    if (xiaoweiMissing) logXiaoweiMissingDevices(xiaoweiMissing);
    logLine(includeAdb ? `DB再読込 OK / ADB${includeUptime ? "稼働時間込み" : "軽量"}` : "DB再読込 OK");
  } catch (error) {
    logLine("DB再読込 NG: " + error.message);
  } finally {
    setBusy(false);
    checkFleetDbRecovery();
  }
}

async function loadLocalSummaryOnly() {
  const [result, master] = await Promise.all([
    fetchJson("/api/fleet-db/summary"),
    fetchJson("/api/device-master").catch((error) => ({ ok: false, error: error.message, entries: [] })),
  ]);
  state.summary = result;
  state.deviceMaster = master;
  renderAll(result);
  renderDeviceMaster(master);
  renderAdbSwipePanel(result.devices || [], state.adbDevices?.devices || []);
  renderSwipeAgentPanel(result.devices || [], state.adbDevices?.devices || []);
  return result;
}

async function checkFleetDbRecovery() {
  if (state.fleetDbRecoveryChecked || state.fleetDbRecoveryPrompted) return;
  state.fleetDbRecoveryChecked = true;
  try {
    const status = await fetchJson("/api/fleet-db/recovery-status");
    const candidate = (status.candidates || []).find((item) => item.candidateId === status.recommendedCandidateId);
    if (!status.recoveryNeeded || !candidate) return;
    state.fleetDbRecoveryPrompted = true;
    showFleetDbRecoveryDialog(status, candidate);
  } catch (error) {
    logLine("端末DB復旧確認 NG: " + error.message);
  }
}

function showFleetDbRecoveryDialog(status, candidate) {
  closeAdbDropDialog();
  const current = status.current || {};
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop fleet-db-recovery-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog" role="dialog" aria-modal="true" aria-labelledby="fleetDbRecoveryTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="fleetDbRecoveryTitle">端末DBを復旧できます</h3>
          <p>現在 接続${esc(current.devices || 0)}台・未接続${esc(current.offlineDevices || 0)}台 / チェック一覧 ${esc(status.tagBoardRows || 0)}台 / 更新直前バックアップ 接続${esc(candidate.devices || 0)}台・未接続${esc(candidate.offlineDevices || 0)}台</p>
        </div>
        <button class="adb-drop-close fleet-db-recovery-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="adb-missing-empty">
        <strong>更新前の端末DBが残っています。</strong><br>
        復旧前の現在DBも別の安全バックアップへ保存してから戻します。端末名、DAY、出金履歴を含むDBが対象です。<br>
        候補: ${esc(candidate.sourceLabel || "更新前バックアップ")} / ${esc(formatDateTime(candidate.backupAt || candidate.modifiedAt || ""))}
      </div>
      <div class="adb-drop-actions">
        <button class="section-head-action fleet-db-recovery-close" type="button">今は戻さない</button>
        <button class="section-head-action action-sync fleet-db-recover-action" type="button">更新直前DBを復旧</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".fleet-db-recovery-close").forEach((button) => {
    button.addEventListener("click", closeFleetDbRecoveryDialog);
  });
  overlay.querySelector(".fleet-db-recover-action")?.addEventListener("click", (event) => {
    recoverFleetDbFromDialog(status, candidate, event.currentTarget);
  });
}

async function recoverFleetDbFromDialog(status, candidate, button) {
  button.disabled = true;
  const originalLabel = button.textContent;
  button.textContent = "復旧中...";
  try {
    const result = await fetchJson("/api/fleet-db/recover", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        candidateId: candidate.candidateId,
        expectedCurrentDevices: Number(status.current?.devices || 0),
      }),
    });
    closeFleetDbRecoveryDialog();
    await loadLocalSummaryOnly();
    reloadTagBoardFrame();
    logLine(`端末DB復旧 OK: 接続${result.restored?.devices || 0}台・未接続${result.restored?.offlineDevices || 0}台 / 復旧前DBも保存済み`);
    window.alert(`端末DBを接続${result.restored?.devices || 0}台・未接続${result.restored?.offlineDevices || 0}台で復旧しました。\nチェック一覧と端末DBを再読込しました。`);
  } catch (error) {
    logLine("端末DB復旧 NG: " + error.message);
    window.alert("端末DBの復旧に失敗しました。\n" + error.message);
    button.disabled = false;
    button.textContent = originalLabel;
  }
}

function closeFleetDbRecoveryDialog() {
  document.querySelector(".fleet-db-recovery-backdrop")?.remove();
}

async function refreshDeviceMasterAndLocalSummary() {
  state.deviceMaster = await fetchJson("/api/device-master");
  renderDeviceMaster(state.deviceMaster);
  await loadLocalSummaryOnly();
}

function storeAdbDevices(adbDevices) {
  const fetchedAt = Date.now();
  const devices = Array.isArray(adbDevices?.devices) ? adbDevices.devices : [];
  rememberAdbLastSeen(devices, adbDevices, fetchedAt);
  const missingSerials = notifyAdbConnectionDrop(devices, adbDevices);
  state.adbMissingSerials = new Set(missingSerials);
  state.adbDevices = {
    ...(adbDevices || { ok: false, devices: [] }),
    devices: devices.map((device) => ({
      ...device,
      uptimeFetchedAt: Number.isFinite(Number(device.uptimeSeconds)) ? fetchedAt : 0,
    })),
    uptimeFetchedAt: fetchedAt,
  };
}

function rememberAdbLastSeen(devices = [], adbDevices = {}, fetchedAt = Date.now()) {
  if (!adbDevices || adbDevices.ok === false || adbDevices.skipped) return;
  const lastSeen = safeJsonObject(localStorage.getItem(ADB_LAST_SEEN_KEY));
  for (const device of devices) {
    if (!device?.serial || !(device.status === "device" || device.connected === true)) continue;
    lastSeen[String(device.serial)] = fetchedAt;
  }
  localStorage.setItem(ADB_LAST_SEEN_KEY, JSON.stringify(lastSeen));
}

function notifyAdbConnectionDrop(devices = [], adbDevices = {}) {
  if (!adbDevices || adbDevices.ok === false || adbDevices.skipped) return;
  const connectedSerials = devices
    .filter((device) => device && device.serial && (device.status === "device" || device.connected === true))
    .map((device) => String(device.serial))
    .sort();
  const connected = Number(adbDevices.connected ?? connectedSerials.length);
  const previousRaw = localStorage.getItem(ADB_CONNECTED_COUNT_KEY);
  const previous = previousRaw === null ? null : Number(previousRaw);
  const previousSerials = safeJsonArray(localStorage.getItem(ADB_CONNECTED_SERIALS_KEY));
  localStorage.setItem(ADB_CONNECTED_COUNT_KEY, String(connected));
  localStorage.setItem(ADB_CONNECTED_SERIALS_KEY, JSON.stringify(connectedSerials));
  if (!Number.isFinite(previous)) return [];
  if (previous <= connected) {
    if (previous < connected) localStorage.removeItem(ADB_DROP_ALERT_KEY);
    return [];
  }
  const missing = previousSerials.filter((serial) => !connectedSerials.includes(serial));
  if (!missing.length) return [];
  const alertKey = `dialog:${previous}->${connected}:${missing.slice(0, 20).join(",")}`;
  if (localStorage.getItem(ADB_DROP_ALERT_KEY) !== alertKey) {
    localStorage.setItem(ADB_DROP_ALERT_KEY, alertKey);
    const missingRows = missing.map(adbDropDeviceInfo);
    const missingText = ` / 消えた端末: ${missingRows.slice(0, 12).map((row) => row.label).join(", ")}${missing.length > 12 ? "..." : ""}`;
    const message = `ADB接続が減りました: ${previous}台 -> ${connected}台${missingText}`;
    logLine(message);
    if (!isAlertSuppressed(ALERT_ADB_DROP)) showAdbDropDialog({ previous, connected, missing, missingRows });
  }
  return missing;
}

function adbDropDeviceInfo(serial) {
  const row = (state.summary?.devices || []).find((device) => String(device.serial || "") === String(serial)) || {};
  const number = rowXiaoweiNumber(row);
  const name = row.laixiName || row.deviceLabel || row.deviceName || row.xiaoweiName || row.modelGroup || "";
  const master = row.deviceName || row.originalName || "";
  const label = [number, name].filter(Boolean).join(" / ") || String(serial || "");
  return {
    serial: String(serial || ""),
    number,
    name,
    master,
    status: row.status || "",
    label,
  };
}

function showAdbDropDialog({ previous, connected, missing, missingRows = null }) {
  closeAdbDropDialog();
  const rows = Array.isArray(missingRows) ? missingRows : missing.map(adbDropDeviceInfo);
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog" role="alertdialog" aria-modal="true" aria-labelledby="adbDropDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="adbDropDialogTitle">ADB接続が切れた端末があります</h3>
          <p>${esc(previous)}台 → ${esc(connected)}台 / 切断 ${esc(missing.length)}台</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="adb-drop-list">
        ${rows.map((row) => `
          <div class="adb-drop-device">
            <div class="adb-drop-device-main">
              <strong>${esc(row.number || "-")}</strong>
              <span>${esc(row.name || "端末名なし")}</span>
            </div>
            <div class="adb-drop-device-sub">
              ${row.master && row.master !== row.name ? `<span>マスタ: ${esc(row.master)}</span>` : ""}
              ${row.status ? `<span>状態: ${esc(row.status)}</span>` : ""}
              <code>${esc(row.serial)}</code>
            </div>
          </div>
        `).join("")}
      </div>
      <div class="adb-drop-actions">
        ${renderAlertSuppressCheckbox("ADB切断アラートを今後出さない")}
        <button class="section-head-action primary-action adb-drop-diagnose-action" type="button">処置する</button>
        <button class="section-head-action adb-drop-ignore-action" type="button" title="意図的に抜いた端末として、今回の切断を集計しません">意図的に外した</button>
        <button class="section-head-action adb-alert-ok-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  bindAlertOkAction(overlay, ALERT_ADB_DROP);
  overlay.querySelector(".adb-drop-diagnose-action")?.addEventListener("click", (event) => {
    showUsbAdbDiagnosisDialog(event.currentTarget);
  });
  overlay.querySelector(".adb-drop-ignore-action")?.addEventListener("click", (event) => {
    ignoreAdbDropHistory(missing, event.currentTarget);
  });
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((button) => {
    button.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

async function ignoreAdbDropHistory(serials, button = null) {
  const clean = [...new Set((serials || []).map((serial) => String(serial || "").trim()).filter(Boolean))];
  if (!clean.length) return;
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/fleet-db/connection-incidents/ignore", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ serials: clean }),
    });
    logLine(`意図的な取り外し: ${result.serials?.length || clean.length}台を切断集計から除外`);
    closeAdbDropDialog();
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine("切断履歴の除外 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function closeAdbDropDialog() {
  document.querySelector(".adb-drop-dialog-backdrop")?.remove();
}

function adbMissingRows() {
  const rows = Array.isArray(state.summary?.devices) ? state.summary.devices : [];
  const adbRows = Array.isArray(state.adbDevices?.devices) ? state.adbDevices.devices : [];
  const lastSeen = safeJsonObject(localStorage.getItem(ADB_LAST_SEEN_KEY));
  const connectedSerials = new Set(adbRows
    .filter((device) => device && device.serial && (device.status === "device" || device.connected === true))
    .map((device) => String(device.serial)));
  return rows
    .filter((row) => row && row.serial && !connectedSerials.has(String(row.serial)))
    .map((row) => ({
      number: rowXiaoweiNumber(row),
      xiaoweiNumber: rowXiaoweiNumber(row),
      laixiNumber: row.laixiNumber || row.managementId || "",
      name: row.deviceLabel || row.laixiName || row.deviceName || row.modelGroup || "",
      xiaoweiName: row.laixiName || "",
      model: row.modelGroup || "",
      status: row.status || "",
      serial: row.serial || "",
      lastSeenAt: adbMissingLastSeenAt(row, lastSeen),
    }))
    .sort((a, b) => managementNumber(a) - managementNumber(b) || String(a.name).localeCompare(String(b.name), "ja"));
}

async function showAdbMissingListDialog(button = null) {
  setBusy(true, button);
  try {
    const adbDevices = await fetchJson("/api/adb/devices?uptime=0");
    storeAdbDevices(adbDevices);
    if (adbDevices.connectionHistoryChanged) {
      await loadLocalSummaryOnly();
    } else if (state.summary?.devices) {
      renderDevices(state.summary.devices);
    }
  } catch (error) {
    logLine("ADB未認識一覧の再読込 NG: " + error.message);
  } finally {
    setBusy(false);
  }
  const rows = adbMissingRows();
  const activeRows = rows.filter((row) => String(row.status || "").toUpperCase() === "ACTIVE");
  closeAdbDropDialog();
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog" role="dialog" aria-modal="true" aria-labelledby="adbMissingDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="adbMissingDialogTitle">ADB未認識端末</h3>
          <p>DB登録 ${esc((state.summary?.devices || []).length)}台 / ADB認識 ${esc(state.adbDevices?.connected ?? "-")}台 / 未認識 ${esc(rows.length)}台${activeRows.length ? ` / ACTIVE ${esc(activeRows.length)}台` : ""}</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      ${rows.length ? `
        <div class="adb-missing-table-wrap">
          <table class="adb-missing-table">
            <thead>
              <tr>
                <th>選択</th>
                <th>番号</th>
                <th>名前</th>
                <th>状態</th>
                <th>最終認識</th>
                <th>端末ID</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map((row) => `
                <tr class="${String(row.status || "").toUpperCase() === "ACTIVE" ? "adb-missing-active" : ""}">
                  <td>${esc(row.number)}</td>
                  <td>
                    <strong>${esc(row.name)}</strong>
                    ${row.xiaoweiName && row.xiaoweiName !== row.name ? `<span>${esc(row.xiaoweiName)}</span>` : ""}
                  </td>
                  <td>${esc(row.status || "-")}</td>
                  <td>${esc(formatAdbLastSeen(row.lastSeenAt))}</td>
                  <td><code>${esc(row.serial)}</code></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">ADB未認識端末はありません。</div>`}
      <div class="adb-drop-actions">
        <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((button) => {
    button.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

async function showUsbAdbDiagnosisDialog(button = null) {
  setBusy(true, button);
  let result = null;
  try {
    result = await fetchJson("/api/adb/usb-diagnosis");
    logLine(`端末トラブル診断: DB ${result.dbCount || 0}台 / ADB ${result.adbCount || 0}台 / 要確認 ${(result.rows || []).length}台`);
  } catch (error) {
    logLine("端末トラブル診断 NG: " + error.message);
    result = { ok: false, rows: [], error: error.message, warning: error.message, counts: {} };
  } finally {
    setBusy(false);
  }
  const rows = Array.isArray(result.rows) ? result.rows : [];
  const hasRepairableRows = rows.some((row) => row.diagnosis !== "adb_ok" && row.serial);
  closeAdbDropDialog();
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog usb-adb-diagnosis-dialog" role="dialog" aria-modal="true" aria-labelledby="usbAdbDiagnosisDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="usbAdbDiagnosisDialogTitle">端末トラブル診断</h3>
          <p>DB ${esc(result.dbCount ?? "-")}台 / ADB ${esc(result.adbCount ?? "-")}台 / 要確認 ${esc(rows.length)}台</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      ${result.warning ? `<div class="adb-missing-empty">警告: ${esc(result.warning)}</div>` : ""}
      <div class="usb-diagnosis-summary">
        ${usbDiagnosisCountChip(result.counts, "adb_unauthorized", "許可待ち")}
        ${usbDiagnosisCountChip(result.counts, "projection_ok_adb_ng", "画面だけ見える")}
        ${usbDiagnosisCountChip(result.counts, "usb_mode_no_adb", "USBモード要確認")}
        ${usbDiagnosisCountChip(result.counts, "usb_only", "半分見えてる")}
        ${usbDiagnosisCountChip(result.counts, "pnp_phantom", "記録だけ")}
        ${usbDiagnosisCountChip(result.counts, "not_seen", "線が届いてない")}
      </div>
      ${hasRepairableRows ? `
        <div class="usb-diagnosis-top-actions">
          <span>直したい端末へチェックを入れて実行</span>
          <button class="section-head-action usb-auto-repair-selected-btn usb-auto-repair-selected-top" type="button" disabled>選択した端末を復旧（0台）</button>
        </div>
      ` : ""}
      ${rows.length ? `
        <div class="adb-missing-table-wrap">
          <table class="adb-missing-table usb-adb-diagnosis-table">
            <thead>
              <tr>
                <th>選択</th>
                <th>番号</th>
                <th>名前</th>
                <th>今の状態</th>
                <th>ADB</th>
                <th>XiaoWei</th>
                <th>Windows</th>
                <th>次にやること</th>
                <th>端末ID</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map((row) => `
                <tr class="usb-diagnosis-row ${esc(row.severity || "")}">
                  <td class="usb-repair-select-cell">
                    ${row.serial && row.diagnosis !== "adb_ok" ? `<input class="usb-repair-select" type="checkbox" value="${esc(row.serial)}" aria-label="${esc(row.number || row.name || row.serial)}を復旧対象にする">` : ""}
                  </td>
                  <td>${esc(row.number || row.managementId || "-")}</td>
                  <td>
                    <strong>${esc(row.name || "端末名なし")}</strong>
                    ${row.model ? `<span>${esc(row.model)}</span>` : ""}
                  </td>
                  <td>${usbDiagnosisChip(row)}</td>
                  <td>
                    <strong>${esc(row.adbStatus || "なし")}</strong>
                    ${row.adbPort ? `<span>port ${esc(row.adbPort)}</span>` : ""}
                    ${row.adbModel ? `<span>${esc(row.adbModel)}</span>` : ""}
                  </td>
                  <td>
                    <strong>${esc(row.xiaoweiState || "-")}</strong>
                    ${row.xiaoweiName ? `<span>${esc(row.xiaoweiName)}</span>` : ""}
                  </td>
                  <td>
                    <strong>${esc(row.pnpStatus || "-")}</strong>
                    ${usbPnpDetail(row.pnpRows)}
                  </td>
                  <td>
                    <strong>${esc(row.action || "-")}</strong>
                    ${row.recoveryCommand && row.diagnosis !== "adb_ok" ? `
                      <button class="section-head-action usb-auto-repair-row-btn" data-serial="${esc(row.serial || "")}" type="button">自動復旧</button>
                      <span class="usb-recovery-label">${esc(row.recoveryCommandLabel || "対象だけ復旧コマンド")}</span>
                      <code class="usb-recovery-command">${esc(row.recoveryCommand)}</code>
                    ` : ""}
                  </td>
                  <td><code>${esc(row.serial || "")}</code></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">要確認端末はありません。</div>`}
      <div class="usb-diagnosis-guide">
        <strong>見方</strong>
        <span>許可待ち: スマホ画面で許可</span>
        <span>半分見えてる: USBは届いてるが操作用の接続が死んでる</span>
        <span>記録だけ: Windowsに古い記録だけ残っている</span>
        <span>線が届いてない: ケーブル/ハブ/電源/端末端子を確認</span>
      </div>
      <div class="adb-drop-actions">
        ${isAlertSuppressed(ALERT_ADB_DROP)
          ? `<button class="section-head-action adb-drop-alert-resume-action" type="button">切断アラートを再開</button>`
          : `<span class="usb-alert-status">切断アラート ON</span>`}
        ${hasRepairableRows ? `<button class="section-head-action usb-auto-repair-selected-btn" type="button" disabled>選択した端末を復旧（0台）</button>` : ""}
        <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".usb-auto-repair-row-btn").forEach((repairButton) => {
    repairButton.addEventListener("click", () => launchUsbAutoRepair([repairButton.dataset.serial], repairButton));
  });
  const selectedRepairButtons = [...overlay.querySelectorAll(".usb-auto-repair-selected-btn")];
  const repairCheckboxes = [...overlay.querySelectorAll(".usb-repair-select")];
  const updateSelectedRepairButton = () => {
    const count = repairCheckboxes.filter((checkbox) => checkbox.checked).length;
    selectedRepairButtons.forEach((repairButton) => {
      repairButton.disabled = count === 0;
      repairButton.textContent = `選択した端末を復旧（${count}台）`;
    });
  };
  repairCheckboxes.forEach((checkbox) => checkbox.addEventListener("change", () => {
    checkbox.closest("tr")?.classList.toggle("repair-selected", checkbox.checked);
    updateSelectedRepairButton();
  }));
  overlay.querySelector(".adb-drop-alert-resume-action")?.addEventListener("click", (event) => {
    localStorage.removeItem(ALERT_SUPPRESS_KEY_PREFIX + ALERT_ADB_DROP);
    event.currentTarget.outerHTML = `<span class="usb-alert-status">切断アラート ON</span>`;
    logLine("ADB切断アラートを再開しました");
  });
  selectedRepairButtons.forEach((repairButton) => {
    repairButton.addEventListener("click", (event) => {
      const serials = repairCheckboxes.filter((checkbox) => checkbox.checked).map((checkbox) => checkbox.value);
      launchUsbAutoRepair(serials, event.currentTarget);
    });
  });
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((closeButton) => {
    closeButton.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

async function launchUsbAutoRepair(serials = [], button = null) {
  const clean = [...new Set((serials || []).map((serial) => String(serial || "").trim()).filter(Boolean))];
  if (!clean.length) return logLine("USB自動復旧: 対象端末がありません");
  const ok = window.confirm(`${clean.length}台のUSB/ADB強制復旧を開始します。\nWindowsの確認画面が出たら「はい」を押してください。\n戻らない選択端末はWindowsのUSB記録を現役分も作り直し、ADB 5037を停止して5038へ戻します。USBハブ全体は再起動しません。`);
  if (!ok) return;
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/adb/usb-repair", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ serials: clean, deep: true, takeover5038: true }),
    });
    logLine(`USB自動復旧 起動: ${result.serials?.length || clean.length}台 / UACが出たら許可`);
    if (result.logPath) logLine(`USB自動復旧ログ: ${result.logPath}`);
    flashButtonResult(button, "起動", "ok", 2200);
  } catch (error) {
    logLine("USB自動復旧 NG: " + error.message);
    flashButtonResult(button, "失敗", "error", 2200);
  } finally {
    setBusy(false);
  }
}

function usbDiagnosisCountChip(counts = {}, key, label) {
  const value = Number(counts && counts[key] || 0);
  return `<span class="${value ? "active" : ""}">${esc(label)} ${esc(value)}台</span>`;
}

function usbDiagnosisChip(row) {
  const severity = String(row?.severity || "");
  return `<span class="usb-diagnosis-chip ${esc(severity)}">${esc(row?.diagnosisLabel || "-")}</span>`;
}

function usbPnpDetail(rows = []) {
  const list = Array.isArray(rows) ? rows.slice(0, 3) : [];
  if (!list.length) return "";
  return list.map((item) => `<span>${esc([item.status, item.class, item.friendlyName].filter(Boolean).join(" / "))}</span>`).join("");
}

async function showXiaoweiMissingListDialog(button = null) {
  setBusy(true, button);
  let result = null;
  try {
    result = await fetchJson("/api/xiaowei/missing-from-xiaowei");
    logLine(`XiaoWei未認識一覧: DB ${result.dbCount || 0}台 / XiaoWei ${result.xiaoweiCount || 0}台 / 未認識 ${result.missingCount || 0}台`);
  } catch (error) {
    logLine("XiaoWei未認識一覧 NG: " + error.message);
    result = { ok: false, rows: [], error: error.message };
  } finally {
    setBusy(false);
  }
  closeAdbDropDialog();
  const rows = Array.isArray(result.rows) ? result.rows : [];
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog" role="dialog" aria-modal="true" aria-labelledby="xiaoweiMissingDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="xiaoweiMissingDialogTitle">XiaoWei未認識端末</h3>
          <p>DB登録 ${esc(result.dbCount ?? "-")}台 / XiaoWei認識 ${esc(result.xiaoweiApiCount ?? result.xiaoweiCount ?? "-")}台 / 未認識 ${esc(rows.length)}台</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      ${result.warning ? `<div class="adb-missing-empty">警告: ${esc(result.warning)}</div>` : ""}
      ${rows.length ? `
        <div class="adb-missing-table-wrap">
          <table class="adb-missing-table">
            <thead>
              <tr>
                <th>番号</th>
                <th>名前</th>
                <th>状態</th>
                <th>見え方</th>
                <th>管理ID</th>
                <th>端末ID</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map((row) => `
                <tr>
                  <td>${esc(rowXiaoweiNumber(row) || "-")}</td>
                  <td>
                    <strong>${esc(row.name || "端末名なし")}</strong>
                    ${row.deviceName && row.deviceName !== row.name ? `<span>${esc(row.deviceName)}</span>` : ""}
                  </td>
                  <td>${esc(row.status || "-")}</td>
                  <td>${esc(xiaoweiSourceLabel(row.xiaoweiSource))}</td>
                  <td>${esc(row.managementId || "-")}</td>
                  <td><code>${esc(row.serial || "")}</code></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">XiaoWei未認識端末はありません。</div>`}
      <div class="adb-drop-actions">
        <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((closeButton) => {
    closeButton.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

function logXiaoweiMissingDevices(result) {
  const rows = Array.isArray(result?.rows) ? result.rows : [];
  if (!rows.length) return;
  logLine(`XiaoWei未認識: ${rows.length}台 / ${rows.slice(0, 8).map((row) => `${rowXiaoweiNumber(row) || row.managementId} ${row.name || row.serial}`).join(", ")}${rows.length > 8 ? "..." : ""}`);
}

function renderAlertSuppressCheckbox(label) {
  return `
    <label class="adb-alert-suppress">
      <input type="checkbox" class="adb-alert-suppress-checkbox">
      <span>${esc(label)}</span>
    </label>
  `;
}

function bindAlertOkAction(overlay, alertKey) {
  overlay.querySelectorAll(".adb-alert-ok-action").forEach((button) => {
    button.addEventListener("click", () => {
      if (overlay.querySelector(".adb-alert-suppress-checkbox")?.checked) suppressAlert(alertKey);
      closeAdbDropDialog();
    });
  });
}

function isAlertSuppressed(alertKey) {
  return localStorage.getItem(ALERT_SUPPRESS_KEY_PREFIX + alertKey) === "1";
}

function suppressAlert(alertKey) {
  localStorage.setItem(ALERT_SUPPRESS_KEY_PREFIX + alertKey, "1");
  const label = alertKey === ALERT_ADB_DROP ? "ADB切断" : alertKey;
  logLine(`${label}アラートを停止しました`);
}

function xiaoweiIssueChips(values = []) {
  const labels = Array.isArray(values) ? values : [];
  if (!labels.length) return `<span>-</span>`;
  return `<div class="xiaowei-issue-chips">${labels.map((label) => `<span>${esc(xiaoweiIssueLabel(label))}</span>`).join("")}</div>`;
}

function xiaoweiIssueLabel(value) {
  return {
    fleet_missing: "DB未登録",
    xiaowei_missing: "XiaoWei未認識",
    not_projected: "未投影",
    resolution_zero: "0x0",
    number_missing: "番号なし",
    name_missing: "名前なし",
    number_mismatch: "番号違い",
    name_mismatch: "名前違い",
  }[String(value || "")] || String(value || "");
}

async function showDeviceCodeAuditDialog(button = null) {
  setBusy(true, button);
  let result = null;
  try {
    result = await fetchJson("/api/fleet-db/device-code-audit");
    logLine(`DB連番監査: グループ ${result.groupCount || 0}件 / 異常 ${result.issueCount || 0}件`);
  } catch (error) {
    logLine("DB連番監査 NG: " + error.message);
    result = { ok: false, rows: [], groups: [], error: error.message };
  } finally {
    setBusy(false);
  }
  closeAdbDropDialog();
  const rows = Array.isArray(result.rows) ? result.rows : [];
  const groups = Array.isArray(result.groups) ? result.groups : [];
  const repairableGroups = groups.filter((group) =>
    (Array.isArray(group.missingSequences) && group.missingSequences.length) ||
    (Array.isArray(group.duplicateSequences) && group.duplicateSequences.length)
  );
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog xiaowei-projection-dialog" role="dialog" aria-modal="true" aria-labelledby="deviceCodeAuditDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="deviceCodeAuditDialogTitle">DB連番監査</h3>
          <p>DB ${esc(result.dbCount ?? "-")}台 / グループ ${esc(result.groupCount ?? "-")}件 / 異常 ${esc(rows.length)}件</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      ${groups.length ? `
        <div class="device-code-audit-groups">
          ${groups.map((group) => `
            <div class="device-code-audit-group">
              <strong>${esc([group.base, group.carrier].filter(Boolean).join(" / "))}</strong>
               <span>${esc(group.count)}台</span>
               ${Array.isArray(group.reservedSequences) && group.reservedSequences.length ? `<span>管理対象外で使用済み: ${esc(group.reservedSequences.map((seq) => String(seq).padStart(2, "0")).join(", "))}</span>` : ""}
               ${Array.isArray(group.missingSequences) && group.missingSequences.length ? `<span>抜け: ${esc(group.missingSequences.map((seq) => String(seq).padStart(2, "0")).join(", "))}</span>` : ""}
              ${Array.isArray(group.duplicateSequences) && group.duplicateSequences.length ? `<span>重複: ${esc(group.duplicateSequences.map((seq) => String(seq).padStart(2, "0")).join(", "))}</span>` : ""}
              <span>異常: ${esc(group.issueCount || 0)}</span>
            </div>
          `).join("")}
        </div>
      ` : ""}
      ${rows.length ? `
        <div class="adb-missing-table-wrap">
          <table class="adb-missing-table xiaowei-projection-table device-code-audit-table">
            <thead>
              <tr>
                <th>番号</th>
                <th>現在</th>
                <th>期待</th>
                <th>グループ</th>
                <th>異常</th>
                <th>端末ID</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map((row) => `
                <tr>
                  <td>
                    <strong>${esc(row.xiaoweiNumber || "-")}</strong>
                    ${row.managementId ? `<span>${esc(row.managementId)}</span>` : ""}
                  </td>
                  <td>
                    <strong>${esc(row.deviceLabel || row.deviceCode || "端末名なし")}</strong>
                    ${row.xiaoweiName ? `<span>XiaoWei: ${esc(row.xiaoweiName)}</span>` : ""}
                  </td>
                  <td>
                    <strong>${esc(row.expectedLabel || "-")}</strong>
                    ${row.expectedSequenceByOrder ? `<span>順番上は ${esc(String(row.expectedSequenceByOrder).padStart(2, "0"))}</span>` : ""}
                  </td>
                  <td>${esc([row.base, row.carrier].filter(Boolean).join(" / ") || "-")}</td>
                  <td>${xiaoweiIssueChips(row.issueLabels || row.issues)}</td>
                  <td><code>${esc(row.serial || "")}</code></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">DB連番の異常はありません。</div>`}
      <div class="adb-drop-actions">
        ${repairableGroups.length ? `<button id="repairDeviceCodeGapsBtn" class="section-head-action" type="button">重複/抜けを修正</button>` : ""}
        <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelector("#repairDeviceCodeGapsBtn")?.addEventListener("click", (event) => repairDeviceCodeGaps(event.currentTarget));
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((closeButton) => {
    closeButton.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

async function repairDeviceCodeGaps(button = null) {
  if (!window.confirm("DB内の重複/抜け連番を並び順で修正します。修正後はXiaoWei名同期で反映できます。実行しますか？")) return;
  setBusy(true, button);
  let result = null;
  try {
    result = await fetchJson("/api/fleet-db/device-code-repair", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    logLine(`DB連番修正: グループ ${result.repaired || 0}件 / 端末 ${result.changedDevices || 0}台 / バックアップ ${result.backup || "-"}`);
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine("DB連番修正 NG: " + error.message);
    result = { ok: false, rows: [], groups: [], error: error.message };
  } finally {
    setBusy(false);
  }
  if (result?.audit) {
    renderDeviceCodeRepairResultDialog(result);
  }
}

function renderDeviceCodeRepairResultDialog(result) {
  closeAdbDropDialog();
  const changes = Array.isArray(result.changes) ? result.changes : [];
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog xiaowei-projection-dialog" role="dialog" aria-modal="true" aria-labelledby="deviceCodeRepairDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="deviceCodeRepairDialogTitle">DB連番修正結果</h3>
          <p>修正グループ ${esc(result.repaired || 0)}件 / 変更 ${esc(result.changedDevices || 0)}台 / 残り異常 ${esc(result.audit?.issueCount ?? "-")}件</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      ${changes.length ? `
        <div class="adb-missing-table-wrap">
          <table class="adb-missing-table xiaowei-projection-table device-code-audit-table">
            <thead>
              <tr>
                <th>番号</th>
                <th>変更前</th>
                <th>変更後</th>
                <th>グループ</th>
                <th>管理ID</th>
                <th>端末ID</th>
              </tr>
            </thead>
            <tbody>
              ${changes.map((row) => `
                <tr>
                  <td>${esc(row.xiaoweiNumber || "-")}</td>
                  <td><strong>${esc(row.beforeCode || "-")}</strong>${row.beforeLabel ? `<span>${esc(row.beforeLabel)}</span>` : ""}</td>
                  <td><strong>${esc(row.afterCode || "-")}</strong>${row.afterLabel ? `<span>${esc(row.afterLabel)}</span>` : ""}</td>
                  <td>${esc([row.base, row.carrier].filter(Boolean).join(" / ") || "-")}</td>
                  <td>${esc(row.managementId || "-")}</td>
                  <td><code>${esc(row.serial || "")}</code></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">${esc(result.message || "変更はありません。")}</div>`}
      <div class="adb-drop-actions">
        <button id="openDeviceCodeAuditAfterRepairBtn" class="section-head-action" type="button">監査を開く</button>
        <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelector("#openDeviceCodeAuditAfterRepairBtn")?.addEventListener("click", () => showDeviceCodeAuditDialog());
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((closeButton) => {
    closeButton.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

function xiaoweiSourceLabel(source) {
  return {
    api: "API認識",
    db_only: "DBのみ",
    db: "XiaoWei DB",
    "db+api": "DB+API",
    missing: "未認識",
  }[String(source || "")] || "-";
}

function adbMissingLastSeenAt(row, lastSeen = {}) {
  const serial = String(row?.serial || "");
  const fromLocal = Number(lastSeen[serial] || 0);
  if (Number.isFinite(fromLocal) && fromLocal > 0) return fromLocal;
  const fallback = Date.parse(row?.adbLastBatteryCheckedAt || row?.adbLastUptimeCheckedAt || "");
  return Number.isFinite(fallback) ? fallback : 0;
}

function formatAdbLastSeen(value) {
  const ms = Number(value || 0);
  if (!Number.isFinite(ms) || ms <= 0) return "不明";
  const date = new Date(ms);
  const pad = (number) => String(number).padStart(2, "0");
  return `${pad(date.getMonth() + 1)}/${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function startAdbConnectionMonitor() {
  if (state.adbConnectionMonitorTimer) window.clearInterval(state.adbConnectionMonitorTimer);
  state.adbConnectionMonitorTimer = window.setInterval(refreshAdbConnectionSnapshot, ADB_CONNECTION_MONITOR_INTERVAL_MS);
}

async function refreshAdbConnectionSnapshot() {
  if (state.busy || state.adbConnectionMonitorBusy || document.hidden) return;
  state.adbConnectionMonitorBusy = true;
  try {
    const adbDevices = await fetchJson("/api/adb/devices?uptime=0");
    storeAdbDevices(adbDevices);
    if (state.summary?.devices) {
      renderDevices(state.summary.devices);
      renderApnTargets(state.summary.devices);
      renderOperationGroupPicker();
    }
  } catch (error) {
    logLine("ADB接続確認 NG: " + error.message);
  } finally {
    state.adbConnectionMonitorBusy = false;
  }
}

function startDeviceFactsAutoRefresh() {
  if (state.deviceFactsAutoTimer) window.clearInterval(state.deviceFactsAutoTimer);
  window.setTimeout(() => refreshDeviceUptime(null, { silent: true, auto: true }), DEVICE_FACTS_AUTO_START_DELAY_MS);
  state.deviceFactsAutoTimer = window.setInterval(
    () => refreshDeviceUptime(null, { silent: true, auto: true }),
    DEVICE_FACTS_AUTO_INTERVAL_MS
  );
}

function safeJsonArray(value) {
  try {
    const parsed = JSON.parse(value || "[]");
    return Array.isArray(parsed) ? parsed.map((item) => String(item)).filter(Boolean) : [];
  } catch {
    return [];
  }
}

function safeJsonObject(value) {
  try {
    const parsed = JSON.parse(value || "{}");
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

async function refreshDeviceUptime(button = null, options = {}) {
  const silent = Boolean(options.silent);
  const auto = Boolean(options.auto);
  if (auto) {
    if (state.busy || state.deviceFactsAutoBusy || document.hidden) return;
    state.deviceFactsAutoBusy = true;
  }
  if (!silent) setBusy(true, button);
  try {
    const endpoint = auto ? "/api/adb/devices?persist=1" : "/api/adb/devices?facts=1&persist=1";
    const simRefresh = auto
      ? Promise.resolve(state.deviceSimInfo)
      : refreshDeviceSimInfo({ force: true });
    const [adbDevices] = await Promise.all([
      fetchJson(endpoint),
      simRefresh,
    ]);
    storeAdbDevices(adbDevices);
    if (adbDevices.includeFacts || adbDevices.includeUptime) {
      state.summary = await fetchJson("/api/fleet-db/summary");
    }
    renderDevices(state.summary?.devices || []);
    if (!silent) logLine(`UPTIME/電池取得OK: 接続 ${adbDevices.connected || 0}台`);
  } catch (error) {
    logLine((auto ? "自動UPTIME/電池取得NG: " : "UPTIME/電池取得NG: ") + error.message);
  } finally {
    if (auto) state.deviceFactsAutoBusy = false;
    if (!silent) setBusy(false);
  }
}

function simCarrierConfidenceLabel(subscription) {
  const confidence = String(subscription?.carrierConfidence || "");
  if (confidence === "android-carrier-id") return "事業者特定";
  if (confidence === "brand") return "SIM名から判定";
  if (confidence === "network-family") return "回線のみ";
  return "要確認";
}

function normalizeNullableSubscriptionId(value) {
  if (value === undefined || value === null || value === "") return null;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= 0 ? parsed : null;
}

function normalizeNullableAdbPort(value) {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 && parsed <= 65535 ? parsed : null;
}

function normalizeDeviceSimInfoResult(result) {
  return {
    status: "ready",
    fetchedAt: Date.now(),
    error: String(result?.warning || ""),
    devices: (Array.isArray(result?.devices) ? result.devices : []).map((device) => ({
      serial: String(device?.serial || ""),
      adbPort: normalizeNullableAdbPort(device?.adbPort),
      warning: String(device?.warning || ""),
      simStatus: String(device?.simStatus || ""),
      simStatusCode: String(device?.simStatusCode || "unknown"),
      lineContractStatus: "not_determinable",
      subscriptions: (Array.isArray(device?.subscriptions) ? device.subscriptions : []).map((subscription) => ({
        slotIndex: Number(subscription?.slotIndex),
        subscriptionId: normalizeNullableSubscriptionId(subscription?.subscriptionId),
        stateLabel: String(subscription?.stateLabel || ""),
        carrier: String(subscription?.carrier || "不明"),
        carrierFamily: String(subscription?.carrierFamily || ""),
        carrierConfidence: String(subscription?.carrierConfidence || "unknown"),
        carrierSource: String(subscription?.carrierSource || ""),
        apnRecommendation: {
          status: ["exact", "ambiguous", "none"].includes(subscription?.apnRecommendation?.status)
            ? subscription.apnRecommendation.status
            : "none",
          profileId: String(subscription?.apnRecommendation?.profileId || ""),
          candidateProfileIds: (Array.isArray(subscription?.apnRecommendation?.candidateProfileIds)
            ? subscription.apnRecommendation.candidateProfileIds
            : []).map((value) => String(value || "")).filter(Boolean),
        },
        serviceStatus: String(subscription?.serviceStatus || "unknown"),
        serviceLabel: String(subscription?.serviceLabel || "回線状態不明"),
        lineContractStatus: "not_determinable",
      })),
    })),
  };
}

function requestDeviceDbSimInfo() {
  if (state.deviceDbSimRequested && state.deviceSimInfo.status !== "failed") return;
  state.deviceDbSimRequested = true;
  void refreshDeviceSimInfo({ force: state.deviceSimInfo.status === "failed" });
}

async function refreshDeviceSimInfo(options = {}) {
  if (state.deviceSimInfoFlight) {
    if (!options.fresh) return state.deviceSimInfoFlight;
    await state.deviceSimInfoFlight.catch(() => null);
  }
  if (!options.force && state.deviceSimInfo.status === "ready") return state.deviceSimInfo;

  state.deviceSimInfo = {
    status: "loading",
    devices: [],
    fetchedAt: 0,
    error: "",
  };
  if (state.summary?.devices) renderDevices(state.summary.devices);

  state.deviceSimInfoFlight = (async () => {
    try {
      const result = await privateFetchJson(options.fresh ? "/api/adb/sim-info?fresh=1" : "/api/adb/sim-info");
      state.deviceSimInfo = normalizeDeviceSimInfoResult(result);
    } catch (error) {
      state.deviceSimInfo = {
        status: "failed",
        devices: [],
        fetchedAt: 0,
        error: String(error?.message || "取得できませんでした"),
      };
    } finally {
      state.deviceSimInfoFlight = null;
      if (state.summary?.devices) renderDevices(state.summary.devices);
    }
    return state.deviceSimInfo;
  })();
  return state.deviceSimInfoFlight;
}

function navigationPositionLabel(value) {
  if (value === "left") return "◁ 戻る・ホーム・履歴";
  if (value === "right") return "履歴・ホーム・戻る ▷";
  if (value === "gesture") return "ジェスチャーナビ";
  return "確認できません";
}

function navigationSupportLabel(device) {
  const positions = Array.isArray(device?.supportedPositions) ? device.supportedPositions : [];
  if (device?.writeSupported && positions.includes("left") && positions.includes("right")) return "設定変更対応";
  if (positions.includes("left")) return "Android標準・戻る左固定";
  return device?.reason || "この機種は初版未対応";
}

function navigationReportedStateHtml(device) {
  if (device?.settingConflict) {
    return `<strong class="navigation-setting-conflict">設定が食い違っています</strong><span>実際に使われる設定では ${esc(navigationPositionLabel(device.backPosition))}</span><span>画面は未確認</span>`;
  }
  if (device?.backPosition === "gesture") {
    return `<strong>ジェスチャーナビ</strong><span>ボタン配置の変更対象外</span>`;
  }
  if (device?.backPosition === "left" || device?.backPosition === "right") {
    const prefix = device?.writeSupported ? "有効な設定値では" : "Android標準";
    return `<strong>${esc(prefix)} ${esc(navigationPositionLabel(device.backPosition))}</strong><span>${device?.writeSupported ? "画面は未確認" : "固定配置・書込みなし"}</span>`;
  }
  return `<strong>確認できません</strong><span>書込み対象外</span>`;
}

function batteryProtectionStatusLabel(status) {
  const labels = {
    charging: "充電中",
    discharging: "放電中",
    not_charging: "給電中・充電停止",
    full: "満充電",
    unknown: "不明",
  };
  return labels[String(status || "")] || "不明";
}

function batteryProtectionPowerLabel(battery = {}) {
  const sources = [];
  const powerStates = [
    battery.usbPowered,
    battery.acPowered,
    battery.wirelessPowered,
    battery.dockPowered,
  ];
  if (battery.usbPowered === true) sources.push("USB給電");
  if (battery.acPowered === true) sources.push("AC給電");
  if (battery.wirelessPowered === true) sources.push("無線給電");
  if (battery.dockPowered === true) sources.push("Dock給電");
  if (sources.length) return sources.join("・");
  return powerStates.every((value) => value === false) ? "外部給電なし" : "給電状態不明";
}

function batteryProtectionGuide(identity = {}) {
  const haystack = [
    identity.manufacturer,
    identity.brand,
    identity.model,
    identity.device,
  ].join(" ");
  if (/samsung|galaxy/i.test(haystack)) {
    return "設定 → バッテリー → バッテリー保護。表示された上限値を選択";
  }
  if (/google|pixel/i.test(haystack)) {
    return "Pixel 6a以降: 設定 → バッテリー → バッテリーの状態 → 充電の最適化 → 80%に制限";
  }
  if (/sharp|aquos/i.test(haystack)) {
    return "設定 → バッテリー → インテリジェントチャージ";
  }
  if (/sony|xperia/i.test(haystack)) {
    return "設定 → バッテリー → いたわり充電";
  }
  if (/motorola|moto/i.test(haystack)) {
    return "設定 → バッテリー → バッテリー保護／過充電防止";
  }
  if (/oppo|realme|oneplus/i.test(haystack)) {
    return "設定 → バッテリー → Smart charging／充電上限";
  }
  if (/xiaomi|redmi|poco/i.test(haystack)) {
    return "設定 → バッテリー → バッテリー保護／Limited charging";
  }
  return "電池画面から「バッテリー保護」「充電の最適化」などを確認";
}

function batteryProtectionResultBySerial(result = {}) {
  return new Map((Array.isArray(result.results) ? result.results : [])
    .map((row) => [String(row.serial || "").toLowerCase(), row]));
}

function mergeBatteryProtectionResults(probeResult = {}, openResult = {}) {
  const openBySerial = batteryProtectionResultBySerial(openResult);
  const merged = (Array.isArray(probeResult.results) ? probeResult.results : []).map((row) => {
    const opened = openBySerial.get(String(row.serial || "").toLowerCase());
    const probeOk = row.ok === true;
    return opened ? {
      ...row,
      probeAttempted: true,
      probeOk,
      probeCode: row.code || "",
      probeMessage: row.message || "",
      openAttempted: true,
      openOk: opened.ok === true,
      openCode: opened.code || "",
      openMessage: opened.message || "",
      ok: opened.ok === true,
      opened: opened.opened || "",
      fallbackUsed: opened.fallbackUsed === true,
    } : {
      ...row,
      probeAttempted: true,
      probeOk,
      probeCode: row.code || "",
      probeMessage: row.message || "",
      openAttempted: false,
      openOk: null,
      openCode: "",
      openMessage: "",
      ok: probeOk,
    };
  });
  for (const opened of Array.isArray(openResult.results) ? openResult.results : []) {
    if (!merged.some((row) => String(row.serial || "").toLowerCase() === String(opened.serial || "").toLowerCase())) {
      merged.push({
        ...opened,
        probeAttempted: false,
        probeOk: null,
        probeCode: "",
        probeMessage: "",
        openAttempted: true,
        openOk: opened.ok === true,
        openCode: opened.code || "",
        openMessage: opened.message || "",
        ok: opened.ok === true,
      });
    }
  }
  const warnings = [openResult.warning, probeResult.warning].filter(Boolean);
  return {
    ...probeResult,
    mode: openResult.mode || probeResult.mode,
    requested: openResult.requested || probeResult.requested,
    targeted: openResult.targeted || probeResult.targeted,
    warning: warnings.join(" / "),
    succeeded: merged.filter((row) => row.ok).length,
    failed: merged.filter((row) => !row.ok).length,
    results: merged,
  };
}

function batteryProtectionOperationHtml(row = {}) {
  if (row.openAttempted === true) {
    if (row.openOk !== true) {
      return `<strong>画面を開けません</strong><span>${esc(row.openMessage || row.openCode || "ADB接続を確認してください")}</span>`;
    }
    if (row.opened === "power_usage_summary") {
      return "<strong>電池画面を開きました</strong><span>端末画面で保護設定を選択してください</span>";
    }
    if (row.opened === "settings") {
      return "<strong>設定トップを開きました</strong><span>案内経路でバッテリー設定へ進んでください</span>";
    }
    return "<strong>設定画面を開きました</strong><span>端末画面で保護設定を確認してください</span>";
  }
  const probeOk = row.probeAttempted === true ? row.probeOk === true : row.ok === true;
  if (!probeOk) {
    return `<strong>確認NG</strong><span>${esc(row.probeMessage || row.message || row.probeCode || row.code || "ADB接続を確認してください")}</span>`;
  }
  return "<strong>読取OK</strong><span>保護設定のON/OFFは端末画面で確認</span>";
}

function batteryProtectionOperationSucceeded(row = {}) {
  if (row.openAttempted === true) return row.openOk === true;
  if (row.probeAttempted === true) return row.probeOk === true;
  return row.ok === true;
}

function renderBatteryProtectionDialog(result = {}, serials = []) {
  closeAdbDropDialog();
  const rowsBySerial = batteryProtectionResultBySerial(result);
  const selectedBySerial = new Map(selectedClipboardDevices()
    .map((row) => [String(row.serial || "").toLowerCase(), row]));
  const rows = serials.map((serial) => {
    const key = String(serial || "").toLowerCase();
    const selected = selectedBySerial.get(key) || {};
    const observed = rowsBySerial.get(key) || {
      serial,
      ok: false,
      code: "ADB_DEVICE_NOT_CONNECTED",
      message: "ADB接続を確認できませんでした。",
      identity: {},
      battery: {},
    };
    return {
      ...observed,
      label: selected.deviceLabel || selected.laixiName || selected.deviceName || selected.modelGroup || observed.label || serial,
      number: selected.laixiNumber || selected.managementId || "",
    };
  });
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop battery-protection-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog navigation-layout-dialog battery-protection-dialog" role="dialog" aria-modal="true" aria-labelledby="batteryProtectionDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="batteryProtectionDialogTitle">バッテリー保護</h3>
          <p>選択端末の電池状態を確認し、メーカー公式のバッテリー画面をまとめて開きます。</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="navigation-layout-notice">
        <strong>画面を開いただけでは設定完了になりません</strong>
        <span>Androidには、全メーカー共通で充電上限を変更・確定読取できる公式ADBコマンドがありません。誤設定防止のため、推測した設定キーや上限値は書き込みません。</span>
        <span>端末画面で保護設定を選び、表示された上限値を確認してください。給電中に80%前後で停止していても、それだけでは保護設定ONと断定しません。</span>
      </div>
      ${result.warning ? `<div class="adb-missing-empty">警告: ${esc(result.warning)}</div>` : ""}
      <div class="adb-missing-table-wrap navigation-layout-table-wrap">
        <table class="adb-missing-table navigation-layout-table battery-protection-table">
          <thead>
            <tr>
              <th>端末</th>
              <th>機種</th>
              <th>電池</th>
              <th>保護設定</th>
              <th>確認経路</th>
              <th>結果</th>
            </tr>
          </thead>
          <tbody>
            ${rows.map((row) => {
              const battery = row.battery || {};
              const identity = row.identity || {};
              const percent = battery.percent !== null
                && battery.percent !== undefined
                && Number.isFinite(Number(battery.percent))
                ? `${Number(battery.percent)}%`
                : "-";
              const temperature = battery.temperatureC !== null
                && battery.temperatureC !== undefined
                && Number.isFinite(Number(battery.temperatureC))
                ? ` / ${Number(battery.temperatureC).toFixed(1)}℃`
                : "";
              return `
                <tr>
                  <td>
                    <strong>${esc(row.label || row.serial || "端末名なし")}</strong>
                    ${row.number ? `<span>番号 ${esc(row.number)}</span>` : ""}
                    <span>${esc(row.serial || "")}</span>
                  </td>
                  <td>
                    <strong>${esc(identity.model || row.model || "-")}</strong>
                    <span>${esc(identity.manufacturer || identity.brand || "-")}${identity.androidVersion ? ` / Android ${esc(identity.androidVersion)}` : ""}</span>
                  </td>
                  <td>
                    <strong>${esc(percent)}${esc(temperature)}</strong>
                    <span>${esc(batteryProtectionStatusLabel(battery.status))} / ${esc(batteryProtectionPowerLabel(battery))}</span>
                  </td>
                  <td class="navigation-result-pending">
                    <strong>未確認</strong>
                    <span>端末画面でON・上限値を確認</span>
                  </td>
                  <td>${esc(batteryProtectionGuide(identity))}</td>
                  <td class="${batteryProtectionOperationSucceeded(row) ? "navigation-result-pending" : "navigation-result-ng"}">${batteryProtectionOperationHtml(row)}</td>
                </tr>
              `;
            }).join("")}
          </tbody>
        </table>
      </div>
      <div class="adb-drop-actions">
        <button class="section-head-action battery-protection-refresh" type="button">状態を再確認</button>
        <button class="section-head-action battery-protection-open" type="button" ${serials.length ? "" : "disabled"}>選択端末の公式画面を開く（${serials.length}台）</button>
        <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((button) => {
    button.addEventListener("click", closeAdbDropDialog);
  });
  overlay.querySelector(".battery-protection-refresh")?.addEventListener("click", (event) => {
    closeAdbDropDialog();
    showBatteryProtectionDialog(event.currentTarget, { serials });
  });
  overlay.querySelector(".battery-protection-open")?.addEventListener("click", (event) => {
    openBatteryProtectionScreens(serials, event.currentTarget);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

async function requestBatteryProtection(mode, serials) {
  return privateFetchJson("/api/adb/battery-protection", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode, serials }),
  });
}

async function showBatteryProtectionDialog(button = null, options = {}) {
  const serials = Array.isArray(options.serials) && options.serials.length
    ? [...options.serials]
    : checkedClipboardTargetSerials();
  if (!serials.length) {
    logLine("バッテリー保護: 対象端末を選んでください");
    return;
  }
  setBusy(true, button, "電池確認中...");
  try {
    const result = await requestBatteryProtection("probe", serials);
    logLine(`バッテリー保護確認: 読取 ${result.succeeded || 0}台 / 要確認 ${result.manualRequired || 0}台 / 失敗 ${result.failed || 0}台`);
    renderBatteryProtectionDialog(result, serials);
  } catch (error) {
    logLine("バッテリー保護確認NG: " + error.message);
    renderBatteryProtectionDialog({ warning: error.message, results: [] }, serials);
  } finally {
    setBusy(false);
  }
}

async function openBatteryProtectionScreens(serials, button = null) {
  if (!serials.length) return;
  const ok = window.confirm(`選択した${serials.length}台で、メーカー公式のバッテリー画面を開きます。\n設定値の変更は行いません。端末画面でバッテリー保護と上限値を確認してください。`);
  if (!ok) return;
  setBusy(true, button, "電池画面を開いています...");
  try {
    let opened;
    try {
      opened = await requestBatteryProtection("open", serials);
    } catch (error) {
      if (!Array.isArray(error.data?.results)) throw error;
      const returnedBySerial = batteryProtectionResultBySerial(error.data);
      const results = serials.map((serial) => returnedBySerial.get(String(serial).toLowerCase()) || {
        serial,
        ok: false,
        code: error.code || error.data.code || "BATTERY_SETTINGS_OPEN_FAILED",
        message: error.message || "バッテリー設定画面を開けませんでした。",
        opened: "none",
        fallbackUsed: false,
      });
      opened = {
        ...error.data,
        results,
        warning: error.data.warning || error.message,
      };
    }
    let probed;
    try {
      probed = await requestBatteryProtection("probe", serials);
    } catch (error) {
      probed = Array.isArray(error.data?.results)
        ? {
          ...error.data,
          warning: error.data.warning || `画面を開いた後の電池状態を再読込できませんでした: ${error.message}`,
        }
        : {
          mode: "probe",
          requested: serials.length,
          targeted: 0,
          results: [],
          warning: `画面は開きましたが、電池状態を再読込できませんでした: ${error.message}`,
        };
    }
    const result = mergeBatteryProtectionResults(probed, opened);
    logLine(`バッテリー保護画面: 開けた端末 ${opened.succeeded || 0}台 / 失敗 ${opened.failed || 0}台`);
    renderBatteryProtectionDialog(result, serials);
  } catch (error) {
    logLine("バッテリー保護画面NG: " + error.message);
    renderBatteryProtectionDialog({ warning: error.message, results: [] }, serials);
  } finally {
    setBusy(false);
  }
}

function navigationActionResultHtml(rowResult) {
  if (!rowResult) return "-";
  if (!rowResult.ok) {
    const title = rowResult.stateUncertain ? "設定状態を確認してください" : "変更できません";
    const failedSettings = Array.isArray(rowResult.rollbackFailedSettings) && rowResult.rollbackFailedSettings.length
      ? `<span>復元確認NG: ${esc(rowResult.rollbackFailedSettings.join(", "))}</span>`
      : "";
    return `<strong>${esc(title)}</strong><span>${esc(rowResult.message || "")}</span>${failedSettings}`;
  }
  const title = rowResult.changed
    ? "設定を書込み・再読取OK"
    : rowResult.reapplied
      ? "同じ設定を再書込み・再読取OK"
      : "書込みなし";
  const visual = rowResult.screenVerified
    ? "画面でも配置を確認済み"
    : "画面確認待ち";
  return `<strong>${esc(title)}</strong><span>${esc(visual)}</span>${rowResult.message ? `<span>${esc(rowResult.message)}</span>` : ""}`;
}

function syncNavigationDialogSelection(overlay) {
  const desired = overlay.querySelector('input[name="navigationBackPosition"]:checked')?.value || "left";
  let selected = 0;
  let allEligible = 0;
  overlay.querySelectorAll(".navigation-device-select").forEach((checkbox) => {
    const supported = String(checkbox.dataset.supported || "").split(",").filter(Boolean);
    const canApply = checkbox.dataset.writeSupported === "true" && supported.includes(desired);
    checkbox.disabled = !canApply;
    if (!canApply) checkbox.checked = false;
    checkbox.closest("tr")?.classList.toggle("navigation-unsupported-direction", !canApply);
    if (canApply) allEligible += 1;
    if (checkbox.checked) selected += 1;
  });
  const applyButton = overlay.querySelector(".navigation-apply");
  if (applyButton) {
    applyButton.disabled = selected === 0;
    applyButton.textContent = `選択した端末へ適用（${selected}台）`;
  }
  const applyAllButton = overlay.querySelector(".navigation-apply-all");
  if (applyAllButton) {
    applyAllButton.disabled = allEligible === 0;
    applyAllButton.textContent = `対応している全端末へ適用（${allEligible}台）`;
  }
}

function renderNavigationLayoutDialog(result, actionResult = null) {
  closeAdbDropDialog();
  const devices = Array.isArray(result?.devices) ? result.devices : [];
  const resultBySerial = new Map((actionResult?.results || []).map((row) => [String(row.serial || ""), row]));
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop navigation-layout-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog navigation-layout-dialog" role="dialog" aria-modal="true" aria-labelledby="navigationLayoutDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="navigationLayoutDialogTitle">端末のナビボタン配置</h3>
          <p>「戻る」ボタンを左右どちらに置くか、対応端末だけ選んで変更します。</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="navigation-position-picker" role="radiogroup" aria-label="戻るボタンの位置">
        <label>
          <input type="radio" name="navigationBackPosition" value="left" checked>
          <strong>◁ 戻る・ホーム・履歴</strong>
          <span>戻るボタンを左</span>
        </label>
        <label>
          <input type="radio" name="navigationBackPosition" value="right">
          <strong>履歴・ホーム・戻る ▷</strong>
          <span>戻るボタンを右</span>
        </label>
      </div>
      <div class="navigation-layout-notice">
        <strong>設定値の一致と、画面上の並びは別に表示します</strong>
        <span>Samsungは端末が実際に使う設定場所を優先し、Xiaomi/Redmiは実機確認済みの機種だけ変更します。PixelはAndroid標準の戻る左固定です。</span>
        <span>同じ設定値でも選んで実行した端末には再書込みします。書込み後は値を2回読み直しますが、画面を確認するまでは「適用済み」とは表示しません。</span>
      </div>
      ${actionResult ? `
        <div class="navigation-action-summary ${actionResult.failed ? "has-error" : ""}">
          <strong>直前の操作: 設定確認 ${Number(actionResult.settingVerified || 0)}台 / 書込み ${Number(actionResult.written || 0)}台 / 再書込み ${Number(actionResult.reapplied || 0)}台 / 失敗 ${Number(actionResult.failed || 0)}台</strong>
          <span>画面確認待ち ${Number(actionResult.visualCheckRequired || 0)}台。設定値だけで「適用済み」にはしていません。</span>
        </div>
      ` : ""}
      ${result?.warning ? `<div class="adb-missing-empty">警告: ${esc(result.warning)}</div>` : ""}
      ${devices.length ? `
        <div class="adb-missing-table-wrap navigation-layout-table-wrap">
          <table class="adb-missing-table navigation-layout-table">
            <thead>
              <tr>
                <th>選択</th>
                <th>端末</th>
                <th>メーカー</th>
                <th>端末が報告した設定</th>
                <th>対応</th>
                <th>結果</th>
              </tr>
            </thead>
            <tbody>
              ${devices.map((device) => {
                const rowResult = resultBySerial.get(String(device.serial || ""));
                const supported = Array.isArray(device.supportedPositions) ? device.supportedPositions : [];
                return `
                  <tr>
                    <td><input class="navigation-device-select" type="checkbox" value="${esc(device.serial || "")}" data-supported="${esc(supported.join(","))}" data-write-supported="${device.writeSupported ? "true" : "false"}" ${device.writeSupported && supported.includes("left") ? "" : "disabled"}></td>
                    <td>
                      <strong>${esc(device.label || device.model || device.serial || "端末名なし")}</strong>
                      ${device.laixiNumber ? `<span>番号 ${esc(device.laixiNumber)}</span>` : ""}
                      ${device.model ? `<span>${esc(device.model)}</span>` : ""}
                    </td>
                    <td>${esc(device.manufacturer || "-")}</td>
                    <td>${navigationReportedStateHtml(device)}</td>
                    <td>
                      ${esc(navigationSupportLabel(device))}
                      ${device.reason && navigationSupportLabel(device) !== device.reason ? `<span>${esc(device.reason)}</span>` : ""}
                    </td>
                    <td class="${rowResult ? (rowResult.ok ? "navigation-result-pending" : "navigation-result-ng") : ""}">
                      ${navigationActionResultHtml(rowResult)}
                    </td>
                  </tr>
                `;
              }).join("")}
            </tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">ADB接続中の端末がありません。</div>`}
      <div class="adb-drop-actions">
        <button class="section-head-action navigation-refresh" type="button">状態を再確認</button>
        <button class="section-head-action navigation-apply-all" type="button" disabled>対応している全端末へ適用（0台）</button>
        <button class="section-head-action navigation-apply" type="button" disabled>選択した端末へ適用（0台）</button>
        <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((closeButton) => {
    closeButton.addEventListener("click", closeAdbDropDialog);
  });
  overlay.querySelectorAll('input[name="navigationBackPosition"], .navigation-device-select').forEach((input) => {
    input.addEventListener("change", () => syncNavigationDialogSelection(overlay));
  });
  overlay.querySelector(".navigation-refresh")?.addEventListener("click", (event) => {
    closeAdbDropDialog();
    showNavigationLayoutDialog(event.currentTarget);
  });
  overlay.querySelector(".navigation-apply-all")?.addEventListener("click", (event) => applyNavigationLayoutFromDialog(overlay, event.currentTarget, { allEligible: true }));
  overlay.querySelector(".navigation-apply")?.addEventListener("click", (event) => applyNavigationLayoutFromDialog(overlay, event.currentTarget));
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
  syncNavigationDialogSelection(overlay);
}

async function showNavigationLayoutDialog(button = null, actionResult = null) {
  setBusy(true, button, "ナビ確認中...");
  let result;
  try {
    result = await privateFetchJson("/api/adb/navigation-layout");
    logLine(`ナビボタン状態確認OK: 接続 ${result.connected || 0}台 / 設定変更対応 ${result.changeable || 0}台`);
  } catch (error) {
    result = { ok: false, devices: [], connected: 0, changeable: 0, warning: error.message };
    logLine("ナビボタン状態確認NG: " + error.message);
  } finally {
    setBusy(false);
  }
  renderNavigationLayoutDialog(result, actionResult);
}

async function applyNavigationLayoutFromDialog(overlay, button, options = {}) {
  const desiredBackPosition = overlay.querySelector('input[name="navigationBackPosition"]:checked')?.value || "left";
  const candidates = [...overlay.querySelectorAll(".navigation-device-select")];
  const serials = candidates
    .filter((checkbox) => options.allEligible ? !checkbox.disabled : checkbox.checked)
    .map((checkbox) => checkbox.value);
  if (!serials.length) return;
  const targetLabel = options.allEligible ? "現在一覧にある対応端末すべて" : "選択した端末";
  const ok = window.confirm(`${targetLabel} ${serials.length}台へ「${navigationPositionLabel(desiredBackPosition)}」を設定します。\n同じ設定値の端末にも再度書き込みます。\n実行直前に各端末を再確認し、対象外になった端末には書き込みません。\n設定値の確認と画面上の確認は別です。`);
  if (!ok) return;
  setBusy(true, button, "ナビ変更中...");
  let actionResult = null;
  try {
    actionResult = await privateFetchJson("/api/adb/navigation-layout", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        serials,
        backPosition: desiredBackPosition,
        forceReapply: true,
        scope: options.allEligible ? "all_eligible_snapshot" : "selected",
      }),
    });
    logLine(`ナビ設定変更完了: 設定確認 ${actionResult.settingVerified || 0}台 / 書込み ${actionResult.written || 0}台 / 再書込み ${actionResult.reapplied || 0}台 / 画面確認待ち ${actionResult.visualCheckRequired || 0}台 / 失敗 ${actionResult.failed || 0}台`);
  } catch (error) {
    logLine("ナビボタン変更NG: " + error.message);
    actionResult = { ok: false, results: [], warning: error.message };
  } finally {
    setBusy(false);
  }
  closeAdbDropDialog();
  await showNavigationLayoutDialog(null, actionResult);
}

function setupAdbSwipeControls() {
  const options = adbSwipeMinuteOptions();
  const select = el("adbSwipeBulkMinutesSelect");
  select.innerHTML = options.map((minutes) =>
    `<option value="${minutes}" ${minutes === 60 ? "selected" : ""}>${minutes}分</option>`
  ).join("");
}

function adbSwipeMinuteOptions() {
  return Array.from({ length: 10 }, (_, index) => (index + 1) * 10);
}

function renderAdbSwipePanel(devices = state.summary?.devices || [], adbDevices = state.adbDevices?.devices || []) {
  const grid = el("adbSwipeDeviceGrid");
  if (!grid) return;
  const rows = adbSwipeRows(devices, adbDevices);
  const connected = rows.filter((row) => row.connected).length;
  const active = rows.filter((row) => row.connected && row.group === "稼働中").length;
  el("adbSwipeMeta").textContent = `ADB接続 ${connected}台 / 稼働中 ${active}台`;
  if (!rows.length) {
    grid.innerHTML = `<div class="adb-empty">ADB接続中の端末がありません。USB接続を確認してください。</div>`;
    return;
  }
  grid.innerHTML = rows.map((row) => {
    const selected = state.adbSwipe.selected.has(row.serial);
    const minutes = state.adbSwipe.minutesBySerial[row.serial] || 60;
    const disabled = row.connected ? "" : "disabled";
    const statusClass = row.group === "稼働中" ? "active" : row.group === "非稼働" ? "idle" : "rest";
    const mode = swipeModeChip(row);
    return `
      <article class="adb-device-card ${selected ? "selected" : ""} ${row.connected ? "" : "offline"} ${swipeModeCardClass(row)}" data-serial="${esc(row.serial)}">
        <label class="adb-device-select-line">
          <input class="adb-swipe-select" type="checkbox" data-serial="${esc(row.serial)}" ${selected ? "checked" : ""} ${disabled}>
          <span class="adb-device-number">${esc(row.laixiNumber || "-")}</span>
          <span class="adb-device-main">${esc(row.label || row.serial)}</span>
        </label>
        <div class="adb-device-sub">${esc(row.serial)}</div>
        <div class="adb-device-meta">
          ${mode}
          <span class="adb-group-chip ${statusClass}">${esc(row.group || "未分類")}</span>
          <span>${row.connected ? "接続中" : "未接続"}</span>
          <span>${row.adbPort ? `P${esc(row.adbPort)}` : "default"}</span>
        </div>
        <label class="adb-minute-line">
          <span>時間</span>
          <select class="adb-swipe-device-minutes" data-serial="${esc(row.serial)}" ${disabled}>
            ${adbSwipeMinuteOptions().map((value) => `<option value="${value}" ${Number(minutes) === value ? "selected" : ""}>${value}分</option>`).join("")}
          </select>
        </label>
      </article>
    `;
  }).join("");
}


function adbSwipeRows(devices = [], adbDevices = []) {
  const dbBySerial = new Map((devices || []).filter((row) => row && row.serial).map((row) => [String(row.serial), row]));
  const adbBySerial = new Map((adbDevices || []).filter((row) => row && row.serial).map((row) => [String(row.serial), row]));
  const serials = new Set([...dbBySerial.keys(), ...adbBySerial.keys()]);
  return [...serials].map((serial) => {
    const db = dbBySerial.get(serial) || {};
    const adb = adbBySerial.get(serial) || {};
    return {
      serial,
      connected: adb.status === "device" || adb.connected === true,
      adbPort: adb.adbPort || "",
      laixiNumber: db.laixiNumber || adb.laixiNumber || "",
      label: db.deviceLabel || adb.label || db.name || adb.model || serial,
      group: db.group || adb.group || "",
      model: db.deviceName || adb.model || "",
      tags: db.tags || [],
      swipeAgentInstalled: db.swipeAgentInstalled,
      swipeAgentAccessibilityEnabled: db.swipeAgentAccessibilityEnabled === true ? true : db.swipeAgentAccessibilityEnabled === false ? false : null,
      swipeAgentVersionName: db.swipeAgentVersionName || "",
      swipeAgentVersionCode: db.swipeAgentVersionCode || "",
      swipeAgentCheckedAt: db.swipeAgentCheckedAt || "",
      swipeAgentLastError: db.swipeAgentLastError || "",
      swipeModePreference: db.swipeModePreference || "auto",
      swipeModeRecommendation: db.swipeModeRecommendation || null,
    };
  }).sort((a, b) =>
    Number(a.connected ? 0 : 1) - Number(b.connected ? 0 : 1) ||
    Number(a.laixiNumber || 9999) - Number(b.laixiNumber || 9999) ||
    String(a.label || "").localeCompare(String(b.label || ""), "ja") ||
    String(a.serial).localeCompare(String(b.serial), "en")
  );
}

function handleAdbSwipeGridChange(event) {
  const checkbox = event.target.closest(".adb-swipe-select");
  if (checkbox) {
    const serial = checkbox.dataset.serial || "";
    if (checkbox.checked) state.adbSwipe.selected.add(serial);
    else state.adbSwipe.selected.delete(serial);
    checkbox.closest(".adb-device-card")?.classList.toggle("selected", checkbox.checked);
    return;
  }
  const minutesSelect = event.target.closest(".adb-swipe-device-minutes");
  if (minutesSelect) {
    state.adbSwipe.minutesBySerial[minutesSelect.dataset.serial || ""] = Number(minutesSelect.value || 60);
  }
}

function applyAdbSwipeBulkMinutes() {
  const minutes = Number(el("adbSwipeBulkMinutesSelect")?.value || 60);
  for (const serial of state.adbSwipe.selected) state.adbSwipe.minutesBySerial[serial] = minutes;
  for (const select of document.querySelectorAll(".adb-swipe-device-minutes")) {
    if (state.adbSwipe.selected.has(select.dataset.serial || "")) select.value = String(minutes);
  }
  logLine(`ADBスワイプ: 選択端末へ${minutes}分を適用`);
}

function setAdbSwipeSelection(mode) {
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  state.adbSwipe.selected.clear();
  for (const row of rows) {
    if (!row.connected) continue;
    if (mode === "all" || (mode === "active" && row.group === "稼働中")) state.adbSwipe.selected.add(row.serial);
  }
  renderAdbSwipePanel();
}

async function refreshAdbSwipeDevices() {
  setBusy(true, el("adbSwipeRefreshBtn"));
  try {
    const adbDevices = await fetchJson("/api/adb/devices");
    storeAdbDevices(adbDevices);
    renderDevices(state.summary?.devices || []);
    renderAdbSwipePanel(state.summary?.devices || [], state.adbDevices.devices || []);
    renderSwipeAgentPanel(state.summary?.devices || [], state.adbDevices.devices || []);
    logLine(`ADB再読込 OK: 接続 ${adbDevices.connected || 0}台`);
  } catch (error) {
    logLine("ADB再読込 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function setupSwipeAgentControls() {
  const select = el("swipeAgentBulkMinutesSelect");
  if (!select) return;
  select.innerHTML = adbSwipeMinuteOptions().map((minutes) =>
    `<option value="${minutes}" ${minutes === 60 ? "selected" : ""}>${minutes}分</option>`
  ).join("");
}

function renderSwipeAgentPanel(devices = state.summary?.devices || [], adbDevices = state.adbDevices?.devices || []) {
  const grid = el("swipeAgentDeviceGrid");
  if (!grid) return;
  const rows = adbSwipeRows(devices, adbDevices);
  const connected = rows.filter((row) => row.connected).length;
  const active = rows.filter((row) => row.connected && row.group === "稼働中").length;
  el("swipeAgentMeta").textContent = `ADB接続 ${connected}台 / 稼働中 ${active}台 / 端末自走方式`;
  if (!rows.length) {
    grid.innerHTML = `<div class="adb-empty">ADB接続中の端末がありません。USB接続を確認してください。</div>`;
    return;
  }
  grid.innerHTML = rows.map((row) => {
    const selected = state.swipeAgent.selected.has(row.serial);
    const minutes = state.swipeAgent.minutesBySerial[row.serial] || 60;
    const disabled = row.connected ? "" : "disabled";
    const statusClass = row.group === "稼働中" ? "active" : row.group === "非稼働" ? "idle" : "rest";
    const mode = swipeModeChip(row);
    const agent = swipeAgentCardStatus(row);
    const tags = Array.isArray(row.tags) ? row.tags : [];
    const hasError = tags.includes("STATE_ERROR");
    const hasErrorHistory = tags.includes("STATE_ERROR_HISTORY");
    const errorDisabled = "disabled";
    return `
      <article class="adb-device-card ${selected ? "selected" : ""} ${hasError ? "has-error" : ""} ${hasErrorHistory ? "has-error-history" : ""} ${row.connected ? "" : "offline"} ${swipeModeCardClass(row)}" data-serial="${esc(row.serial)}">
        <label class="adb-device-select-line">
          <input class="swipe-agent-select" type="checkbox" data-serial="${esc(row.serial)}" ${selected ? "checked" : ""} ${disabled}>
          <span class="adb-device-number">${esc(row.laixiNumber || "-")}</span>
          <span class="adb-device-main">${esc(row.label || row.serial)}</span>
        </label>
        <div class="adb-device-sub">${esc(row.serial)}</div>
        <div class="adb-device-meta">
          ${mode}
          <span class="adb-group-chip ${statusClass}">${esc(row.group || "未分類")}</span>
          <span class="agent-install-chip ${agent.klass}" title="${esc(agent.title)}">${esc(agent.label)}</span>
          ${appInstallChip("TTL", row.ttlInstalled, row.ttlCheckedAt, row.ttlInstallLastError)}
          ${appInstallChip("LINE", row.lineInstalled, row.lineCheckedAt, row.lineInstallLastError)}
          <span>${row.connected ? "接続中" : "未接続"}</span>
          <span>${row.adbPort ? `P${esc(row.adbPort)}` : "default"}</span>
        </div>
        <div class="swipe-error-row">
          <label class="swipe-error-toggle">
            <input class="swipe-error-checkbox" type="checkbox" data-serial="${esc(row.serial)}" ${hasError ? "checked" : ""} ${errorDisabled}>
            <span class="swipe-error-label" title="ERRORはチェック一覧で変更し、DBへ反映します">ERROR中</span>
          </label>
          ${hasErrorHistory ? `<em title="過去にERRORが付いた端末です">ERROR歴あり</em>` : ""}
        </div>
        <label class="adb-minute-line">
          <span>時間</span>
          <select class="swipe-agent-device-minutes" data-serial="${esc(row.serial)}" ${disabled}>
            ${adbSwipeMinuteOptions().map((value) => `<option value="${value}" ${Number(minutes) === value ? "selected" : ""}>${value}分</option>`).join("")}
          </select>
        </label>
      </article>
    `;
  }).join("");
}


function swipeAgentCardStatus(row) {
  if (row.swipeAgentInstalled === true) {
    const version = [row.swipeAgentVersionName, row.swipeAgentVersionCode].filter(Boolean).join("/");
    if (row.swipeAgentAccessibilityEnabled === false) {
      return {
        klass: "missing",
        label: "導入済 / 権限OFF",
        title: "",
      };
    }
    return {
      klass: "installed",
      label: version ? `導入済 ${version}` : "導入済",
      title: row.swipeAgentCheckedAt || "",
    };
  }
  if (row.swipeAgentInstalled === false) {
    return {
      klass: "missing",
      label: "未導入",
      title: row.swipeAgentLastError || row.swipeAgentCheckedAt || "",
    };
  }
  return {
    klass: "unknown",
    label: "",
    title: "",
  };
}

function appInstallChip(label, installed, checkedAt, lastError) {
  if (installed === true) {
    return `<span class="app-install-chip installed" title="${esc(checkedAt || "")}">${esc(label)}済</span>`;
  }
  if (installed === false) {
    return `<span class="app-install-chip missing" title="${esc(lastError || checkedAt || "")}">${esc(label)}未</span>`;
  }
  return `<span class="app-install-chip unknown" title="">${esc(label)}未確認</span>`;
}

function baselineSettingsStatus(row, options = {}) {
  const settings = row.baselineSettings || row.initialSettings || {};
  const checks = [
    settings.emergencyOff,
    settings.autoRotateOff,
    settings.dataSaverOn,
    settings.nfcOff,
    settings.silentOn,
    settings.userAppNotificationsOff,
  ];
  const done = checks.filter((value) => value === true).length;
  const total = checks.length;
  const errors = [settings.lastError].filter(Boolean);
  const checkedAt = settings.checkedAt || "";
  const label = done === total ? "": `${done}/${total}`;
  const klass = errors.length ? "error" : done === total ? "done" : done ? "partial" : "unknown";
  const title = [
    `初期設定 ${done}/${total}`,
    checkedAt ? `確認 ${checkedAt}` : "",
    errors.length ? `エラー ${errors.join(" / ")}` : "",
  ].filter(Boolean).join(" / ");
  return `<span class="baseline-settings-chip ${klass}" title="${esc(title)}">${esc(label)}</span>`;
}

function baselineSettingsStatusDetail(row) {
  const settings = row.deviceSettings && typeof row.deviceSettings === "object" ? row.deviceSettings : {};
  const settingItems = [
    { key: "emergencyAlertsOff", label: "緊急メールOFF" },
    { key: "autoRotateOff", label: "画面回転OFF" },
    { key: "dataSaverOn", label: "データセーバーON" },
    { key: "nfcOff", label: "NFC OFF" },
    { key: "silentOn", label: "サイレントON" },
    { key: "userAppNotificationsOff", label: "ユーザーアプリ通知を非表示（Android 12以降・管理アプリ除く）" },
  ];
  const statusItems = settingItems.map((item) => {
      const value = settings[item.key] && typeof settings[item.key] === "object" ? settings[item.key] : {};
      return {
        label: item.label,
        done: Boolean(value.appliedAt || value.source === "legacy"),
        checkedAt: value.checkedAt || value.appliedAt || "",
        error: value.lastError || value.error || "",
      };
    });
  const doneItems = statusItems.filter((item) => item.done);
  const pendingItems = statusItems.filter((item) => !item.done);
  const errors = statusItems
    .filter((item) => item.error)
    .map((item) => `${item.label}: ${item.error}`);
  const latestCheckedAt = statusItems
    .map((item) => item.checkedAt)
    .filter(Boolean)
    .sort()
    .pop() || "";
  const done = doneItems.length;
  const total = statusItems.length;
  const klass = errors.length ? "error" : done === total ? "complete" : done ? "partial" : "empty";
  const title = [
    `初期設定 ${done}/${total}`,
    doneItems.length ? `完了: ${doneItems.map((item) => item.label).join("、")}` : "",
    pendingItems.length ? `未完了: ${pendingItems.map((item) => item.label).join("、")}` : "",
    latestCheckedAt ? `確認: ${latestCheckedAt}` : "",
    errors.length ? `エラー: ${errors.join(" / ")}` : "",
  ].filter(Boolean).join("\n");
  return `<span class="baseline-settings-chip ${klass}" title="${esc(title)}">${esc(`${done}/${total}`)}</span>`;
}

function handleSwipeAgentGridChange(event) {
  const errorToggle = event.target.closest(".swipe-agent-error-toggle");
  if (errorToggle) {
    event.preventDefault();
    renderSwipeAgentPanel();
    return;
  }
  const checkbox = event.target.closest(".swipe-agent-select");
  if (checkbox) {
    const serial = checkbox.dataset.serial || "";
    if (checkbox.checked) state.swipeAgent.selected.add(serial);
    else state.swipeAgent.selected.delete(serial);
    checkbox.closest(".adb-device-card")?.classList.toggle("selected", checkbox.checked);
    return;
  }
  const minutesSelect = event.target.closest(".swipe-agent-device-minutes");
  if (minutesSelect) {
    state.swipeAgent.minutesBySerial[minutesSelect.dataset.serial || ""] = Number(minutesSelect.value || 60);
  }
}

function handleSwipeAgentGridClick(event) {
  const input = event.target.closest(".swipe-agent-error-toggle");
  if (!input) return;
  event.preventDefault();
  event.stopPropagation();
  logLine("");
}

function cssEscape(value) {
  if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(String(value || ""));
  return String(value || "").replace(/["\\]/g, "\\$&");
}

function applySwipeAgentBulkMinutes() {
  const minutes = Number(el("swipeAgentBulkMinutesSelect")?.value || 60);
  for (const serial of state.swipeAgent.selected) state.swipeAgent.minutesBySerial[serial] = minutes;
  for (const select of document.querySelectorAll(".swipe-agent-device-minutes")) {
    if (state.swipeAgent.selected.has(select.dataset.serial || "")) select.value = String(minutes);
  }
  logLine(`Swipe Agent: 選択端末へ${minutes}分を適用`);
}

function setSwipeAgentSelection(mode) {
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  state.swipeAgent.selected.clear();
  for (const row of rows) {
    if (!row.connected) continue;
    if (mode === "all" || (mode === "active" && row.group === "稼働中")) state.swipeAgent.selected.add(row.serial);
  }
  renderSwipeAgentPanel();
}

async function refreshSwipeAgentDevices() {
  setBusy(true, el("swipeAgentRefreshBtn"));
  try {
    const adbDevices = await fetchJson("/api/adb/devices");
    storeAdbDevices(adbDevices);
    renderDevices(state.summary?.devices || []);
    renderAdbSwipePanel(state.summary?.devices || [], state.adbDevices.devices || []);
    renderSwipeAgentPanel(state.summary?.devices || [], state.adbDevices.devices || []);
    logLine(`Swipe Agent ADB再読込 OK: 接続 ${adbDevices.connected || 0}台`);
  } catch (error) {
    logLine("Swipe Agent ADB再読込 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function runSwipeAgentInstallAction(label, endpoint, button = null) {
  const ok = endpoint.endsWith("/install") ? window.confirm("Swipe Agentを導入/更新します。よろしいですか？") : true;
  if (!ok) return;
  setBusy(true, button);
  logLine(label + " 実行中...");
  try {
    const response = await fetch(endpoint, { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    const result = await response.json();
    logLine(label + " OK: 接続 " + (result.connected || 0) + "台 / 成功 " + (result.installed || result.succeeded || 0) + " / スキップ " + (result.skipped || 0) + " / 失敗 " + (result.failed || 0));
    const failed = (result.results || []).filter((row) => !row.ok);
    for (const row of failed.slice(0, 20)) {
      logLine("- " + (row.label || row.serial) + ": " + (row.error || row.after?.error || "理由不明"));
    }
    if (!response.ok || result.ok === false) logLine(label + ": 一部失敗");
    await loadSummary();
  } catch (error) {
    logLine(label + " NG: " + error.message);
  } finally {
    setBusy(false);
  }
}


async function saveSiteName() {
  const siteName = el("siteNameInput").value.trim() || "Android Fleet";
  setBusy(true);
  logLine("名前保存 実行中...");
  try {
    const result = await fetchJson("/api/fleet-db/settings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ siteName }),
    });
    renderSiteName(result.settings?.siteName || siteName);
    logLine("名前保存 OK: " + (result.settings?.siteName || siteName));
    await loadSummary();
  } catch (error) {
    logLine("名前保存 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function addManualWithdrawal(event) {
  event.preventDefault();
  const withdrawalId = el("withdrawalIdInput").value;
  const deviceSelection = selectedWithdrawalDevice();
  const deviceValue = deviceSelection.device;
  const amountYen = Number(el("withdrawalAmountInput").value);
  const withdrawalDate = el("withdrawalDateInput").value;
  const memo = el("withdrawalMemoInput").value.trim();
  if (!deviceValue || !withdrawalDate || !Number.isFinite(amountYen) || amountYen <= 0) {
    logLine("出金登録 NG: 日付・端末・金額を確認してください");
    return;
  }
  setBusy(true);
  logLine((withdrawalId ? "出金訂正" : "出金登録") + " 実行中...");
  try {
    const endpoint = withdrawalId ? "/api/fleet-db/withdrawals/update" : "/api/fleet-db/withdrawals";
    const result = await fetchJson(endpoint, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ withdrawalId, ...deviceSelection, withdrawalDate, amountYen, memo }),
    });
    const savedDeviceName = result.withdrawal.deviceName || result.withdrawal.managementId || "端末名なし";
    logLine((withdrawalId ? "出金訂正" : "出金登録") + " OK: " + savedDeviceName + " " + yen(result.withdrawal.amountYen));
    clearWithdrawalForm();
    await loadSummary();
  } catch (error) {
    logLine((withdrawalId ? "出金訂正" : "出金登録") + " NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function clearWithdrawalForm() {
  el("withdrawalIdInput").value = "";
  el("withdrawalDeviceSelect").value = "";
  el("withdrawalAmountInput").value = "";
  el("withdrawalMemoInput").value = "";
  state.withdrawalDeviceSelection = null;
  el("addWithdrawalBtn").textContent = "出金登録";
  el("cancelWithdrawalEditBtn").classList.add("hidden");
}

async function runAction(label, endpoint, button = null) {
  setBusy(true, button);
  logLine(label + " 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson(endpoint, { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    logLine(label + " OK: " + summarizeActionResult(result));
    await loadSummary();
  } catch (error) {
    logLine(label + " NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

async function importMigrationDataFromFolder(button = null) {
  const ok = window.confirm("移行データを取り込みます。現在のデータはバックアップしてから上書きします。実行しますか？");
  if (!ok) return;
  setBusy(true, button);
  logLine("移行データ取込 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson("/api/migration/import", { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    logLine("移行データ取込 OK: " + summarizeActionResult(result));
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("移行データ取込 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

async function applyPendingTagBoardChangesBeforeXiaoweiSync() {
  const frame = el("tagBoardFrame");
  const frameApi = frame && frame.contentWindow && frame.contentWindow.androidFleetTagBoard;
  if (!frameApi || typeof frameApi.applyPendingChanges !== "function") {
    throw new Error("チェック一覧を準備中です。表示完了後にもう一度お試しください");
  }

  logLine("チェック一覧の未保存内容をDBへ反映中...");
  const result = await frameApi.applyPendingChanges();
  if (result.cancelled) {
    logLine("チェック一覧のDB反映をキャンセルしました");
    return result;
  }
  const failed = result.failed || 0;
  logLine(`チェック変更保存 OK: ${result.applied || 0}/${result.requested || 0}件${failed ? ` / 失敗 ${failed}件` : ""}`);
  if (failed) {
    const failedRows = (result.results || []).filter((row) => !row.ok).slice(0, 8);
    for (const row of failedRows) logLine(`チェック変更保存 失敗: ${row.serial || "-"} ${row.tag || "-"} ${row.error || row.message || ""}`);
  }
  if (result.needsRegeneration) {
    logLine(`チェック変更はDBへ保存済みです。XiaoWei同期で一覧再生成を再試行します: ${result.applyWarning || "一覧更新失敗"}`);
  }
  return result;
}

async function runTagBoardSync(button = null) {
  setBusy(true, button);
  logLine("XiaoWei名/番号同期 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const applyResult = await applyPendingTagBoardChangesBeforeXiaoweiSync();
    if (applyResult.cancelled) {
      flash = { message: "中止", type: "warn" };
      return;
    }
    const result = await fetchJson("/api/xiaowei/sync", { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    logLine("XiaoWei名/番号同期 OK: " + summarizeActionResult(result));
    const warningSteps = result.warningSteps || [];
    const xiaoweiWarnings = warningSteps.filter((step) => step !== "sheets");
    if (warningSteps.includes("sheets")) logLine("Google Sheets同期待ち: XiaoWei名/番号は反映済み");
    if ((result.failedSteps || []).length || xiaoweiWarnings.length) flash = { message: "要確認", type: "warn" };
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("XiaoWei名/番号同期 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

async function runXiaoweiFullSync(button = null) {
  setBusy(true, button);
  logLine("XiaoWei名/番号同期 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const applyResult = await applyPendingTagBoardChangesBeforeXiaoweiSync();
    if (applyResult.cancelled) {
      flash = { message: "中止", type: "warn" };
      return;
    }
    if (applyResult.requested || applyResult.applied) {
      logLine(`XiaoWei名/番号同期: DB反映 ${applyResult.applied || 0}/${applyResult.requested || 0}件`);
    }

    const dayResult = await fetchJson("/api/day-tags/advance", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ syncXiaowei: false, syncLegacyMirror: false }),
    });
    logLine(dayResult.skipped
      ? "XiaoWei名/番号同期: DAY更新 変更なし"
      : `XiaoWei名/番号同期: DAY更新 ${dayResult.changed || 0}件`);

    const syncResult = await fetchJson("/api/xiaowei/sync", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    const failed = (syncResult.failedSteps || []).length;
    const warningSteps = syncResult.warningSteps || [];
    const xiaoweiWarnings = warningSteps.filter((step) => step !== "sheets");
    const sheetsPending = warningSteps.includes("sheets");
    const numberStep = syncResult.refresh && syncResult.refresh.numbers || {};
    const codeStep = syncResult.refresh && syncResult.refresh.deviceCodeSync || {};
    logLine(`XiaoWei名/番号同期: 端末名再取得 ${codeStep.changedDevices || 0}件`);
    logLine(`XiaoWei名/番号同期: 名前/番号 ${failed ? "一部NG" : "OK"} / 対象 ${numberStep.logicalRequested ?? numberStep.requested ?? 0}件 / 失敗 ${failed}件 / XiaoWei警告 ${xiaoweiWarnings.length}件`);
    if (Number(numberStep.disconnectedMatched || 0) > 0) {
      logLine(`XiaoWei名/番号同期: 未接続も強制対象 ${numberStep.disconnectedMatched}台 / 番号変更 ${numberStep.disconnectedRequested || 0}台 / 成功 ${numberStep.disconnectedSucceeded || 0}台 / 失敗 ${numberStep.disconnectedFailed || 0}台`);
      if (numberStep.xiaoweiCacheProtectedUpdates) logLine(`XiaoWei名/番号同期: 終了時の書戻し防止 ${numberStep.xiaoweiCacheProtectedUpdates}台 OK`);
      if (numberStep.xiaoweiRestartRecommended) logLine("XiaoWei名/番号同期: 番号は保存済みです。未接続端末の表示順は画面再読込または再起動後に反映されます");
    }
    if (numberStep.error) logLine(`XiaoWei名/番号同期: ${numberStep.error}`);
    if (sheetsPending) logLine("Google Sheets同期待ち: XiaoWei名/番号は反映済み");
    const timings = summarizeSyncStepDurations(syncResult.refresh);
    if (timings) logLine(`XiaoWei名/番号同期: 所要 ${timings}`);
    if (failed || xiaoweiWarnings.length) flash = { message: "要確認", type: "warn" };

    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("XiaoWei名/番号同期 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}


async function runXiaoweiNameSync(button = null) {
  setBusy(true, button);
  logLine("XiaoWei名同期 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const applyResult = await applyPendingTagBoardChangesBeforeXiaoweiSync();
    if (applyResult.cancelled) {
      flash = { message: "中止", type: "warn" };
      return;
    }
    const result = await fetchJson("/api/xiaowei/display-names/sync", { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    const failed = (result.failedSteps || []).length;
    const codeStep = result.refresh && result.refresh.deviceCodeSync || {};
    logLine(`XiaoWei名同期: 端末名再取得 ${codeStep.changedDevices || 0}件`);
    logLine(`XiaoWei名同期 ${failed ? "一部NG" : "OK"}: 失敗 ${failed}件`);
    if (failed) flash = { message: "要確認", type: "warn" };
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("XiaoWei名同期 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}


async function runDayAdvance(button = null) {
  setBusy(true, button);
  logLine("DAY更新 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson("/api/day-tags/advance", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ syncXiaowei: false, syncLegacyMirror: false }) });
    logLine(result.skipped ? "DAY更新: 変更なし" : `DAY更新 OK: ${result.changed || 0}件 / DB反映`);
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("DAY更新 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}


async function runDeviceCodeSync(button = null) {
  const ok = window.confirm("端末名を再取得します。DBへ反映してよろしいですか？");
  if (!ok) return;
  setBusy(true, button);
  logLine("端末名再取得 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson("/api/fleet-db/device-codes/sync", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ force: true, refreshIdentity: true }) });
    const corrected = result.identityRefresh?.correctedDevices || 0;
    logLine(`端末名再取得 OK: 機種修正 ${corrected}件 / 端末名 ${result.changedDevices || 0}件 / 出金履歴 ${result.changedWithdrawals || 0}件`);
    if (announceUnregisteredDeviceMaster(result, "端末名再取得")) {
      flash = { message: "マスタ未登録", type: "warn" };
    }
    reloadTagBoardFrame();
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine("端末名再取得 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}


async function runXiaoweiNumberSync(button = null) {
  const ok = window.confirm(["DBの内容をXiaoWeiへ同期します。", "よろしいですか？"].join("\n"));
  if (!ok) return;
  setBusy(true, button);
  logLine("XiaoWei番号反映 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const applyResult = await applyPendingTagBoardChangesBeforeXiaoweiSync();
    if (applyResult.cancelled) {
      flash = { message: "中止", type: "warn" };
      return;
    }
    const result = await fetchJson("/api/xiaowei/numbers/sync", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ apply: true }) });
    logLine(`XiaoWei番号反映 OK: 対象 ${result.logicalRequested ?? result.requested ?? 0}件 / 成功 ${result.succeeded || 0} / 失敗 ${result.failed || 0}`);
    if (Number(result.failed || 0) > 0) flash = { message: "要確認", type: "warn" };
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("XiaoWei番号反映 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}


async function importNewAdbDevices(button = null) {
  const ok = window.confirm("新規端末をDBへ取り込みます。よろしいですか？");
  if (!ok) return;
  setBusy(true, button);
  logLine("新規端末取込 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await importNewDevicesUntilStable({
      label: "新規端末取込",
      minPasses: 3,
      maxPasses: 5,
      intervalMs: 3000,
    });
    const labels = (result.devices || []).slice(0, 5).map((device) => `${device.managementId} ${device.name || device.model || device.serial}`).join(" / ");
    logLine(`新規端末取込 OK: 自動確認 ${result.passes || 0}回 / 検出 ${result.scanned || 0}台（ADB ${result.adbScanned || 0}台 / XiaoWei投影 ${result.xiaoweiScanned || 0}台 / USB実機救済 ${result.xiaoweiUsbConfirmed || 0}台） / 取込 ${result.imported || 0}台 / 既存 ${result.skipped || 0}台${labels ? " / " + labels : ""}`);
    if (Number(result.xiaoweiHistorySkipped || 0) > 0) {
      logLine(`新規端末取込 除外: XiaoWeiの未接続保存履歴 ${result.xiaoweiHistorySkipped}台`);
    }
    if (announceUnregisteredDeviceMaster(result, "新規端末取込")) {
      flash = { message: "マスタ未登録", type: "warn" };
    }
    await loadSummary();
    reloadTagBoardFrame();
  } catch (error) {
    logLine("新規端末取込 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}


function devicePreviewLabel(row = {}) {
  const candidates = [
    row.laixiNumber ? `No.${row.laixiNumber}` : "",
    row.deviceDisplayCode ? `${row.deviceDisplayCode}${row.carrierCode ? ` ${row.carrierCode}` : ""}` : "",
    row.deviceLabel,
    row.desiredName ? String(row.desiredName).replace(/^(?:DAY\d+\s+)?(?:180分[○〇]\s+)?(?:追加[○〇]\s+)?/, "") : "",
    row.currentName ? String(row.currentName).replace(/^(?:DAY\d+\s+)?(?:180分[○〇]\s+)?(?:追加[○〇]\s+)?/, "") : "",
  ].map((value) => String(value || "").trim()).filter((value) => value && !/^A-\d+$/i.test(value));
  if (candidates.length) return candidates[0];
  const id = String(row.serial || row.deviceSerial || row.deviceId || "").trim();
  return id ? `ID ${id.slice(-8)}` : "端末";
}

async function startAdbSwipeJobFromPanel(button = null) {
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  const selectedRows = rows
    .filter((row) => state.adbSwipe.selected.has(row.serial) && row.connected)
    .map((row) => ({
      ...row,
      minutes: Number(state.adbSwipe.minutesBySerial[row.serial] || 60),
    }));
  if (!selectedRows.length) {
    logLine("ADBスワイプ NG: 対象端末が選択されていません");
    return;
  }
  const sample = selectedRows.slice(0, 10).map((row) => `${row.laixiNumber || "-"} ${row.label} ${row.minutes}?`).join("\n");
  const ok = window.confirm([
    `ADBスワイプを開始します。対象 ${selectedRows.length}台`,
    "",
    sample,
    selectedRows.length > 10 ? `...ほか ${selectedRows.length - 10}台` : "",
  ].join("\n"));
  if (!ok) return;
  await startAdbSwipeJob(selectedRows, button, `${selectedRows.length}台`);
}

async function restartTtlForSelectedAdbSwipeDevices(button = null) {
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  const selectedRows = rows
    .filter((row) => state.adbSwipe.selected.has(row.serial) && row.connected)
    .map((row) => ({
      serial: row.serial,
      adbPort: row.adbPort || "",
      label: `${row.laixiNumber ? row.laixiNumber + " " : ""}${row.label || row.serial}`,
    }));
  if (!selectedRows.length) {
    logLine("TTL再起動 NG: 対象端末が選択されていません");
    return;
  }
  const sample = selectedRows.slice(0, 10).map((row) => row.label || row.serial).join("\n");
  const ok = window.confirm([
    `選択端末のTikTok Liteを再起動します。対象 ${selectedRows.length}台`,
    "",
    sample,
    selectedRows.length > 10 ? `...ほか${selectedRows.length - 10}台` : "",
  ].join("\n"));
  if (!ok) return;
  setBusy(true, button);
  logLine(`TTL再起動 実行中: ${selectedRows.length}台`);
  try {
    const result = await fetchJson("/api/adb/restart-ttl", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ targets: selectedRows }),
    });
    logLine(`TTL再起動 ${result.ok ? "OK" : "NG"}: 成功 ${result.succeeded || 0} / 失敗 ${result.failed || 0}`);
    logFailedDeviceRows("TTL再起動", result.results || []);
    await refreshAdbSwipeDevices();
  } catch (error) {
    logLine("TTL再起動 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function runSwipeRecoveryTest(button = null, options = {}) {
  if (state.swipeStopBusy) { logLine("停止処理中です"); return; }
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  const selectedRows = rows.filter((row) => state.swipeAgent.selected.has(row.serial) && row.connected).map((row) => ({
    serial: row.serial, adbPort: row.adbPort || "", label: `${row.laixiNumber ? row.laixiNumber + " " : ""}${row.label || row.serial}`, laixiNumber: row.laixiNumber || "", minutes: Number(state.swipeAgent.minutesBySerial[row.serial] || 10), swipeMode: normalizeSwipeModeRecommendation(row).mode,
  }));
  if (!selectedRows.length) { logLine("対象端末が選択されていません"); return; }
  const stopAgent = options.stopAgent !== false;
  const title = stopAgent ? "選択端末のスワイプ停止" : "スワイプ本体停止";
  const sample = selectedRows.slice(0, 6).map((row) => `${row.label || row.serial} / ${row.minutes}分`).join("\n");
  const ok = window.confirm([`${title} 対象 ${selectedRows.length}台`, sample, selectedRows.length > 6 ? `ほか ${selectedRows.length - 6}台` : ""].join("\n"));
  if (!ok) return;
  setBusy(true, button);
  logLine(`${title} 実行中: ${selectedRows.length}台`);
  try {
    const result = await fetchJson("/api/swipe-agent/recovery-test", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ targets: selectedRows, stopAgent }) });
    logLine(`${title} ${result.ok ? "OK" : "NG"}: 成功 ${result.succeeded || 0} / 失敗 ${result.failed || 0}`);
    for (const row of result.results || []) {
      const name = row.label || row.serial || "-";
      logLine(`${title}: ${name}${row.screenshotUrl ? ` / ${row.screenshotUrl}` : ""}`);
      for (const step of (row.steps || []).slice(0, 12)) { logLine(`- ${formatTime(step.at)} ${name}: ${step.name} ${step.ok ? "OK" : "NG"}${step.error ? ` / ${step.error}` : ""}`); }
    }
    await refreshSwipeAgentDevices();
  } catch (error) {
    logLine(`${title} NG: ${error.message}`);
  } finally {
    setBusy(false);
  }
}
async function startAdbSwipeJob(rows, button = null, targetLabel = "") {
  if (!rows.length) {
    logLine("ADBスワイプ NG: ADB接続端末がありません");
    return;
  }
  setBusy(true, button);
  logLine(`ADBスワイプ起動中: ${targetLabel || rows.length + "台"}`);
  try {
    const result = await fetchJson("/api/adb/swipe-jobs", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        minutes: 60,
        minIntervalSeconds: 10,
        maxIntervalSeconds: 15,
        targets: rows.map((row) => ({
          serial: row.serial,
          adbPort: row.adbPort || "",
          label: `${row.laixiNumber ? row.laixiNumber + " " : ""}${row.label || row.serial}`,
          laixiNumber: row.laixiNumber || "",
          minutes: row.minutes || 60,
        })),
      }),
    });
    state.adbSwipe.jobId = result.job?.jobId || "";
    renderAdbSwipeJob(result.job);
    startAdbSwipePolling();
    logLine(`ADBスワイプ ${result.merged ? "合流OK" : "開始OK"}: ${targetLabel || rows.length + "台"} / job ${state.adbSwipe.jobId || "-"}`);
    logFailedSwipeDevices(result.job, "ADBスワイプ");
  } catch (error) {
    logLine("ADBスワイプ NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function startAdbSwipePolling() {
  if (state.adbSwipe.pollTimer) window.clearInterval(state.adbSwipe.pollTimer);
  if (!state.adbSwipe.jobId) return;
  state.adbSwipe.pollTimer = window.setInterval(loadAdbSwipeJobStatus, 2000);
  loadAdbSwipeJobStatus();
}

async function refreshRunningSwipeJobs() {
  const [agentList, adbList] = await Promise.all([
    fetchJson("/api/swipe-agent/jobs").catch(() => ({ jobs: [] })),
    fetchJson("/api/adb/swipe-jobs").catch(() => ({ jobs: [] })),
  ]);
  const pickJob = (jobs = []) =>
    jobs.find((job) => ["running", "stopping"].includes(job.status || "")) ||
    jobs.find((job) => job.jobId === state.swipeAgent.jobId || job.jobId === state.adbSwipe.jobId) ||
    jobs[0] ||
    null;
  const agentJob = pickJob(agentList.jobs || []);
  const adbJob = pickJob(adbList.jobs || []);
  state.swipeAgent.jobId = agentJob?.jobId || "";
  state.adbSwipe.jobId = adbJob?.jobId || "";
  renderSwipeAgentJob(agentJob);
  renderAdbSwipeJob(adbJob);
  if (state.swipeAgent.jobId && ["running", "stopping"].includes(agentJob?.status || "")) startSwipeAgentPolling();
  if (state.adbSwipe.jobId && ["running", "stopping"].includes(adbJob?.status || "")) startAdbSwipePolling();
}

async function loadAdbSwipeJobStatus() {
  if (!state.adbSwipe.jobId) return;
  try {
    const result = await fetchJson(`/api/adb/swipe-jobs/${encodeURIComponent(state.adbSwipe.jobId)}`);
    renderAdbSwipeJob(result.job);
    if (!["running", "stopping"].includes(result.job?.status || "")) {
      logFailedSwipeDevices(result.job, "ADBスワイプ");
      window.clearInterval(state.adbSwipe.pollTimer);
      state.adbSwipe.pollTimer = 0;
    }
  } catch (error) {
    logLine("ADBスワイプ進捗 NG: " + error.message);
    window.clearInterval(state.adbSwipe.pollTimer);
    state.adbSwipe.pollTimer = 0;
  }
}

function logFailedSwipeDevices(job, label) {
  const failed = (job?.devices || []).filter((device) =>
    device.state === "failed" ||
    device.state === "missing" ||
    Number(device.failCount || 0) > 0 ||
    device.lastError
  );
  if (!failed.length) return;
  logLine(`${label} 失敗端末:`);
  for (const device of failed.slice(0, 20)) {
    const name = device.label || device.serial || "unknown";
    const reason = device.lastError || device.state || "理由不明";
    logLine(`- ${name}: ${reason}`);
  }
  if (failed.length > 20) logLine(`- ...ほか${failed.length - 20}台`);
}

function logFailedDeviceRows(label, rows = []) {
  const failed = (rows || []).filter((row) => !row.ok);
  if (!failed.length) return;
  logLine(`${label} 失敗端末:`);
  for (const row of failed.slice(0, 20)) {
    const name = row.label || row.serial || "unknown";
    const reason = row.error || row.message || row.status || "理由不明";
    logLine(`- ${name}: ${reason}`);
  }
  if (failed.length > 20) logLine(`- ...ほか${failed.length - 20}台`);
}

async function stopAdbSwipeJob(button = null) {
  if (!state.adbSwipe.jobId) return;
  setBusy(true, button);
  try {
    const result = await fetchJson(`/api/adb/swipe-jobs/${encodeURIComponent(state.adbSwipe.jobId)}/stop`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    renderAdbSwipeJob(result.job);
    logLine("ADBスワイプ 停止要求OK");
  } catch (error) {
    logLine("ADBスワイプ停止 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function stopAllSwipeJobs(button = null) {
  if (state.swipeStopBusy) return;
  state.swipeStopBusy = true;
  setSwipeStopControlsLocked(true);
  setBusy(true, button, "停止中...");
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  const selectedSerials = new Set([...state.swipeAgent.selected, ...state.adbSwipe.selected]);
  const selectedTargets = rows
    .filter((row) => selectedSerials.has(row.serial) && row.connected)
    .map((row) => ({
      serial: row.serial,
      adbPort: row.adbPort || "",
      label: `${row.laixiNumber ? row.laixiNumber + " " : ""}${row.label || row.serial}`,
      laixiNumber: row.laixiNumber || "",
    }));
  const selectedOnly = selectedTargets.length > 0;
  logLine(selectedOnly
    ? `停止中... 対象 ${selectedTargets.length}台`
    : "停止中...");
  try {
    const result = await fetchJson("/api/swipe/stop-all", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(selectedOnly
        ? { selectedOnly: true, includeConnected: false, targets: selectedTargets }
        : { includeConnected: true }),
    });
    logLine(`${result.selectedOnly ? "スワイプ選択停止" : "スワイプ全体停止"}完了 Agentジョブ ${result.agentJobs || 0} / ADBジョブ ${result.adbJobs || 0} / Agent停止 ${result.directSucceeded || 0}/${result.directTargets || 0}台`);
    const failed = (result.directResults || []).filter((item) => !item.ok);
    for (const item of failed.slice(0, 12)) logLine(`スワイプ停止 NG: ${item.label || item.serial} ${item.error || ""}`);
    if (failed.length > 12) logLine(`スワイプ停止 NG: ほか${failed.length - 12}台`);
    await refreshRunningSwipeJobs();
  } catch (error) {
    logLine("スワイプ停止 NG: " + error.message);
  } finally {
    state.swipeStopBusy = false;
    setBusy(false);
    setSwipeStopControlsLocked(false);
    await refreshRunningSwipeJobs().catch(() => null);
  }
}

async function startSwipeAgentJobFromPanel(button = null) {
  if (state.swipeStopBusy) {
    logLine("スワイプ開始 NG: 停止処理が終わるまで待ってください");
    return;
  }
  const rows = adbSwipeRows(state.summary?.devices || [], state.adbDevices?.devices || []);
  const selectedRows = rows
    .filter((row) => state.swipeAgent.selected.has(row.serial) && row.connected)
    .map((row) => ({
      ...row,
      minutes: Number(state.swipeAgent.minutesBySerial[row.serial] || 60),
    }));
  if (!selectedRows.length) {
    logLine("スワイプ NG: 対象端末が選択されていません");
    return;
  }
  const agentRows = selectedRows.filter((row) => normalizeSwipeModeRecommendation(row).mode !== "adb");
  const adbRows = selectedRows.filter((row) => normalizeSwipeModeRecommendation(row).mode === "adb");
  const sample = selectedRows.slice(0, 10).map((row) => {
    const mode = normalizeSwipeModeRecommendation(row).mode === "adb" ? "ADB" : "Agent";
    return `${row.laixiNumber || "-"} ${row.label} ${row.minutes}分 / ${mode}`;
  }).join("\n");
  const ok = window.confirm([
    `スワイプを開始します。対象 ${selectedRows.length}台`,
    `Agent ${agentRows.length}台 / ADB ${adbRows.length}台`,
    "Agent推奨端末は端末側アプリ、ADB推奨端末はPC側ADBで実行します。",
    "",
    sample,
    selectedRows.length > 10 ? `...ほか ${selectedRows.length - 10}台` : "",
  ].join("\n"));
  if (!ok) return;
  if (agentRows.length) await startSwipeAgentJob(agentRows, button, `Agent ${agentRows.length}台`);
  if (adbRows.length) await startAdbSwipeJob(adbRows, button, `ADB ${adbRows.length}台`);
}

async function startSwipeAgentJob(rows, button = null, targetLabel = "") {
  setBusy(true, button);
  logLine(`Swipe Agent 起動中: ${targetLabel || rows.length + "台"}`);
  try {
    const result = await fetchJson("/api/swipe-agent/jobs", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        minutes: 60,
        monitorIntervalSeconds: 30,
        staleSeconds: 90,
        targets: rows.map((row) => ({
          serial: row.serial,
          adbPort: row.adbPort || "",
          label: `${row.laixiNumber ? row.laixiNumber + " " : ""}${row.label || row.serial}`,
          laixiNumber: row.laixiNumber || "",
          minutes: row.minutes || 60,
        })),
      }),
    });
    state.swipeAgent.jobId = result.job?.jobId || "";
    renderSwipeAgentJob(result.job);
    trackSwipeAgentFallbackAdbJob(result.job);
    startSwipeAgentPolling();
    logLine(`Swipe Agent ${result.merged ? "合流OK" : "開始OK"}: ${targetLabel || rows.length + "台"} / job ${state.swipeAgent.jobId || "-"}`);
    logFailedSwipeDevices(result.job, "Swipe Agent");
  } catch (error) {
    logLine("Swipe Agent NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function startSwipeAgentPolling() {
  if (state.swipeAgent.pollTimer) window.clearInterval(state.swipeAgent.pollTimer);
  if (!state.swipeAgent.jobId) return;
  state.swipeAgent.pollTimer = window.setInterval(loadSwipeAgentJobStatus, 5000);
  loadSwipeAgentJobStatus();
}

function trackSwipeAgentFallbackAdbJob(job) {
  const fallbackIds = Array.isArray(job?.fallbackAdbJobIds) ? job.fallbackAdbJobIds.filter(Boolean) : [];
  if (!fallbackIds.length) return;
  const latest = fallbackIds[fallbackIds.length - 1];
  if (!latest || state.adbSwipe.jobId === latest) return;
  state.adbSwipe.jobId = latest;
  logLine(`Swipe Agent: Agent失敗端末をADBへ自動切替 / job ${latest}`);
  startAdbSwipePolling();
}

async function loadSwipeAgentJobStatus() {
  if (!state.swipeAgent.jobId) return;
  try {
    const result = await fetchJson(`/api/swipe-agent/jobs/${encodeURIComponent(state.swipeAgent.jobId)}`);
    renderSwipeAgentJob(result.job);
    trackSwipeAgentFallbackAdbJob(result.job);
    if (!["running", "stopping"].includes(result.job?.status || "")) {
      logFailedSwipeDevices(result.job, "Swipe Agent");
      window.clearInterval(state.swipeAgent.pollTimer);
      state.swipeAgent.pollTimer = 0;
    }
  } catch (error) {
    logLine("Swipe Agent進捗取得 NG: " + error.message);
    window.clearInterval(state.swipeAgent.pollTimer);
    state.swipeAgent.pollTimer = 0;
  }
}

async function stopSwipeAgentJob(button = null) {
  if (!state.swipeAgent.jobId) return;
  setBusy(true, button);
  try {
    const result = await fetchJson(`/api/swipe-agent/jobs/${encodeURIComponent(state.swipeAgent.jobId)}/stop`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    renderSwipeAgentJob(result.job);
    logLine("Swipe Agent 停止要求 OK");
  } catch (error) {
    logLine("Swipe Agent停止 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function renderSwipeAgentJob(job) {
  const panel = el("swipeAgentJobPanel");
  if (!panel) return;
  state.swipeAgent.currentJob = job || null;
  renderCombinedSwipeJobs();
  return;
  el("swipeAgentStopBtn").disabled = !job || !["running", "stopping"].includes(job.status || "");
  if (!job) {
    panel.innerHTML = `<div class="adb-job-empty">実行中のSwipe Agentジョブはありません</div>`;
    return;
  }
  const totals = job.totals || {};
  panel.innerHTML = `
    <div class="adb-job-summary">
      <div>
        <span class="adb-job-label">状態</span>
        <strong>${esc(adbJobStatusLabel(job.status))}</strong>
      </div>
      <div>
        <span class="adb-job-label">監視</span>
        <strong>${esc(job.monitorIntervalSeconds || 30)}秒ごと</strong>
      </div>
      <div>
        <span class="adb-job-label">Agent対象</span>
        <strong>${esc(totals.devices || 0)}台</strong>
      </div>
      <div>
        <span class="adb-job-label">再投入</span>
        <strong>${esc(totals.restarts || 0)}</strong>
      </div>
      <div>
        <span class="adb-job-label">ADB切替</span>
        <strong>${esc(totals.adbFallback || 0)}</strong>
      </div>
      <div>
        <span class="adb-job-label">失敗</span>
        <strong>${esc(totals.failed || 0)}</strong>
      </div>
    </div>
    <details class="adb-job-details" open>
      ${swipeLogSummaryHtml()}
      <div class="adb-progress-list">
        ${(job.devices || []).slice(0, 120).map((device) => `
          <div class="adb-progress-row ${esc(device.state || "")}">
            <div>
              <strong>${esc(device.label || device.serial)}</strong>
              <span>${esc(device.serial)}</span>
            </div>
            <div><span class="swipe-mode-chip agent">Agent</span></div>
            <div>${esc(adbJobStatusLabel(device.state))}</div>
            <div>実働 ${esc(formatSeconds(Number(device.elapsedSeconds || 0)))}</div>
            <div>再投入 ${esc(device.restartCount || 0)}</div>
            <div>${esc(lastActivityLabel(device.lastSeenAt || device.lastStatusAt || device.lastStartCommandAt || ""))}</div>
            <div class="adb-error-text">${esc(device.lastError || "")}</div>
          </div>
        `).join("")}
        ${(job.devices || []).length > 120 ? `<div class="adb-progress-more">仁E{(job.devices || []).length - 120}台</div>` : ""}
      </div>
      <div class="adb-job-log">
        ${(job.logs || []).slice(-40).map((row) => `<div><span>${esc(formatTime(row.at))}</span>${formatSwipeLogMessage(row.message || "")}</div>`).join("")}
      </div>
    </details>
  `;
}

function renderAdbSwipeJob(job) {
  const panel = el("adbSwipeJobPanel");
  if (!panel) return;
  state.adbSwipe.currentJob = job || null;
  renderAdbSwipeMeta(job);
  renderCombinedSwipeJobs();
  return;
  el("adbSwipeStopBtn").disabled = !job || !["running", "stopping"].includes(job.status || "");
  if (!job) {
    panel.innerHTML = `<div class="adb-job-empty">実行中のADBスワイプはありません</div>`;
    return;
  }
  const totals = job.totals || {};
  panel.innerHTML = `
    <div class="adb-job-summary">
      <div>
        <span class="adb-job-label">状態</span>
        <strong>${esc(adbJobStatusLabel(job.status))}</strong>
      </div>
      <div>
        <span class="adb-job-label">残り</span>
        <strong>${esc(formatAdbRemaining(job))}</strong>
      </div>
      <div>
        <span class="adb-job-label">ADB対象</span>
        <strong>${esc(totals.devices || 0)}台</strong>
      </div>
      <div>
        <span class="adb-job-label">失敗</span>
        <strong>${esc(totals.failed || 0)}</strong>
      </div>
    </div>
    <details class="adb-job-details" open>
      ${swipeLogSummaryHtml()}
      <div class="adb-progress-list">
        ${(job.devices || []).slice(0, 120).map((device) => `
          <div class="adb-progress-row ${esc(device.state || "")}">
            <div>
              <strong>${esc(device.label || device.serial)}</strong>
              <span>${esc(device.serial)}</span>
            </div>
            <div><span class="swipe-mode-chip adb">ADB</span></div>
            <div>${esc(adbJobStatusLabel(device.state))}</div>
            <div>${esc(formatAdbDeviceRemaining(device))}</div>
            <div>-</div>
            <div>${esc(lastActivityLabel(device.lastRunAt || device.lastSwipeAt || device.finishedAt || device.startedAt || ""))}</div>
            <div class="adb-error-text">${esc(device.lastError || "")}</div>
          </div>
        `).join("")}
        ${(job.devices || []).length > 120 ? `<div class="adb-progress-more">仁E{(job.devices || []).length - 120}台</div>` : ""}
      </div>
      <div class="adb-job-log">
        ${(job.logs || []).slice(-40).map((row) => `<div><span>${esc(formatTime(row.at))}</span>${formatSwipeLogMessage(row.message || "")}</div>`).join("")}
      </div>
    </details>
  `;
}

function renderCombinedSwipeJobs() {
  const panel = el("swipeAgentJobPanel");
  if (!panel) return;
  const adbPanel = el("adbSwipeJobPanel");
  if (adbPanel) adbPanel.innerHTML = `<div class="adb-job-empty">ADBログは上の端末モニタに統合しました</div>`;
  const agentJob = state.swipeAgent.currentJob;
  const adbJob = state.adbSwipe.currentJob;
  const agentDevices = (agentJob?.devices || []).map((device) => ({ ...device, mode: "agent" }));
  const adbDevices = (adbJob?.devices || []).map((device) => ({ ...device, mode: "adb" }));
  const devices = [...agentDevices, ...adbDevices];
  annotateSwipeAttemptNumbers(devices);
  const running = devices.filter((device) => ["queued", "starting", "running", "stopping"].includes(device.state || ""));
  const hasActive = running.length > 0;
  if (el("swipeAgentStopBtn")) el("swipeAgentStopBtn").disabled = state.swipeStopBusy || !hasActive;
  if (el("adbSwipeStopBtn")) el("adbSwipeStopBtn").disabled = state.swipeStopBusy || !hasActive;
  if (state.swipeStopBusy) setSwipeStopControlsLocked(true);
  if (!agentJob && !adbJob) {
    panel.innerHTML = `<div class="adb-job-empty">実行中のスワイプはありません</div>`;
    renderAdbSwipeMeta(null);
    return;
  }
  const agentCount = agentDevices.length;
  const adbCount = adbDevices.length;
  const failed = running.filter((device) => device.state === "failed" || device.state === "missing" || device.lastError).length;
  const restarts = agentDevices.reduce((sum, device) => sum + Number(device.restartCount || 0), 0);
  const fallback = agentDevices.filter((device) => device.state === "adb_fallback").length;
  const logs = [
    ...(agentJob?.logs || []).map((row) => ({ ...row, mode: "Agent" })),
    ...(adbJob?.logs || []).map((row) => ({ ...row, mode: "ADB" })),
  ].sort((a, b) => String(a.at || "").localeCompare(String(b.at || "")));
  if (!hasActive) {
    panel.innerHTML = `
      <div class="adb-job-summary">
        <div>
          <span class="adb-job-label">状態</span>
          <strong>停止</strong>
        </div>
        <div>
          <span class="adb-job-label">対象</span>
          <strong>${esc(devices.length)}台</strong>
        </div>
        <div>
          <span class="adb-job-label">内訳</span>
          <strong>Agent ${esc(agentCount)} / ADB ${esc(adbCount)}</strong>
        </div>
        <div>
          <span class="adb-job-label">再投入</span>
          <strong>${esc(restarts)}</strong>
        </div>
        <div>
          <span class="adb-job-label">ADB切替</span>
          <strong>${esc(fallback)}</strong>
        </div>
        <div>
          <span class="adb-job-label">要確認</span>
          <strong>${esc(failed)}</strong>
        </div>
      </div>
      <details class="adb-job-details recent-job-details" open>
        ${swipeLogSummaryHtml()}
        <p class="swipe-log-note">${esc(swipeLogRetentionText())}</p>
        <div class="adb-progress-list">
          ${devices.map((device) => renderCombinedSwipeDeviceRow(device)).join("")}
        </div>
        <div class="adb-job-log">
          ${logs.map((row) => `<div><span>${esc(formatTime(row.at))}</span><b>${esc(row.mode)}</b> ${formatSwipeLogMessage(row.message || "")}</div>`).join("")}
        </div>
      </details>
    `;
    renderAdbSwipeMeta(null);
    return;
  }
  panel.innerHTML = `
    <div class="adb-job-summary">
      <div>
        <span class="adb-job-label">状態</span>
        <strong>${esc(hasActive ? "実行中" : "停止")}</strong>
      </div>
      <div>
        <span class="adb-job-label">対象</span>
        <strong>${esc(devices.length)}台</strong>
      </div>
      <div>
        <span class="adb-job-label">内訳</span>
        <strong>Agent ${esc(agentCount)} / ADB ${esc(adbCount)}</strong>
      </div>
      <div>
        <span class="adb-job-label">再投入</span>
        <strong>${esc(restarts)}</strong>
      </div>
      <div>
        <span class="adb-job-label">ADB切替</span>
        <strong>${esc(fallback)}</strong>
      </div>
      <div>
        <span class="adb-job-label">要確認</span>
        <strong>${esc(failed)}</strong>
      </div>
    </div>
    <details class="adb-job-details" open>
      ${swipeLogSummaryHtml()}
      <p class="swipe-log-note">${esc(swipeLogRetentionText())}</p>
      <div class="adb-progress-list">
        ${devices.map((device) => renderCombinedSwipeDeviceRow(device)).join("")}
      </div>
      <div class="adb-job-log">
        ${logs.map((row) => `<div><span>${esc(formatTime(row.at))}</span><b>${esc(row.mode)}</b> ${formatSwipeLogMessage(row.message || "")}</div>`).join("")}
      </div>
    </details>
  `;
}

function swipeLogRetentionText() {
  return "";
}

function swipeLogSummaryHtml() {
  return `
    <summary class="swipe-log-summary">
      <span>端末モニタ / ログ</span>
      <button class="swipe-past-log-btn" type="button" data-action="swipe-past-logs">過去ログ</button>
    </summary>
  `;
}

function handleSwipeJobPanelClick(event) {
  const button = event.target.closest("[data-action='swipe-past-logs']");
  if (!button) return;
  event.preventDefault();
  event.stopPropagation();
  openSwipePastLogsModal();
}

function handleSwipePastLogsModalClick(event) {
  if (event.target === el("swipePastLogsModal")) closeSwipePastLogsModal();
}

function handleSwipePastLogsKeydown(event) {
  if (event.key !== "Escape") return;
  const modal = el("swipePastLogsModal");
  if (!modal || modal.classList.contains("hidden")) return;
  closeSwipePastLogsModal();
}

async function openSwipePastLogsModal() {
  const modal = el("swipePastLogsModal");
  const text = el("swipePastLogsText");
  if (!modal || !text) return;
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  text.value = "過去ログを読み込み中...";
  try {
    const [agentList, adbList] = await Promise.all([
      fetchJson("/api/swipe-agent/jobs").catch(() => ({ jobs: [] })),
      fetchJson("/api/adb/swipe-jobs").catch(() => ({ jobs: [] })),
    ]);
    text.value = buildSwipePastLogsText(agentList.jobs || [], adbList.jobs || []);
    text.focus();
    text.setSelectionRange(0, 0);
  } catch (error) {
    text.value = `過去ログの読み込みに失敗しました。\n${error.message}`;
  }
}

function closeSwipePastLogsModal() {
  const modal = el("swipePastLogsModal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
}

function buildSwipePastLogsText(agentJobs = [], adbJobs = []) {
  const currentIds = new Set([
    state.swipeAgent.currentJob?.jobId,
    state.adbSwipe.currentJob?.jobId,
  ].filter(Boolean));
  const jobs = [
    ...agentJobs.map((job) => ({ ...job, mode: "Agent" })),
    ...adbJobs.map((job) => ({ ...job, mode: "ADB" })),
  ]
    .filter((job) => job && job.jobId && !currentIds.has(job.jobId))
    .filter((job) => !isSwipeJobAppendable(job))
    .sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));

  if (!jobs.length) {
    return [
      "過去ログはまだありません。",
      "",
      "現在表示中のログ、または完了後1時間以内で追加できるログはここには出ません。",
    ].join("\n");
  }

  return jobs.map(formatSwipePastLogJob).join("\n\n" + "=".repeat(72) + "\n\n");
}

function isSwipeJobAppendable(job) {
  if (!job || job.stopRequested) return false;
  if (job.status === "running") return true;
  if (job.status !== "done") return false;
  const finishedMs = Date.parse(job.finishedAt || 0);
  return Boolean(finishedMs && Date.now() - finishedMs <= SWIPE_JOB_MERGE_GRACE_MS);
}

function formatSwipePastLogJob(job) {
  const devices = Array.isArray(job.devices) ? job.devices : [];
  annotateSwipeAttemptNumbers(devices);
  const logs = Array.isArray(job.logs) ? job.logs : [];
  const header = [
    `[${job.mode}] ${job.jobId || "-"}`,
    `状態 ${adbJobStatusLabel(job.status)}`,
    `開始 ${formatDateTime(job.startedAt || job.createdAt || "")}`,
    `完了 ${formatDateTime(job.finishedAt || "") || "-"}`,
    `端末: ${devices.length}台`,
  ];
  const deviceLines = devices.map((device) => {
    const no = device.laixiNumber ? `${device.laixiNumber} ` : "";
    const name = device.label || device.serial || "-";
    const stateLabel = adbJobStatusLabel(device.state);
    const attempt = Number(device.attemptNo || 1) > 1 ? ` ${Number(device.attemptNo)}回目` : "";
    const detail = device.lastError ? ` / ${device.lastError}` : "";
    return `- ${no}${name} [${job.mode}]${attempt} ${stateLabel}${detail}`;
  });
  const logLines = logs.map((row) => `${formatDateTime(row.at || "")}  ${row.message || ""}`);
  return [
    ...header,
    "",
    "端末",
    ...(deviceLines.length ? deviceLines : ["- なし"]),
    "",
    "ログ",
    ...(logLines.length ? logLines : ["- なし"]),
  ].join("\n");
}

function formatSwipeLogMessage(message) {
  const text = translateSwipeLogMessage(String(message || ""));
  const match = /^(\d{1,3})(\s+)(.+)$/.exec(text);
  if (!match) return esc(text);
  return `<strong class="swipe-log-device-no">${esc(match[1])}</strong>${esc(match[2])}${esc(match[3])}`;
}

function translateSwipeLogMessage(message) {
  let text = String(message || "");
  text = text.replace(/agent still running, wait remaining (\d+)m/gi, "Agent稼働中: 残り$1分待機");
  text = text.replace(/agent elapsed (\d+)s\/(\d+)s -> wait (\d+)m/gi, "Agent経過 $1秒/$2秒 -> $3分待機");
  text = text.replace(/real time elapsed but agent worked (\d+)s -> restart (\d+)m/gi, "実働不足: $2分後に復旧");
  text = text.replace(/stop requested/gi, "停止要求");
  text = text.replace(/job stopped/gi, "ジョブ停止");
  text = text.replace(/job done/gi, "ジョブ完了");
  text = text.replace(/job started: (\d+)\/(\d+) devices/gi, "ジョブ開始: $1/$2台");
  text = text.replace(/start (\d+)m \(initial\)/gi, "$1分開始");
  return text;
}


function renderCombinedSwipeDeviceRow(device) {
  const isAdb = device.mode === "adb";
  const activityAt = isAdb
    ? device.lastRunAt || device.lastSwipeAt || device.lastHeartbeatAt || device.finishedAt || device.startedAt || ""
    : device.lastSeenAt || device.lastStatusAt || device.lastStartCommandAt || "";
  const stateLabel = swipeDeviceStateLabel(device, activityAt);
  const adbActiveSeconds = Math.floor(Number(device.activeElapsedMs || 0) / 1000);
  const timing = isAdb ? `実働 ${formatSeconds(adbActiveSeconds)}` : `実働 ${formatSeconds(Number(device.elapsedSeconds || 0))}`;
  const requestedMinutes = isAdb ? Number(device.minutes || 0) : Number(device.currentMinutes || device.requestedMinutes || device.totalRequestedMinutes || 0);
  const requestedBadge = requestedMinutes > 0 ? `<em class="swipe-duration-badge">指定 ${esc(requestedMinutes)}分</em>` : "";
  const attemptNo = Number(device.attemptNo || device.displayAttemptNo || 1);
  const repeatBadge = attemptNo > 1 ? `<em class="swipe-repeat-badge">${esc(attemptNo)}回目</em>` : "";
  return `
    <div class="adb-progress-row ${esc(device.state || "")}">
      <div>
        <strong>${esc(device.label || device.serial)}</strong>
        <span>${esc(device.serial)}</span>
      </div>
      <div><span class="swipe-mode-chip ${isAdb ? "adb" : "agent"}">${isAdb ? "ADB" : "Agent"}</span></div>
      <div>${esc(stateLabel)}</div>
      <div class="adb-timing-cell"><span>${esc(timing)}</span>${requestedBadge}</div>
      <div>${isAdb ? "-" : `再投入 ${esc(device.restartCount || 0)}`}</div>
      <div class="adb-last-activity">${esc(lastActivityLabel(activityAt))}${repeatBadge}</div>
      <div class="adb-error-text">${esc(translateSwipeLogMessage(device.lastError || ""))}</div>
    </div>
  `;
}

function annotateSwipeAttemptNumbers(devices = []) {
  const countBySerial = new Map();
  for (const device of devices) {
    const serial = String(device.serial || "");
    if (!serial) continue;
    const next = (countBySerial.get(serial) || 0) + 1;
    countBySerial.set(serial, next);
    if (!Number(device.attemptNo || 0)) device.displayAttemptNo = next;
  }
}

function swipeDeviceStateLabel(device, activityAt) {
  const status = device && device.state || "";
  if (["running", "starting", "queued"].includes(status)) {
    const at = Date.parse(activityAt || "");
    if (!Number.isFinite(at)) return "";
    const staleSeconds = Math.floor((Date.now() - at) / 1000);
    if (staleSeconds > 90) return "";
  }
  return adbJobStatusLabel(status);
}

function renderAdbSwipeMeta(job) {
  const meta = el("adbSwipeMeta");
  if (!meta) return;
  const running = (job?.devices || []).filter((device) => ["queued", "running"].includes(device.state || ""));
  if (!job || !running.length) {
    meta.textContent = "ADB側の進捗なし";
    return;
  }
  const labels = running.slice(0, 8).map((device) => device.label || device.serial || "-").join(" / ");
  const more = running.length > 8 ? ` / ほか${running.length - 8}台` : "";
  meta.textContent = `ADBで動作中 ${running.length}台: ${labels}${more}`;
}

function adbJobStatusLabel(status) {
  const labels = {
    running: "実行中",
    stopping: "停止中",
    stopped: "停止",
    done: "完了",
    failed: "失敗",
    queued: "待機中",
    missing: "未接続",
    adb_fallback: "ADBへ切替",
  };
  return labels[status] || status || "-";
}

function formatAdbRemaining(job) {
  if (!job || !["running", "stopping"].includes(job.status || "")) return "-";
  const end = Date.parse(job.endAt || "");
  if (!Number.isFinite(end)) return "-";
  return formatSeconds(Math.max(0, Math.ceil((end - Date.now()) / 1000)));
}

function formatAdbDeviceRemaining(device) {
  if (!device || !["running", "queued"].includes(device.state || "")) return "-";
  const end = Date.parse(device.endAt || "");
  if (!Number.isFinite(end)) return "-";
  return formatSeconds(Math.max(0, Math.ceil((end - Date.now()) / 1000)));
}

function formatSeconds(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}分${String(secs).padStart(2, "0")}秒`;
}

function formatTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:${String(date.getSeconds()).padStart(2, "0")}`;
}

function lastActivityLabel(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "確認 -";
  const seconds = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
  if (seconds < 60) return `確認 ${formatTime(value)} / ${seconds}秒前`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `確認 ${formatTime(value)} / ${minutes}分前`;
  const hours = Math.floor(minutes / 60);
  return `確認 ${formatTime(value)} / ${hours}時間前`;
}

async function runDeviceSettingAction(label, endpoint, button = null) {
  setBusy(true, button);
  logLine(label + " 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJsonResult(endpoint, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    const targetCount = Number.isFinite(Number(result.targeted)) ? Number(result.targeted) : Number(result.connected || 0);
    const failed = result.failed ? ` / 失敗 ${result.failed}台` : "";
    const skippedActive = result.skippedActive ? ` / 稼働中スキップ ${result.skippedActive}台` : "";
    const apkSummary = formatApkInstallSummary(result);
    const needsReview = Number(result.failed || 0) > 0 || Number(result.packageSummary?.failed || 0) > 0;
    logLine(`${label} ${needsReview ? "要確認" : "OK"}: 成功 ${result.succeeded || 0}/${targetCount}台${failed}${skippedActive}${apkSummary}`);
    logApkInstallDetails(result);
    logDeviceSettingFailureDetails(label, result);
    if (needsReview) flash = { message: "要確認", type: "warn" };
  } catch (error) {
    logLine(label + " NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

function logDeviceSettingFailureDetails(label, result = {}) {
  const rows = Array.isArray(result.results) ? result.results : [];
  const failed = rows.filter((row) => row && row.ok === false).slice(0, 8);
  for (const row of failed) {
    const id = row.serial || row.label || "-";
    const reason = row.message || row.code || row.rawResult?.error || row.rawResult?.stderr || "理由不明";
    logLine(`${label} 失敗詳細: ${id} / ${reason}`);
  }
}

async function refreshBaselineSettings(button = null) {
  setBusy(true, button);
  logLine("初期設定 全再読込 実行中...");
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJsonResult("/api/adb/baseline-device-settings/refresh", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    const targetCount = Number.isFinite(Number(result.targeted)) ? Number(result.targeted) : Number(result.connected || 0);
    const failed = result.failed ? ` / 失敗 ${result.failed}台` : "";
    logLine(`初期設定 全再読込 OK: 成功 ${result.succeeded || 0}/${targetCount}台${failed}`);
    if (Number(result.failed || 0) > 0) flash = { message: "要確認", type: "warn" };
    await loadSummary();
  } catch (error) {
    logLine("初期設定 全再読込 NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

async function openApkFolder(button = null) {
  setBusy(true, button);
  let flash = { message: "開きました", type: "ok" };
  try {
    const result = await fetchJson("/api/apk-folder/open", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    logLine(`APKフォルダ OK: ${result.path || "data/apk"}`);
  } catch (error) {
    logLine("APKフォルダ NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

function formatApkInstallSummary(result) {
  const summary = result && result.packageSummary;
  if (!summary) return "";
  const missing = summary.missingApk ? ` / APK未配置 ${summary.missingApk}件` : "";
  return ` / APK成功 ${summary.installed}件 / インストール済みスキップ ${summary.skipped}件 / APK失敗 ${summary.failed}件${missing}`;
}

function logApkInstallDetails(result) {
  if (!result || !Array.isArray(result.results) || !result.packageSummary) return;
  const lines = [];
  const missingLabels = new Set();
  const expectedPathsByLabel = new Map();
  for (const device of result.results) {
    for (const pkg of device.packages || []) {
      if (pkg.skipped) {
        lines.push(`${device.serial} ${pkg.label}: インストール済みのためスキップ`);
      } else if (pkg.ok) {
        const mode = pkg.installMode ? ` / ${pkg.installMode}${pkg.reason ? ":" + pkg.reason : ""}` : "";
        const splits = Number(pkg.splitCount || 0) > 1 ? ` / ${pkg.splitCount}分割` : "";
        lines.push(`${device.serial} ${pkg.label}: インストール完了${mode}${splits}`);
      } else {
        if (pkg.code === "APK_NOT_FOUND") {
          missingLabels.add(pkg.label || "APK");
          if (Array.isArray(pkg.expectedPaths) && pkg.expectedPaths.length) {
            expectedPathsByLabel.set(pkg.label || "APK", pkg.expectedPaths.slice(0, 4).join(" / "));
          }
        }
        lines.push(`${device.serial} ${pkg.label}: ${pkg.message || pkg.code || "インストール失敗"}`);
      }
    }
  }
  for (const label of missingLabels) {
    const expected = expectedPathsByLabel.get(label);
    logLine(`APK未配置: ${label}${expected ? " / 探索先 " + expected : ""}`);
  }
  for (const line of lines.slice(0, 30)) logLine(line);
  if (lines.length > 30) logLine(`APK詳細: 残り${lines.length - 30}件は同期ログJSONで確認`);
}

function reloadTagBoardFrame() {
  const frame = el("tagBoardFrame");
  if (frame) frame.src = "/tag-board?ts=" + Date.now();
}

async function saveDbFile(button = null) {
  setBusy(true, button);
  logLine("DB保存 準備中...");
  try {
    const data = await fetchJson("/api/fleet-db/export-json");
    const text = JSON.stringify(data, null, 2);
    const fileName = `android-fleet-db-${new Date().toISOString().slice(0, 10)}.json`;
    if (window.showSaveFilePicker) {
      const handle = await window.showSaveFilePicker({
        suggestedName: fileName,
        types: [{
          description: "Android Fleet DB JSON",
          accept: { "application/json": [".json"] },
        }],
      });
      const writable = await handle.createWritable();
      await writable.write(text);
      await writable.close();
      logLine("DB保存 OK: " + handle.name);
    } else {
      const blob = new Blob([text], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(url);
      logLine("");
    }
  } catch (error) {
    if (error && error.name === "AbortError") {
      logLine("DB保存 キャンセル");
    } else {
      logLine("DB保存 NG: " + error.message);
    }
  } finally {
    setBusy(false);
  }
}

async function generateSupportDiagnostics(button = null) {
  const confirmed = window.confirm([
    "診断情報を生成します。",
    "",
    "含むもの:",
    "・現在版と更新状態",
    "・更新失敗時の安全なSHA情報と失敗段階",
    "・ADB 5037/5038の接続・未許可・オフライン件数",
    "・Windows USB問題コード、XiaoWei、Fleetの件数差",
    "・画面版とXiaoWei実反映の一致確認",
    "・匿名のサポート用PC ID（同じPCか判別するため）",
    "※ 不具合が出ている状態で押すと、切り分け精度が上がります。",
    "※ 生成時に接続状態を1回だけ照会します（30秒以内の再生成は照会結果を再利用）。",
    "",
    "含まないもの:",
    "・端末名、シリアル、電話番号、金額の明細",
    "・DB本体、ライセンスキー、認証情報",
    "",
    "安全な診断JSONを保存しますか？",
  ].join("\n"));
  if (!confirmed) return;

  let saveTarget;
  try {
    saveTarget = await prepareSupportDiagnosticsSaveTarget();
  } catch (error) {
    if (error && error.name === "AbortError") {
      logLine("診断情報 保存キャンセル");
      return;
    }
    saveTarget = { fileName: `AndroidFleet-診断情報-${localTimestampForFile()}.json`, handle: null };
  }

  setBusy(true, button, "診断中...");
  logLine("診断情報 生成中...");
  try {
    const report = await privateFetchJson("/api/support/diagnostics", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ clientAssets: supportDiagnosticsClientAssets() }),
    });
    await saveSupportDiagnosticsReport(report, saveTarget);
    logLine("診断情報 生成 OK");
    window.alert("診断情報を保存しました。\nまずこのJSONだけをサポートへ送ってください。追加資料が必要な場合だけ、こちらからご案内します。");
  } catch (error) {
    if (error && error.name === "AbortError") {
      logLine("診断情報 保存キャンセル");
    } else {
      const code = /^[A-Z][A-Z0-9_]{0,63}$/.test(String(error && error.code || ""))
        ? String(error.code)
        : "SUPPORT_DIAGNOSTICS_FAILED";
      logLine(`診断情報 生成 NG: ${code}`);
      window.alert(`診断情報を生成できませんでした。\n画面を再読み込みして、もう一度お試しください。\nコード: ${code}`);
    }
  } finally {
    setBusy(false);
  }
}

function supportDiagnosticsClientAssets() {
  const cssMarker = String(
    window.getComputedStyle(document.documentElement).getPropertyValue("--fleet-ui-build") || ""
  ).trim().replace(/^["']|["']$/g, "");
  return {
    jsBuild: FLEET_UI_JS_BUILD_ID,
    cssBuild: /^[A-Za-z0-9._-]{1,160}$/.test(cssMarker) ? cssMarker : "",
  };
}

async function prepareSupportDiagnosticsSaveTarget() {
  const fileName = `AndroidFleet-診断情報-${localTimestampForFile()}.json`;
  if (!window.showSaveFilePicker) return { fileName, handle: null };
  try {
    const handle = await window.showSaveFilePicker({
      suggestedName: fileName,
      types: [{
        description: "Android Fleet 診断JSON",
        accept: { "application/json": [".json"] },
      }],
    });
    return { fileName, handle };
  } catch (error) {
    if (error && error.name === "AbortError") throw error;
    return { fileName, handle: null };
  }
}

async function saveSupportDiagnosticsReport(report, saveTarget = {}) {
  const fileName = saveTarget.fileName || `AndroidFleet-診断情報-${localTimestampForFile()}.json`;
  const text = `${JSON.stringify(report, null, 2)}\n`;
  if (saveTarget.handle) {
    const writable = await saveTarget.handle.createWritable();
    await writable.write(text);
    await writable.close();
    return;
  }

  const blob = new Blob([text], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function bindScriptBuilderActions() {
  const deviceSelect = el("scriptDeviceSelect");
  if (!deviceSelect) return;
  setupScriptPackageSelect();
  el("scriptRefreshShotBtn").addEventListener("click", () => refreshScriptScreenshot());
  el("scriptCopyScreenTextBtn").addEventListener("click", copySelectedDeviceScreenText);
  el("scriptCopyDeviceClipboardBtn").addEventListener("click", copySelectedDeviceClipboardText);
  el("scriptAdbChromeTestBtn").addEventListener("click", runAdbChromeTest);
  el("scriptAutoRefreshInput").addEventListener("change", toggleScriptAutoRefresh);
  el("scriptPreviewImage").addEventListener("click", addTapStepFromPreview);
  el("scriptMinimalPresetBtn").addEventListener("click", setMinimalToastPreset);
  el("scriptDebugPresetBtn").addEventListener("click", setDebugScriptPreset);
  el("scriptChromePresetBtn").addEventListener("click", setChromeScriptPreset);
  el("scriptAddLaunchBtn").addEventListener("click", () => {
    const selected = selectedScriptPackageOption();
    addScriptStep({
      type: "launch",
      packageName: selected.packageName,
      appName: selected.appName || "",
      launchUrl: selected.launchUrl || "",
      waitMs: scriptWaitMs(),
    });
  });
  el("scriptAddWaitBtn").addEventListener("click", () => addScriptStep({
    type: "wait",
    waitMs: scriptWaitMs(),
  }));
  el("scriptAddTextBtn").addEventListener("click", () => {
    const text = el("scriptTextInput").value;
    if (!text) return logLine("");
    addScriptStep({ type: "text", text, waitMs: scriptWaitMs() });
  });
  el("scriptAddBackBtn").addEventListener("click", () => addScriptStep({ type: "back", waitMs: scriptWaitMs() }));
  el("scriptAddHomeBtn").addEventListener("click", () => addScriptStep({ type: "home", waitMs: scriptWaitMs() }));
  el("scriptClearBtn").addEventListener("click", clearScriptSteps);
  el("scriptStepList").addEventListener("click", handleScriptStepListClick);
  el("scriptCopyBtn").addEventListener("click", copyScriptOutput);
  el("scriptDownloadBtn").addEventListener("click", downloadScriptOutput);
  el("scriptRunXiaoweiBtn").addEventListener("click", runXiaoweiGeneratedScript);
  el("scriptInstallTestsBtn").addEventListener("click", installXiaoweiTestScripts);
  el("scriptFolderCheckBtn").addEventListener("click", checkXiaoweiScriptFolder);
  el("scriptLogTailBtn").addEventListener("click", checkXiaoweiLogTail);
  el("scriptLogMarkBtn").addEventListener("click", markXiaoweiLogBaseline);
  el("scriptLogDeltaBtn").addEventListener("click", checkXiaoweiLogDelta);
  el("scriptCopyAdminInstallBtn").addEventListener("click", copyAdminInstallCommand);
  el("scriptRepeatInput").addEventListener("input", renderScriptBuilder);
  el("scriptRepeatInput").addEventListener("change", renderScriptBuilder);
  renderScriptBuilder();
}

function setupScriptPackageSelect() {
  const select = el("scriptPackageSelect");
  if (!select) return;
  select.innerHTML = SCRIPT_PACKAGE_OPTIONS.map((option) =>
    `<option value="${esc(option.packageName)}">${esc(option.label)} / ${esc(option.packageName === "custom" ? "": option.packageName)}</option>`
  ).join("");
  select.value = "com.android.chrome";
  select.addEventListener("change", updateScriptPackageCustomVisibility);
  updateScriptPackageCustomVisibility();
}

function updateScriptPackageCustomVisibility() {
  const customInput = el("scriptPackageCustomInput");
  if (!customInput) return;
  customInput.classList.toggle("hidden", el("scriptPackageSelect").value !== "custom");
}

function selectedScriptPackageName() {
  return selectedScriptPackageOption().packageName;
}

function selectedScriptPackageOption() {
  const selected = el("scriptPackageSelect").value;
  if (selected === "custom") {
    const packageName = el("scriptPackageCustomInput").value.trim() || "com.android.chrome";
    return { packageName, appName: "", launchUrl: "" };
  }
  return SCRIPT_PACKAGE_OPTIONS.find((option) => option.packageName === selected) || SCRIPT_PACKAGE_OPTIONS[0];
}

function renderScriptBuilderDevices(rows) {
  const select = el("scriptDeviceSelect");
  if (!select) return;
  const current = select.value;
  const candidates = rows
    .filter((row) => row.serial)
    .slice()
    .sort((a, b) => managementNumber(a) - managementNumber(b));
  select.innerHTML = [
    `<option value="">端末を選択</option>`,
    ...candidates.map((row) => {
      const label = formatXiaoWeiDeviceOptionLabel(row);
      return `<option value="${esc(row.serial)}">${esc(label)}</option>`;
    }),
  ].join("");
  if (current && [...select.options].some((option) => option.value === current)) select.value = current;
}

function renderClipboardDevices(rows) {
  renderClipboardTargets(rows);
}

function renderClipboardTargets(rows) {
  const wrap = el("clipboardTargetGrid");
  if (!wrap) return;
  const candidates = clipboardTargetCandidates(rows);
  pruneClipboardTargets(candidates);
  if (!candidates.length) {
    wrap.innerHTML = `<div class="clipboard-empty compact">ADB接続中の送信先がありません。</div>`;
    return;
  }
  const disabled = state.busy ? "disabled" : "";
  wrap.innerHTML = candidates.map((row) => {
    const checked = state.clipboardTargetSerials.has(row.serial) ? "checked" : "";
    const label = formatXiaoWeiDeviceOptionLabel(row);
    return `
      <label class="clipboard-target-item" title="${esc(label)}">
        <input type="checkbox" value="${esc(row.serial)}" ${checked} ${disabled}>
        <span>${esc(label)}</span>
      </label>
    `;
  }).join("");
}

function clipboardTargetCandidates(rows = state.summary?.devices || []) {
  return (rows || [])
    .filter((row) => row.serial)
    .filter((row) => row.adbConnected !== false)
    .filter((row) => !el("clipboardActiveOnlyInput")?.checked || isClipboardTargetActive(row))
    .slice()
    .sort((a, b) => managementNumber(a) - managementNumber(b));
}

function isClipboardTargetActive(row) {
  if (!row || row.excluded) return false;
  const number = Number(row.laixiNumber || row.number || row.managementNumber || 0);
  if (Number.isFinite(number) && number >= 800) return false;
  const tags = Array.isArray(row.tags) ? row.tags : [];
  if (tags.some((tag) => /^STATE_WAITING$|^RESET_DONE$|^NO_CYCLE$|^GROUP_WAIT/i.test(String(tag)))) return false;
  if (row.group === "稼働中" || row.status === "ACTIVE" || row.isActive === true) return true;
  return tags.some((tag) => /^(DAY_\d+|CI_|V180_|V10_)/.test(String(tag)));
}

function pruneClipboardTargets(candidates = clipboardTargetCandidates()) {
  const allowed = new Set(candidates.map((row) => row.serial));
  const next = new Set([...state.clipboardTargetSerials].filter((serial) => allowed.has(serial)));
  const changed = next.size !== state.clipboardTargetSerials.size;
  state.clipboardTargetSerials = next;
  return changed;
}

function handleClipboardTargetChange(event) {
  const input = event.target.closest("#clipboardTargetGrid input[type='checkbox']");
  if (!input) return;
  if (state.busy) {
    input.checked = state.clipboardTargetSerials.has(input.value);
    logLine("処理中は送信先を変更できません");
    return;
  }
  if (input.checked) {
    state.clipboardTargetSerials.add(input.value);
  } else {
    state.clipboardTargetSerials.delete(input.value);
  }
}

function selectClipboardTargets(mode) {
  if (state.busy) {
    logLine("処理中は送信先を変更できません");
    return;
  }
  if (mode === "clear" || mode === "manual") {
    state.clipboardTargetSerials.clear();
  } else {
    const candidates = clipboardTargetCandidates();
    state.clipboardTargetSerials = new Set(
      candidates
        .filter((row) => mode !== "active" || isClipboardTargetActive(row))
        .map((row) => row.serial)
    );
  }
  renderClipboardTargets(state.summary?.devices || []);
}

function checkedClipboardTargetSerials() {
  const checked = [...document.querySelectorAll("#clipboardTargetGrid input[type='checkbox']:checked")]
    .map((input) => input.value)
    .filter(Boolean);
  if (checked.length) {
    for (const serial of checked) state.clipboardTargetSerials.add(serial);
    return checked;
  }
  return [...state.clipboardTargetSerials];
}

function liveAdbDeviceBySerial(serial) {
  const key = uiSerialKey(serial);
  if (!key) return null;
  return (state.adbDevices?.devices || []).find((device) => (
    uiSerialKey(device?.serial) === key
    && (device?.status === "device" || device?.connected === true)
  )) || null;
}

function apnTargetCandidates(rows = state.summary?.devices || []) {
  return (Array.isArray(rows) ? rows : [])
    .filter((row) => row && row.serial)
    .slice()
    .sort((left, right) => managementNumber(left) - managementNumber(right));
}

function apnTargetSearchText(row = {}) {
  return [
    row.laixiNumber,
    row.managementId,
    row.day ? `day${row.day}` : "",
    row.deviceName,
    row.deviceLabel,
    row.laixiName,
    row.serial,
    ...(Array.isArray(row.tags) ? row.tags : []),
  ].filter(Boolean).join(" ").toLowerCase();
}

function renderApnTargets(rows = state.summary?.devices || []) {
  const wrap = el("apnTargetGrid");
  if (!wrap) return;
  const candidates = apnTargetCandidates(rows);
  const candidateByKey = new Map(candidates.map((row) => [uiSerialKey(row.serial), String(row.serial)]));
  state.apnTargetSerials = new Set([...state.apnTargetSerials]
    .map((serial) => candidateByKey.get(uiSerialKey(serial)))
    .filter((serial) => serial && (state.apnSetup.running || liveAdbDeviceBySerial(serial))));
  const query = String(el("apnTargetSearchInput")?.value || "").trim().toLowerCase();
  const visible = candidates.filter((row) => !query || apnTargetSearchText(row).includes(query));
  if (!visible.length) {
    wrap.innerHTML = `<div class="clipboard-empty compact">${candidates.length ? "検索に一致する端末がありません。" : "端末DBに端末がありません。"}</div>`;
    syncApnSelectionWithTarget();
    return;
  }
  wrap.innerHTML = visible.map((row) => {
    const connected = Boolean(liveAdbDeviceBySerial(row.serial));
    const checked = state.apnTargetSerials.has(String(row.serial)) ? "checked" : "";
    const disabled = state.busy || state.apnSetup.running || !connected ? "disabled" : "";
    const day = Number(row.day || 0) ? `D${Number(row.day)}` : "D-";
    const status = isClipboardTargetActive(row) ? "稼働" : "非稼働";
    const adb = connected ? "ADB接続" : "ADB未接続";
    return `
      <label class="apn-target-item ${connected ? "connected" : "disconnected"}">
        <input type="checkbox" value="${esc(row.serial)}" data-adb-connected="${connected ? "true" : "false"}" ${checked} ${disabled}>
        <b>${esc(row.laixiNumber || "-")}</b>
        <span>${esc(day)}｜${esc(row.deviceLabel || row.deviceName || row.laixiName || row.serial)}</span>
        <small>${esc(status)}・${esc(adb)}</small>
      </label>
    `;
  }).join("");
  syncApnSelectionWithTarget();
}

function handleApnTargetChange(event) {
  const input = event.target.closest("#apnTargetGrid input[type='checkbox']");
  if (!input) return;
  if (state.busy || state.apnSetup.running) {
    input.checked = state.apnTargetSerials.has(input.value);
    return logLine("処理中はAPN対象を変更できません");
  }
  if (input.checked) state.apnTargetSerials.add(input.value);
  else state.apnTargetSerials.delete(input.value);
  syncApnSelectionWithTarget();
}

function selectApnTargets(mode) {
  if (state.busy || state.apnSetup.running) return logLine("処理中はAPN対象を変更できません");
  state.apnTargetSerials = mode === "connected"
    ? new Set(apnTargetCandidates().filter((row) => liveAdbDeviceBySerial(row.serial)).map((row) => row.serial))
    : new Set();
  renderApnTargets();
}

async function refreshApnTargets(button = null) {
  setBusy(true, button);
  try {
    const adbDevices = await fetchJson("/api/adb/devices?uptime=0");
    storeAdbDevices(adbDevices);
    renderApnTargets();
    renderDevices(state.summary?.devices || []);
    renderOperationGroupPicker();
    logLine(`APN対象再読込 OK: ADB接続 ${Number(adbDevices.connected || 0)}台`);
  } catch (error) {
    logLine(`APN対象再読込 NG: ${error.message}`);
  } finally {
    setBusy(false);
  }
}

function checkedApnTargetSerials() {
  const checked = [...document.querySelectorAll("#apnTargetGrid input[type='checkbox']:checked")]
    .map((input) => input.value)
    .filter(Boolean);
  if (checked.length) {
    for (const serial of checked) state.apnTargetSerials.add(serial);
  }
  return [...state.apnTargetSerials];
}

function selectedApnDevices() {
  const rows = state.summary?.devices || [];
  const bySerial = new Map(rows.map((row) => [uiSerialKey(row.serial), row]));
  return checkedApnTargetSerials()
    .map((serial) => bySerial.get(uiSerialKey(serial)) || { serial })
    .filter((row) => row?.serial);
}

function selectedApnDevice() {
  return selectedApnDevices()[0] || null;
}

function apnTargetKey(serials = checkedApnTargetSerials()) {
  return serials
    .map((serial) => String(serial || "").trim().toLowerCase())
    .filter(Boolean)
    .sort()
    .join("|");
}

function selectedClipboardDevices() {
  const rows = state.summary?.devices || [];
  const bySerial = new Map(rows.map((row) => [uiSerialKey(row.serial), row]));
  return checkedClipboardTargetSerials()
    .map((serial) => bySerial.get(uiSerialKey(serial)) || { serial })
    .filter((row) => row?.serial);
}

function focusApnSetup(triggerButton = null) {
  openWorkspaceToolDialog("apnSetup", triggerButton || el("apnSetupOpenBtn"));
  const section = el("apnSetupSection");
  if (!section) return;
  section.classList.add("apn-section-highlight");
  window.setTimeout(() => section.classList.remove("apn-section-highlight"), 1600);
  window.requestAnimationFrame(() => el("apnTargetSearchInput")?.focus({ preventScroll: true }));
}

function apnPresetById(profileId) {
  return APN_PRESETS.find((preset) => preset.id === String(profileId || "")) || null;
}

function apnPlanGroups(plan = state.apnSetup.plan) {
  const counts = new Map();
  for (const item of Array.isArray(plan) ? plan : []) {
    if (!apnPresetById(item.profileId)) continue;
    counts.set(item.profileId, (counts.get(item.profileId) || 0) + 1);
  }
  return [...counts.entries()].map(([profileId, count]) => ({
    profileId,
    count,
    preset: apnPresetById(profileId),
  }));
}

function apnPlanSummaryText(plan = state.apnSetup.plan) {
  return apnPlanGroups(plan)
    .map((group) => `${group.preset?.carrier || group.profileId} ${group.count}台`)
    .join(" / ");
}

function apnUnresolvedReasonLabel(reason) {
  if (reason === "multiple-sim") return "SIMが2枚以上";
  if (reason === "sim-not-found") return "SIMなし・未認識";
  if (reason === "ambiguous") return "候補が複数";
  return "事業者を特定できません";
}

function classifyApnSaveFailure(error) {
  const code = String(error?.code || "");
  const guardState = String(error?.data?.guard?.state || "");
  const releaseToken = String(error?.data?.guard?.releaseToken || "");
  const previousSaveIsUnknown = code === "APN_SAVE_STATE_UNKNOWN"
    || guardState === "pending"
    || guardState === "unknown";
  if (previousSaveIsUnknown) {
    return { saveState: "unknown", releaseToken };
  }

  const responseSaysMutationStarted = error?.data?.mutationStarted === true;
  const responseSaysDefinitelyNotStarted = error?.data?.mutationStarted === false;
  const definitelyNotStarted = responseSaysDefinitelyNotStarted
    || (!responseSaysMutationStarted && new Set([
      "ADB_TARGET_INVALID",
      "ADB_TARGET_NOT_CONNECTED",
      "ADB_TARGET_PORT_AMBIGUOUS",
      "ADB_TARGET_PORT_CHANGED",
      "ADB_TARGET_PORT_SCAN_FAILED",
      "APN_DRAFT_ALREADY_RUNNING",
      "APN_ACTIVE_SUBSCRIPTION_AMBIGUOUS",
      "APN_FIELDS_PROFILE_MISMATCH",
      "APN_PROFILE_INVALID",
      "APN_PROFILE_AMBIGUOUS",
      "APN_PROFILE_MISMATCH",
      "APN_SIM_ABSENT",
      "APN_SIM_INFO_UNAVAILABLE",
      "APN_SIM_NOT_READY",
      "APN_SUBSCRIPTION_CHANGED",
      "APN_SUBSCRIPTION_INVALID",
      "APN_SUBSCRIPTION_UNAVAILABLE",
      "APN_SAVE_GUARD_CORRUPT",
      "APN_SAVE_GUARD_FAILED",
      "APN_SAVE_REQUIRES_FRESH_EDITOR",
      "APN_TARGET_INVALID",
    ]).has(code));
  return {
    saveState: definitelyNotStarted ? "not-saved" : "unknown",
    releaseToken: definitelyNotStarted ? "" : releaseToken,
  };
}

function apnSaveReasonLabel(reason) {
  return {
    "apn-entry-already-visible": "同じAPNが一覧にあるため追加停止",
    "apn-list-not-found": "APN一覧画面を安全に確認できないため停止",
    "apn-list-session-changed": "APN一覧画面が切り替わったため停止",
    "apn-settings-not-foreground": "APN設定画面を前面で確認できないため停止",
    "device-locked": "端末が安全なロック中のため、解除せず停止",
    "apn-subscription-not-active": "有効なSIMを1件に特定できないため停止",
    "apn-add-restricted-or-unavailable": "APN追加が端末・回線側で許可されていないため手動確認",
    "add-button-not-found": "APN追加ボタンが表示されません（SIM状態・端末制限を確認）",
    "add-button-not-interactable": "APN追加ボタンを安全に操作できないため停止",
    "add-bounds-missing": "APN追加ボタンの位置を確認できないため停止",
    "apn-editor-not-found": "APN新規追加画面へ移動できないため停止",
    "overflow-bounds-missing": "APNメニューの位置を安全に確認できないため停止",
    "apn-editor-already-open": "既存APNの編集画面を検出したため停止",
    "apn-save-requires-fresh-editor": "新規追加画面ではないため保存停止",
    "apn-editor-session-changed": "APN編集画面が切り替わったため保存停止",
    "field-not-found": "APN入力欄を安全に特定できないため保存停止",
    "editor-not-interactable": "APN入力欄を安全に操作できないため保存停止",
    "editor-focus-not-verified": "APN入力欄のフォーカスを確認できないため保存停止",
    "field-not-cleared": "既存値を消去できたことを確認できないため保存停止",
    "confirm-button-not-interactable": "APN入力のOKボタンを安全に操作できないため保存停止",
    "typed-value-not-verified": "入力値を確認できないため保存停止",
    "choice-not-verified": "選択項目を確認できないため保存停止",
    "choice-not-interactable": "選択候補を安全に操作できないため保存停止",
    "save-menu-not-interactable": "保存メニューを安全に操作できません",
    "save-menu-bounds-missing": "保存メニューの位置を確認できません",
    "save-button-not-found": "保存ボタンを確認できません",
    "save-button-not-interactable": "保存ボタンを安全に操作できません",
    "save-bounds-missing": "保存ボタンの位置を確認できません",
    "save-result-unknown": "保存を押しましたが結果未確認・再実行禁止",
    "saved-entry-not-visible": "保存を押しましたが一覧確認待ち・再実行禁止",
    "ADB_TARGET_NOT_CONNECTED": "対象端末がADB接続されていないため処理開始せず",
    "ADB_TARGET_PORT_AMBIGUOUS": "同じ端末が複数ADBポートに見えるため処理開始せず",
    "ADB_TARGET_PORT_CHANGED": "SIM判定後にADBポートが変わったため処理開始せず",
    "ADB_TARGET_PORT_SCAN_FAILED": "ADBポートを安全に確定できないため処理開始せず",
    "APN_DRAFT_ALREADY_RUNNING": "同じ端末で別のAPN操作中のため処理開始せず",
    "APN_ACTIVE_SUBSCRIPTION_AMBIGUOUS": "有効なSIMが複数あるため処理開始せず",
    "APN_FIELDS_PROFILE_MISMATCH": "SIM判定とAPN設定内容が一致しないため処理開始せず",
    "APN_PROFILE_AMBIGUOUS": "APNプロファイルを一意に特定できないため処理開始せず",
    "APN_PROFILE_MISMATCH": "SIM判定後にAPNプロファイルが変わったため処理開始せず",
    "APN_SIM_ABSENT": "SIMが入っていないため対象外",
    "APN_SIM_INFO_UNAVAILABLE": "SIM情報を再確認できないため処理開始せず",
    "APN_SIM_NOT_READY": "SIMが利用可能な状態ではないため処理開始せず",
    "APN_SUBSCRIPTION_CHANGED": "SIM判定後に対象SIMが変わったため処理開始せず",
    "APN_SUBSCRIPTION_INVALID": "対象SIMの識別情報がないため処理開始せず",
    "APN_SUBSCRIPTION_UNAVAILABLE": "有効なSIMを特定できないため処理開始せず",
    "APN_SAVE_GUARD_CORRUPT": "重複防止記録を確認できないため処理開始せず",
    "APN_SAVE_GUARD_FAILED": "重複防止記録を更新できないため処理開始せず",
    "APN_RESET_SCOPE_UNAVAILABLE": "端末の初期化世代を確認できないため処理開始せず",
    "APN_SAVE_STATE_UNKNOWN": "前回の保存結果が未確認・端末確認まで再実行禁止",
  }[String(reason || "")] || String(reason || "端末画面を特定できません");
}

function renderApnBatchSummary() {
  const wrap = el("apnBatchSummary");
  if (!wrap) return;
  const groups = apnPlanGroups();
  const unresolved = Array.isArray(state.apnSetup.unresolved) ? state.apnSetup.unresolved : [];
  const results = Array.isArray(state.apnSetup.results) ? state.apnSetup.results : [];
  if (!groups.length && !unresolved.length && !results.length) {
    wrap.classList.add("hidden");
    wrap.innerHTML = "";
    return;
  }
  const resultOk = results.filter((item) => item.ok).length;
  const resultNg = results.filter((item) => !item.ok).length;
  const plannedCount = groups.reduce((sum, group) => sum + group.count, 0);
  const unknownResults = results.filter((item) => item.saveState === "unknown" && item.released !== true);
  const unresolvedTitle = unresolved.map((item) => {
    const row = findSummaryDeviceBySerial(item.serial) || { serial: item.serial };
    return `${formatXiaoWeiDeviceOptionLabel(row)}: ${apnUnresolvedReasonLabel(item.reason)}`;
  }).join("\n");
  wrap.classList.remove("hidden");
  wrap.innerHTML = [
    plannedCount
      ? `<span class="apn-batch-chip">保存対象 <strong>${esc(plannedCount)}台</strong></span>`
      : "",
    ...groups.map((group) => `
      <span class="apn-batch-chip">
        ${esc(group.preset?.carrier || group.profileId)}
        <strong>${esc(group.count)}台</strong>
      </span>
    `),
    unresolved.length
      ? `<span class="apn-batch-chip warning" title="${esc(unresolvedTitle)}">保存しない（要確認） <strong>${esc(unresolved.length)}台</strong></span>`
      : "",
    results.length
      ? `<span class="apn-batch-chip ${resultNg ? "warning" : "success"}">保存結果 <strong>OK ${esc(resultOk)} / 要確認 ${esc(resultNg)}</strong></span>`
      : "",
    ...unknownResults.map((item) => {
      const row = findSummaryDeviceBySerial(item.serial) || { serial: item.serial };
      if (!item.releaseToken) {
        return `<span class="apn-batch-chip warning">隔離中・再起動後に再確認：${esc(formatXiaoWeiDeviceOptionLabel(row))}</span>`;
      }
      return `
        <button
          class="apn-guard-release-btn"
          type="button"
          data-serial="${esc(item.serial)}"
          data-profile-id="${esc(item.profileId)}"
          title="端末のAPN一覧を目視確認した後だけ解除してください"
        >端末確認済み・隔離解除：${esc(formatXiaoWeiDeviceOptionLabel(row))}</button>
      `;
    }),
  ].join("");
}

async function handleApnBatchSummaryAction(event) {
  const button = event.target.closest(".apn-guard-release-btn");
  if (!button || state.apnSetup.running) return;
  const serial = String(button.dataset.serial || "");
  const profileId = String(button.dataset.profileId || "");
  const resultRow = state.apnSetup.results.find((item) => (
    String(item.serial || "") === serial
    && String(item.profileId || "") === profileId
    && item.saveState === "unknown"
    && item.released !== true
  ));
  if (!resultRow) return;
  const releaseToken = String(resultRow.releaseToken || "");
  if (!releaseToken) {
    return logLine("APN保存隔離: この画面には現在の保存試行の解除情報がないため解除しません");
  }
  const row = findSummaryDeviceBySerial(serial) || { serial };
  const confirmed = window.confirm(
    `${formatXiaoWeiDeviceOptionLabel(row)} の端末画面でAPN一覧を開き、`
    + "同じAPNが重複していないことを目視確認しましたか？\n\n"
    + "確認済みの場合だけ隔離を解除します。解除後も自動再実行はせず、SIM判定からやり直します。"
  );
  if (!confirmed) return;

  setBusy(true, button);
  try {
    await privateFetchJson("/api/adb/apn-save-guard/release", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        serial,
        profileId,
        releaseToken,
        acknowledgeDeviceChecked: true,
      }),
    });
    resultRow.released = true;
    resultRow.saveState = "released";
    resultRow.releaseToken = "";
    resultRow.reason = "端末確認済み・保存隔離解除済み";
    logLine(`APN保存隔離 解除: ${formatXiaoWeiDeviceOptionLabel(row)} / 次回はSIM判定から`);
    renderApnSelectionStatus("隔離を解除しました。再実行する場合はSIM判定からやり直してください");
  } catch (error) {
    logLine(`APN保存隔離 解除NG: ${formatXiaoWeiDeviceOptionLabel(row)} / ${error.message}`);
  } finally {
    setBusy(false);
    renderApnBatchSummary();
  }
}

function renderApnPalette() {
  const wrap = el("apnPalette");
  if (!wrap) return;
  const targetCount = checkedApnTargetSerials().length;
  const batchMode = targetCount > 1;
  wrap.innerHTML = APN_PRESETS.map((preset, index) => {
    const selected = state.apnSetup.selectedProfileId === preset.id;
    const candidate = state.apnSetup.candidateProfileIds.includes(preset.id);
    const fields = Object.entries(APN_FIELD_LABELS)
      .map(([key, label]) => ({ key, label, value: preset.fields?.[key] || "" }))
      .filter((field) => String(field.value).trim())
      .map((field) => `
        <div class="apn-field-row">
          <div class="apn-field-label">${esc(field.label)}</div>
          <div class="apn-field-value">${esc(field.value)}</div>
          <button class="apn-paste-btn" data-apn-index="${index}" data-apn-field="${esc(field.key)}" type="button">貼付</button>
        </div>
      `).join("");
    return `
      <article class="apn-card${selected ? " apn-selected" : ""}${candidate ? " apn-candidate" : ""}" data-apn-profile="${esc(preset.id)}">
        <div class="apn-card-head">
          <div>
            <div class="apn-card-title">${esc(preset.carrier)}</div>
            <div class="apn-card-sub">${esc(preset.profile || "")}</div>
          </div>
          <div class="apn-card-note">${esc(preset.note || "")}</div>
        </div>
        <button class="apn-select-btn${selected ? " selected" : ""}" data-apn-profile="${esc(preset.id)}" type="button"${batchMode ? " disabled" : ""}>${batchMode ? "複数端末は自動振り分け" : selected ? "選択中" : candidate ? "候補から選ぶ" : "このAPNを選ぶ"}</button>
        <div class="apn-fields">${fields}</div>
      </article>
    `;
  }).join("");
  const manualDetails = el("apnManualDetails");
  const needsManualChoice = targetCount === 1
    && state.apnSetup.candidateProfileIds.length > 0
    && state.apnSetup.plan.length === 0;
  if (manualDetails && needsManualChoice) manualDetails.open = true;
  renderApnSelectionStatus();
}

function setApnStepState(stepId, stateName, warning = false) {
  const step = el(stepId);
  if (!step) return;
  step.classList.remove("is-pending", "is-active", "is-ready", "is-done", "has-warning");
  step.classList.add(`is-${stateName}`);
  if (warning) step.classList.add("has-warning");
}

function renderApnSelectionStatus(message = "") {
  const status = el("apnSelectionStatus");
  const start = el("apnStartBtn");
  if (!status || !start) return;
  const detect = el("apnDetectBtn");
  const openSettings = el("apnOpenSettingsBtn");
  const targetSummary = el("apnTargetSummary");
  const saveSafetyNote = el("apnSaveSafetyNote");
  const preset = APN_PRESETS.find((item) => item.id === state.apnSetup.selectedProfileId);
  const serials = checkedApnTargetSerials();
  const targetCount = serials.length;
  const planCurrent = state.apnSetup.targetKey === apnTargetKey(serials);
  const plan = planCurrent && Array.isArray(state.apnSetup.plan) ? state.apnSetup.plan : [];
  const unresolvedCount = planCurrent && Array.isArray(state.apnSetup.unresolved)
    ? state.apnSetup.unresolved.length
    : 0;
  const results = planCurrent && Array.isArray(state.apnSetup.results) ? state.apnSetup.results : [];
  const alreadyRun = results.length > 0;
  const checkCompleted = planCurrent && (plan.length > 0 || unresolvedCount > 0 || alreadyRun);
  const resultNg = results.filter((item) => !item.ok).length;

  if (targetSummary) {
    targetSummary.textContent = targetCount
      ? `${targetCount}台を選択中`
      : "上の一覧から端末を選んでください";
  }
  if (message) {
    status.textContent = message;
  } else if (state.apnSetup.running) {
    status.textContent = "APNを順番に入力・保存しています";
  } else if (plan.length) {
    status.textContent = `自動判定: ${apnPlanSummaryText(plan)}${unresolvedCount ? ` / 要確認 ${unresolvedCount}台` : ""}`;
  } else if (preset && targetCount === 1) {
    const prefix = state.apnSetup.selectionSource === "detected" ? "自動候補" : "選択中";
    status.textContent = `${prefix}: ${preset.carrier} / 入力後に新規APNとして保存`;
  } else if (state.apnSetup.candidateProfileIds.length) {
    status.textContent = `候補 ${state.apnSetup.candidateProfileIds.length}件 / カードから選択してください`;
  } else if (targetCount) {
    status.textContent = `選択 ${targetCount}台 / SIM判定してください`;
  } else {
    status.textContent = "対象端末を選択してください";
  }

  setApnStepState("apnStepTargets", targetCount ? "done" : "active");
  setApnStepState(
    "apnStepCheck",
    !targetCount ? "pending" : checkCompleted ? "done" : "active",
    checkCompleted && unresolvedCount > 0,
  );
  setApnStepState(
    "apnStepSave",
    state.apnSetup.running
      ? "active"
      : alreadyRun
        ? "done"
        : plan.length
          ? "ready"
          : "pending",
    resultNg > 0,
  );

  if (detect) {
    detect.textContent = checkCompleted
      ? `SIMとAPNを再判定（${targetCount}台）`
      : targetCount
        ? `SIMを判定してAPNを確認（${targetCount}台）`
        : "SIMを判定してAPNを確認";
    detect.disabled = state.busy || state.apnSetup.running || !targetCount;
  }
  if (openSettings) openSettings.disabled = state.busy || state.apnSetup.running || targetCount !== 1;
  if (saveSafetyNote) {
    saveSafetyNote.textContent = state.apnSetup.running
      ? `保存中です。${plan.length}台を1台ずつ処理しています。`
      : alreadyRun
        ? `保存処理は完了しました。OK ${results.length - resultNg}台 / 要確認 ${resultNg}台`
        : plan.length
          ? `確実に判定できた${plan.length}台だけ保存します。${unresolvedCount ? `要確認${unresolvedCount}台には保存しません。` : "要確認端末はありません。"}`
          : checkCompleted
            ? "確実に判定できる端末がないため保存できません。"
            : "SIM判定後に保存できます。要確認端末には保存しません。";
  }

  if (!start.classList.contains("is-loading")) {
    start.textContent = alreadyRun
      ? "保存済み・再実行はSIM判定から"
      : plan.length > 1
        ? `確認したAPNを保存（${plan.length}台）`
        : plan.length === 1
          ? "確認したAPNを保存（1台）"
          : "確認したAPNを保存";
  }
  start.disabled = state.busy || state.apnSetup.running || alreadyRun || !plan.length || !planCurrent;
  for (const button of document.querySelectorAll(".apn-select-btn")) {
    const profileId = button.dataset.apnProfile || "";
    const selected = state.apnSetup.selectedProfileId === profileId;
    const candidate = state.apnSetup.candidateProfileIds.includes(profileId);
    button.disabled = state.busy || state.apnSetup.running || targetCount !== 1;
    button.textContent = targetCount > 1
      ? "複数端末は自動振り分け"
      : selected
        ? "選択中"
        : candidate
          ? "候補から選ぶ"
          : "このAPNを選ぶ";
  }
  for (const button of document.querySelectorAll(".apn-paste-btn")) {
    button.disabled = state.busy || state.apnSetup.running || targetCount !== 1;
  }
  renderApnBatchSummary();
}

function selectApnProfile(profileId, source = "manual") {
  const preset = APN_PRESETS.find((item) => item.id === String(profileId || ""));
  if (!preset) return false;
  const serials = checkedApnTargetSerials();
  if (serials.length !== 1) {
    renderApnSelectionStatus(serials.length
      ? "複数端末は「選択端末をSIM判定」で自動振り分けしてください"
      : "対象端末を1台選んでください");
    return false;
  }
  const row = selectedApnDevice();
  if (!row?.serial) return false;
  state.apnSetup.targetKey = apnTargetKey(serials);
  state.apnSetup.serial = String(row?.serial || "");
  state.apnSetup.selectedProfileId = preset.id;
  state.apnSetup.selectionSource = source;
  state.apnSetup.plan = [{
    serial: row.serial,
    profileId: preset.id,
    source,
  }];
  state.apnSetup.unresolved = [];
  state.apnSetup.results = [];
  if (!state.apnSetup.candidateProfileIds.includes(preset.id)) {
    state.apnSetup.candidateProfileIds = [preset.id];
  }
  renderApnPalette();
  document.querySelector(`.apn-card[data-apn-profile="${CSS.escape(preset.id)}"]`)
    ?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  return true;
}

function clearApnSelection(message = "") {
  const serials = checkedApnTargetSerials();
  state.apnSetup.targetKey = apnTargetKey(serials);
  state.apnSetup.serial = serials.length === 1 ? serials[0] : "";
  state.apnSetup.selectedProfileId = "";
  state.apnSetup.candidateProfileIds = [];
  state.apnSetup.selectionSource = "";
  state.apnSetup.plan = [];
  state.apnSetup.unresolved = [];
  state.apnSetup.results = [];
  renderApnPalette();
  if (message) renderApnSelectionStatus(message);
}

function syncApnSelectionWithTarget() {
  if (state.apnSetup.running) return;
  const serials = checkedApnTargetSerials();
  const targetKey = apnTargetKey(serials);
  const serial = serials.length === 1 ? serials[0] : "";
  if (state.apnSetup.targetKey === targetKey) {
    renderApnSelectionStatus();
    return;
  }
  state.apnSetup = {
    targetKey,
    serial,
    selectedProfileId: "",
    candidateProfileIds: [],
    selectionSource: "",
    plan: [],
    unresolved: [],
    results: [],
    running: false,
  };
  renderApnPalette();
  if (serials.length) renderApnSelectionStatus(`選択 ${serials.length}台 / SIM判定してください`);
}

async function suggestApnForSelectedDevices(button = null) {
  const serials = checkedApnTargetSerials();
  if (!serials.length) {
    clearApnSelection("対象端末を選んでください");
    return;
  }
  const rows = selectedApnDevices();
  if (!rows.length) return clearApnSelection("対象端末を確認できません");
  setBusy(true, button);
  try {
    const simInfo = await refreshDeviceSimInfo({ force: true, fresh: true });
    const devicesBySerial = new Map((simInfo.devices || [])
      .map((device) => [String(device.serial || "").toLowerCase(), device]));
    const plan = [];
    const unresolved = [];
    const candidateProfileIds = new Set();

    for (const row of rows) {
      const device = devicesBySerial.get(String(row.serial || "").toLowerCase());
      const subscriptions = Array.isArray(device?.subscriptions) ? device.subscriptions : [];
      const recommendations = subscriptions.map((subscription) => subscription.apnRecommendation || {});
      const candidates = [...new Set(recommendations.flatMap((recommendation) => (
        Array.isArray(recommendation.candidateProfileIds) ? recommendation.candidateProfileIds : []
      )))].filter((profileId) => apnPresetById(profileId));
      for (const profileId of candidates) candidateProfileIds.add(profileId);

      if (subscriptions.length !== 1) {
        unresolved.push({
          serial: row.serial,
          reason: subscriptions.length > 1 ? "multiple-sim" : "sim-not-found",
          candidateProfileIds: candidates,
        });
        continue;
      }
      const recommendation = recommendations[0] || {};
      const profileId = recommendation.status === "exact" ? String(recommendation.profileId || "") : "";
      if (!profileId || !apnPresetById(profileId)) {
        unresolved.push({
          serial: row.serial,
          reason: recommendation.status === "ambiguous" ? "ambiguous" : "not-determined",
          candidateProfileIds: candidates,
        });
        continue;
      }
      candidateProfileIds.add(profileId);
      plan.push({
        serial: row.serial,
        adbPort: Number(device?.adbPort || 0) || null,
        subscriptionId: normalizeNullableSubscriptionId(subscriptions[0]?.subscriptionId),
        profileId,
        source: "detected",
      });
    }

    if (apnTargetKey(serials) !== apnTargetKey()) {
      clearApnSelection("選択端末が変わりました。SIM判定をやり直してください");
      logLine("APN自動判定 中止: 判定中に選択端末が変わりました");
      return;
    }

    state.apnSetup.targetKey = apnTargetKey(serials);
    state.apnSetup.serial = serials.length === 1 ? serials[0] : "";
    state.apnSetup.candidateProfileIds = [...candidateProfileIds];
    state.apnSetup.selectedProfileId = rows.length === 1 && plan.length === 1 ? plan[0].profileId : "";
    state.apnSetup.selectionSource = plan.length ? "detected" : "";
    state.apnSetup.plan = plan;
    state.apnSetup.unresolved = unresolved;
    state.apnSetup.results = [];
    renderApnPalette();
    for (const item of unresolved) {
      const row = findSummaryDeviceBySerial(item.serial) || { serial: item.serial };
      logLine(`APN自動判定 要確認: ${formatXiaoWeiDeviceOptionLabel(row)} / ${apnUnresolvedReasonLabel(item.reason)}`);
    }

    if (plan.length) {
      const summary = apnPlanSummaryText(plan);
      renderApnSelectionStatus(`SIM判定 ${plan.length}/${rows.length}台: ${summary}${unresolved.length ? ` / 要確認 ${unresolved.length}台` : ""}`);
      logLine(`APN自動判定 OK: ${summary}${unresolved.length ? ` / 要確認 ${unresolved.length}台` : ""}`);
    } else {
      renderApnSelectionStatus(`SIM判定: ${rows.length}台すべて要確認 / 誤設定防止のため自動入力しません`);
      logLine(`APN自動判定 要確認: ${rows.length}台 / 確実なAPNなし`);
    }
  } catch (error) {
    clearApnSelection(`SIM判定NG: ${error.message}`);
    logLine(`APN候補 NG: ${error.message}`);
  } finally {
    setBusy(false);
  }
}

async function loadClipboardItems() {
  try {
    const result = await fetchJson("/api/clipboard-items");
    state.clipboardItems = Array.isArray(result.items) ? result.items : [];
    renderClipboardItems();
  } catch (error) {
    logLine("保管リスト読込 NG: " + error.message);
  }
}

function renderClipboardItems() {
  const wrap = el("clipboardItems");
  if (!wrap) return;
  const items = state.clipboardItems || [];
  el("clipboardMeta").textContent = `保管 ${items.length}件 / Chrome起動からURLジャンプまで実行`;
  if (!items.length) {
    wrap.innerHTML = `<div class="clipboard-empty">まだ保存されたURL/本文はありません。</div>`;
    return;
  }
  wrap.innerHTML = items.map((item, index) => {
    const source = clipboardItemSourceLabel(item);
    const upDisabled = index === 0 ? "disabled" : "";
    const downDisabled = index === items.length - 1 ? "disabled" : "";
    const colorButtonLabel = isHoneyClipboardItem(item) ? "黄色押す" : "ピンク押す";
    return `
      <article class="clipboard-item" data-id="${esc(item.id)}">
        <div class="clipboard-item-main">
          <strong>${esc(item.title || "無題")}</strong>
          <time>${esc(formatDateTime(item.updatedAt || item.createdAt))}</time>
        </div>
        <div class="clipboard-item-source">${esc(source || "手動保存")}</div>
        <div class="clipboard-item-text">${esc(item.text || "")}</div>
        ${item.note ? `<div class="clipboard-item-note">${esc(item.note)}</div>` : ""}
        <div class="clipboard-item-foot">
          <button class="clipboard-task-run-btn primary-action" data-id="${esc(item.id)}" type="button">URLへ飛ぶ</button>
          <button class="clipboard-chrome-prepare-btn primary-action" data-id="${esc(item.id)}" type="button">Chrome準備</button>
          <button class="clipboard-send-btn primary-action" data-id="${esc(item.id)}" type="button">UIへ送信</button>
          <button class="clipboard-enter-btn primary-action" data-id="${esc(item.id)}" type="button">Enter</button>
          <button class="clipboard-pink-button-btn primary-action" data-id="${esc(item.id)}" type="button">${colorButtonLabel}</button>
          <button class="clipboard-copy-btn" data-id="${esc(item.id)}" type="button">コピー</button>
          <button class="clipboard-number-step-btn" data-id="${esc(item.id)}" data-delta="1" type="button">数字進む</button>
          <button class="clipboard-number-step-btn" data-id="${esc(item.id)}" data-delta="-1" type="button">数字戻る</button>
          <button class="clipboard-move-up-btn" data-id="${esc(item.id)}" type="button" ${upDisabled}>↑</button>
          <button class="clipboard-move-down-btn" data-id="${esc(item.id)}" type="button" ${downDisabled}>↓</button>
          <button class="clipboard-edit-btn" data-id="${esc(item.id)}" type="button">編集</button>
          <button class="clipboard-delete-btn danger-action" data-id="${esc(item.id)}" type="button">削除</button>
        </div>
      </article>
    `;
  }).join("");
}

function findSummaryDeviceBySerial(serial) {
  const value = uiSerialKey(serial);
  if (!value) return null;
  return (state.summary?.devices || []).find((row) => uiSerialKey(row.serial) === value) || null;
}

function clipboardItemSourceLabel(item = {}) {
  const current = findSummaryDeviceBySerial(item.sourceSerial);
  if (current) {
    const currentLabel = formatXiaoWeiDeviceOptionLabel(current);
    const savedLabel = [item.sourceNumber, item.sourceLabel].filter(Boolean).join(" ");
    if (savedLabel && savedLabel !== currentLabel) return `取得元: ${currentLabel}（保存時: ${savedLabel}）`;
    return `取得元: ${currentLabel}`;
  }
  const saved = [item.sourceNumber, item.sourceLabel].filter(Boolean).join(" ");
  return saved ? `取得元: ${saved}` : "手動保存";
}

function selectedClipboardDevice() {
  const serial = checkedClipboardTargetSerials()[0] || "";
  return findSummaryDeviceBySerial(serial);
}

function clipboardDevicePayload(row = selectedClipboardDevice()) {
  if (!row) return {};
  return {
    sourceSerial: row.serial || "",
    sourceLabel: row.deviceLabel || row.deviceName || row.laixiName || row.modelGroup || "",
    sourceNumber: row.laixiNumber || "",
  };
}

async function saveClipboardForm(event) {
  event.preventDefault();
  const text = el("clipboardTextInput").value.trim();
  if (!text) return logLine("URL/本文が空です");
  const title = clipboardTitleValue();
  setBusy(true, el("clipboardSaveBtn"));
  try {
    const result = await fetchJson("/api/clipboard-items", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        id: state.clipboardEditingId,
        title,
        text,
        note: el("clipboardNoteInput").value.trim(),
        ...clipboardDevicePayload(),
      }),
    });
    state.clipboardItems = result.items || [];
    state.clipboardEditingId = "";
    renderClipboardItems();
    logLine(`保管リスト保存 OK: ${result.item?.title || ""}`);
  } catch (error) {
    logLine("保管リスト保存 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function clipboardTitleValue() {
  const preset = el("clipboardTitlePreset")?.value || "";
  if (preset === "custom") return el("clipboardTitleInput").value.trim();
  return preset || el("clipboardTitleInput").value.trim();
}

function setClipboardTitleValue(value) {
  const title = String(value || "").trim();
  const preset = el("clipboardTitlePreset");
  const input = el("clipboardTitleInput");
  const presetValues = ["QR招待", "ハチミツURL"];
  if (presetValues.includes(title)) {
    preset.value = title;
    input.value = "";
  } else {
    preset.value = "custom";
    input.value = title;
  }
  syncClipboardTitleInputVisibility();
}

function syncClipboardTitleInputVisibility() {
  const input = el("clipboardTitleInput");
  const isCustom = el("clipboardTitlePreset").value === "custom";
  input.classList.toggle("hidden", !isCustom);
  if (!isCustom) input.value = "";
}

async function captureSelectedDeviceClipboardToVault() {
  const row = selectedClipboardDevice();
  if (!row || !row.serial) return logLine("端末クリップ取得: 対象端末を選んでください");
  setBusy(true, el("clipboardCaptureBtn"));
  try {
    logLine(`端末クリップ取得 実行中: ${formatXiaoWeiDeviceOptionLabel(row)}`);
    const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "clipboard_text", timeout: 15000 }),
    });
    const payload = result.result || {};
    const text = String(payload.text || "").trim();
    if (!text) return logLine("端末クリップ取得: 取得できる文字がありません");
    const inferredTitle = inferClipboardTitleClient(text);
    el("clipboardTextInput").value = text;
    setClipboardTitleValue(inferredTitle);
    const saveResult = await fetchJson("/api/clipboard-items", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        title: inferredTitle,
        text,
        note: el("clipboardNoteInput").value.trim(),
        ...clipboardDevicePayload(row),
      }),
    });
    state.clipboardItems = saveResult.items || [];
    renderClipboardItems();
    logLine(`端末クリップ取得 OK: URL欄へ反映 / ${text.length}文字 / ${formatXiaoWeiDeviceOptionLabel(row)}`);
  } catch (error) {
    logLine("端末クリップ取得 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function handleClipboardItemAction(event) {
  const button = event.target.closest("button[data-id]");
  if (!button) return;
  if (state.clipboardUrlTaskRunning) {
    logLine("URLタスク: すでに実行中です");
    flashButtonResult(button, "実行中", "warn");
    return;
  }
  if (state.busy) {
    logLine("タスク操作: 別の処理中です。完了後にもう一度押してください");
    flashButtonResult(button, "処理中", "warn");
    return;
  }
  const item = (state.clipboardItems || []).find((entry) => entry.id === button.dataset.id);
  if (!item) return;
  if (button.classList.contains("clipboard-send-btn")) {
    await sendClipboardItemToDevice(item, button);
    return;
  }
  if (button.classList.contains("clipboard-chrome-prepare-btn")) {
    await prepareChromeSearchForSelectedClipboardTargets(item, button);
    return;
  }
  if (button.classList.contains("clipboard-enter-btn")) {
    await pressEnterForSelectedClipboardTargets(item, button);
    return;
  }
  if (button.classList.contains("clipboard-pink-button-btn")) {
    await tapPinkButtonForSelectedClipboardTargets(item, button);
    return;
  }
  if (button.classList.contains("clipboard-copy-btn")) {
    await copyClipboardItemText(item, button);
    return;
  }
  if (button.classList.contains("clipboard-task-run-btn")) {
    logLine(`URLタスク クリック: ${item.title || "無題"}`);
    await runClipboardUrlTask(item, button);
    return;
  }
  if (button.classList.contains("clipboard-number-step-btn")) {
    const delta = Number(button.dataset.delta || 0);
    await stepClipboardItemNumber(item, delta, button);
    return;
  }
  if (button.classList.contains("clipboard-move-up-btn")) {
    await moveClipboardItem(item.id, -1, button);
    return;
  }
  if (button.classList.contains("clipboard-move-down-btn")) {
    await moveClipboardItem(item.id, 1, button);
    return;
  }
  if (button.classList.contains("clipboard-edit-btn")) {
    state.clipboardEditingId = item.id;
    setClipboardTitleValue(item.title || "");
    el("clipboardTextInput").value = item.text || "";
    el("clipboardNoteInput").value = item.note || "";
    return;
  }
  if (button.classList.contains("clipboard-delete-btn")) {
    const ok = window.confirm("削除しますか？");
    if (!ok) return;
    await deleteClipboardItem(item.id, button);
  }
}

async function copyClipboardItemText(item, button = null) {
  const text = String(item.text || "");
  if (!text.trim()) {
    logLine(`コピー: 本文が空です / ${item.title || "無題"}`);
    return;
  }
  setBusy(true, button);
  try {
    await navigator.clipboard.writeText(text);
    logLine(`コピー OK: ${item.title || "無題"} / ${text.length}文字`);
  } catch (error) {
    logLine(`コピー NG: ${error.message}`);
  } finally {
    setBusy(false);
  }
}

function formatSteppedNumber(rawNumber, delta) {
  const value = Number(rawNumber);
  if (!Number.isFinite(value)) return null;
  const next = Math.max(0, value + delta);
  const nextText = String(next);
  return rawNumber.length > 1 && nextText.length <= rawNumber.length
    ? nextText.padStart(rawNumber.length, "0")
    : nextText;
}

function stepClipboardTextNumber(text, delta) {
  const value = String(text || "");
  const emailNumberPattern = /([A-Za-z0-9._%+-]*?)(\d+)(@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/;
  const emailMatch = value.match(emailNumberPattern);
  if (emailMatch) {
    const nextNumber = formatSteppedNumber(emailMatch[2], delta);
    if (nextNumber === null) return { ok: false };
    return {
      ok: true,
      text: value.replace(emailNumberPattern, `${emailMatch[1]}${nextNumber}${emailMatch[3]}`),
      before: emailMatch[2],
      after: nextNumber,
    };
  }

  const suffixMatch = value.match(/([\s\S]*?)(\d+)(\s*)$/);
  if (!suffixMatch) return { ok: false };
  const nextNumber = formatSteppedNumber(suffixMatch[2], delta);
  if (nextNumber === null) return { ok: false };
  return {
    ok: true,
    text: `${suffixMatch[1]}${nextNumber}${suffixMatch[3]}`,
    before: suffixMatch[2],
    after: nextNumber,
  };
}

async function stepClipboardItemNumber(item, delta, button = null) {
  if (!delta) return;
  const stepped = stepClipboardTextNumber(item.text || "", delta);
  if (!stepped.ok) {
    logLine(`数字${delta > 0 ? "進む" : "戻る"}: 対象の数字が見つかりません / ${item.title || "無題"}`);
    return;
  }
  const originalIds = (state.clipboardItems || []).map((entry) => entry.id);
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/clipboard-items", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        id: item.id,
        title: item.title || "",
        text: stepped.text,
        note: item.note || "",
        sourceSerial: item.sourceSerial || "",
        sourceLabel: item.sourceLabel || "",
        sourceNumber: item.sourceNumber || "",
      }),
    });
    state.clipboardItems = result.items || [];
    if (originalIds.length) {
      const reorderResult = await fetchJson("/api/clipboard-items/reorder", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ids: originalIds }),
      });
      state.clipboardItems = reorderResult.items || state.clipboardItems;
    }
    if (state.clipboardEditingId === item.id) {
      el("clipboardTextInput").value = stepped.text;
    }
    renderClipboardItems();
    logLine(`数字${delta > 0 ? "進む" : "戻る"} OK: ${stepped.before} -> ${stepped.after} / ${item.title || "無題"}`);
  } catch (error) {
    logLine(`数字${delta > 0 ? "進む" : "戻る"} NG: ${error.message}`);
    await loadClipboardItems();
  } finally {
    setBusy(false);
  }
}

async function runClipboardDeviceActionBatch(label, targets, payloadForRow, options = {}) {
  const button = options.button || null;
  const concurrency = Math.max(1, Number(options.concurrency || 8));
  if (!targets.length) {
    logLine(`${label}: 送信先端末を選んでください`);
    return { succeeded: 0, failed: 0 };
  }
  setBusy(true, button);
  let succeeded = 0;
  let failed = 0;
  let cursor = 0;
  async function worker() {
    while (cursor < targets.length) {
      const row = targets[cursor++];
      try {
        const payload = payloadForRow(row);
        const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(payload),
        });
        succeeded += 1;
        if (options.successLog) {
          logLine(options.successLog(row, result));
        } else {
          logLine(`${label} OK: ${formatXiaoWeiDeviceOptionLabel(row)}`);
        }
      } catch (error) {
        failed += 1;
        logLine(`${label} NG: ${formatXiaoWeiDeviceOptionLabel(row)} / ${error.message}`);
      }
    }
  }
  try {
    logLine(`${label} 開始: ${targets.length}台 / 同時${concurrency}台`);
    await Promise.all(Array.from({ length: Math.min(concurrency, targets.length) }, () => worker()));
    logLine(`${label} 完了: 成功 ${succeeded} / 失敗 ${failed}`);
    return { succeeded, failed };
  } finally {
    setBusy(false);
    flashButtonResult(button, failed ? "要確認" : "完了", failed ? "warn" : "ok");
  }
}

async function moveClipboardItem(id, direction, button = null) {
  const items = [...(state.clipboardItems || [])];
  const index = items.findIndex((entry) => entry.id === id);
  const nextIndex = index + direction;
  if (index < 0 || nextIndex < 0 || nextIndex >= items.length) return;
  [items[index], items[nextIndex]] = [items[nextIndex], items[index]];
  state.clipboardItems = items;
  renderClipboardItems();
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/clipboard-items/reorder", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ids: items.map((entry) => entry.id) }),
    });
    state.clipboardItems = result.items || items;
    renderClipboardItems();
    logLine("保管リスト並べ替え OK");
  } catch (error) {
    logLine("保管リスト並べ替え NG: " + error.message);
    await loadClipboardItems();
  } finally {
    setBusy(false);
  }
}

async function sendClipboardItemToDevice(item, button = null) {
  const targets = selectedClipboardTargetsForDeviceAction(item);
  if (!targets.length) return logLine("UIへ送信: 送信先端末を選んでください");
  if (!String(item.text || "").trim()) return logLine("UIへ送信: 送信する本文が空です");
  await runClipboardDeviceActionBatch(
    `UIへ送信 ${item.title || ""}`.trim(),
    targets,
    () => ({ action: "input_text", text: item.text, timeout: 15000 }),
    {
      button,
      concurrency: 8,
      successLog: (row, result) => `UIへ送信 OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${result.result?.length || String(item.text).length}文字`,
    }
  );
}

async function prepareChromeSearchForSelectedClipboardTargets(item, button = null) {
  const targets = selectedClipboardTargetsForDeviceAction(item);
  await runClipboardDeviceActionBatch(
    `Chrome準備 ${item?.title || ""}`.trim(),
    targets,
    () => ({
      action: "chrome_search_prepare",
      afterHomeWaitMs: 700,
      afterLaunchWaitMs: 1400,
      timeout: 12000,
    }),
    {
      button,
      concurrency: 8,
      successLog: (row, result) => `Chrome準備 OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${result.result?.addressFocus?.method || "focus"}`,
    }
  );
}

async function pressEnterForSelectedClipboardTargets(item, button = null) {
  const targets = selectedClipboardTargetsForDeviceAction(item);
  await runClipboardDeviceActionBatch(
    `Enter ${item?.title || ""}`.trim(),
    targets,
    () => ({ action: "press_enter", timeout: 5000 }),
    {
      button,
      concurrency: 12,
      successLog: (row) => `Enter OK: ${formatXiaoWeiDeviceOptionLabel(row)}`,
    }
  );
}

async function tapPinkButtonForSelectedClipboardTargets(item, button = null) {
  const targets = selectedClipboardTargetsForDeviceAction(item);
  const honey = isHoneyClipboardItem(item);
  const label = honey ? "黄色押す" : "ピンク押す";
  await runClipboardDeviceActionBatch(
    `${label} ${item?.title || ""}`.trim(),
    targets,
    () => ({
      action: "tap_landing_button",
      mode: "image",
      fallbackCoordinate: true,
      timeout: 15000,
    }),
    {
      button,
      concurrency: 8,
      successLog: (row, result) => {
        const tap = result.result?.tap || {};
        const method = tap.method || tap.imageTap?.method || "tap";
        const foreground = tap.foreground?.packageName || tap.tap?.foreground?.packageName || "";
        return `${label} OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${method}${foreground ? ` / ${foreground}` : ""}`;
      },
    }
  );
}

function isHoneyClipboardItem(item = {}) {
  const value = `${item.title || ""} ${item.note || ""} ${item.text || ""}`;
  return /ハチミツ|はちみつ|蜂蜜|サッカー|soccer|ranking|challenge/i.test(value);
}

async function runClipboardUrlTask(item, button = null) {
  if (state.clipboardUrlTaskRunning) {
    logLine("URLタスク: すでに実行中です");
    return;
  }
  const targetPlan = clipboardUrlTargetPlan(item);
  const targets = targetPlan.targets;
  const selectedCount = targetPlan.selectedCount;
  logLine(`URLタスク 選択 ${selectedCount}件 / 送信 ${targets.length}件`);
  if (selectedCount !== targets.length) {
    logClipboardTargetFilterReasons(item);
  }
  const text = String(item.text || "").trim();
  if (!text) return logLine("URLタスク: URL/本文が空です");
  const action = preferredUrlAction(item, text);
  const packageName = preferredUrlPackageName(item, text);
  const landingButtonMode = preferredLandingButtonMode(item, text);
  const inviteTaskKind = preferredInviteTaskKind(item, text);
  const onePassInviteTask = action === "chrome_url_task" && ["qr", "soccer"].includes(inviteTaskKind);
  const startedAt = Date.now();
  const failures = targetPlan.failures.slice();
  const excluded = targetPlan.excluded.slice();
  if (!targets.length) {
    if (!selectedCount) return logLine("URLタスク: 送信先端末を選んでください");
    logLine(`URLタスク 完了: 実行対象なし / 事前NG ${failures.length} / 対象外 ${excluded.length}`);
    showClipboardUrlTaskResultDialog({
      title: item.title || "URLタスク",
      selectedCount,
      succeeded: 0,
      failures,
      excluded,
      startedAt,
      finishedAt: Date.now(),
      onePassInviteTask,
    });
    return;
  }
  state.clipboardUrlTaskRunning = true;
  setBusy(true, button);
  let succeeded = 0;
  let fatalError = null;
  try {
    logLine(`URLタスク 開始: ${targets.length}台 / ${item.title || ""}`);
    logLine(`URLタスク 方法: ${action}${packageName ? " / " + packageName : ""} / ${inviteTaskKind}${onePassInviteTask ? " / 1巡のみ" : ""}`);
    for (const row of targets) {
      try {
        const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            action,
            url: text,
            packageName,
            lockPortrait: true,
            forceStopPackage: true,
            landingButtonMode,
            inviteTaskKind,
            skipInviteVerification: onePassInviteTask,
            retryOnUnverified: !onePassInviteTask,
            fastAfterTap: onePassInviteTask,
            timeout: 25000,
          }),
        });
        const resultFailure = clipboardUrlTaskResponseFailure(row, result, { onePassInviteTask, inviteTaskKind });
        if (resultFailure) {
          failures.push(resultFailure);
          logLine(`URLタスク NG: ${resultFailure.label} / ${resultFailure.reason} / 予想: ${resultFailure.prediction}`);
          continue;
        }
        succeeded += 1;
        const foreground = result.result?.foreground?.component || result.result?.foreground?.packageName || "";
        logLine(`URLタスク OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${action}${packageName ? " / " + packageName : ""}${foreground ? " / " + foreground : ""}`);
      } catch (error) {
        const failure = clipboardUrlTaskErrorFailure(row, error);
        failures.push(failure);
        logLine(`URLタスク NG: ${failure.label} / ${failure.reason} / 予想: ${failure.prediction}`);
      }
    }
  } catch (error) {
    fatalError = error;
    failures.push(clipboardUrlTaskErrorFailure(null, error, "タスク全体"));
    logLine(`URLタスク 全体NG: ${error.message}`);
  } finally {
    const failed = failures.length;
    logLine(onePassInviteTask
      ? `URLタスク 1巡完了: 成功 ${succeeded} / 失敗 ${failed} / 対象外 ${excluded.length} / 自動確認・再送なし`
      : `URLタスク 完了: 成功 ${succeeded} / 失敗 ${failed} / 対象外 ${excluded.length}`);
    state.clipboardUrlTaskRunning = false;
    setBusy(false);
    flashButtonResult(button, failed ? "要確認" : "完了", failed ? "warn" : "ok");
    showClipboardUrlTaskResultDialog({
      title: item.title || "URLタスク",
      selectedCount,
      succeeded,
      failures,
      excluded,
      startedAt,
      finishedAt: Date.now(),
      onePassInviteTask,
      fatalError: fatalError?.message || "",
    });
  }
}

function clipboardUrlTaskDeviceInfo(row = null, fallbackSerial = "") {
  const serial = String(row?.serial || fallbackSerial || "");
  return {
    label: row ? formatXiaoWeiDeviceOptionLabel(row) : fallbackSerial || "タスク全体",
    serial,
  };
}

function clipboardUrlTaskFailure(row, reason, prediction, detail = "", fallbackSerial = "") {
  return {
    ...clipboardUrlTaskDeviceInfo(row, fallbackSerial),
    reason: String(reason || "原因不明のエラー"),
    prediction: String(prediction || "ADB接続または端末側の一時的な不調の可能性があります"),
    detail: String(detail || "").trim().slice(0, 600),
  };
}

function clipboardUrlTaskResponseFailure(row, response, options = {}) {
  if (!options.onePassInviteTask) return null;
  const tap = response?.result?.landingFallbackTap;
  const buttonLabel = options.inviteTaskKind === "qr" ? "ピンクの招待ボタン" : "黄色の招待ボタン";
  if (!tap) {
    return clipboardUrlTaskFailure(
      row,
      `${buttonLabel}の押下結果を取得できませんでした`,
      "Fleetの画面とサーバーの版違い、または端末応答の途中切断が考えられます",
      "landingFallbackTap missing"
    );
  }
  const tapReason = String(tap.reason || tap.error || tap.imageTap?.reason || "");
  if (tap.ok === false || tapReason === "yellow-not-detected") {
    return clipboardUrlTaskFailure(
      row,
      `${buttonLabel}を検出・押下できませんでした`,
      "Chromeの読み込み遅延、初回確認画面、URLページ変更、またはボタンの色・位置変更が考えられます",
      tapReason || "button tap failed"
    );
  }
  return null;
}

function clipboardUrlTaskErrorFailure(row, error, fallbackLabel = "") {
  const detail = String(error?.message || error || "原因不明").trim();
  const value = detail.toLowerCase();
  let reason = "端末処理でエラーが発生しました";
  let prediction = "ADBの一時切断、端末の高負荷、またはChromeの読み込み不調が考えられます";
  if (/unauthorized|not authorized|authorization/.test(value)) {
    reason = "ADB接続が許可待ちになりました";
    prediction = "スマホ画面のUSBデバッグ許可が未承認、または承認情報が失効した可能性があります";
  } else if (/\boffline\b/.test(value)) {
    reason = "処理中にADBがオフラインになりました";
    prediction = "USBケーブル、ハブ、端末端子の瞬断、またはADBポートの不調が考えられます";
  } else if (/device[^\n]*(not found|missing)|no devices|connected device not found|unknown serial|not connected/.test(value)) {
    reason = "処理中に端末のADB接続が切れました";
    prediction = "USBケーブル、ハブ、端末端子、USBデバッグ接続を確認してください";
  } else if (/timed out|timeout|etimedout|\b504\b/.test(value)) {
    reason = "端末が制限時間内に応答しませんでした";
    prediction = "端末の高負荷、ADB停止、Chromeの読み込み遅延、USB通信の不安定化が考えられます";
  } else if (/adb_not_available|adb[^\n]*(not found|enoent)|spawn[^\n]*enoent/.test(value)) {
    reason = "ADBを起動できませんでした";
    prediction = "ADB実行ファイル、Fleetの起動場所、またはADBサーバーの状態を確認してください";
  } else if (/chrome|activity[^\n]*(not found|unable)|unable to resolve intent/.test(value)) {
    reason = "Chromeまたは招待URLを開けませんでした";
    prediction = "Chrome未導入、初回起動画面、無効化状態、またはURL形式の問題が考えられます";
  } else if (/screencap|screenshot|png|decode|image/.test(value)) {
    reason = "招待ボタンを探す画面画像を取得できませんでした";
    prediction = "端末画面が消灯中、ADB画面取得の失敗、または端末応答の遅延が考えられます";
  } else if (/failed to fetch|networkerror|econnrefused|socket|unexpected[^\n]*json/.test(value)) {
    reason = "Fleetサーバーとの通信に失敗しました";
    prediction = "Fleetサーバーの再起動、ブラウザとサーバーの接続、またはPC負荷を確認してください";
  }
  const failure = clipboardUrlTaskFailure(row, reason, prediction, detail);
  if (!row && fallbackLabel) failure.label = fallbackLabel;
  return failure;
}

function clipboardUrlTaskResultText(result = {}) {
  const lines = [
    `URLタスク結果: ${result.title || "URLタスク"}`,
    `選択 ${Number(result.selectedCount || 0)}台 / 成功 ${Number(result.succeeded || 0)}台 / 失敗 ${(result.failures || []).length}台 / 対象外 ${(result.excluded || []).length}台`,
  ];
  if (result.onePassInviteTask) lines.push("成功の意味: URL表示と招待ボタン押下まで完了。招待結果画面の再確認は未実施。");
  for (const failure of result.failures || []) {
    lines.push(`失敗: ${failure.label}${failure.serial ? ` [${failure.serial}]` : ""}`);
    lines.push(`理由: ${failure.reason}`);
    lines.push(`予想: ${failure.prediction}`);
    if (failure.detail) lines.push(`詳細: ${failure.detail}`);
  }
  for (const row of result.excluded || []) {
    lines.push(`対象外: ${row.label}${row.serial ? ` [${row.serial}]` : ""} / ${row.reason}`);
  }
  return lines.join("\n");
}

function showClipboardUrlTaskResultDialog(result = {}) {
  document.querySelector(".url-task-result-backdrop")?.remove();
  const failures = Array.isArray(result.failures) ? result.failures : [];
  const excluded = Array.isArray(result.excluded) ? result.excluded : [];
  const succeeded = Number(result.succeeded || 0);
  const selectedCount = Number(result.selectedCount || 0);
  const durationSeconds = Math.max(0, Math.round((Number(result.finishedAt || Date.now()) - Number(result.startedAt || Date.now())) / 1000));
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop url-task-result-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog url-task-result-dialog ${failures.length ? "has-failures" : "all-success"}" role="alertdialog" aria-modal="true" aria-labelledby="urlTaskResultTitle">
      <div class="adb-drop-dialog-head url-task-result-head">
        <div>
          <h3 id="urlTaskResultTitle">URLタスク完了</h3>
          <p>${esc(result.title || "URLタスク")} / 選択 ${selectedCount}台 / ${durationSeconds}秒</p>
        </div>
        <button class="adb-drop-close url-task-result-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="url-task-result-body">
        <div class="url-task-result-counts">
          <div class="success"><span>成功</span><strong>${succeeded}</strong><small>台</small></div>
          <div class="failure"><span>失敗</span><strong>${failures.length}</strong><small>台</small></div>
          <div class="excluded"><span>対象外</span><strong>${excluded.length}</strong><small>台</small></div>
        </div>
        <div class="url-task-result-definition">
          ${result.onePassInviteTask
            ? "成功は、URL表示と招待ボタン押下まで完了した台数です。招待結果画面の再確認はしていません。"
            : "成功は、端末アクションがエラーなく完了した台数です。"}
        </div>
        ${failures.length ? `
          <section class="url-task-result-section failure-list">
            <h4>失敗した端末と予想原因</h4>
            <div class="url-task-result-failure-list">
              ${failures.map((failure) => `
                <article class="url-task-result-failure-row">
                  <div class="url-task-result-device">
                    <strong>${esc(failure.label || failure.serial || "不明な端末")}</strong>
                    ${failure.serial ? `<code>${esc(failure.serial)}</code>` : ""}
                  </div>
                  <div class="url-task-result-reason"><span>失敗理由</span><b>${esc(failure.reason || "原因不明")}</b></div>
                  <div class="url-task-result-prediction"><span>予想原因</span><p>${esc(failure.prediction || "確認できませんでした")}</p></div>
                  ${failure.detail ? `<details><summary>エラー詳細</summary><code>${esc(failure.detail)}</code></details>` : ""}
                </article>
              `).join("")}
            </div>
          </section>
        ` : `<div class="url-task-result-all-clear"><strong>処理エラーはありません</strong><span>${succeeded ? "選択した実行対象を一巡しました。" : "実行対象はありませんでした。対象外の理由を確認してください。"}</span></div>`}
        ${excluded.length ? `
          <section class="url-task-result-section excluded-list">
            <h4>対象外 ${excluded.length}台</h4>
            <div class="url-task-result-excluded-list">
              ${excluded.map((row) => `<span><b>${esc(row.label || row.serial || "不明な端末")}</b> / ${esc(row.reason || "対象外")}</span>`).join("")}
            </div>
          </section>
        ` : ""}
      </div>
      <div class="adb-drop-actions url-task-result-actions">
        <button class="section-head-action url-task-result-copy" type="button">結果をコピー</button>
        <button class="section-head-action url-task-result-close" type="button">閉じる</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".url-task-result-close").forEach((closeButton) => {
    closeButton.addEventListener("click", () => overlay.remove());
  });
  overlay.querySelector(".url-task-result-copy")?.addEventListener("click", async (event) => {
    const copyButton = event.currentTarget;
    const text = clipboardUrlTaskResultText(result);
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const input = document.createElement("textarea");
      input.value = text;
      document.body.appendChild(input);
      input.select();
      document.execCommand("copy");
      input.remove();
    }
    flashButtonResult(copyButton, "コピー済み", "ok");
  });
  overlay.querySelector(".url-task-result-close")?.focus();
}

function logClipboardTargetFilterReasons(item = null) {
  const plan = clipboardUrlTargetPlan(item);
  if (!plan.selectedCount) {
    logLine("URLタスク: チェックされた端末がありません");
    return;
  }
  for (const failure of plan.failures.slice(0, 12)) {
    logLine(`URLタスク 事前NG: ${failure.label} / ${failure.reason} / 予想: ${failure.prediction}`);
  }
  for (const row of plan.excluded.slice(0, 12)) {
    logLine(`URLタスク 対象外: ${row.label} / ${row.reason}`);
  }
}

function preferredUrlPackageName(item, text) {
  const value = `${item?.title || ""} ${item?.note || ""} ${text || ""}`.toLowerCase();
  if (isBrowserUrlTask(item, text)) {
    return "com.android.chrome";
  }
  if (/tiktok|tiktoklite|tik tok|vt\.tiktok|www\.tiktok|m\.tiktok|lite/.test(value)) {
    if (/lite\.tiktok\.com|lite\.tt\./.test(value)) return "com.ss.android.ugc.tiktok.lite";
    return "com.zhiliaoapp.musically.go";
  }
  if (/line\.me|lin\.ee|line/.test(value)) {
    return "jp.naver.line.android";
  }
  return "";
}

function preferredUrlAction(item, text) {
  if (isBrowserUrlTask(item, text)) {
    return "chrome_url_task";
  }
  return "launch_url";
}

function preferredLandingButtonMode(item, text) {
  const value = `${item?.title || ""} ${item?.note || ""} ${text || ""}`.toLowerCase();
  return /qr|qr招待|招待|invite/.test(value) ? "optional" : "required";
}

function preferredInviteTaskKind(item, text) {
  const value = `${item?.title || ""} ${item?.note || ""} ${text || ""}`.toLowerCase();
  if (/qr|qr招待/.test(value)) return "qr";
  if (/ハチミツ|はちみつ|サッカー|soccer|ranking|challenge/.test(value)) return "soccer";
  return /invite|招待/.test(value) ? "qr" : "generic";
}

function isBrowserUrlTask(item, text) {
  const value = `${item?.title || ""} ${item?.note || ""} ${text || ""}`.toLowerCase();
  return /^https?:\/\//i.test(String(text || "").trim()) || /qr招待|招待|invite/.test(value);
}

function selectedClipboardUrlTargets(item = null) {
  return clipboardUrlTargetPlan(item).targets;
}

function clipboardUrlTargetPlan(item = null) {
  const rows = state.summary?.devices || [];
  const serials = checkedClipboardTargetSerials();
  const serialSet = new Set(serials);
  const sourceSerial = String(item?.sourceSerial || "");
  const activeOnly = Boolean(el("clipboardActiveOnlyInput")?.checked);
  const excludeSource = Boolean(el("clipboardExcludeSourceInput")?.checked && sourceSerial);
  const seen = new Set();
  const targets = [];
  const failures = [];
  const excluded = [];
  for (const row of rows) {
    if (!row.serial || !serialSet.has(row.serial)) continue;
    seen.add(row.serial);
    const info = clipboardUrlTaskDeviceInfo(row);
    if (row.adbConnected === false) {
      failures.push(clipboardUrlTaskFailure(
        row,
        "開始時点でADB未接続でした",
        "USBケーブル、ハブ、端末端子、USBデバッグ許可、ADBポートの状態を確認してください",
        row.adbStatus || row.status || "adbConnected=false"
      ));
      continue;
    }
    if (activeOnly && !isClipboardTargetActive(row)) {
      excluded.push({ ...info, reason: "非稼働端末フィルター" });
      continue;
    }
    if (excludeSource && row.serial === sourceSerial) {
      excluded.push({ ...info, reason: "取得元へ送らない設定" });
      continue;
    }
    targets.push(row);
  }
  for (const serial of serials) {
    if (seen.has(serial)) continue;
    failures.push(clipboardUrlTaskFailure(
      null,
      "選択端末が端末DBに見つかりませんでした",
      "端末DB更新後に画面の選択状態が古くなっている可能性があります。画面を更新して再選択してください",
      "selected serial missing from current summary",
      serial
    ));
  }
  return { selectedCount: serials.length, targets, failures, excluded };
}

function selectedClipboardTargetsForDeviceAction(item = null, options = {}) {
  const rows = state.summary?.devices || [];
  const serialSet = new Set(checkedClipboardTargetSerials());
  const sourceSerial = String(item?.sourceSerial || "");
  return rows
    .filter((row) => row.serial && serialSet.has(row.serial))
    .filter((row) => options.ignoreSummaryAdbState === true || row.adbConnected !== false)
    .filter((row) => !el("clipboardActiveOnlyInput")?.checked || isClipboardTargetActive(row))
    .filter((row) => !item || !el("clipboardExcludeSourceInput")?.checked || !sourceSerial || row.serial !== sourceSerial);
}

function rootPseudoResetLiveTargetFromRow(row = {}) {
  const serial = String(row.serial || "");
  const liveRows = Array.isArray(state.adbDevices?.devices) ? state.adbDevices.devices : [];
  const live = liveRows.find((item) => String(item?.serial || "") === serial);
  if (!live || String(live.status || "") !== "device") {
    return { ok: false, error: "ライブADB一覧でdevice状態を確認できません。ADB一覧を再読込してからやり直してください。" };
  }
  const adbPort = Number(live.adbPort);
  if (!Number.isInteger(adbPort) || adbPort <= 0 || adbPort > 65535) {
    return { ok: false, error: "ライブADBポートを確認できません。既定ポートへは自動フォールバックしません。" };
  }
  return {
    ok: true,
    target: {
      serial,
      adbPort,
      label: formatXiaoWeiDeviceOptionLabel(row),
    },
  };
}

function setRootPseudoResetTriggerBusy(button, busy) {
  if (!button) return;
  if (busy) {
    button.dataset.rootPseudoResetOriginalText = button.dataset.rootPseudoResetOriginalText || button.textContent;
    button.textContent = "事前確認中...";
    button.disabled = true;
    button.classList.add("is-loading");
    return;
  }
  button.textContent = button.dataset.rootPseudoResetOriginalText || "選択アプリを初期化";
  delete button.dataset.rootPseudoResetOriginalText;
  button.classList.remove("is-loading");
  button.disabled = Boolean(state.busy);
}

async function openRootPseudoResetDialog(button = null) {
  const reset = state.rootPseudoReset;
  if (reset.previewBusy || reset.executeBusy || reset.phase === "executing") {
    logLine("選択アプリ初期化: すでに確認または実行中です");
    return;
  }
  const selectedRows = selectedClipboardTargetsForDeviceAction(null, { ignoreSummaryAdbState: true });
  if (selectedRows.length !== 1) {
    const message = selectedRows.length
      ? `選択アプリ初期化 NG: 対象が${selectedRows.length}台あります。1台だけ選択してください。`
      : "選択アプリ初期化 NG: 対象端末を1台選択してください。";
    logLine(message);
    window.alert(message);
    return;
  }

  const liveTarget = rootPseudoResetLiveTargetFromRow(selectedRows[0]);
  if (!liveTarget.ok) {
    const message = `選択アプリ初期化 NG: ${liveTarget.error}`;
    logLine(message);
    window.alert(message);
    return;
  }
  const target = liveTarget.target;
  const requestId = ++reset.requestId;
  reset.phase = "loading";
  reset.previewBusy = true;
  reset.executeBusy = false;
  reset.preview = null;
  reset.target = target;
  reset.triggerButton = button;
  showRootPseudoResetLoading(target);
  setRootPseudoResetTriggerBusy(button, true);
  logLine(`選択アプリ初期化 事前確認中: ${target.label}`);

  try {
    const result = await requestRootPseudoResetPreview(target);
    if (requestId !== reset.requestId || el("rootPseudoResetModal").classList.contains("hidden")) return;
    reset.preview = result;
    renderRootPseudoResetPreview(result);
    const blockers = Array.isArray(result.preflight?.blockers) ? result.preflight.blockers.length : 0;
    const installed = Array.isArray(result.packages) ? result.packages.filter((item) => item?.installed).length : 0;
    logLine(`選択アプリ初期化 事前確認 ${result.ready ? "OK" : "要確認"}: ${target.label} / 対象アプリ ${installed}件 / ブロッカー ${blockers}件`);
  } catch (error) {
    if (requestId !== reset.requestId || el("rootPseudoResetModal").classList.contains("hidden")) return;
    reset.phase = "preview-error";
    renderRootPseudoResetPreviewError(error.message);
    logLine("選択アプリ初期化 事前確認 NG: " + error.message);
  } finally {
    reset.previewBusy = false;
    setRootPseudoResetTriggerBusy(button, false);
    if (requestId === reset.requestId) updateRootPseudoResetExecuteState();
  }
}

function showRootPseudoResetLoading(target) {
  const modal = el("rootPseudoResetModal");
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  el("rootPseudoResetSummary").textContent = `完全初期化ではありません。${target.label || target.serial}の選択アプリデータだけを消去します。`;
  el("rootPseudoResetLoading").classList.remove("hidden");
  el("rootPseudoResetPreviewError").classList.add("hidden");
  el("rootPseudoResetPreviewError").textContent = "";
  el("rootPseudoResetPreview").classList.add("hidden");
  el("rootPseudoResetExecutionResult").className = "root-pseudo-reset-result hidden";
  el("rootPseudoResetExecutionResult").innerHTML = "";
  el("rootPseudoResetConfirmationInput").value = "";
  el("rootPseudoResetConfirmationInput").disabled = true;
  el("rootPseudoResetConfirmationText").textContent = "-";
  el("rootPseudoResetConfirmationHint").textContent = "事前確認が完了すると入力できます。";
  el("rootPseudoResetActionStatus").textContent = "事前確認中です。";
  el("rootPseudoResetExecuteBtn").disabled = true;
  el("rootPseudoResetCloseBtn").disabled = false;
  el("rootPseudoResetCancelBtn").disabled = false;
  window.requestAnimationFrame(() => el("rootPseudoResetCloseBtn")?.focus());
}

async function requestRootPseudoResetPreview(target, packages) {
  const body = {
    serial: target.serial,
    adbPort: target.adbPort,
    label: target.label,
  };
  if (Array.isArray(packages)) body.packages = [...packages];
  const response = await fetch("/api/adb/root-pseudo-reset/preview", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-android-fleet-destructive-action": "preview",
    },
    body: JSON.stringify(body),
  });
  const result = await readRootPseudoResetResponse(response);
  if (!response.ok || result.ok === false) {
    throw new Error(rootPseudoResetErrorMessage(result, response));
  }
  return result;
}

async function requestRootPseudoResetExecute(target, authorization, confirmation, packages) {
  const response = await fetch("/api/adb/root-pseudo-reset/execute", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-android-fleet-destructive-action": "execute",
    },
    body: JSON.stringify({
      serial: target.serial,
      adbPort: target.adbPort,
      label: target.label,
      packages: [...packages],
      confirmationToken: authorization.confirmationToken,
      confirmation,
    }),
  });
  const result = await readRootPseudoResetResponse(response);
  return { response, result };
}

async function readRootPseudoResetResponse(response) {
  try {
    const result = await response.json();
    if (!result || typeof result !== "object") throw new Error("empty response");
    return result;
  } catch (_) {
    throw new Error(`サーバー応答を確認できませんでした（HTTP ${response.status || "不明"}）。`);
  }
}

function rootPseudoResetErrorMessage(result = {}, response = {}) {
  const blockers = Array.isArray(result.preflight?.blockers) ? result.preflight.blockers.filter(Boolean) : [];
  return String(result.error || result.message || blockers.join(" / ") || result.code || response.statusText || "処理に失敗しました。");
}

function rootPseudoResetStateCard(label, ok, text) {
  return `<div class="root-pseudo-reset-state-card"><span>${esc(label)}</span><strong class="${ok ? "ok" : "warn"}">${esc(text)}</strong></div>`;
}

function renderRootPseudoResetPreview(result = {}) {
  const reset = state.rootPseudoReset;
  const target = result.target || reset.target || {};
  const preflight = result.preflight || {};
  const packages = Array.isArray(result.packages) ? result.packages.filter((item) => item?.installed) : [];
  reset.phase = "ready";

  el("rootPseudoResetLoading").classList.add("hidden");
  el("rootPseudoResetPreviewError").classList.add("hidden");
  el("rootPseudoResetPreview").classList.remove("hidden");
  el("rootPseudoResetTarget").innerHTML = `
    <div><span>表示名</span><strong>${esc(target.label || reset.target?.label || "-")}</strong></div>
    <div><span>シリアル</span><code>${esc(target.serial || reset.target?.serial || "-")}</code></div>
    <div><span>ADBポート</span><strong>${esc(Number(target.adbPort || 0) || "既定")}</strong></div>
    <div><span>機種</span><strong>${esc(preflight.model || "-")}</strong></div>
    <div><span>Android</span><strong>${esc(preflight.androidVersion || "-")}${preflight.sdkVersion ? ` / SDK ${esc(preflight.sdkVersion)}` : ""}</strong></div>
    <div><span>ユーザー</span><strong>${esc(Number.isInteger(preflight.currentUser) ? `user ${preflight.currentUser}` : "未確認")}</strong></div>`;
  el("rootPseudoResetStateGrid").innerHTML = [
    rootPseudoResetStateCard("ADB接続", preflight.connected === true && preflight.adbState === "device", `${preflight.adbState || "未接続"} / ${preflight.usbState || "USB不明"}`),
    rootPseudoResetStateCard("USBデバッグ", preflight.adbEnabled === true, preflight.adbEnabled ? "有効" : "無効または未確認"),
    rootPseudoResetStateCard("ADB認証鍵", preflight.adbKeyPresent === true, preflight.adbKeyPresent ? "確認済み" : "未確認"),
    rootPseudoResetStateCard("root", preflight.rootAvailable === true, preflight.rootAvailable ? "利用可能" : "利用不可"),
    rootPseudoResetStateCard("Magisk", preflight.magiskPresent === true, preflight.magiskPresent ? preflight.magiskVersion || "検出" : "未検出"),
    rootPseudoResetStateCard("Android起動", preflight.bootCompleted === true, preflight.bootCompleted ? "完了" : "未完了または未確認"),
  ].join("");

  const blockers = [...(Array.isArray(preflight.blockers) ? preflight.blockers.filter(Boolean) : [])];
  if (!packages.length) blockers.push("許可リスト内のインストール済みアプリがありません");
  const blockerBox = el("rootPseudoResetBlockers");
  if (blockers.length) {
    blockerBox.className = "root-pseudo-reset-blockers";
    blockerBox.innerHTML = `<strong>実行を止めている事前条件</strong><ul>${blockers.map((item) => `<li>${esc(item)}</li>`).join("")}</ul>`;
  } else {
    blockerBox.className = "root-pseudo-reset-blockers clear";
    blockerBox.textContent = "事前条件のブロッカーはありません。";
  }

  el("rootPseudoResetPackages").innerHTML = packages.length
    ? packages.map((item) => `
      <label class="root-pseudo-reset-package">
        <input class="root-pseudo-reset-package-input" type="checkbox" value="${esc(item.packageName)}"${item.recommended ? " checked" : ""}>
        <span><strong>${esc(item.label || item.packageName)}</strong><code>${esc(item.packageName)}</code></span>
        ${item.recommended ? "<em>推奨</em>" : ""}
      </label>`).join("")
    : '<div class="root-pseudo-reset-packages-empty">初期化できるインストール済み許可アプリがありません。</div>';

  const notTouched = [...new Set([
    ...(Array.isArray(result.scope?.notTouchedByThisOperation) ? result.scope.notTouchedByThisOperation : []),
    "Fleet DB（この操作では更新しません）",
  ].filter(Boolean))];
  const caveats = [...new Set([
    ...(Array.isArray(result.scope?.caveats) ? result.scope.caveats : []),
    "選択アプリの内部データ・権限に加え、アプリ固有の外部データが削除される場合があります",
  ].filter(Boolean))];
  el("rootPseudoResetPreserved").innerHTML = notTouched.map((item) => `<li>${esc(item)}</li>`).join("");
  el("rootPseudoResetCaveats").innerHTML = caveats.map((item) => `<li>${esc(item)}</li>`).join("");

  el("rootPseudoResetExecutionResult").className = "root-pseudo-reset-result hidden";
  el("rootPseudoResetExecutionResult").innerHTML = "";
  el("rootPseudoResetConfirmationText").textContent = result.confirmationText || "-";
  el("rootPseudoResetConfirmationInput").value = "";
  updateRootPseudoResetExecuteState();
  if (result.ready && result.confirmationText && packages.length) {
    window.requestAnimationFrame(() => el("rootPseudoResetConfirmationInput")?.focus());
  }
}

function renderRootPseudoResetPreviewError(message) {
  el("rootPseudoResetLoading").classList.add("hidden");
  el("rootPseudoResetPreview").classList.add("hidden");
  const box = el("rootPseudoResetPreviewError");
  box.textContent = `事前確認に失敗しました。アプリデータ消去は実行していません。${message || ""}`;
  box.classList.remove("hidden");
  el("rootPseudoResetActionStatus").textContent = "事前確認NG。実行はしていません。";
  el("rootPseudoResetExecuteBtn").disabled = true;
}

function selectedRootPseudoResetPackages() {
  return [...document.querySelectorAll(".root-pseudo-reset-package-input:checked")]
    .map((input) => String(input.value || "").trim())
    .filter(Boolean);
}

function updateRootPseudoResetExecuteState() {
  const reset = state.rootPseudoReset;
  const preview = reset.preview;
  const input = el("rootPseudoResetConfirmationInput");
  const executeButton = el("rootPseudoResetExecuteBtn");
  if (!input || !executeButton) return;
  const phaseLocked = ["loading", "authorizing", "executing", "finished", "preview-error"].includes(reset.phase);
  const previewReady = reset.phase === "ready" && preview?.ready === true && Boolean(preview.confirmationText);
  const packages = selectedRootPseudoResetPackages();
  const confirmationExact = previewReady && input.value === String(preview.confirmationText);
  const canExecute = previewReady && !reset.previewBusy && !reset.executeBusy && confirmationExact && packages.length > 0;
  executeButton.disabled = !canExecute;
  input.disabled = !previewReady || phaseLocked;
  for (const checkbox of document.querySelectorAll(".root-pseudo-reset-package-input")) {
    checkbox.disabled = !previewReady || phaseLocked;
  }
  const closeLocked = ["authorizing", "executing"].includes(reset.phase);
  el("rootPseudoResetCloseBtn").disabled = closeLocked;
  el("rootPseudoResetCancelBtn").disabled = closeLocked;

  const hint = el("rootPseudoResetConfirmationHint");
  const status = el("rootPseudoResetActionStatus");
  hint.className = "";
  if (reset.phase === "authorizing") {
    hint.textContent = "選択したアプリ集合をサーバーでもう一度確認しています。";
    status.textContent = "最終確認中です。まだ消去は実行していません。";
  } else if (reset.phase === "executing") {
    hint.textContent = "実行中です。二重送信や自動再試行は行いません。";
    status.textContent = "アプリデータ消去と保持確認を実行中です。";
  } else if (reset.phase === "finished") {
    hint.textContent = "このプレビューでは再実行できません。再度必要なら閉じて新しいプレビューを行ってください。";
    status.textContent = "実行結果を確認してください。自動再試行はしていません。";
  } else if (!previewReady) {
    hint.textContent = "事前条件を満たしていないため実行できません。";
    status.textContent = "事前確認のブロッカーを確認してください。";
  } else if (!packages.length) {
    hint.textContent = "初期化するアプリを1つ以上選択してください。";
    status.textContent = "アプリ未選択です。";
  } else if (!confirmationExact) {
    hint.textContent = `「${preview.confirmationText}」と完全一致するように入力してください。`;
    status.textContent = "確認文字の完全一致が必要です。";
  } else {
    hint.className = "ok";
    hint.textContent = "確認文字が一致しました。実行時に選択アプリを再プレビューしてから1回だけ送信します。";
    status.textContent = `実行可能: ${packages.length}アプリ。`;
  }
}

function normalizedRootPseudoResetPort(value) {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 && parsed <= 65535 ? parsed : -1;
}

function sameRootPseudoResetTarget(expected = {}, actual = {}) {
  return String(expected.serial || "") === String(actual.serial || "")
    && normalizedRootPseudoResetPort(expected.adbPort) === normalizedRootPseudoResetPort(actual.adbPort);
}

function sameRootPseudoResetPackageSet(expected = [], actual = []) {
  const normalize = (values) => [...new Set((Array.isArray(values) ? values : []).map((value) => String(value || "").trim()).filter(Boolean))].sort();
  const left = normalize(expected);
  const right = normalize(actual);
  return left.length === right.length && left.every((value, index) => value === right[index]);
}

function validateRootPseudoResetAuthorization(authorization, target, confirmation, packages) {
  if (!authorization || authorization.ok === false || authorization.ready !== true) {
    throw new Error(rootPseudoResetErrorMessage(authorization || {}));
  }
  if (authorization.authorizationReady !== true || !String(authorization.confirmationToken || "")) {
    throw new Error("選択アプリに固定された確認トークンを取得できませんでした。");
  }
  if (!sameRootPseudoResetTarget(target, authorization.target || {})) {
    throw new Error("最終確認で対象端末またはADBポートが変わりました。");
  }
  if (String(authorization.confirmationText || "") !== String(confirmation || "")) {
    throw new Error("最終確認で確認文字が一致しませんでした。");
  }
  if (!sameRootPseudoResetPackageSet(packages, authorization.authorizedPackages)) {
    throw new Error("最終確認で許可されたアプリ集合が選択内容と一致しませんでした。");
  }
}

async function executeRootPseudoReset() {
  const reset = state.rootPseudoReset;
  if (reset.executeBusy || reset.previewBusy || reset.phase !== "ready") return;
  const preview = reset.preview;
  const target = reset.target ? { ...reset.target } : null;
  const packages = selectedRootPseudoResetPackages();
  const confirmation = el("rootPseudoResetConfirmationInput").value;
  if (!target || preview?.ready !== true || confirmation !== String(preview.confirmationText || "") || !packages.length) {
    updateRootPseudoResetExecuteState();
    return;
  }

  reset.executeBusy = true;
  reset.phase = "authorizing";
  updateRootPseudoResetExecuteState();
  logLine(`選択アプリ初期化 最終確認中: ${target.label} / ${packages.length}アプリ`);
  let executeAttempted = false;
  try {
    const authorization = await requestRootPseudoResetPreview(target, packages);
    validateRootPseudoResetAuthorization(authorization, target, confirmation, packages);
    reset.phase = "executing";
    updateRootPseudoResetExecuteState();
    logLine(`選択アプリ初期化 実行開始: ${target.label} / ${packages.length}アプリ`);
    executeAttempted = true;
    const { response, result } = await requestRootPseudoResetExecute(target, authorization, confirmation, packages);
    reset.phase = "finished";
    renderRootPseudoResetExecutionResult(result, packages, response.ok);
    logRootPseudoResetExecutionResult(result, packages, response.ok);
  } catch (error) {
    if (executeAttempted) {
      reset.phase = "finished";
      renderRootPseudoResetUnknownResult(error.message);
      logLine(`選択アプリ初期化 結果不明: ${error.message} / 自動再試行なし`);
    } else {
      reset.phase = "ready";
      renderRootPseudoResetAuthorizationFailure(error.message);
      logLine(`選択アプリ初期化 最終確認 NG: ${error.message} / 消去未実行 / 自動再試行なし`);
    }
  } finally {
    reset.executeBusy = false;
    updateRootPseudoResetExecuteState();
  }
}

function rootPseudoResetPackageLabel(packageName) {
  const packages = Array.isArray(state.rootPseudoReset.preview?.packages) ? state.rootPseudoReset.preview.packages : [];
  const found = packages.find((item) => item?.packageName === packageName);
  return found?.label ? `${found.label} / ${packageName}` : packageName;
}

function renderRootPseudoResetExecutionResult(result = {}, requestedPackages = [], responseOk = false) {
  const box = el("rootPseudoResetExecutionResult");
  const succeeded = Number(result.succeeded || 0);
  const failed = result.failed === undefined
    ? Math.max(0, requestedPackages.length - succeeded)
    : Number(result.failed || 0);
  const completed = responseOk && result.ok === true;
  const partial = !completed && succeeded > 0;
  const heading = completed ? "完了" : partial ? "一部失敗" : "失敗";
  const tone = completed ? "success" : partial ? "partial" : "failure";
  const rows = Array.isArray(result.results) ? result.results : [];
  const byPackage = new Map(rows.map((item) => [String(item?.packageName || ""), item]));
  const resultRows = requestedPackages.map((packageName) => {
    const row = byPackage.get(packageName);
    const ok = row?.ok === true;
    const status = row ? ok ? "成功" : "失敗" : "未実行";
    const message = row?.message || (result.stoppedEarly ? "前の失敗後に停止" : "APIが処理を開始しませんでした");
    return `<div class="root-pseudo-reset-result-row"><span>${esc(rootPseudoResetPackageLabel(packageName))}</span><strong class="${ok ? "ok" : "warn"}">${esc(status)}</strong><span>${esc(message)}</span></div>`;
  }).join("");
  const preservationLabels = {
    adbConnection: "ADB接続",
    adbKey: "ADB認証鍵",
    root: "root",
    magisk: "Magisk",
  };
  const preservation = result.preservation && typeof result.preservation === "object"
    ? Object.entries(preservationLabels).map(([key, label]) => {
      const ok = result.preservation[key] === true;
      return `<span class="${ok ? "ok" : "warn"}">${esc(label)}: ${ok ? "保持" : "要確認"}</span>`;
    }).join("")
    : "";
  const retryNotice = completed
    ? "Fleet DBは更新していません。"
    : "一部失敗を含め、自動再試行はしていません。再度必要な場合は閉じて新しいプレビューから確認してください。";
  box.className = `root-pseudo-reset-result ${tone}`;
  box.innerHTML = `
    <h4>${esc(heading)}</h4>
    <div class="root-pseudo-reset-result-summary">
      <span>要求 ${esc(result.requested ?? requestedPackages.length)}</span>
      <span>成功 ${esc(succeeded)}</span>
      <span>失敗・未実行 ${esc(failed)}</span>
    </div>
    ${result.error ? `<p>${esc(result.error)}</p>` : ""}
    ${result.stoppedEarly ? "<p><strong>途中で停止しました。</strong> 残りのアプリは実行していません。</p>" : ""}
    <div class="root-pseudo-reset-result-list">${resultRows}</div>
    ${preservation ? `<div class="root-pseudo-reset-result-preservation">${preservation}</div>` : ""}
    <p>${esc(retryNotice)}</p>`;
}

function renderRootPseudoResetAuthorizationFailure(message) {
  const box = el("rootPseudoResetExecutionResult");
  box.className = "root-pseudo-reset-result failure";
  box.innerHTML = `
    <h4>最終確認に失敗</h4>
    <p>${esc(message || "選択内容を確認できませんでした。")}</p>
    <p>アプリデータ消去は送信していません。自動再試行もしていません。内容を確認して、必要なら実行ボタンを押し直してください。</p>`;
}

function renderRootPseudoResetUnknownResult(message) {
  const box = el("rootPseudoResetExecutionResult");
  box.className = "root-pseudo-reset-result unknown";
  box.innerHTML = `
    <h4>実行結果を確認できません</h4>
    <p>${esc(message || "通信またはサーバー応答を確認できませんでした。")}</p>
    <p>端末側では処理済みの可能性があります。二重消去を避けるため自動再試行せず、このプレビューでの再実行も無効にしました。</p>`;
}

function logRootPseudoResetExecutionResult(result = {}, requestedPackages = [], responseOk = false) {
  const succeeded = Number(result.succeeded || 0);
  const failed = result.failed === undefined
    ? Math.max(0, requestedPackages.length - succeeded)
    : Number(result.failed || 0);
  const completed = responseOk && result.ok === true;
  const status = completed ? "OK" : succeeded > 0 ? "一部失敗" : "NG";
  logLine(`選択アプリ初期化 ${status}: 成功 ${succeeded} / 失敗・未実行 ${failed}${completed ? "" : " / 自動再試行なし"}`);
  const rows = Array.isArray(result.results) ? result.results : [];
  const byPackage = new Map(rows.map((item) => [String(item?.packageName || ""), item]));
  for (const packageName of requestedPackages) {
    const row = byPackage.get(packageName);
    logLine(`選択アプリ初期化 ${row?.ok ? "OK" : row ? "NG" : "未実行"}: ${rootPseudoResetPackageLabel(packageName)}${row?.message ? ` / ${row.message}` : ""}`);
  }
  if (result.preservation && typeof result.preservation === "object") {
    const preserved = Object.entries(result.preservation).map(([key, value]) => `${key}=${value ? "保持" : "NG"}`).join(" / ");
    logLine(`選択アプリ初期化 保持確認: ${preserved}`);
  }
}

function closeRootPseudoResetDialog() {
  const reset = state.rootPseudoReset;
  if (["authorizing", "executing"].includes(reset.phase)) return;
  const modal = el("rootPseudoResetModal");
  if (modal.classList.contains("hidden")) return;
  const triggerButton = reset.triggerButton;
  reset.requestId += 1;
  reset.phase = "idle";
  reset.preview = null;
  reset.target = null;
  reset.executeBusy = false;
  reset.triggerButton = null;
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
  el("rootPseudoResetExecutionResult").innerHTML = "";
  if (triggerButton?.isConnected) triggerButton.focus();
}

function handleRootPseudoResetKeydown(event) {
  if (event.key !== "Escape") return;
  const modal = el("rootPseudoResetModal");
  if (!modal || modal.classList.contains("hidden")) return;
  closeRootPseudoResetDialog();
}

async function closeTtlForSelectedClipboardTargets(button = null) {
  const targets = selectedClipboardTargetsForDeviceAction().map((row) => ({
    serial: row.serial,
    adbPort: row.adbPort || "",
    label: formatXiaoWeiDeviceOptionLabel(row),
  }));
  if (!targets.length) {
    logLine("TTLアプリを閉じる NG: 対象端末が選択されていません");
    return;
  }
  setBusy(true, button);
  logLine(`TTLアプリを閉じる 実行中: ${targets.length}台`);
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson("/api/adb/close-ttl", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ targets }),
    });
    logLine(`TTLアプリを閉じる ${result.ok ? "OK" : "NG"}: 成功 ${result.succeeded || 0} / 失敗 ${result.failed || 0}`);
    if (!result.ok || Number(result.failed || 0) > 0) flash = { message: "要確認", type: "warn" };
    logFailedDeviceRows("TTLアプリを閉じる", result.results || []);
  } catch (error) {
    logLine("TTLアプリを閉じる NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

async function launchAppForSelectedClipboardTargets(app, label, button = null) {
  const actionLabel = label || (app === "ttl" ? "TTL起動" : app === "line" ? "LINE起動" : "アプリ起動");
  const targets = selectedClipboardTargetsForDeviceAction().map((row) => ({
    serial: row.serial,
    adbPort: row.adbPort || "",
    label: formatXiaoWeiDeviceOptionLabel(row),
  }));
  if (!targets.length) {
    logLine(`${actionLabel} NG: 対象端末が選択されていません`);
    return;
  }
  setBusy(true, button);
  logLine(`${actionLabel} 実行中: ${targets.length}台`);
  let flash = { message: "完了", type: "ok" };
  try {
    const result = await fetchJson("/api/adb/launch-app", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ app, targets }),
    });
    logLine(`${actionLabel} ${result.ok ? "OK" : "NG"}: 成功 ${result.succeeded || 0} / 失敗 ${result.failed || 0}`);
    if (!result.ok || Number(result.failed || 0) > 0) flash = { message: "要確認", type: "warn" };
    logFailedDeviceRows(actionLabel, result.results || []);
  } catch (error) {
    logLine(`${actionLabel} NG: ${error.message}`);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

async function installApksForSelectedClipboardTargets(button = null) {
  if (state.apkInstallBusy) {
    logLine("APKインストール 重複操作を停止: すでに選択またはインストール処理が進行中です");
    flashButtonResult(button, "進行中", "warn");
    return;
  }
  state.apkInstallBusy = true;
  let requestStarted = false;
  let flash = { message: "完了", type: "ok" };
  try {
    const selectedRows = selectedClipboardTargetsForDeviceAction();
    const targets = selectedRows.map((row) => ({
      serial: row.serial,
      adbPort: row.adbPort || "",
      label: formatXiaoWeiDeviceOptionLabel(row),
    }));
    if (!targets.length) {
      logLine("APKインストール NG: 対象端末が選択されていません");
      return;
    }

    let selectedFiles = null;
    while (selectedFiles === null) {
      let library;
      try {
        library = await fetchJson("/api/apk-library");
      } catch (error) {
        logLine("APK一覧 NG: " + error.message);
        flashButtonResult(button, "失敗", "error");
        return;
      }
      const picked = await showApkInstallPickerDialog(library.files || [], {
        targetCount: targets.length,
        path: library.path || "data/apk",
      });
      if (!picked) return;
      if (picked.reload) continue;
      selectedFiles = picked.files;
    }
    if (!selectedFiles.length) return;

    setBusy(true, button);
    requestStarted = true;
    logLine(`APKインストール 実行中: ${targets.length}台 × ${selectedFiles.length}ファイル（1回だけ送信）`);
    const result = await fetchJson("/api/adb/install-apks", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ targets, files: selectedFiles }),
    });
    const targetCount = Number.isFinite(Number(result.targeted)) ? Number(result.targeted) : targets.length;
    const failed = result.failed ? ` / 失敗 ${result.failed}台` : "";
    const apkSummary = formatApkInstallSummary(result);
    const needsReview = Number(result.failed || 0) > 0 || Number(result.packageSummary?.failed || 0) > 0;
    logLine(`APKインストール ${needsReview ? "要確認" : "OK"}: 成功 ${result.succeeded || 0}/${targetCount}台${failed}${apkSummary}`);
    if (needsReview) flash = { message: "要確認", type: "warn" };
    logApkInstallDetails(result);
  } catch (error) {
    logLine("APKインストール NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    state.apkInstallBusy = false;
    if (requestStarted) {
      setBusy(false);
      flashButtonResult(button, flash.message, flash.type);
    }
  }
}

function showApkInstallPickerDialog(files = [], options = {}) {
  return new Promise((resolve) => {
    closeAdbDropDialog();
    const rows = Array.isArray(files) ? files : [];
    const overlay = document.createElement("div");
    overlay.className = "adb-drop-dialog-backdrop";
    overlay.innerHTML = `
      <div class="adb-drop-dialog app-extract-dialog apk-install-dialog" role="dialog" aria-modal="true" aria-labelledby="apkInstallDialogTitle">
        <div class="adb-drop-dialog-head">
          <div>
            <h3 id="apkInstallDialogTitle">APKインストール</h3>
            <p>対象 ${esc(options.targetCount || 0)}台 / APKフォルダ ${esc(rows.length)}件</p>
          </div>
          <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
        </div>
        <div class="app-extract-toolbar apk-install-toolbar">
          <button class="section-head-action apk-install-select-all" type="button">すべて選択</button>
          <button class="section-head-action apk-install-clear" type="button">解除</button>
          <button class="section-head-action apk-install-refresh" type="button">再読込</button>
          <button class="section-head-action apk-install-open-folder" type="button">APKフォルダ</button>
          <span class="apk-install-selection-count">選択 0件</span>
        </div>
        <div class="apk-install-path" title="${esc(options.path || "data/apk")}">${esc(options.path || "data/apk")}</div>
        <div class="app-extract-list apk-install-list">
          ${rows.length ? rows.map((file) => `
            <label class="app-extract-item apk-install-item ${file.kind === "split APK" ? "split" : ""}">
              <input type="checkbox" value="${esc(file.name)}">
              <span>
                <strong>${esc(file.name)}</strong>
                <small>${esc(file.kind || "APK")} / ${esc(formatApkFileSize(file.sizeBytes))}</small>
                ${file.kind === "split APK" ? "<em>本体と追加APKをまとめて導入</em>" : ""}
              </span>
            </label>
          `).join("") : '<div class="apk-install-empty">APKフォルダにAPK/APKM/XAPKがありません。<br>「APKフォルダ」を開いてファイルを入れてください。</div>'}
        </div>
        <div class="adb-drop-actions">
          <button class="section-head-action apk-install-start primary-action" type="button" disabled>この内容で1回だけインストール</button>
          <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    const close = (value) => {
      overlay.remove();
      resolve(value);
    };
    const updateSelection = () => {
      const count = overlay.querySelectorAll(".apk-install-item input:checked").length;
      const countNode = overlay.querySelector(".apk-install-selection-count");
      const startButton = overlay.querySelector(".apk-install-start");
      if (countNode) countNode.textContent = `選択 ${count}件`;
      if (startButton) startButton.disabled = count === 0;
    };
    overlay.querySelector(".adb-drop-close")?.addEventListener("click", () => close(null));
    overlay.querySelector(".adb-drop-close-action")?.addEventListener("click", () => close(null));
    overlay.querySelector(".apk-install-select-all")?.addEventListener("click", () => {
      overlay.querySelectorAll(".apk-install-item input").forEach((input) => { input.checked = true; });
      updateSelection();
    });
    overlay.querySelector(".apk-install-clear")?.addEventListener("click", () => {
      overlay.querySelectorAll(".apk-install-item input").forEach((input) => { input.checked = false; });
      updateSelection();
    });
    overlay.querySelector(".apk-install-refresh")?.addEventListener("click", () => close({ reload: true, files: [] }));
    overlay.querySelector(".apk-install-open-folder")?.addEventListener("click", (event) => openApkFolder(event.currentTarget));
    overlay.querySelector(".apk-install-list")?.addEventListener("change", updateSelection);
    overlay.querySelector(".apk-install-start")?.addEventListener("click", () => {
      const selected = [...overlay.querySelectorAll(".apk-install-item input:checked")].map((input) => input.value);
      close({ reload: false, files: selected });
    });
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) close(null);
    });
    updateSelection();
  });
}

function formatApkFileSize(value) {
  const bytes = Number(value || 0);
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  if (bytes >= 1024 ** 3) return `${(bytes / 1024 ** 3).toFixed(1)} GB`;
  if (bytes >= 1024 ** 2) return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
  if (bytes >= 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${bytes} B`;
}

async function extractAppBundleFromSelectedClipboardTarget(button = null) {
  const targets = selectedClipboardTargetsForDeviceAction();
  if (targets.length !== 1) {
    const message = targets.length
      ? `スマホアプリ吸い出し NG: 吸い出し元は1台だけ選択してください（現在 ${targets.length}台）`
      : "スマホアプリ吸い出し NG: 吸い出し元スマホを1台チェックしてください";
    logLine(message);
    window.alert(message);
    return;
  }
  const row = targets[0];

  setBusy(true, button);
  let flash = { message: "完了", type: "ok" };
  try {
    logLine(`スマホアプリ一覧 取得中: ${formatXiaoWeiDeviceOptionLabel(row)}`);
    const packageQuery = new URLSearchParams({ limit: "300", scope: "third_party" });
    packageQuery.set("includeLabels", "1");
    const adbPort = Number(row.adbPort || 0);
    if (Number.isInteger(adbPort) && adbPort > 0) packageQuery.set("adbPort", String(adbPort));
    const listResult = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/packages?${packageQuery.toString()}`);
    const packageCatalog = extractPackageCatalogFromListResult(listResult, row.serial);
    const packageInfoByName = new Map(packageCatalog.map((item) => [item.packageName, item]));
    const packages = prioritizeExtractablePackages(packageCatalog.map((item) => item.packageName), packageInfoByName);
    if (!packages.length) {
      logLine("スマホアプリ吸い出し NG: アプリ一覧が空です");
      flash = { message: "失敗", type: "error" };
      return;
    }
    const pickedPackages = await showAppExtractPickerDialog(packages, row, packageInfoByName);
    if (!pickedPackages) {
      flash = { message: "中止", type: "warn" };
      return;
    }
    if (!pickedPackages.length) {
      logLine("スマホアプリ吸い出し NG: アプリが選択されていません");
      flash = { message: "失敗", type: "error" };
      return;
    }
    let okCount = 0;
    let ngCount = 0;
    for (const packageName of pickedPackages) {
      const saveName = defaultAppBundleSaveName(packageName);
      try {
        logLine(`スマホアプリ吸い出し 実行中: ${formatXiaoWeiDeviceOptionLabel(row)} / ${packageDisplayName(packageName, packageInfoByName)} -> ${saveName}.apkm`);
        const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            action: "extract_app_bundle",
            packageName,
            saveName,
            timeout: 240000,
          }),
        });
        const data = result.result || {};
        const splits = Number(data.splitCount || 0);
        const backup = data.backupPath ? " / 旧ファイルはバックアップ済み" : "";
        okCount += 1;
        logLine(`スマホアプリ吸い出し OK: ${packageDisplayName(packageName, packageInfoByName)} / ${saveName}.apkm / ${splits}分割${backup}`);
      } catch (error) {
        ngCount += 1;
        logLine(`スマホアプリ吸い出し NG: ${packageDisplayName(packageName, packageInfoByName)} / ${error.message}`);
      }
    }
    if (ngCount) flash = { message: "要確認", type: "warn" };
    window.alert(`スマホアプリ吸い出し 完了\n成功 ${okCount} / 失敗 ${ngCount}\n保存先: data/apk`);
  } catch (error) {
    logLine("スマホアプリ吸い出し NG: " + error.message);
    flash = { message: "失敗", type: "error" };
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

function showAppExtractPickerDialog(packages = [], row = {}, packageInfoByName = new Map()) {
  return new Promise((resolve) => {
    closeAdbDropDialog();
    const defaults = new Set([
      "com.ss.android.ugc.tiktok.lite",
      "com.zhiliaoapp.musically.go",
      "com.zhiliaoapp.musically",
      "jp.naver.line.android",
    ].filter((packageName) => packages.includes(packageName)));
    const recommendedPackages = packages.filter((packageName) => defaults.has(packageName));
    const otherPackages = packages.filter((packageName) => !defaults.has(packageName));
    const renderPackageItem = (packageName, recommended = false) => {
      const info = appPackageInfo(packageName, packageInfoByName);
      const searchText = `${info.name} ${packageName} ${info.note || ""}`.toLocaleLowerCase("ja-JP");
      const nameMarkup = info.known
        ? `<strong>${esc(info.name)}</strong><small>${esc(packageName)}</small>`
        : `<strong class="label-missing">名前を取得できません</strong><small>${esc(packageName)}</small>`;
      return `
        <label class="app-extract-item ${recommended ? "recommended" : ""}" data-search="${esc(searchText)}">
          <input type="checkbox" value="${esc(packageName)}" ${defaults.has(packageName) ? "checked" : ""}>
          <span>
            ${nameMarkup}
            ${info.note ? `<em>${esc(info.note)}</em>` : ""}
          </span>
        </label>
      `;
    };
    const overlay = document.createElement("div");
    overlay.className = "adb-drop-dialog-backdrop";
    overlay.innerHTML = `
      <div class="adb-drop-dialog app-extract-dialog app-extract-picker-dialog" role="dialog" aria-modal="true" aria-labelledby="appExtractDialogTitle">
        <div class="adb-drop-dialog-head">
          <div>
            <h3 id="appExtractDialogTitle">端末からアプリをPCへ保存</h3>
            <p>対象端末：${esc(formatXiaoWeiDeviceOptionLabel(row))} / 端末内アプリ：${esc(packages.length)}件</p>
          </div>
          <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
        </div>
        <div class="app-extract-copy-notice">
          <strong>アプリ本体（APK）を端末からPCへコピーします。</strong>
          <span>端末上のアプリやデータは削除・変更されません。保存先：<code>data/apk</code></span>
        </div>
        ${recommendedPackages.length ? `
          <section class="app-extract-recommended-section">
            <div class="app-extract-section-head">
              <div>
                <h4>よく使うアプリ</h4>
                <p>定番アプリは選択済みです。不要なものだけチェックを外してください。</p>
              </div>
              <button class="section-head-action app-extract-priority" type="button">定番アプリだけ選択</button>
            </div>
            <div class="app-extract-recommended-list">
              ${recommendedPackages.map((packageName) => renderPackageItem(packageName, true)).join("")}
            </div>
          </section>
        ` : ""}
        <details class="app-extract-other"${recommendedPackages.length ? "" : " open"}>
          <summary>
            <span class="app-extract-other-title"><i aria-hidden="true">▶</i>その他のアプリを探す</span>
            <small>端末内のユーザーアプリ ${esc(otherPackages.length)}件</small>
          </summary>
          <div class="app-extract-search-row">
            <input class="app-extract-search" type="search" placeholder="アプリ名・パッケージ名で検索" aria-label="その他のアプリを検索">
            <span class="app-extract-search-count">${esc(otherPackages.length)}件表示</span>
          </div>
          <div class="app-extract-list">
            ${otherPackages.slice(0, 300).map((packageName) => renderPackageItem(packageName)).join("")}
            <div class="app-extract-no-results hidden">一致するアプリがありません。</div>
          </div>
        </details>
        <div class="adb-drop-actions">
          <div class="app-extract-selection" aria-live="polite">
            <strong>選択中：0件</strong>
            <span class="app-extract-selection-names">保存するアプリを選んでください</span>
          </div>
          <button class="section-head-action app-extract-clear" type="button">選択をすべて解除</button>
          <button class="section-head-action app-extract-start primary-action" type="button">選択したアプリをPCへ保存</button>
          <button class="section-head-action adb-drop-close-action" type="button">閉じる</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    const close = (value) => {
      overlay.remove();
      resolve(value);
    };
    const updateSelection = () => {
      const selected = [...overlay.querySelectorAll(".app-extract-item input:checked")];
      const count = selected.length;
      const selection = overlay.querySelector(".app-extract-selection strong");
      const selectedNames = overlay.querySelector(".app-extract-selection-names");
      const startButton = overlay.querySelector(".app-extract-start");
      overlay.querySelectorAll(".app-extract-item").forEach((item) => {
        item.classList.toggle("selected", Boolean(item.querySelector("input")?.checked));
      });
      if (selection) selection.textContent = `選択中：${count}件`;
      if (selectedNames) {
        const names = selected.map((input) => appPackageInfo(input.value, packageInfoByName).name);
        const preview = names.slice(0, 3).join("、");
        selectedNames.textContent = count
          ? `${preview}${count > 3 ? `、ほか${count - 3}件` : ""}`
          : "保存するアプリを選んでください";
      }
      if (startButton) {
        startButton.disabled = count === 0;
        startButton.textContent = count
          ? `選択した${count}件をPCへ保存`
          : "保存するアプリを選んでください";
      }
    };
    const applySearch = () => {
      const input = overlay.querySelector(".app-extract-search");
      const query = String(input?.value || "").trim().toLocaleLowerCase("ja-JP");
      const items = [...overlay.querySelectorAll(".app-extract-other .app-extract-item")];
      let visibleCount = 0;
      for (const item of items) {
        const visible = !query || String(item.dataset.search || "").includes(query);
        item.hidden = !visible;
        if (visible) visibleCount += 1;
      }
      const count = overlay.querySelector(".app-extract-search-count");
      const empty = overlay.querySelector(".app-extract-no-results");
      if (count) count.textContent = query ? `${visibleCount}/${items.length}件表示` : `${items.length}件表示`;
      if (empty) empty.classList.toggle("hidden", visibleCount !== 0);
    };
    overlay.querySelector(".adb-drop-close")?.addEventListener("click", () => close(null));
    overlay.querySelector(".adb-drop-close-action")?.addEventListener("click", () => close(null));
    overlay.querySelector(".app-extract-priority")?.addEventListener("click", () => {
      overlay.querySelectorAll(".app-extract-item input").forEach((input) => {
        input.checked = defaults.has(input.value);
      });
      updateSelection();
    });
    overlay.querySelector(".app-extract-clear")?.addEventListener("click", () => {
      overlay.querySelectorAll(".app-extract-item input").forEach((input) => {
        input.checked = false;
      });
      updateSelection();
    });
    overlay.querySelector(".app-extract-search")?.addEventListener("input", applySearch);
    overlay.addEventListener("change", (event) => {
      if (event.target.matches(".app-extract-item input")) updateSelection();
    });
    overlay.querySelector(".app-extract-start")?.addEventListener("click", () => {
      const selected = [...overlay.querySelectorAll(".app-extract-item input:checked")].map((input) => input.value);
      close(selected);
    });
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) close(null);
    });
    updateSelection();
  });
}

function prioritizeExtractablePackages(packages = [], packageInfoByName = new Map()) {
  const seen = new Set();
  const normalized = packages.map((value) => String(value || "").trim()).filter(Boolean);
  const priority = [
    "com.ss.android.ugc.tiktok.lite",
    "com.zhiliaoapp.musically.go",
    "com.zhiliaoapp.musically",
    "jp.naver.line.android",
  ];
  const sorted = normalized.sort((a, b) => {
    const aInfo = appPackageInfo(a, packageInfoByName);
    const bInfo = appPackageInfo(b, packageInfoByName);
    return aInfo.name.localeCompare(bInfo.name, "ja", { numeric: true, sensitivity: "base" })
      || a.localeCompare(b, "en", { numeric: true });
  });
  return [...priority, ...sorted]
    .filter((packageName) => {
      if (!normalized.includes(packageName) || seen.has(packageName)) return false;
      seen.add(packageName);
      return true;
    });
}

function extractPackageCatalogFromListResult(result, serial = "") {
  const body = result?.result || result || {};
  const rows = [];
  if (Array.isArray(body.packages)) rows.push(...body.packages);
  if (Array.isArray(body.apps)) rows.push(...body.apps);
  const bySerial = body[String(serial)] || body[serial];
  if (Array.isArray(bySerial)) rows.push(...bySerial);
  if (!rows.length) {
    const firstArray = Object.values(body).find((value) => Array.isArray(value));
    if (Array.isArray(firstArray)) rows.push(...firstArray);
  }
  const catalog = new Map();
  for (const item of rows) {
    const packageName = String(
      typeof item === "string"
        ? item
        : item?.packageName || item?.apk || item?.name || ""
    ).trim();
    if (!/^[A-Za-z0-9_.]+$/.test(packageName)) continue;
    const label = normalizeDeviceAppLabel(typeof item === "object" ? item?.label || item?.appLabel || item?.displayName : "", packageName);
    const existing = catalog.get(packageName) || { packageName, label: "", labelSource: "" };
    if (label) {
      existing.label = label;
      existing.labelSource = String(item?.labelSource || "android-package-manager");
    }
    catalog.set(packageName, existing);
  }
  return [...catalog.values()];
}

function extractPackageNamesFromListResult(result, serial = "") {
  return extractPackageCatalogFromListResult(result, serial).map((item) => item.packageName);
}

function packageDisplayName(packageName, packageInfoByName = new Map()) {
  const info = appPackageInfo(packageName, packageInfoByName);
  return info.known ? `${info.name} / ${packageName}` : packageName;
}

function appPackageInfo(packageName, packageInfoByName = new Map()) {
  const known = {
    "com.ss.android.ugc.tiktok.lite": ["TikTok Lite", "招待検証の本命"],
    "com.zhiliaoapp.musically.go": ["TikTok Lite", "別パッケージ候補"],
    "com.zhiliaoapp.musically": ["TikTok", "TikTok本家"],
    "jp.naver.line.android": ["LINE", "APKから任意導入"],
    "com.android.chrome": ["Chrome", ""],
    "com.google.android.youtube": ["YouTube", ""],
    "com.android.vending": ["Google Play", ""],
    "com.google.android.gms": ["Google Play開発者サービス", ""],
    "com.google.android.gm": ["Gmail", ""],
    "com.google.android.apps.nbu.files": ["Files", ""],
    "com.tencent.mm": ["WeChat", ""],
    "com.teslacoilsw.launcher": ["Nova Launcher", ""],
    "com.teslacoilsw.launcher.prime": ["Nova Launcher Prime", ""],
    "com.theswitchbot.switchbot": ["SwitchBot", ""],
    "com.transferwise.android": ["Wise", ""],
    "com.truedevelopersstudio.automatictap.autoclicker": ["Auto Clicker", ""],
    "com.twitter.android": ["X（旧Twitter）", ""],
    "com.united.mobile.android": ["United Airlines", ""],
    "com.valvesoftware.android.steam.community": ["Steam", ""],
    "com.vimeo.android.videoapp": ["Vimeo", ""],
    "com.yodobashi.coupon": ["ヨドバシ", ""],
    "com.zzkko": ["SHEIN", ""],
    "intl.costco.com.mobile.japan": ["コストコ", ""],
    "io.trustdock.app": ["TRUSTDOCK", ""],
    "jp.auone.wallet": ["au PAY", ""],
    "jp.co.aeon.credit.android.wallet": ["AEON Wallet", ""],
  };
  const liveInfo = packageInfoByName && typeof packageInfoByName.get === "function"
    ? packageInfoByName.get(packageName)
    : packageInfoByName?.[packageName];
  const liveLabel = normalizeDeviceAppLabel(liveInfo?.label || liveInfo, packageName);
  if (liveLabel) {
    const curated = known[packageName] || [];
    const alias = curated[0] && curated[0].toLocaleLowerCase("ja-JP") !== liveLabel.toLocaleLowerCase("ja-JP")
      ? curated[0]
      : "";
    return {
      name: liveLabel,
      note: [curated[1], alias].filter(Boolean).join(" / "),
      known: true,
      source: String(liveInfo?.labelSource || "android-package-manager"),
    };
  }
  if (known[packageName]) {
    return { name: known[packageName][0], note: known[packageName][1], known: true, source: "curated" };
  }
  return { name: String(packageName || ""), note: "", known: false, source: "package-name" };
}

function normalizeDeviceAppLabel(value, packageName = "") {
  const label = String(value || "")
    .replace(/[\u0000-\u001f\u007f-\u009f]/g, " ")
    .replace(/[\u061c\u200b-\u200f\u202a-\u202e\u2060-\u2069\ufeff]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 160);
  return !label || label === String(packageName || "").trim() ? "" : label;
}

function resolvePickedPackageName(input, packages = []) {
  const value = String(input || "").trim();
  const number = Number(value);
  if (Number.isInteger(number) && number >= 1 && number <= packages.length) return packages[number - 1];
  if (/^[A-Za-z0-9_.]+$/.test(value)) return value;
  return "";
}

function defaultAppBundleSaveName(packageName) {
  if (packageName === "com.ss.android.ugc.tiktok.lite") return "tiktok-lite";
  if (packageName === "com.zhiliaoapp.musically.go") return "tiktok-lite-alt";
  if (packageName === "com.zhiliaoapp.musically") return "tiktok";
  if (packageName === "jp.naver.line.android") return "line";
  return packageName.replace(/[^A-Za-z0-9_.-]+/g, "-").replace(/\.+/g, ".").slice(0, 80) || "app";
}

async function diagnoseTtlInviteForSelectedClipboardTargets(button = null) {
  const selectedTargets = selectedClipboardTargetsForDeviceAction();
  if (!selectedTargets.length) {
    const message = "TTL招待診断 NG: 対象端末が選択されていません。端末にチェックを入れてください。";
    logLine(message);
    window.alert(message);
    return;
  }
  const targets = selectedTargets.slice(0, 12);
  if (selectedTargets.length > targets.length) {
    logLine(`TTL招待診断: 選択 ${selectedTargets.length}台中、先頭 ${targets.length}台だけ診断します`);
  }
  const input = window.prompt("診断する招待URLを貼ってください。空欄ならテストURLで確認します。", "");
  if (input === null) return;
  const url = String(input || "").trim() || "https://lite.tiktok.com/t/test";
  setBusy(true, button);
  let okCount = 0;
  let warnCount = 0;
  logLine(`TTL招待診断 開始: ${targets.length}台 / ${url}`);
  let cursor = 0;
  const concurrency = Math.min(4, targets.length);
  async function worker() {
    while (cursor < targets.length) {
      const row = targets[cursor++];
      logLine(`TTL招待診断 実行中: ${formatXiaoWeiDeviceOptionLabel(row)}`);
      await diagnoseOneTtlInviteTarget(row, url).then((ok) => {
        if (ok) okCount += 1;
        else warnCount += 1;
      });
    }
  }
  try {
    await Promise.all(Array.from({ length: concurrency }, () => worker()));
    logLine(`TTL招待診断 完了: OK ${okCount} / 要確認 ${warnCount}`);
    window.alert(`TTL招待診断 完了\nOK ${okCount} / 要確認 ${warnCount}\n詳細はログを見てください。`);
    flashButtonResult(button, warnCount ? "要確認" : "OK", warnCount ? "warn" : "ok");
  } finally {
    setBusy(false);
  }
}

async function diagnoseOneTtlInviteTarget(row, url) {
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "ttl_invite_diagnostics",
        url,
        timeout: 8000,
      }),
    });
    const diagnosis = result.result?.diagnosis || "診断結果なし";
    const installedCount = result.result?.installedCount ?? "-";
    const matches = Array.isArray(result.result?.installedMatches) ? result.result.installedMatches.join(",") : "";
    if (result.result?.ok) {
      logLine(`TTL招待診断 OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${diagnosis}${matches ? " / " + matches : ""}`);
      return true;
    }
    const duplicate = result.result?.duplicateInstalled ? " / TTL複数" : "";
    logLine(`TTL招待診断 要確認: ${formatXiaoWeiDeviceOptionLabel(row)} / TTL ${installedCount}個${duplicate} / ${diagnosis}`);
    return false;
  } catch (error) {
    logLine(`TTL招待診断 NG: ${formatXiaoWeiDeviceOptionLabel(row)} / ${error.message}`);
    return false;
  }
}

async function cleanupTtlInviteForSelectedClipboardTargets(button = null) {
  const selectedTargets = selectedClipboardTargetsForDeviceAction();
  if (!selectedTargets.length) {
    const message = "TTL整理 NG: 対象端末が選択されていません。端末にチェックを入れてください。";
    logLine(message);
    window.alert(message);
    return;
  }
  const targets = selectedTargets.slice(0, 12);
  if (selectedTargets.length > targets.length) {
    logLine(`TTL整理: 選択 ${selectedTargets.length}台中、先頭 ${targets.length}台だけ整理します`);
  }
  const input = window.prompt("整理判定に使う招待URLを貼ってください。空欄ならテストURLで確認します。", "");
  if (input === null) return;
  const url = String(input || "").trim() || "https://lite.tiktok.com/t/test";
  setBusy(true, button);
  const plans = [];
  try {
    logLine(`TTL整理 診断開始: ${targets.length}台 / ${url}`);
    for (const row of targets) {
      try {
        const dryRun = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            action: "ttl_invite_cleanup",
            url,
            execute: false,
            timeout: 12000,
          }),
        });
        const plan = dryRun.result?.plan || {};
        plans.push({ row, plan, dryRun });
        const remove = Array.isArray(plan.removePackageNames) ? plan.removePackageNames.join(",") : "";
        logLine(`TTL整理 予定: ${formatXiaoWeiDeviceOptionLabel(row)} / 残す ${plan.keepPackageName || "-"}${remove ? " / 消す " + remove : " / 整理不要"}`);
      } catch (error) {
        plans.push({ row, error });
        logLine(`TTL整理 診断NG: ${formatXiaoWeiDeviceOptionLabel(row)} / ${error.message}`);
      }
    }
    const executable = plans.filter((item) => item.plan?.needsCleanup && item.plan?.keepPackageName);
    if (!executable.length) {
      logLine("TTL整理 完了: 整理が必要な端末はありません");
      window.alert("TTL整理: 整理が必要な端末はありません。");
      flashButtonResult(button, "整理不要", "ok");
      return;
    }
    const confirmLines = executable.map((item) => {
      const remove = item.plan.removePackageNames.join(", ");
      return `${formatXiaoWeiDeviceOptionLabel(item.row)}\n残す: ${item.plan.keepPackageName}\n消す: ${remove}`;
    });
    const ok = window.confirm(`APK側TTLを残して、重複TTLを削除します。\n\n${confirmLines.join("\n\n")}\n\n実行しますか？`);
    if (!ok) {
      logLine("TTL整理 キャンセル");
      return;
    }
    let okCount = 0;
    let ngCount = 0;
    for (const item of executable) {
      try {
        const result = await fetchJson(`/api/devices/${encodeURIComponent(item.row.serial)}/actions`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            action: "ttl_invite_cleanup",
            url,
            execute: true,
            timeout: 30000,
          }),
        });
        if (result.result?.ok) {
          okCount += 1;
          logLine(`TTL整理 OK: ${formatXiaoWeiDeviceOptionLabel(item.row)} / ${result.result.message || ""}`);
        } else {
          ngCount += 1;
          logLine(`TTL整理 要確認: ${formatXiaoWeiDeviceOptionLabel(item.row)} / ${result.result?.message || "未確認"}`);
        }
      } catch (error) {
        ngCount += 1;
        logLine(`TTL整理 NG: ${formatXiaoWeiDeviceOptionLabel(item.row)} / ${error.message}`);
      }
    }
    logLine(`TTL整理 完了: OK ${okCount} / 要確認 ${ngCount}`);
    window.alert(`TTL整理 完了\nOK ${okCount} / 要確認 ${ngCount}\n続けてTTL招待診断を実行してください。`);
    flashButtonResult(button, ngCount ? "要確認" : "OK", ngCount ? "warn" : "ok");
  } finally {
    setBusy(false);
  }
}

async function openApnSettingsForSelectedDevice(button = null) {
  const serials = checkedApnTargetSerials();
  if (serials.length !== 1) return logLine("APN設定: 対象端末を1台だけ選んでください");
  const row = selectedApnDevice();
  if (!row || !row.serial) return logLine("APN設定: 対象端末を選んでください");
  const simDevice = (state.deviceSimInfo?.devices || []).find(
    (device) => String(device?.serial || "").toLowerCase() === String(row.serial).toLowerCase(),
  );
  const subscriptions = Array.isArray(simDevice?.subscriptions) ? simDevice.subscriptions : [];
  const subscriptionId = subscriptions.length === 1
    ? normalizeNullableSubscriptionId(subscriptions[0]?.subscriptionId)
    : null;
  const adbDevice = (state.adbDevices?.devices || []).find(
    (device) => String(device?.serial || "").toLowerCase() === String(row.serial).toLowerCase(),
  );
  const adbPort = normalizeNullableAdbPort(simDevice?.adbPort || adbDevice?.adbPort);
  setBusy(true, button);
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "open_apn_settings",
        apnManualOnly: true,
        adbPort,
        subscriptionId,
        timeout: 12000,
      }),
    });
    if (result.result?.opened !== true) {
      throw new Error(result.result?.reason || "APN設定画面を確認できませんでした");
    }
    const foreground = result.result?.foreground?.component || result.result?.foreground?.packageName || "";
    logLine(`APN設定 OK: ${formatXiaoWeiDeviceOptionLabel(row)}${foreground ? " / " + foreground : ""}`);
  } catch (error) {
    logLine("APN設定 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function handleApnPaletteAction(event) {
  const selectButton = event.target.closest(".apn-select-btn");
  if (selectButton) {
    if (checkedApnTargetSerials().length !== 1) {
      renderApnSelectionStatus("複数端末は「選択端末をSIM判定」で自動振り分けしてください");
      return;
    }
    const selected = selectApnProfile(selectButton.dataset.apnProfile, "manual");
    if (selected) {
      const preset = APN_PRESETS.find((item) => item.id === selectButton.dataset.apnProfile);
      logLine(`APN選択: ${preset?.carrier || selectButton.dataset.apnProfile}`);
    }
    return;
  }
  const button = event.target.closest(".apn-paste-btn");
  if (!button) return;
  const preset = APN_PRESETS[Number(button.dataset.apnIndex)];
  const fieldKey = button.dataset.apnField || "";
  const value = preset?.fields?.[fieldKey];
  if (!preset || !String(value || "").trim()) return;
  await pasteApnValueToSelectedDevice(preset, fieldKey, value, button);
}

async function prepareSelectedApnOnDevices(button = null) {
  const serials = checkedApnTargetSerials();
  const currentTargetKey = apnTargetKey(serials);
  if (!serials.length) return logLine("APN自動入力: 対象端末を選んでください");
  if (state.apnSetup.targetKey !== currentTargetKey) {
    return logLine("APN自動入力: 選択端末が変わりました。SIM判定をやり直してください");
  }
  const selectedSet = new Set(serials.map((serial) => String(serial || "").toLowerCase()));
  const plan = (Array.isArray(state.apnSetup.plan) ? state.apnSetup.plan : [])
    .filter((item) => selectedSet.has(String(item.serial || "").toLowerCase()))
    .map((item) => ({ ...item, preset: apnPresetById(item.profileId) }))
    .filter((item) => item.serial && item.preset);
  if (!plan.length) return logLine("APN自動入力: 確実に判定できた端末がありません");
  if (state.apnSetup.results.length) {
    return logLine("APN自動入力: 再実行する場合はSIM判定をやり直してください");
  }
  const unresolved = Array.isArray(state.apnSetup.unresolved) ? state.apnSetup.unresolved : [];
  const summary = apnPlanSummaryText(plan);
  const ok = window.confirm(
    `選択 ${serials.length}台のうち、確実に判定できた ${plan.length}台へAPNを順番に入力・保存します。\n\n`
    + `${summary}\n`
    + (unresolved.length ? `要確認のため自動入力しない端末: ${unresolved.length}台\n` : "")
    + "\n新規APNとして保存します。既存APN編集画面や同名APNを検出した端末は上書きせず停止します。"
  );
  if (!ok) return;

  state.apnSetup.running = true;
  state.apnSetup.results = [];
  setBusy(true, button);
  const results = [];
  let finalMessage = "";
  try {
    for (let index = 0; index < plan.length; index += 1) {
      const item = plan[index];
      const row = findSummaryDeviceBySerial(item.serial) || { serial: item.serial };
      renderApnSelectionStatus(`APN保存中 ${index + 1}/${plan.length}: ${formatXiaoWeiDeviceOptionLabel(row)} / ${item.preset.carrier}`);
      logLine(`APN一括保存 ${index + 1}/${plan.length}: ${formatXiaoWeiDeviceOptionLabel(row)} / ${item.preset.carrier}`);
      try {
        const result = await privateFetchJson("/api/adb/apn-draft", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            serial: item.serial,
            adbPort: item.adbPort || null,
            subscriptionId: normalizeNullableSubscriptionId(item.subscriptionId),
            profileId: item.preset.id,
            fields: item.preset.fields,
            requireFreshEditor: true,
            saveAfterFill: true,
            timeout: 120000,
          }),
        });
        const draft = result.result || {};
        const failed = Array.isArray(draft.failedFields) ? draft.failedFields : [];
        if (!draft.prepared || !draft.saved) {
          const rawReason = failed[0]?.reason || draft.reason || "端末画面を特定できません";
          const reason = apnSaveReasonLabel(rawReason);
          results.push({
            serial: item.serial,
            profileId: item.preset.id,
            ok: false,
            reason,
            rawReason,
            saveState: draft.saveState || "",
            releaseToken: String(result.guard?.releaseToken || ""),
          });
          logLine(`APN一括保存 要確認: ${formatXiaoWeiDeviceOptionLabel(row)} / ${reason}`);
          continue;
        }
        results.push({
          serial: item.serial,
          profileId: item.preset.id,
          ok: true,
          saved: true,
          idempotent: result.idempotent === true,
        });
        logLine(
          `APN一括保存 OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${item.preset.carrier} / `
          + (result.idempotent === true ? "前回の保存確認済み記録から重複保存を省略" : "保存確認済み"),
        );
      } catch (error) {
        const rawReason = String(error?.message || "通信エラー");
        const failure = classifyApnSaveFailure(error);
        const saveState = failure.saveState;
        const reason = saveState === "unknown"
          ? `保存結果不明・端末確認まで再実行禁止: ${rawReason}`
          : apnSaveReasonLabel(error?.code || rawReason);
        results.push({
          serial: item.serial,
          profileId: item.preset.id,
          ok: false,
          reason,
          rawReason,
          saveState,
          releaseToken: failure.releaseToken,
        });
        logLine(`APN一括保存 NG: ${formatXiaoWeiDeviceOptionLabel(row)} / ${reason}`);
      }
    }
    state.apnSetup.results = results;
    const okCount = results.filter((item) => item.ok).length;
    const failedCount = results.length - okCount;
    const unknownCount = results.filter((item) => item.saveState === "unknown").length;
    finalMessage = `APN保存完了: OK ${okCount}台 / 要確認 ${failedCount}台${unknownCount ? ` / 保存結果未確認 ${unknownCount}台` : ""}${unresolved.length ? ` / 判定要確認 ${unresolved.length}台` : ""}`;
    logLine(`${finalMessage} / OK端末は保存確認済み`);
    window.alert(
      `${finalMessage}\n\n`
      + "OK端末は新規APNとして保存済みです。保存結果未確認の端末は重複防止のため再実行せず、端末画面を確認してください。通信できない場合は使用するAPNの選択状態も確認してください。"
    );
  } finally {
    state.apnSetup.running = false;
    const targetChanged = state.apnSetup.targetKey !== apnTargetKey();
    if (targetChanged) syncApnSelectionWithTarget();
    setBusy(false);
    if (!targetChanged) renderApnSelectionStatus(finalMessage || "APN保存を終了しました");
    if (results.length) {
      const failedCount = results.filter((item) => !item.ok).length;
      flashButtonResult(button, failedCount ? "要確認あり" : "確認へ", failedCount ? "warn" : "ok");
    }
  }
}

async function pasteApnValueToSelectedDevice(preset, fieldKey, value, button = null) {
  const serials = checkedApnTargetSerials();
  if (serials.length !== 1) return logLine("APN貼付: 対象端末を1台だけ選んでください");
  const row = selectedApnDevice();
  if (!row || !row.serial) return logLine("APN貼付: 対象端末を選んでください");
  const adbDevice = (state.adbDevices?.devices || []).find(
    (device) => String(device?.serial || "").toLowerCase() === String(row.serial).toLowerCase(),
  );
  const adbPort = normalizeNullableAdbPort(adbDevice?.adbPort);
  setBusy(true, button);
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(row.serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "input_text",
        adbPort,
        text: String(value),
        clearFirst: true,
        apnEditorOnly: true,
        apnField: fieldKey,
        timeout: 15000,
      }),
    });
    const label = APN_FIELD_LABELS[fieldKey] || fieldKey;
    logLine(`APN貼付 OK: ${formatXiaoWeiDeviceOptionLabel(row)} / ${preset.carrier} / ${label} / ${result.result?.length || String(value).length}文字`);
  } catch (error) {
    logLine("APN貼付 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function deleteClipboardItem(id, button = null) {
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/clipboard-items/delete", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id }),
    });
    state.clipboardItems = result.items || [];
    renderClipboardItems();
    logLine("保管リスト削除 OK");
  } catch (error) {
    logLine("保管リスト削除 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function clearClipboardForm() {
  state.clipboardEditingId = "";
  setClipboardTitleValue("QR招待");
  el("clipboardTextInput").value = "";
  el("clipboardNoteInput").value = "";
}

function inferClipboardTitleClient(text) {
  const value = String(text || "").trim();
  try {
    return new URL(value).hostname;
  } catch {
    return value.replace(/\s+/g, " ").slice(0, 40) || "クリップ";
  }
}

async function refreshScriptScreenshot() {
  const serial = el("scriptDeviceSelect").value;
  if (!serial) return logLine("JSビルダー: 対象端末を選んでください");
  if (state.scriptBuilder.refreshing) return;
  state.scriptBuilder.refreshing = true;
  const button = el("scriptRefreshShotBtn");
  button.disabled = true;
  el("scriptPreviewMeta").textContent = "取得中...";
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "screenshot" }),
    });
    if (!result.screenshotUrl) throw new Error("スクショURLが返りませんでした");
    const url = result.screenshotUrl + "?ts=" + Date.now();
    state.scriptBuilder.latestScreenshotUrl = url;
    setScriptPreviewImage(url);
    logLine("JSビルダー スクショ更新 OK");
  } catch (error) {
    el("scriptPreviewMeta").textContent = "取得NG";
    logLine("JSビルダー スクショ更新 NG: " + error.message);
  } finally {
    state.scriptBuilder.refreshing = false;
    button.disabled = state.busy;
  }
}

async function copySelectedDeviceScreenText() {
  const serial = el("scriptDeviceSelect").value;
  if (!serial) return logLine("画面テキストコピー: 対象端末を選んでください");
  setBusy(true, el("scriptCopyScreenTextBtn"));
  logLine("画面テキストコピー 実行中...");
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "screen_text", timeout: 15000 }),
    });
    const text = result.result?.text || "";
    const count = Number(result.result?.count || 0);
    if (!text.trim()) {
      logLine("画面テキストコピー: 取得できるUIテキストがありません");
      return;
    }
    await writeClipboardText(text);
    logLine(`画面テキストコピー OK: ${count}行`);
  } catch (error) {
    logLine("画面テキストコピー NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function copySelectedDeviceClipboardText() {
  const serial = el("scriptDeviceSelect").value;
  if (!serial) return logLine("端末クリップコピー: 対象端末を選んでください");
  setBusy(true, el("scriptCopyDeviceClipboardBtn"));
  logLine("端末クリップコピー 実行中...");
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "clipboard_text", timeout: 15000 }),
    });
    const payload = result.result || {};
    const text = payload.text || "";
    if (!text.trim()) {
      const detail = [
        payload.message || "",
        payload.nativeError ? `ADB=${payload.nativeError}` : "",
        payload.laixiError ? `XiaoWei=${payload.laixiError}` : "",
      ].filter(Boolean).join(" / ");
      logLine("端末クリップコピー: 取得できるクリップボード文字がありません" + (detail ? ` / ${detail}` : ""));
      return;
    }
    await writeClipboardText(text);
    logLine(`端末クリップコピー OK: ${text.length}文字 / ${payload.method || "unknown"}`);
  } catch (error) {
    logLine("端末クリップコピー NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function runAdbChromeTest() {
  const serial = el("scriptDeviceSelect").value;
  if (!serial) return logLine("ADB Chrome確認: 対象端末を選んでください");
  setBusy(true);
  logLine("ADB Chrome確認 実行中...");
  try {
    const result = await fetchJson(`/api/devices/${encodeURIComponent(serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "launch_url",
        packageName: "com.android.chrome",
        url: "https://www.google.com/",
      }),
    });
    const foreground = result.result?.foreground?.packageName || "unknown";
    const activity = result.result?.foreground?.activity || "";
    const firstRun = /FirstRunActivity/i.test(activity) ? " / Chrome初回画面" : "";
    logLine("ADB Chrome確認 OK: " + (result.result?.packageName || "com.android.chrome") + " / foreground=" + foreground + (activity ? " / activity=" + activity : "") + firstRun);
    await new Promise((resolve) => setTimeout(resolve, 1200));
    await refreshScriptScreenshot();
  } catch (error) {
    logLine("ADB Chrome確認 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function runXiaoweiGeneratedScript() {
  const serial = el("scriptDeviceSelect").value;
  if (!serial) return logLine("XiaoWei実行: 対象端末を選んでください");
  renderScriptBuilder();
  const script = el("scriptOutput").value.trim();
  if (!script) return logLine("XiaoWei実行: 生成JSが空です");
  logScriptCompatibility(script);

  setBusy(true);
  logLine("XiaoWei実行: ログ基準保存...");
  try {
    const baseline = await fetchJson("/api/xiaowei/log-tail?limit=1");
    state.scriptBuilder.logBaseline = {
      file: baseline.file || "",
      lineCount: Number(baseline.lineCount || 0),
      sizeBytes: Number(baseline.sizeBytes || 0),
      markedAt: new Date().toISOString(),
    };

    logLine("XiaoWei実行: 送信中...");
    const result = await fetchJson(`/api/devices/${encodeURIComponent(serial)}/actions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "xiaowei_js",
        script,
      }),
    });
    const foreground = result.result?.foreground?.packageName || "unknown";
    const activity = result.result?.foreground?.activity || "";
    const bytes = result.result?.scriptBytes || script.length;
    logLine(`XiaoWei実行 OK: ${bytes} bytes / foreground=${foreground}${activity ? " / activity=" + activity : ""}`);
    await new Promise((resolve) => setTimeout(resolve, 1200));
    await checkXiaoweiLogDelta();
    await refreshScriptScreenshot();
  } catch (error) {
    logLine("XiaoWei実行 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function checkXiaoweiScriptFolder() {
  setBusy(true);
  logLine("XiaoWei scriptフォルダ確認 実行中...");
  try {
    const result = await fetchJson("/api/xiaowei/scripts");
    const files = (result.files || []).slice(0, 5).map((file) => file.name).join(", ") || "なし";
    const expected = (result.expectedTestScripts || [])
      .map((file) => `${file.name}:${file.present ? "OK" : "不足"}`)
      .join(", ") || "未確認";
    const writable = result.writable ? "書込OK" : "書込NG";
    const extra = result.writeError ? " / " + result.writeError : "";
    logLine(`XiaoWei scriptフォルダ: ${result.exists ? "存在OK" : "未検出"} / ${writable} / テスト=${expected} / JS=${files}${extra}`);
    if (result.exists && !result.writable) {
      logLine("XiaoWei scriptフォルダ: 書込NGのためXiaoWeiのscriptフォルダへ手動配置してください");
    }
  } catch (error) {
    logLine("XiaoWei scriptフォルダ確認 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function installXiaoweiTestScripts() {
  setBusy(true);
  logLine("XiaoWei テストJS配置 実行中...");
  try {
    const result = await fetchJson("/api/xiaowei/scripts/install-tests", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    const copied = (result.copied || []).join(", ") || "なし";
    const failed = (result.failed || []).map((item) => `${item.name}: ${item.error}`).join(" / ");
    const expected = (result.scripts?.expectedTestScripts || [])
      .map((file) => `${file.name}:${file.present ? "OK" : "不足"}`)
      .join(", ") || "未確認";
    logLine(`XiaoWei テストJS配置 ${result.ok ? "OK" : "NG"}: copied=${copied} / テスト=${expected}${failed ? " / " + failed : ""}`);
  } catch (error) {
    logLine("XiaoWei テストJS配置 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function copyAdminInstallCommand() {
  const command = `explorer.exe "C:\\Program Files (x86)\\xiaowei_android\\script"`;
  try {
    await navigator.clipboard.writeText(command);
    logLine("管理者コマンドコピー OK");
  } catch (error) {
    el("scriptOutput").value = command;
    el("scriptOutput").select();
    logLine("管理者コマンドコピー NG: 生成JS欄に出しました");
  }
}

async function checkXiaoweiLogTail() {
  setBusy(true);
  logLine("XiaoWeiログ確認 実行中...");
  try {
    const result = await fetchJson("/api/xiaowei/log-tail?limit=80");
    const keywords = /(script|js|toast|chrome|error|エラー|失敗|launch|autox|app_process)/i;
    const lines = (result.lines || []).filter((line) => keywords.test(line)).slice(-6);
    const summary = lines.length ? lines.join(" | ") : "";
    logLine(`XiaoWeiログ: ${result.file || "なし"} / lines=${result.lineCount || 0} / ${summary}`);
  } catch (error) {
    logLine("XiaoWeiログ確認 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function markXiaoweiLogBaseline() {
  setBusy(true);
  logLine("XiaoWeiログ基準保存 実行中...");
  try {
    const result = await fetchJson("/api/xiaowei/log-tail?limit=1");
    state.scriptBuilder.logBaseline = {
      file: result.file || "",
      lineCount: Number(result.lineCount || 0),
      sizeBytes: Number(result.sizeBytes || 0),
      markedAt: new Date().toISOString(),
    };
    logLine(`XiaoWeiログ基準保存 OK: ${state.scriptBuilder.logBaseline.file} / lines=${state.scriptBuilder.logBaseline.lineCount}`);
  } catch (error) {
    logLine("XiaoWeiログ基準保存 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function checkXiaoweiLogDelta() {
  const baseline = state.scriptBuilder.logBaseline;
  if (!baseline) return logLine("XiaoWeiログ差分確認: 先にログ基準保存を押してください");
  setBusy(true);
  logLine("XiaoWeiログ差分確認 実行中...");
  try {
    const result = await fetchJson("/api/xiaowei/log-tail?limit=500");
    if ((result.file || "") !== baseline.file) {
      logLine(`XiaoWeiログ差分: ログファイル変更 ${baseline.file} -> ${result.file || "なし"}`);
    }
    const allTail = result.lines || [];
    const addedCount = Math.max(0, Number(result.lineCount || 0) - Number(baseline.lineCount || 0));
    const addedLines = addedCount > 0 ? allTail.slice(-Math.min(addedCount, allTail.length)) : [];
    const keywords = /(script|js|toast|chrome|error|エラー|失敗|launch|autox|app_process|open api)/i;
    const relevant = addedLines.filter((line) => keywords.test(line)).slice(-8);
    const summary = relevant.length ? relevant.join(" | ") : (addedLines.length ? addedLines.slice(-3).join(" | ") : "");
    logLine(`XiaoWeiログ差分: +${addedCount}行 / ${summary}`);
  } catch (error) {
    logLine("XiaoWeiログ差分確認 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function setScriptPreviewImage(url) {
  const stage = el("scriptPreviewStage");
  const image = el("scriptPreviewImage");
  const marker = el("scriptTapMarker");
  image.onload = () => {
    stage.classList.add("has-image");
    marker.classList.add("hidden");
    el("scriptPreviewMeta").textContent = `${image.naturalWidth} x ${image.naturalHeight} / ${new Date().toLocaleTimeString("ja-JP")}`;
  };
  image.src = url;
}

function toggleScriptAutoRefresh() {
  if (state.scriptBuilder.autoRefreshTimer) {
    clearInterval(state.scriptBuilder.autoRefreshTimer);
    state.scriptBuilder.autoRefreshTimer = 0;
  }
  if (el("scriptAutoRefreshInput").checked) {
    refreshScriptScreenshot();
    state.scriptBuilder.autoRefreshTimer = setInterval(refreshScriptScreenshot, 3000);
    logLine("JSビルダー: 3秒スクショ更新 ON");
  } else {
    logLine("JSビルダー: 3秒スクショ更新 OFF");
  }
}

function addTapStepFromPreview(event) {
  const image = el("scriptPreviewImage");
  if (!image.naturalWidth || !image.naturalHeight) return;
  const rect = image.getBoundingClientRect();
  const rx = clamp((event.clientX - rect.left) / rect.width, 0, 1);
  const ry = clamp((event.clientY - rect.top) / rect.height, 0, 1);
  const marker = el("scriptTapMarker");
  marker.style.left = `${event.clientX - el("scriptPreviewStage").getBoundingClientRect().left}px`;
  marker.style.top = `${event.clientY - el("scriptPreviewStage").getBoundingClientRect().top}px`;
  marker.classList.remove("hidden");
  addScriptStep({
    type: "tap",
    rx: round(rx, 4),
    ry: round(ry, 4),
    waitMs: scriptWaitMs(),
  });
}

function scriptWaitMs() {
  const waitMs = Number(el("scriptWaitInput").value || 0);
  return Number.isFinite(waitMs) && waitMs >= 0 ? Math.round(waitMs) : 0;
}

function scriptRepeatCount() {
  const repeat = Number(el("scriptRepeatInput").value || 1);
  return Number.isFinite(repeat) && repeat > 0 ? Math.round(repeat) : 1;
}

function addScriptStep(step) {
  state.scriptBuilder.steps.push(step);
  renderScriptBuilder();
}

function setMinimalToastPreset() {
  state.scriptBuilder.steps = [
    { type: "minimal_toast", label: "xiaowei minimal toast", waitMs: 0 },
  ];
  renderScriptBuilder();
  logLine("");
}

function setDebugScriptPreset() {
  state.scriptBuilder.steps = [
    { type: "debug", label: "visible log 1", waitMs: 1000 },
    { type: "debug", label: "visible log 2", waitMs: 1000 },
    { type: "debug", label: "visible log 3", waitMs: 1000 },
  ];
  renderScriptBuilder();
  logLine("JSビルダー: ログテストを生成");
}

function setChromeScriptPreset() {
  const chrome = SCRIPT_PACKAGE_OPTIONS.find((option) => option.packageName === "com.android.chrome") || SCRIPT_PACKAGE_OPTIONS[0];
  state.scriptBuilder.steps = [
    {
      type: "launch",
      packageName: chrome.packageName,
      appName: chrome.appName,
      launchUrl: chrome.launchUrl || "",
      waitMs: 3000,
    },
    {
      type: "chrome_search_focus",
      waitMs: 500,
    },
  ];
  renderScriptBuilder();
  logLine("");
}

function clearScriptSteps() {
  const ok = window.confirm("JSビルダーのステップをクリアします。よろしいですか？");
  if (!ok) return;
  state.scriptBuilder.steps = [];
  renderScriptBuilder();
  logLine("JSビルダー: ステップをクリア");
}

function renderScriptBuilder() {
  const list = el("scriptStepList");
  const output = el("scriptOutput");
  if (!list || !output) return;
  list.innerHTML = state.scriptBuilder.steps.map((step, index) =>
    `<li><span>${esc(scriptStepLabel(step))}</span><button class="script-step-delete" data-step-index="${esc(index)}" type="button" title="この行を削除">削除</button></li>`
  ).join("");
  output.value = buildAutoxScript(state.scriptBuilder.steps, scriptRepeatCount());
}

function handleScriptStepListClick(event) {
  const button = event.target.closest(".script-step-delete");
  if (!button) return;
  const index = Number(button.dataset.stepIndex);
  if (!Number.isInteger(index) || index < 0 || index >= state.scriptBuilder.steps.length) return;
  const [removed] = state.scriptBuilder.steps.splice(index, 1);
  renderScriptBuilder();
  logLine("JSビルダー 行削除: " + scriptStepLabel(removed));
}

function scriptStepLabel(step) {
  if (step.type === "launch") {
    const appName = step.appName ? ` (${step.appName})` : "";
    return `起動 ${step.packageName}${appName} / wait ${step.waitMs}ms`;
  }
  if (step.type === "minimal_toast") return `最小toast ${step.label || ""}`;
  if (step.type === "debug") return `ログ ${step.label || "test"} / wait ${step.waitMs}ms`;
  if (step.type === "chrome_search_focus") return `Chrome検索欄フォーカス / wait ${step.waitMs}ms`;
  if (step.type === "tap") return `tap x=${step.rx} y=${step.ry} / wait ${step.waitMs}ms`;
  if (step.type === "wait") return `wait ${step.waitMs}ms`;
  if (step.type === "text") return `入力 ${step.text} / wait ${step.waitMs}ms`;
  if (step.type === "back") return `戻る / wait ${step.waitMs}ms`;
  if (step.type === "home") return `HOME / wait ${step.waitMs}ms`;
  return step.type || "step";
}

function buildAutoxScript(steps, repeat) {
  if (steps.length === 1 && steps[0].type === "minimal_toast") {
    return `"auto";\ntoast(${JSON.stringify(steps[0].label || "xiaowei minimal toast")});`;
  }

  const lines = [
    "\"auto\";",
    "// Generated by Android Fleet JS Builder",
    "// XiaoWei/AutoJS script test. Test on one device first.",
    "",
    "try {",
    "  if (typeof console !== \"undefined\" && typeof console.hide === \"function\") console.hide();",
    "} catch (error) {}",
    "",
    "function say(message) {",
    "  try {",
    "    if (typeof toast === \"function\") toast(message);",
    "  } catch (error) {}",
    "}",
    "",
    "say(\"script start\");",
    "",
    "function tapRatio(rx, ry) {",
    "  click(Math.round(device.width * rx), Math.round(device.height * ry));",
    "}",
    "",
    "function findOneSafe(selector, timeoutMs) {",
    "  try {",
    "    if (selector && typeof selector.findOne === \"function\") return selector.findOne(timeoutMs || 1000);",
    "  } catch (error) {}",
    "  return null;",
    "}",
    "",
    "function clickNodeSafe(node) {",
    "  if (!node) return false;",
    "  try {",
    "    if (typeof node.click === \"function\" && node.click()) return true;",
    "  } catch (error) {}",
    "  try {",
    "    var b = node.bounds();",
    "    if (b) {",
    "      click(b.centerX(), b.centerY());",
    "      return true;",
    "    }",
    "  } catch (error) {}",
    "  return false;",
    "}",
    "",
    "function focusChromeSearchBox() {",
    "  var target = null;",
    "  try { if (!target && typeof id === \"function\") target = findOneSafe(id(\"search_box_text\"), 1200); } catch (error) {}",
    "  try { if (!target && typeof id === \"function\") target = findOneSafe(id(\"url_bar\"), 1200); } catch (error) {}",
    "  try { if (!target && typeof id === \"function\") target = findOneSafe(id(\"com.android.chrome:id/search_box_text\"), 1200); } catch (error) {}",
    "  try { if (!target && typeof id === \"function\") target = findOneSafe(id(\"com.android.chrome:id/url_bar\"), 1200); } catch (error) {}",
    "  try { if (!target && typeof descMatches === \"function\") target = findOneSafe(descMatches(/検索|Search|URL|アドレス|address/i), 1200); } catch (error) {}",
    "  try { if (!target && typeof textMatches === \"function\") target = findOneSafe(textMatches(/検索|Search|URL|アドレス|address|google/i), 1200); } catch (error) {}",
    "  if (clickNodeSafe(target)) {",
    "    say(\"chrome search focus ok\");",
    "    return true;",
    "  }",
    "  tapRatio(0.24, 0.35);",
    "  say(\"chrome search focus fallback\");",
    "  return false;",
    "}",
    "",
    "function openPackage(packageName, appName, launchUrl) {",
    "  var ok = false;",
    "  try {",
    "    if (launchUrl && typeof app !== \"undefined\" && typeof app.startActivity === \"function\") {",
    "      say(\"try app.startActivity: \" + launchUrl);",
    "      app.startActivity({",
    "        action: \"VIEW\",",
    "        data: launchUrl",
    "      });",
    "      ok = true;",
    "    }",
    "  } catch (error) {",
    "    say(\"startActivity failed\");",
    "  }",
    "  try {",
    "    if (!ok) say(\"try launchPackage: \" + packageName);",
    "    if (typeof launchPackage === \"function\") ok = launchPackage(packageName);",
    "  } catch (error) {}",
    "  try {",
    "    if (!ok) say(\"try app.launchPackage: \" + packageName);",
    "    if (!ok && typeof app !== \"undefined\" && typeof app.launchPackage === \"function\") ok = app.launchPackage(packageName);",
    "  } catch (error) {}",
    "  try {",
    "    if (!ok && appName && typeof launchApp === \"function\") {",
    "      say(\"try launchApp: \" + appName);",
    "      ok = launchApp(appName);",
    "    }",
    "  } catch (error) {}",
    "  say(ok ? \"launch ok\" : \"launch failed: \" + packageName);",
    "  return ok;",
    "}",
    "",
    `for (var run = 0; run < ${Math.max(1, repeat)}; run++) {`,
  ];
  for (const step of steps) {
    if (step.type === "launch") {
      lines.push(`  openPackage(${JSON.stringify(step.packageName || "com.android.chrome")}, ${JSON.stringify(step.appName || "")}, ${JSON.stringify(step.launchUrl || "")});`);
      appendSleep(lines, step.waitMs);
    } else if (step.type === "debug") {
      lines.push(`  say(${JSON.stringify(step.label || "visible log test")});`);
      appendSleep(lines, step.waitMs);
    } else if (step.type === "tap") {
      lines.push(`  tapRatio(${Number(step.rx).toFixed(4)}, ${Number(step.ry).toFixed(4)});`);
      appendSleep(lines, step.waitMs);
    } else if (step.type === "chrome_search_focus") {
      lines.push("  focusChromeSearchBox();");
      appendSleep(lines, step.waitMs);
    } else if (step.type === "wait") {
      appendSleep(lines, step.waitMs);
    } else if (step.type === "text") {
      lines.push(`  setText(${JSON.stringify(step.text || "")});`);
      appendSleep(lines, step.waitMs);
    } else if (step.type === "back") {
      lines.push("  back();");
      appendSleep(lines, step.waitMs);
    } else if (step.type === "home") {
      lines.push("  home();");
      appendSleep(lines, step.waitMs);
    }
  }
  lines.push("}");
  lines.push("");
  lines.push("say(\"script done\");");
  return lines.join("\n");
}

function appendSleep(lines, waitMs) {
  const value = Number(waitMs || 0);
  if (value > 0) lines.push(`  sleep(${Math.round(value)});`);
}

async function copyScriptOutput() {
  const text = el("scriptOutput").value;
  logScriptCompatibility(text);
  await writeClipboardText(text, "JSビルダー コピー");
}

async function writeClipboardText(text, label = "コピー") {
  let browserCopied = false;
  try {
    await navigator.clipboard.writeText(text);
    browserCopied = true;
  } catch (error) {
    browserCopied = false;
  }

  if (browserCopied) {
    logLine(`${label} OK`);
    return;
  }

  try {
    const result = await fetchJson("/api/pc/clipboard", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ text }),
    });
    logLine(`${label} OK: PCクリップボード ${result.length || String(text || "").length}文字`);
    return;
  } catch (error) {
    el("scriptOutput").value = text;
    el("scriptOutput").select();
    const copied = document.execCommand("copy");
    logLine(`${label} ${copied ? "OK" : "NG"}: ブラウザ/PCクリップボード不可${error.message ? " / " + error.message : ""}`);
  }
}

function downloadScriptOutput() {
  const text = el("scriptOutput").value;
  logScriptCompatibility(text);
  const blob = new Blob([text], { type: "text/javascript;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `autox-script-${localTimestampForFile()}.js`;
  link.click();
  URL.revokeObjectURL(url);
  logLine("JSビルダー JS保存 OK");
}

function logScriptCompatibility(text) {
  const issues = [];
  if (/\blet\b/.test(text)) issues.push("let");
  if (/\bconst\b/.test(text)) issues.push("const");
  if (/=>/.test(text)) issues.push("=>");
  if (issues.length) {
    logLine("JSビルダー 互換注意: XiaoWei/AutoJS環境によって落ちる可能性 " + issues.join(", "));
  } else {
    logLine("");
  }
}

async function exportBranchReport() {
  setBusy(true);
  try {
    const summary = state.summary || await fetchJson("/api/fleet-db/summary");
    const siteName = summary.settings?.siteName || "Android Fleet";
    const payload = {
      kind: "android-fleet-branch-report",
      version: 2,
      siteName,
      exportedAt: new Date().toISOString(),
      withdrawals: summary.withdrawals || [],
    };
    const text = JSON.stringify(payload, null, 2);
    const fileName = `android-fleet-report_${siteName}_${localDateInputValue()}_${localTimestampForFile()}.json`.replace(/[\\/:*?"<>|]/g, "_");
    await saveTextFile(fileName, text, "支店日報JSON");
  } catch (error) {
    if (error && error.name === "AbortError") logLine("支店日報出力 キャンセル");
    else logLine("支店日報出力 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function importBranchReportFile() {
  const file = el("branchReportFileInput").files[0];
  el("branchReportFileInput").value = "";
  if (!file) return;
  setBusy(true);
    logLine("日報取込 プレビュー中...");
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    const preview = await fetchJson("/api/fleet-db/preview-branch-report", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(data),
    });
    const message = [
      "日報取込プレビュー",
      "",
      `拠点: ${preview.siteName || data.siteName || "支店"}`,
      `総件数: ${preview.total || 0}件`,
      `追加予定: ${preview.importable || 0}件`,
      `重複スキップ: ${preview.duplicate || 0}件`,
      `要確認: ${preview.invalid || 0}件`,
      "",
      "この内容で取り込みますか？",
    ].join("\n");
    logLine(`日報取込 プレビュー: 追加 ${preview.importable || 0}件 / 重複 ${preview.duplicate || 0}件 / 要確認 ${preview.invalid || 0}件`);
    if (!window.confirm(message)) {
      logLine("日報取込 キャンセル");
      return;
    }
    logLine("日報取込 実行中...");
    const result = await fetchJson("/api/fleet-db/import-branch-report", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(data),
    });
    logLine(`日報取込 OK: 追加 ${result.imported}件 / スキップ ${result.skipped}件`);
    await loadSummary();
  } catch (error) {
    logLine("日報取込 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function saveTextFile(fileName, text, description) {
  if (window.showSaveFilePicker) {
    const handle = await window.showSaveFilePicker({
      suggestedName: fileName,
      types: [{
        description,
        accept: { "application/json": [".json"] },
      }],
    });
    const writable = await handle.createWritable();
    await writable.write(text);
    await writable.close();
    logLine("日報出力 OK: " + handle.name);
    return;
  }
  const blob = new Blob([text], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  link.click();
  URL.revokeObjectURL(url);
  logLine("");
}

async function fetchJson(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok || data.ok === false) {
    const portText = Array.isArray(data.triedAdbPorts)
      ? " / tried: " + data.triedAdbPorts.map((item) => item.adbPort || "default").join(", ")
      : "";
    const error = new Error(data.error || data.message || data.result?.stderr || data.result?.stdout || data.code || response.statusText + portText);
    error.code = String(data.code || "");
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}

async function privateFetchJson(url, options = {}) {
  const session = await fetchJson("/api/local-session-token");
  const headers = new Headers(options.headers || {});
  headers.set(String(session.header || "x-android-fleet-session"), String(session.token || ""));
  return fetchJson(url, {
    ...options,
    headers,
  });
}

async function fetchJsonResult(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok && !data.results && !data.packageSummary) {
    const portText = Array.isArray(data.triedAdbPorts)
      ? " / tried: " + data.triedAdbPorts.map((item) => item.adbPort || "default").join(", ")
      : "";
    throw new Error(data.error || data.message || data.result?.stderr || data.result?.stdout || data.code || response.statusText + portText);
  }
  return data;
}

function renderAll(data) {
  renderSiteName(data.settings?.siteName || "Android Fleet");
  renderAppVersion(data.appVersion);
  renderGlobalErrorRate(data.errorStats);
  renderGlobalInviteRate(inviteAnalyticsRows(data));
  renderDeviceDbFleetCounts(data.devices || []);
  const license = data.license || {};
  const customerText = license.customerId
    ? `購入ID ${license.customerId}${license.packageId ? ` / ${license.packageId}` : ""}`
    : "";
  el("appMeta").textContent = [
    `登録端末 ${data.counts.devices}台`,
    Number(data.counts.offlineDevices || 0) ? `未接続 ${Number(data.counts.offlineDevices)}台` : "",
    `出金 ${data.counts.withdrawals}件`,
    customerText,
    formatDateTime(data.generatedAt),
  ].filter(Boolean).join(" / ");
  el("retiredDevicesBtn").textContent = Number(data.counts?.retired || 0)
    ? `管理対象外 (${Number(data.counts.retired)})`
    : "管理対象外";
  renderWithdrawalForm([...(data.devices || []), ...(data.offlineDevices || [])], data.withdrawals || []);
  renderDevices(data.devices || []);
  renderOfflineDeviceDb(data.offlineDevices || []);
  renderWithdrawals(data.withdrawals || []);
  renderDeviceRevenue(data.deviceRevenue || []);
  renderMonthlyRevenue(data.monthlyRevenue || [], data.monthlyRevenueBySite || [], data.siteRevenue || []);
  renderScriptBuilderDevices(data.devices || []);
  renderClipboardDevices(data.devices || []);
  renderApnTargets(data.devices || []);
  renderOperationGroupSavedList();
  renderOperationGroupPicker();
  renderClipboardItems();
  renderRewardCalculator();
  renderDeviceMaster(state.deviceMaster);
}

function inviteAnalyticsRows(summary = state.summary) {
  const source = summary && typeof summary === "object" ? summary : {};
  const connected = Array.isArray(source.devices) ? source.devices : [];
  const offline = (Array.isArray(source.offlineDevices) ? source.offlineDevices : [])
    .filter((row) => row && row.status !== "archived");
  return [...connected, ...offline];
}

function renderDeviceDbFleetCounts(rows = []) {
  const devices = Array.isArray(rows) ? rows : [];
  const active = devices.filter((row) => deviceOrderBand(row) === "active").length;
  el("deviceDbActiveCount").textContent = `稼働 ${active}台`;
  el("deviceDbInactiveCount").textContent = `非稼働 ${devices.length - active}台`;
}

function offlineDeviceById(offlineId) {
  return (state.summary?.offlineDevices || []).find((row) => row.offlineId === offlineId) || null;
}

function offlineCurrentDay(row, now = new Date()) {
  const start = String(row?.operationStartedOn || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(start)) return 0;
  const parse = (value) => {
    const [year, month, day] = value.split("-").map(Number);
    return Date.UTC(year, month - 1, day);
  };
  const elapsed = Math.max(0, Math.floor((parse(localDateInputValue(now)) - parse(start)) / 86400000));
  return Math.min(14, Math.max(1, Number(row.initialDay || 1) + elapsed));
}

function offlineCurrentUptimeMinutes(row, nowMs = Date.now()) {
  let minutes = Number(row?.uptimeBaseMinutes || 0);
  const recordedAt = Date.parse(row?.uptimeRecordedAt || "");
  if (row?.uptimeRunning && row?.status === "active" && Number.isFinite(recordedAt)) {
    minutes += Math.max(0, Math.floor((nowMs - recordedAt) / 60000));
  }
  return Math.max(0, Math.round(minutes));
}

function offlineRestTiming(row, nowMs = Date.now()) {
  if (row?.status !== "resting" || !row?.restStartedAt) return { state: "none", remainingMinutes: 0, endsAt: "" };
  const startedAt = Date.parse(row.restStartedAt);
  const endsAtMs = startedAt + Number(row.restHours || 24) * 3600000;
  const remainingMinutes = Math.max(0, Math.ceil((endsAtMs - nowMs) / 60000));
  return {
    state: remainingMinutes > 0 ? "resting" : "ready",
    remainingMinutes,
    endsAt: Number.isFinite(endsAtMs) ? new Date(endsAtMs).toISOString() : "",
  };
}

function offlineStatusInfo(row, nowMs = Date.now()) {
  if (row?.status === "archived") return { key: "archived", label: "管理終了" };
  if (row?.status === "resting") {
    return offlineRestTiming(row, nowMs).state === "ready"
      ? { key: "ready", label: "寝かせ完了" }
      : { key: "resting", label: "寝かせ中" };
  }
  if (row?.status === "completed") return { key: "complete", label: "完走" };
  if (offlineCurrentDay(row, new Date(nowMs)) >= 14) return { key: "complete", label: "完走待ち" };
  return { key: "active", label: "稼働中" };
}

function offlineDurationLabel(minutes) {
  const value = Math.max(0, Math.round(Number(minutes || 0)));
  const days = Math.floor(value / 1440);
  const hours = Math.floor((value % 1440) / 60);
  const mins = value % 60;
  if (days) return `${days}日 ${hours}時間`;
  if (hours) return `${hours}時間 ${mins}分`;
  return `${mins}分`;
}

function offlineTaskConfigLabel(config = {}) {
  const values = [
    Number(config.ciYen || 0) ? `CI ${yen(config.ciYen)}` : "",
    Number(config.video180PointsPerDay || 0) ? `180分 ${number(config.video180PointsPerDay)}P` : "",
    Number(config.video10Yen || 0) ? `追加 ${yen(config.video10Yen)}` : "",
  ].filter(Boolean);
  return values.length ? values.map((value) => `<span>${esc(value)}</span>`).join("") : `<span class="muted">未設定</span>`;
}

function offlineActionButtons(row, status) {
  const id = esc(row.offlineId || "");
  const buttons = [`<button class="offline-row-action" data-offline-edit="${id}" type="button">編集</button>`];
  if (status.key === "active" || status.key === "complete") {
    buttons.push(`<button class="offline-row-action" data-offline-action="toggle-uptime" data-offline-id="${id}" type="button">${row.uptimeRunning ? "UPTIME停止" : "UPTIME開始"}</button>`);
    buttons.push(`<button class="offline-row-action primary-action" data-offline-action="complete-cycle" data-offline-id="${id}" type="button">完走→寝かせ</button>`);
  } else if (status.key === "ready" || row.status === "completed") {
    buttons.push(`<button class="offline-row-action primary-action" data-offline-action="start-cycle" data-offline-id="${id}" type="button">次周期開始</button>`);
  }
  if (status.key === "archived") {
    buttons.push(`<button class="offline-row-action" data-offline-action="restore" data-offline-id="${id}" type="button">管理再開</button>`);
  } else {
    buttons.push(`<button class="offline-row-action danger-action" data-offline-action="archive" data-offline-id="${id}" type="button">管理終了</button>`);
  }
  return buttons.join("");
}

function offlineInviteProfileSummary(row, product) {
  const profile = inviteProfileForRow(row, product.value);
  const details = [
    profile.ttlRegisterMethod,
    profile.inviteType,
    profile.inviteRole,
    profile.inviteResult,
    invitePartnerLabel(profile.invitePartner),
  ].filter(Boolean);
  const resultTone = inviteResultKind(profile.inviteResult);
  return `
    <div class="offline-invite-profile ${esc(resultTone || "empty")}">
      <strong>${esc(product.label)}</strong>
      <span>${details.length ? esc(details.join(" / ")) : "未設定"}</span>
    </div>`;
}

function renderOfflineInviteSummary(row) {
  const entries = inviteHistoryEntries(row);
  const stats = inviteHistoryStats(row, entries);
  const device = row.offlineId || row.serial || "";
  const title = stats.total
    ? `未接続DB: 成功 ${stats.success}件 / 失敗 ${stats.fail}件`
    : "未接続DBの招待結果はまだありません";
  return `
    <div class="offline-invite-summary">
      ${INVITE_PRODUCTS.map((product) => offlineInviteProfileSummary(row, product)).join("")}
      <button class="invite-device-rate-btn ${esc(inviteSuccessRateTone(stats))}"
        data-invite-analytics-device="${esc(device)}" type="button" title="${esc(title)}">招待成功率 ${esc(stats.rateLabel)}</button>
    </div>`;
}

function renderOfflineDeviceDb(rows = []) {
  const devices = Array.isArray(rows) ? rows : [];
  const nowMs = Date.now();
  const liveRows = devices.filter((row) => row.status !== "archived");
  const statusRows = liveRows.map((row) => ({ row, status: offlineStatusInfo(row, nowMs) }));
  const activeCount = statusRows.filter((item) => ["active", "complete"].includes(item.status.key)).length;
  const restingCount = statusRows.filter((item) => item.status.key === "resting").length;
  const readyRows = statusRows.filter((item) => item.status.key === "ready").map((item) => item.row);
  el("offlineDeviceTotal").textContent = `稼働 ${activeCount}台`;
  el("offlineDeviceResting").textContent = `寝かせ中 ${restingCount}台`;
  el("offlineDeviceReady").textContent = `寝かせ完了 ${readyRows.length}台`;
  el("offlineDeviceTotal").title = `登録 ${liveRows.length}台 / 管理終了 ${devices.length - liveRows.length}台`;
  const alert = el("offlineReadyAlert");
  alert.classList.toggle("hidden", readyRows.length === 0);
  alert.textContent = readyRows.length
    ? `寝かせ完了: ${readyRows.map((row) => `${row.number} ${row.name}`).join(" / ")}`
    : "";
  if (!el("offlineDeviceStartDateInput").value) el("offlineDeviceStartDateInput").value = localDateInputValue();

  const body = el("offlineDeviceRows");
  if (!devices.length) {
    body.innerHTML = `<tr class="offline-empty-row"><td colspan="11">未接続端末はまだ登録されていません</td></tr>`;
    return;
  }
  body.innerHTML = devices.map((row) => {
    const status = offlineStatusInfo(row, nowMs);
    const day = offlineCurrentDay(row, new Date(nowMs));
    const uptimeMinutes = offlineCurrentUptimeMinutes(row, nowMs);
    const uptimeHours = uptimeMinutes / 60;
    const rest = offlineRestTiming(row, nowMs);
    const restText = status.key === "ready"
      ? "完了"
      : status.key === "resting"
        ? `残り ${offlineDurationLabel(rest.remainingMinutes)}`
        : "-";
    const tasks = row.todayTasks || {};
    const taskDisabled = row.status === "archived" ? "disabled" : "";
    const withdrawalText = Number(row.withdrawalCount || 0)
      ? `${Number(row.withdrawalCount)}件 / ${yen(row.withdrawalTotalYen || 0)}`
      : "0件";
    return `
      <tr class="offline-device-row offline-row-${esc(status.key)}" data-offline-id="${esc(row.offlineId || "")}" data-offline-status="${esc(status.key)}">
        <td class="offline-device-identity"><strong>No.${esc(row.number || "-")}</strong><span>${esc(row.name || row.offlineId || "")}</span><small>${esc([row.model, row.carrier, row.simStatus, row.offlineId].filter(Boolean).join(" / "))}</small></td>
        <td><strong class="offline-day-value">${day ? `DAY ${day}` : "-"}</strong><small>${esc(row.operationStartedOn || "")}</small></td>
        <td><span class="offline-status-badge ${esc(status.key)}">${esc(status.label)}</span><small>${Number(row.completedCycles || 0) ? `${Number(row.completedCycles)}周期完了` : ""}</small></td>
        <td><span class="uptime-pill ${uptimeBandClass(uptimeHours)} offline-uptime-value">${esc(uptimeLabel(uptimeHours))}</span><small>${row.uptimeRunning && row.status === "active" ? "カウント中" : "停止中"}</small></td>
        <td><strong class="offline-rest-value">${esc(restText)}</strong><small>${rest.endsAt ? `${formatDateTime(rest.endsAt)}まで` : `${Number(row.restHours || 24)}時間設定`}</small></td>
        <td class="offline-task-cell">
          <label><input class="offline-task-check" data-task="ci" type="checkbox" ${tasks.ci ? "checked" : ""} ${taskDisabled}> CI</label>
          <label><input class="offline-task-check" data-task="video180" type="checkbox" ${tasks.video180 ? "checked" : ""} ${taskDisabled}> 180分</label>
          <label><input class="offline-task-check" data-task="video10" type="checkbox" ${tasks.video10 ? "checked" : ""} ${taskDisabled}> 追加</label>
        </td>
        <td class="offline-task-config">${offlineTaskConfigLabel(row.taskConfig)}</td>
        <td>${renderOfflineInviteSummary(row)}</td>
        <td><strong>${esc(withdrawalText)}</strong><small>${esc(row.lastWithdrawalDate || "")}</small></td>
        <td class="offline-notes-cell">${esc(row.notes || "-")}</td>
        <td><span class="offline-row-actions">${offlineActionButtons(row, status)}</span></td>
      </tr>`;
  }).join("");
}

async function saveOfflineDevice(event) {
  event.preventDefault();
  const offlineId = el("offlineDeviceIdInput").value.trim();
  const payload = {
    offlineId,
    number: el("offlineDeviceNumberInput").value,
    name: el("offlineDeviceNameInput").value.trim(),
    model: el("offlineDeviceModelInput").value.trim(),
    carrier: el("offlineDeviceCarrierInput").value.trim(),
    simStatus: el("offlineDeviceSimInput").value,
    networkType: el("offlineDeviceNetworkInput").value,
    networkSwitchedDay: el("offlineDeviceNetworkSwitchedDayInput").value,
    osVersion: el("offlineDeviceOsInput").value.trim(),
    operationStartedOn: el("offlineDeviceStartDateInput").value,
    initialDay: Number(el("offlineDeviceInitialDayInput").value || 1),
    uptimeHours: Number(el("offlineDeviceUptimeInput").value || 0),
    uptimeRunning: el("offlineDeviceUptimeRunningInput").checked,
    restHours: Number(el("offlineDeviceRestHoursInput").value || 24),
    inviteProduct: el("offlineDeviceInviteProductInput").value,
    ttlRegisterMethod: el("offlineDeviceRegisterMethodInput").value,
    inviteType: el("offlineDeviceInviteTypeInput").value,
    inviteRole: el("offlineDeviceInviteRoleInput").value,
    inviteResult: el("offlineDeviceInviteResultInput").value,
    invitePartner: el("offlineDeviceInvitePartnerInput").value.trim(),
    inviteOpsNote: el("offlineDeviceInviteNoteInput").value.trim(),
    notes: el("offlineDeviceNotesInput").value.trim(),
    taskConfig: {
      ciYen: Number(el("offlineDeviceCiInput").value || 0),
      video180PointsPerDay: Number(el("offlineDeviceVideo180Input").value || 0),
      video10Yen: Number(el("offlineDeviceVideo10Input").value || 0),
    },
  };
  setBusy(true, el("offlineDeviceSaveBtn"), offlineId ? "更新中..." : "登録中...");
  try {
    const result = await fetchJson("/api/fleet-db/offline-devices/upsert", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    logLine(`${offlineId ? "未接続端末更新" : "未接続端末登録"} OK: No.${result.device.number} ${result.device.name}`);
    clearOfflineDeviceForm();
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine(`${offlineId ? "未接続端末更新" : "未接続端末登録"} NG: ${error.message}`);
    window.alert(error.message);
  } finally {
    setBusy(false);
  }
}

function populateOfflineInviteProfile(row, product) {
  const selectedProduct = normalizeInviteProduct(product);
  const profile = row ? inviteProfileForRow(row, selectedProduct) : {};
  el("offlineDeviceRegisterMethodInput").value = profile.ttlRegisterMethod || "";
  const typeSelect = el("offlineDeviceInviteTypeInput");
  typeSelect.querySelector('option[data-legacy-invite-type="true"]')?.remove();
  if (profile.inviteType && ![...typeSelect.options].some((option) => option.value === profile.inviteType)) {
    const legacyOption = document.createElement("option");
    legacyOption.value = profile.inviteType;
    legacyOption.textContent = `${profile.inviteType}（旧データ）`;
    legacyOption.dataset.legacyInviteType = "true";
    legacyOption.disabled = true;
    typeSelect.appendChild(legacyOption);
  }
  typeSelect.value = profile.inviteType || "";
  el("offlineDeviceInviteRoleInput").value = profile.inviteRole || "";
  el("offlineDeviceInviteResultInput").value = profile.inviteResult || "";
  el("offlineDeviceInvitePartnerInput").value = invitePartnerLabel(profile.invitePartner) || "";
  el("offlineDeviceInviteNoteInput").value = profile.inviteOpsNote || "";
  updateOfflineInviteProductAppearance(selectedProduct);
}

function handleOfflineInviteProductChange() {
  const row = state.offlineEditingId ? offlineDeviceById(state.offlineEditingId) : null;
  populateOfflineInviteProfile(row, el("offlineDeviceInviteProductInput").value);
}

function handleOfflineInviteProductToggle(event) {
  const button = event.target.closest("[data-offline-invite-product]");
  if (!button) return;
  const product = normalizeInviteProduct(button.dataset.offlineInviteProduct);
  if (product === normalizeInviteProduct(el("offlineDeviceInviteProductInput").value)) return;
  el("offlineDeviceInviteProductInput").value = product;
  handleOfflineInviteProductChange();
}

function updateOfflineInviteProductAppearance(product = el("offlineDeviceInviteProductInput")?.value) {
  const selectedProduct = normalizeInviteProduct(product);
  const input = el("offlineDeviceInviteProductInput");
  if (input) input.value = selectedProduct;
  const editor = el("offlineDeviceEditorGrid");
  const card = el("offlineInviteEditorCard");
  if (editor) editor.dataset.inviteProduct = selectedProduct;
  if (card) card.dataset.inviteProduct = selectedProduct;
  for (const button of document.querySelectorAll("[data-offline-invite-product]")) {
    const active = normalizeInviteProduct(button.dataset.offlineInviteProduct) === selectedProduct;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", active ? "true" : "false");
  }
  const method = el("offlineDeviceRegisterMethodInput")?.value || "導入方法未設定";
  const title = el("offlineInviteEditorTitle");
  if (title) title.textContent = `TikTok ${selectedProduct === "main" ? "本家" : "Lite"}: ${method}`;
}

function clearOfflineDeviceForm() {
  if (!el("offlineDeviceForm")) return;
  state.offlineEditingId = "";
  el("offlineDeviceIdInput").value = "";
  el("offlineDeviceForm").reset();
  el("offlineDeviceStartDateInput").value = localDateInputValue();
  el("offlineDeviceInitialDayInput").value = "1";
  el("offlineDeviceUptimeInput").value = "0";
  el("offlineDeviceUptimeRunningInput").checked = true;
  el("offlineDeviceRestHoursInput").value = "24";
  el("offlineDeviceInviteProductInput").value = "lite";
  populateOfflineInviteProfile(null, "lite");
  el("offlineDeviceStatusPreview").textContent = "新規";
  el("offlineDeviceSaveBtn").textContent = "手動登録";
  el("offlineDeviceCancelBtn").classList.add("hidden");
}

function startOfflineDeviceEdit(offlineId) {
  const row = offlineDeviceById(offlineId);
  if (!row) return logLine("未接続端末編集 NG: 端末が見つかりません");
  state.offlineEditingId = offlineId;
  el("offlineDeviceIdInput").value = offlineId;
  el("offlineDeviceNumberInput").value = row.number || "";
  el("offlineDeviceNameInput").value = row.name || "";
  el("offlineDeviceModelInput").value = row.model || "";
  el("offlineDeviceCarrierInput").value = row.carrier || "";
  el("offlineDeviceSimInput").value = row.simStatus || "";
  el("offlineDeviceNetworkInput").value = row.networkType || "";
  el("offlineDeviceNetworkSwitchedDayInput").value = row.networkSwitchedDay || "";
  el("offlineDeviceOsInput").value = row.osVersion || "";
  el("offlineDeviceStartDateInput").value = row.operationStartedOn || localDateInputValue();
  el("offlineDeviceInitialDayInput").value = row.initialDay || 1;
  el("offlineDeviceUptimeInput").value = (offlineCurrentUptimeMinutes(row) / 60).toFixed(1);
  el("offlineDeviceUptimeRunningInput").checked = row.uptimeRunning === true && row.status === "active";
  el("offlineDeviceRestHoursInput").value = row.restHours || 24;
  el("offlineDeviceCiInput").value = row.taskConfig?.ciYen || "";
  el("offlineDeviceVideo180Input").value = row.taskConfig?.video180PointsPerDay || "";
  el("offlineDeviceVideo10Input").value = row.taskConfig?.video10Yen || "";
  el("offlineDeviceInviteProductInput").value = "lite";
  populateOfflineInviteProfile(row, "lite");
  el("offlineDeviceStatusPreview").textContent = offlineStatusInfo(row).label;
  el("offlineDeviceNotesInput").value = row.notes || "";
  el("offlineDeviceSaveBtn").textContent = "登録内容を更新";
  el("offlineDeviceCancelBtn").classList.remove("hidden");
  el("offlineDeviceForm").scrollIntoView({ behavior: "smooth", block: "start" });
  el("offlineDeviceNumberInput").focus({ preventScroll: true });
}

function handleOfflineDeviceRowAction(event) {
  const inviteAnalyticsButton = event.target.closest("[data-invite-analytics-device]");
  if (inviteAnalyticsButton) {
    showInviteAnalyticsDialog(inviteAnalyticsButton.dataset.inviteAnalyticsDevice || "");
    return;
  }
  const edit = event.target.closest("[data-offline-edit]");
  if (edit) return startOfflineDeviceEdit(edit.dataset.offlineEdit || "");
  const button = event.target.closest("[data-offline-action]");
  if (!button) return;
  runOfflineDeviceAction(button.dataset.offlineId || "", button.dataset.offlineAction || "", button);
}

async function runOfflineDeviceAction(offlineId, action, button) {
  const row = offlineDeviceById(offlineId);
  if (!row) return logLine("未接続端末操作 NG: 端末が見つかりません");
  const confirmations = {
    "complete-cycle": "完走として記録し、寝かせ時間のカウントを開始します。よろしいですか？",
    "start-cycle": "寝かせ完了としてDAY 1から次周期を開始します。よろしいですか？",
    archive: "この端末を管理終了にします。履歴と出金記録は残ります。よろしいですか？",
    restore: "この端末の管理を再開します。DAY 1、UPTIME停止で再開します。よろしいですか？",
  };
  if (confirmations[action] && !window.confirm(confirmations[action])) return;
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/fleet-db/offline-devices/action", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        offlineId,
        action,
        operationStartedOn: action === "start-cycle" ? localDateInputValue() : undefined,
        initialDay: action === "start-cycle" ? 1 : undefined,
      }),
    });
    logLine(`未接続端末操作 OK: No.${result.device.number} ${result.device.name}`);
    if (state.offlineEditingId === offlineId && action !== "toggle-uptime") clearOfflineDeviceForm();
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine(`未接続端末操作 NG: ${error.message}`);
    window.alert(error.message);
  } finally {
    setBusy(false);
  }
}

async function handleOfflineDeviceTaskChange(event) {
  const checkbox = event.target.closest(".offline-task-check");
  if (!checkbox) return;
  const tableRow = checkbox.closest("tr[data-offline-id]");
  const offlineId = tableRow?.dataset.offlineId || "";
  const checks = Object.fromEntries([...tableRow.querySelectorAll(".offline-task-check")].map((input) => [input.dataset.task, input.checked]));
  for (const input of tableRow.querySelectorAll(".offline-task-check")) input.disabled = true;
  tableRow.classList.add("saving");
  try {
    await fetchJson("/api/fleet-db/offline-devices/task-checks", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ offlineId, date: localDateInputValue(), ...checks }),
    });
    logLine(`未接続タスク保存 OK: ${offlineDeviceById(offlineId)?.number || offlineId} ${Object.values(checks).filter(Boolean).length}/3`);
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine(`未接続タスク保存 NG: ${error.message}`);
    await loadLocalSummaryOnly().catch(() => {});
  }
}

function renderGlobalErrorRate(stats = {}) {
  const target = el("globalErrorRate");
  if (!target) return;
  const rate = stats && stats.rateLabel || "-";
  const noError = Number(stats && stats.noError || 0);
  const day1 = Number(stats && stats.day1 || 0);
  const day2Plus = Number(stats && stats.day2Plus || 0);
  const unclassified = Number(stats && stats.unclassified || 0);
  target.textContent = `ERROR率 ${rate}`;
  target.classList.toggle("empty", !stats || !Number(stats.total || 0));
  target.title = `エラーなし ${noError}件 / 初日 ${day1}件 / 2日目以降 ${day2Plus}件${unclassified ? ` / 判定待ち ${unclassified}件` : ""}`;
}

function renderGlobalInviteRate(rows = []) {
  const target = el("inviteAnalyticsBtn");
  if (!target) return;
  const analytics = inviteAnalyticsSnapshot(rows);
  target.textContent = `招待成功率 ${analytics.rateLabel}`;
  target.className = `global-invite-rate ${inviteSuccessRateTone(analytics)}`;
  target.title = analytics.total
    ? `接続DB＋未接続DB: 成功 ${analytics.success}件 / 失敗 ${analytics.fail}件 / クリックして分析`
    : "招待結果の記録はまだありません";
}

function renderSiteName(siteName) {
  const name = siteName || "Android Fleet";
  el("appTitle").textContent = name;
  el("siteNameInput").value = name;
  document.title = name;
}

function renderAppVersion(version = {}) {
  const badge = el("appVersionBadge");
  if (!badge) return;
  const updateId = String(version.updateId || "").trim();
  const label = String(version.label || updateId || "版情報なし").trim();
  badge.textContent = `適用版 ${label}`;
  badge.classList.toggle("version-untracked", !updateId);
  const details = [
    updateId ? `適用ID: ${updateId}` : "適用ID: 記録なし",
    version.displayName ? `内容: ${version.displayName}` : "",
    version.appliedAt ? `適用日時: ${version.appliedAt}` : "",
    version.stateConsistent === false ? "更新記録と更新状態が一致していません" : "",
  ].filter(Boolean);
  badge.title = details.join("\n");
  badge.setAttribute("aria-label", details.join("。"));
}

function renderWithdrawalForm(rows, withdrawals = []) {
  const input = el("withdrawalDeviceSelect");
  const list = el("withdrawalDeviceOptions");
  const current = input.value;
  const previousSelection = state.withdrawalDeviceSelection;
  const sortedRows = rows.slice().sort(compareWithdrawalDeviceOptions);
  const entries = withdrawalDeviceOptionEntries(sortedRows, withdrawals);
  state.withdrawalDeviceOptions = entries;
  list.innerHTML = entries.map((entry) => (
    `<option value="${esc(entry.label)}" data-device-value="${esc(entry.device)}" data-subject-kind="${esc(entry.subjectKind)}" data-subject-id="${esc(entry.subjectId)}" data-device-name="${esc(entry.deviceName)}"></option>`
  )).join("");
  if (previousSelection) {
    const selected = entries.find((entry) => sameWithdrawalDeviceSelection(entry, previousSelection));
    if (selected && normalizeWithdrawalDeviceLabel(current) === normalizeWithdrawalDeviceLabel(previousSelection.label)) {
      input.value = selected.label;
      state.withdrawalDeviceSelection = selected;
    }
  }
  if (!el("withdrawalDateInput").value) el("withdrawalDateInput").value = localDateInputValue();
}

function withdrawalDeviceOptionEntries(rows, withdrawals = []) {
  const entries = rows.map((row) => {
    const device = row.serial || row.managementId || "";
    const subjectKind = row.isOffline ? "offline" : "fleet";
    return {
      label: formatWithdrawalDeviceOptionLabel(row),
      device,
      subjectKind,
      subjectId: `${subjectKind}:${device}`,
      deviceName: row.deviceLabel || row.laixiName || row.deviceName || row.name || row.model || device,
    };
  }).filter((entry) => entry.device && entry.label);
  const customSeen = new Set();
  for (const row of withdrawals) {
    if (String(row?.subjectKind || "").toLowerCase() !== "custom" || !row?.subjectId || !row?.deviceName) continue;
    const key = String(row.subjectId).toLowerCase();
    if (customSeen.has(key)) continue;
    customSeen.add(key);
    entries.push({
      label: String(row.deviceName),
      device: String(row.deviceName),
      subjectKind: "custom",
      subjectId: String(row.subjectId),
      deviceName: String(row.deviceName),
    });
  }
  const labelCounts = new Map();
  for (const entry of entries) {
    const key = normalizeWithdrawalDeviceLabel(entry.label);
    labelCounts.set(key, (labelCounts.get(key) || 0) + 1);
  }
  return entries.map((entry) => {
    const duplicate = labelCounts.get(normalizeWithdrawalDeviceLabel(entry.label)) > 1;
    return duplicate ? { ...entry, label: `${entry.label} / ${entry.subjectId}` } : entry;
  });
}

function normalizeWithdrawalDeviceLabel(value) {
  return String(value || "").normalize("NFKC").trim().replace(/\s+/g, " ").toLocaleLowerCase("ja-JP");
}

function sameWithdrawalDeviceSelection(left, right) {
  const leftSubject = String(left?.subjectId || "").toLowerCase();
  const rightSubject = String(right?.subjectId || "").toLowerCase();
  if (leftSubject && rightSubject) return leftSubject === rightSubject;
  return Boolean(left?.device && right?.device && String(left.device) === String(right.device));
}

function handleWithdrawalDeviceInput() {
  const typed = normalizeWithdrawalDeviceLabel(el("withdrawalDeviceSelect").value);
  state.withdrawalDeviceSelection = (state.withdrawalDeviceOptions || [])
    .find((entry) => normalizeWithdrawalDeviceLabel(entry.label) === typed) || null;
}

function selectedWithdrawalDevice() {
  const typed = el("withdrawalDeviceSelect").value.trim();
  const normalized = normalizeWithdrawalDeviceLabel(typed);
  let selected = state.withdrawalDeviceSelection;
  if (!selected || normalizeWithdrawalDeviceLabel(selected.label) !== normalized) {
    selected = (state.withdrawalDeviceOptions || [])
      .find((entry) => normalizeWithdrawalDeviceLabel(entry.label) === normalized) || null;
  }
  if (!selected) {
    state.withdrawalDeviceSelection = null;
    return { device: typed, deviceName: typed, subjectKind: "custom", subjectId: "" };
  }
  state.withdrawalDeviceSelection = selected;
  return {
    device: selected.device || typed,
    deviceName: selected.deviceName || typed,
    subjectKind: selected.subjectKind || "",
    subjectId: selected.subjectId || "",
  };
}

function compareWithdrawalDeviceOptions(a, b) {
  const aNumber = managementNumber(a);
  const bNumber = managementNumber(b);
  if (aNumber !== bNumber) return aNumber - bNumber;
  return String(formatWithdrawalDeviceOptionLabel(a)).localeCompare(String(formatWithdrawalDeviceOptionLabel(b)), "ja");
}

function formatWithdrawalDeviceOptionLabel(row) {
  const number = formatXiaoWeiNumber(row.laixiNumber || row.managementId || row.xiaoweiSort || "");
  const fixed = row.deviceLabel || row.laixiName || row.uiName || "";
  const original = row.deviceName || row.xiaoweiName || "";
  const serial = String(row.serial || "").trim();
  const serialTail = serial ? `ID:${serial.slice(-6)}` : "";
  const status = withdrawalDeviceStatusLabel(row.effectiveStatus || row.status || "");
  const parts = [];
  if (row.isOffline) parts.push("未接続");
  if (number) parts.push(number);
  if (fixed) parts.push(fixed);
  if (original && original !== fixed && !String(original).includes(fixed)) parts.push(`元: ${original}`);
  if (status) parts.push(status);
  if (serialTail) parts.push(serialTail);
  return parts.filter(Boolean).join(" / ") || serial || "端末名なし";
}

function withdrawalDeviceStatusLabel(status) {
  return {
    ONLINE: "稼働中",
    ACTIVE: "稼働中",
    RESTING: "寝かせ中",
    READY: "寝かせ完了",
    COMPLETED: "完走",
    ARCHIVED: "管理終了",
    "NO CYCLE": "",
    WAITING: "",
    INACTIVE: "",
  }[String(status || "").toUpperCase()] || "";
}

function deviceEditorControlKey(control) {
  if (!control) return "";
  const device = control.dataset.device || control.closest("tr")?.dataset.device || "";
  const field = control.dataset.field || control.dataset.kind || "";
  const inviteProduct = control.dataset.inviteProduct || "";
  return device && field ? `${device}\u001f${inviteProduct}\u001f${field}` : "";
}

function deviceEditorValueChanged(control) {
  if (!control) return false;
  const value = control.classList.contains("device-edit-input") ? control.value.trim() : control.value;
  return value !== (control.dataset.original || "");
}

function captureDeviceEditorDrafts() {
  const drafts = new Map();
  for (const control of document.querySelectorAll("#deviceRows .device-edit-input, #deviceRows .device-task-select")) {
    if (!deviceEditorValueChanged(control)) continue;
    const key = deviceEditorControlKey(control);
    if (!key) continue;
    drafts.set(key, {
      value: control.value,
      error: control.classList.contains("input-error"),
      title: control.title || "",
    });
  }
  return drafts;
}

function restoreDeviceEditorDrafts(drafts) {
  if (!(drafts instanceof Map) || !drafts.size) return;
  const controls = new Map();
  for (const control of document.querySelectorAll("#deviceRows .device-edit-input, #deviceRows .device-task-select")) {
    const key = deviceEditorControlKey(control);
    if (key) controls.set(key, control);
  }
  for (const [key, draft] of drafts.entries()) {
    const control = controls.get(key);
    if (!control) continue;
    if (control.tagName === "SELECT" && ![...control.options].some((option) => option.value === draft.value)) continue;
    control.value = draft.value;
    const changed = deviceEditorValueChanged(control);
    control.classList.toggle("changed-input", changed);
    control.classList.toggle("input-error", changed && draft.error);
    control.title = changed && draft.error ? draft.title : "";
  }
}

function deviceEditorHasFocus() {
  const active = document.activeElement;
  return Boolean(active && active.closest?.("#deviceRows") && active.matches(".device-edit-input, .device-task-select"));
}

function schedulePendingDeviceRender() {
  if (state.deviceRenderFlushTimer) window.clearTimeout(state.deviceRenderFlushTimer);
  state.deviceRenderFlushTimer = window.setTimeout(() => {
    state.deviceRenderFlushTimer = 0;
    if (deviceEditorHasFocus() || !Array.isArray(state.pendingDeviceRows)) return;
    const pendingRows = state.pendingDeviceRows;
    state.pendingDeviceRows = null;
    renderDevices(pendingRows, { force: true });
  }, 0);
}

function renderXiaoweiDisplayName(value) {
  const fullName = String(value || "").trim();
  const statusMatch = fullName.match(/^(?:(?:DAY\d+|180分[○〇]|追加[○〇])(?:\s+|$))+/i);
  const statusText = String(statusMatch?.[0] || "").trim();
  const deviceName = statusText
    ? fullName.slice(statusMatch[0].length).trim()
    : fullName;
  const firstLine = ["XiaoWei名:", statusText].filter(Boolean).join(" ");

  return `
    <div class="xiaowei-display-name" title="${esc(fullName)}">
      <span class="xiaowei-display-name-line">${esc(firstLine)}</span>
      <span class="xiaowei-display-name-line xiaowei-display-name-device">${esc(deviceName || "-")}</span>
    </div>
  `;
}

function renderDeviceSimStatus(kind, label, detail = "") {
  return `
    <div class="device-sim-inline device-sim-${esc(kind)}" role="status"${detail ? ` title="${esc(detail)}"` : ""}>
      <span class="device-sim-status-badge">${esc(label)}</span>
    </div>
  `;
}

function renderDeviceSimInline(row, simDevice, context = {}) {
  if (!row?.serial) return renderDeviceSimStatus("idle", "SIM未取得", "端末IDがありません");
  const simState = state.deviceSimInfo || {};
  if (simState.status === "loading") return renderDeviceSimStatus("loading", "SIM取得中");
  if (simState.status === "failed") {
    const retryDetail = simState.error
      ? `${simState.error} / 端末DBを開き直すかUPTIME/電池取得で再試行できます`
      : "端末DBを開き直すかUPTIME/電池取得で再試行できます";
    return renderDeviceSimStatus("failed", "SIM取得失敗", retryDetail);
  }
  if (simState.status === "ready" && simDevice) {
    const subscriptions = Array.isArray(simDevice.subscriptions) ? simDevice.subscriptions : [];
    if (!subscriptions.length) {
      return simDevice.warning
        ? renderDeviceSimStatus("failed", "SIM取得失敗", "端末からSIM情報を読み取れませんでした")
        : renderDeviceSimStatus("empty", "SIMなし・未認識", "利用可能なSIMを確認できませんでした");
    }

    const warning = simDevice.warning
      ? `<span class="device-sim-warning" title="一部のSIM情報を取得できませんでした">一部取得失敗</span>`
      : "";
    return `
      <div class="device-sim-inline device-sim-ready" aria-label="SIM情報">
        ${subscriptions.map((subscription) => {
          const confidence = ["android-carrier-id", "brand", "network-family"].includes(subscription.carrierConfidence)
            ? subscription.carrierConfidence
            : "unknown";
          const slotNumber = Number.isInteger(subscription.slotIndex) && subscription.slotIndex >= 0
            ? subscription.slotIndex + 1
            : "?";
          return `
            <div class="device-sim-subscription" title="${esc(`${subscription.stateLabel || "SIM状態不明"} / ${subscription.serviceLabel || "回線状態不明"} / 携帯回線への接続状態で、インターネット疎通とは別です`)}">
              ${subscriptions.length > 1 ? `<span class="device-sim-slot">SIM${esc(slotNumber)}</span>` : ""}
              <span class="device-sim-carrier" title="キャリア">${esc(subscription.carrier || "不明")}</span>
              <span class="device-sim-family" title="回線系統">${esc(subscription.carrierFamily || "回線不明")}</span>
              <span class="device-sim-confidence ${esc(confidence)}" title="事業者名の判定根拠">${esc(simCarrierConfidenceLabel(subscription))}</span>
              <span class="device-sim-service ${esc(subscription.serviceStatus || "unknown")}" title="携帯基地局への接続状態。インターネット疎通確認とは別です">${esc(subscription.serviceLabel || "回線状態不明")}</span>
            </div>
          `;
        }).join("")}
        ${warning}
      </div>
    `;
  }
  if (context.hasAdbSnapshot && !context.adbConnected) {
    return renderDeviceSimStatus("offline", "ADB未接続", "接続中の端末だけSIM情報を取得します");
  }
  if (simState.status !== "ready") return renderDeviceSimStatus("idle", "SIM未取得", "端末DB表示時にバックグラウンド取得します");
  if (!simDevice) return renderDeviceSimStatus("idle", "SIM未取得", "SIM走査時にADB接続対象になりませんでした");
}

function renderDevices(rows, options = {}) {
  const nextRows = Array.isArray(rows) ? rows : [];
  if (!options.force && deviceEditorHasFocus()) {
    state.pendingDeviceRows = nextRows.slice();
    return;
  }
  const drafts = captureDeviceEditorDrafts();
  state.pendingDeviceRows = null;
  const adbRows = state.adbDevices?.devices || [];
  const hasAdbSnapshot = Boolean(state.adbDevices && !state.adbDevices.skipped && Array.isArray(adbRows));
  const adbBySerial = new Map(adbRows
    .filter((device) => device && device.serial)
    .map((device) => [String(device.serial), device]));
  const simBySerial = new Map((state.deviceSimInfo?.devices || [])
    .filter((device) => device && device.serial)
    .map((device) => [String(device.serial), device]));
  const invitePartnerOptions = buildInvitePartnerSuggestions(nextRows);
  el("invitePartnerOptions").innerHTML = invitePartnerOptions
    .map((label) => `<option value="${esc(label)}"></option>`)
    .join("");
  el("deviceRows").innerHTML = sortDeviceRows(nextRows).map((row, index) => {
    const adb = adbBySerial.get(String(row.serial || ""));
    const simDevice = simBySerial.get(String(row.serial || ""));
    const adbConnected = Boolean(adb && (adb.status === "device" || adb.connected === true));
    const inviteVerificationIdle = String(row.status || "").toUpperCase() === "INACTIVE";
    const currentBatteryPercent = hasAdbSnapshot && row.serial && !adbConnected
      ? ""
      : (adb?.batteryPercent ?? row.batteryPercent ?? row.adbLastBatteryPercent ?? "");
    const displayRow = {
      ...row,
      adbConnected: hasAdbSnapshot && row.serial ? adbConnected : null,
      simStatus: inviteVerificationIdle ? "" : row.simStatus || adb?.simStatus || "",
      networkType: inviteVerificationIdle ? "" : row.networkType || adb?.networkType || "",
      osVersion: inviteVerificationIdle ? "" : row.osVersion || adb?.osVersion || "",
      adbUptimeSeconds: adb?.uptimeSeconds ?? row.adbLastUptimeSeconds,
      adbUptimeRaw: adb?.uptimeRaw || row.adbLastUptimeRaw || "",
      adbUptimeFetchedAt: adb?.uptimeFetchedAt || Date.parse(row.adbLastUptimeCheckedAt || "") || 0,
      batteryPercent: currentBatteryPercent,
    };
    const batteryMissing = displayRow.batteryPercent === "" || displayRow.batteryPercent === null || displayRow.batteryPercent === undefined;
    const activityBand = deviceOrderBand(row);
    const rowClasses = [
      displayRow.adbConnected === false ? "device-row-offline" : "",
      row.serial && state.adbMissingSerials?.has(String(row.serial)) ? "device-row-dropped" : "",
      displayRow.adbConnected === false && batteryMissing ? "device-row-offline-battery-missing" : "",
    ].filter(Boolean).join(" ");
    const masterNameMarkup = row.masterRegistered === false
      ? `<span class="device-master-name device-master-unregistered" title="型番 ${esc(row.masterLookupModelCode || "不明")} / キャリア ${esc(row.masterLookupCarrierCode || "UNKNOWN")}">マスタ未登録: ${esc(row.masterLookupModelCode || row.deviceName || "機種要確認")}</span>`
      : `<span class="device-master-name">マスタ: ${esc(row.deviceName || "")}</span>`;
    return `
    <table class="device-db-table device-db-record-table device-db-card device-card-${esc(activityBand)}" data-device-position="${index + 1}" data-device="${esc(row.serial || row.managementId || "")}" data-activity-band="${esc(activityBand)}" aria-label="端末 ${esc(row.laixiNumber || index + 1)}">
      <tbody>
      <tr class="${rowClasses}" data-device="${esc(row.serial || row.managementId || "")}">
      <td class="management-id-cell" data-card-block="number">${esc(row.laixiNumber || "")}</td>
      <td class="device-summary-cell" data-card-block="device">
        ${renderDeviceSummaryStatusBand(displayRow)}
        <div class="device-summary-name-block">
          ${renderXiaoweiDisplayName(row.laixiName)}
          <div class="short-name-editor">
            <label>短縮名編集</label>
            <input class="table-input device-edit-input short-name-input" type="text" value="${esc(row.modelGroup || "")}" data-field="shortName" data-device="${esc(row.serial || row.managementId || "")}" data-original="${esc(row.modelGroup || "")}" placeholder="A25">
            <span>${esc(row.carrierCode || "")}</span>
          </div>
          <div class="device-name-meta">
            ${masterNameMarkup}
            <span class="raw-device-name">${row.serial ? `端末ID: ${esc(row.serial)}` : ""}</span>
          </div>
          ${renderDeviceSimInline(row, simDevice, { hasAdbSnapshot, adbConnected })}
        </div>
      </td>
      <td class="device-work-cell" data-card-block="work">
        <div class="device-work-main">
          <section class="device-work-task-section" data-card-role="task" aria-label="タスクと所属グループ">
            ${renderDeviceTasksCell(displayRow)}
          </section>
          <section class="device-work-runtime-section" data-card-role="operation" aria-label="端末操作方式">
            ${renderDeviceRuntimeCell(displayRow)}
          </section>
        </div>
        <div class="device-work-history-section" data-card-role="history">
          ${renderDeviceHistoryButton(displayRow)}
        </div>
      </td>
      <td class="invite-factors-cell" data-card-block="invite">${renderInviteFactorsCell(displayRow)}</td>
      </tr>
      </tbody>
    </table>
  `;
  }).join("");
  restoreDeviceEditorDrafts(drafts);
  syncInviteProductView();
  updateDeviceNameSaveState();
}

function operationGroupTone(group = {}) {
  const key = String(group.groupId || group.name || "group");
  let hash = 0;
  for (const char of key) hash = ((hash * 31) + char.codePointAt(0)) >>> 0;
  return `tone-${hash % 6}`;
}

function renderOperationGroupMembership(row = {}) {
  const ids = Array.isArray(row.operationGroupIds) ? row.operationGroupIds : [];
  const groups = ids.map(operationGroupById).filter(Boolean);
  const chips = groups.length
    ? groups.map((group) => `<button class="operation-group-membership-chip ${operationGroupTone(group)}" type="button" data-operation-group-edit="${esc(group.groupId || "")}" title="${esc(group.name || "グループ")}">${esc(group.name || "名称未設定")}</button>`).join("")
    : `<button class="operation-group-membership-chip empty" type="button" data-operation-group-edit="" title="グループを設定">未所属</button>`;
  return `
    <div class="device-task-group-block">
      <span class="device-task-group-label">所属グループ</span>
      <div class="device-task-group-chips">${chips}</div>
    </div>
  `;
}

function renderDeviceRuntimeCell(row = {}) {
  return `
    <div class="device-runtime-stack">
      ${renderSwipeMethodCell(row)}
    </div>
  `;
}

function renderDeviceSummaryStatusBand(row = {}) {
  const batteryMissing = row.adbConnected === false
    || row.batteryPercent === ""
    || row.batteryPercent === null
    || row.batteryPercent === undefined;
  const battery = batteryMissing ? "--%" : `${row.batteryPercent}%`;
  return `
    <div class="device-summary-status-band" data-card-band="summary">
      ${renderDeviceDaySettings(row)}
      <span class="device-summary-chip device-summary-battery ${!batteryMissing && Number(row.batteryPercent) <= 20 ? "battery-low" : ""}" data-summary-role="battery" title="${batteryMissing ? "現在の電池残量は未取得です" : "現在の電池残量"}">電池 ${esc(battery)}</span>
      <span class="device-summary-chip device-summary-fleet" data-summary-role="fleet-state">${statusPill(row.status, row)}</span>
    </div>
  `;
}

function batteryCell(row) {
  if (row && row.adbConnected === false) {
    return `<td class="num battery-cell battery-missing battery-offline-missing" title="ADB未接続のため現在の電池残量は取得できません">OFFLINE</td>`;
  }
  const value = row && row.batteryPercent;
  const missing = value === "" || value === null || value === undefined;
  if (missing) {
    return `<td class="num battery-cell battery-missing" title="電池未取得">未取得</td>`;
  }
  return `<td class="num battery-cell ${Number(value) <= 20 ? "battery-low" : ""}">${esc(value)}%</td>`;
}

function formatDeviceDay(row) {
  const fromRow = Number(row && row.day || 0);
  const fromTags = Array.isArray(row && row.tags)
    ? row.tags.map((tag) => /^DAY_(\d{2})$/.exec(String(tag || ""))).find(Boolean)
    : null;
  const day = fromRow || (fromTags ? Number(fromTags[1]) : 0);
  return day ? `<span class="device-day-chip">DAY${String(day).padStart(2, "0")}</span>` : "";
}

function normalizeInviteProduct(value) {
  return value === "main" ? "main" : "lite";
}

function inviteProductForRow() {
  return normalizeInviteProduct(state.inviteProductView);
}

function syncInviteProductView() {
  const product = normalizeInviteProduct(state.inviteProductView);
  state.inviteProductView = product;
  for (const button of document.querySelectorAll("[data-invite-product-global]")) {
    const active = normalizeInviteProduct(button.dataset.inviteProductGlobal) === product;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", active ? "true" : "false");
  }
  for (const panel of document.querySelectorAll("#deviceRows [data-invite-profile-panel]")) {
    panel.hidden = normalizeInviteProduct(panel.dataset.inviteProfilePanel) !== product;
  }
  for (const mirror of document.querySelectorAll("[data-invite-product-mirror]")) {
    mirror.textContent = product === "main" ? "本家表示中" : "Lite表示中";
    mirror.classList.toggle("main", product === "main");
  }
  for (const layout of document.querySelectorAll(".device-db-table-layout")) {
    layout.dataset.inviteProduct = product;
  }
}

function handleInviteProductGlobalToggle(event) {
  const button = event.target.closest("[data-invite-product-global]");
  if (!button) return;
  state.inviteProductView = normalizeInviteProduct(button.dataset.inviteProductGlobal);
  syncInviteProductView();
}

function renderDeviceDaySettings(row) {
  return `
    <div class="device-summary-chip device-summary-day" data-summary-role="day">
      ${formatDeviceDay(row) || '<span class="device-day-empty">-</span>'}
    </div>
    <div class="device-summary-chip device-summary-initial-settings" data-summary-role="baseline">
      <span>初期設定</span>
      ${baselineSettingsStatusDetail(row)}
    </div>
  `;
}

function inviteProfileForRow(row, product) {
  const normalizedProduct = normalizeInviteProduct(product);
  const stored = row?.inviteProfiles && typeof row.inviteProfiles === "object"
    ? row.inviteProfiles[normalizedProduct]
    : null;
  const profile = stored && typeof stored === "object" ? stored : {};
  const legacy = normalizedProduct === "lite" ? row || {} : {};
  return {
    inviteType: Object.prototype.hasOwnProperty.call(profile, "inviteType") ? profile.inviteType || "" : legacy.inviteType || "",
    inviteRole: Object.prototype.hasOwnProperty.call(profile, "inviteRole") ? profile.inviteRole || "" : legacy.inviteRole || "",
    inviteResult: Object.prototype.hasOwnProperty.call(profile, "inviteResult") ? profile.inviteResult || "" : legacy.inviteResult || "",
    invitePartner: Object.prototype.hasOwnProperty.call(profile, "invitePartner") ? profile.invitePartner || "" : legacy.invitePartner || "",
    ttlRegisterMethod: Object.prototype.hasOwnProperty.call(profile, "ttlRegisterMethod") ? profile.ttlRegisterMethod || "" : legacy.ttlRegisterMethod || "",
    inviteOpsNote: Object.prototype.hasOwnProperty.call(profile, "inviteOpsNote") ? profile.inviteOpsNote || "" : legacy.inviteOpsNote || "",
  };
}

function renderInviteFactorsCell(row) {
  const device = row.serial || row.managementId || "";
  const osValue = formatOsVersion(row.osVersion);
  const selectedProduct = inviteProductForRow(row);
  return `
    <div class="invite-factor-grid invite-factor-layout" aria-label="端末共通情報と招待情報">
      ${renderInviteFactorSelect(row, "simStatus", { className: "invite-slot-sim" })}
      ${renderInviteFactorSelect(row, "networkType", { className: "invite-slot-network" })}
      ${renderInviteUptimeChip(row)}
      <label class="invite-factor-field invite-slot-switch" title="SIMからWi-Fiなどへ切り替えた日">
        <span>切替</span>
        <input class="table-input device-edit-input invite-small-input" type="number" min="1" max="365" value="${esc(row.networkSwitchedDay || "")}" data-field="networkSwitchedDay" data-device="${esc(device)}" data-original="${esc(row.networkSwitchedDay || "")}" placeholder="日">
      </label>
      <input class="table-input device-edit-input invite-os-input invite-slot-os" type="text" value="${esc(osValue)}" data-field="osVersion" data-device="${esc(device)}" data-original="${esc(osValue)}" placeholder="OS">
      ${INVITE_PRODUCTS.map((product) => {
        const profile = inviteProfileForRow(row, product.value);
        return `
          <div class="invite-profile-panel" data-invite-profile-panel="${esc(product.value)}"
            ${product.value === selectedProduct ? "" : "hidden"}>
            ${renderTtlMethodChip(profile, product.value)}
            ${renderInviteFactorSelect(profile, "ttlRegisterMethod", { device, product: product.value, className: "invite-slot-register-method" })}
            ${renderInviteFactorSelect(profile, "inviteType", { device, product: product.value, className: "invite-slot-type" })}
            ${renderInviteFactorSelect(profile, "inviteRole", { device, product: product.value, className: "invite-slot-role" })}
            ${renderInviteFactorSelect(profile, "inviteResult", { device, product: product.value, className: "invite-slot-result" })}
            ${renderInvitePartnerSelect(profile, { device, product: product.value, className: "invite-slot-partner" })}
            <input class="table-input device-edit-input invite-note-input invite-slot-note" type="text" data-field="inviteOpsNote"
              data-device="${esc(device)}" data-invite-product="${esc(product.value)}"
              data-original="${esc(profile.inviteOpsNote || "")}" value="${esc(profile.inviteOpsNote || "")}"
              placeholder="${product.value === "main" ? "本家" : "Lite"}備考: 紹介条件、追加視聴、検索など">
          </div>
        `;
      }).join("")}
    </div>
  `;
}

function renderTtlMethodChip(row, product = "lite") {
  const method = String(row.ttlRegisterMethod || "").trim();
  const label = `${product === "main" ? "TikTok本家" : "TikTok Lite"}: ${method || "導入方法未設定"}`;
  const klass = method === "Google Play" ? "play" : method === "APK自動" ? "apk" : "empty";
  return `<span class="ttl-method-chip invite-slot-method-chip ${klass}" title="導入方法">${esc(label)}</span>`;
}

function renderInviteUptimeChip(row) {
  const rawUptimeSeconds = row.adbUptimeSeconds;
  const uptimeSeconds = rawUptimeSeconds === null || rawUptimeSeconds === undefined || rawUptimeSeconds === ""
    ? NaN
    : Number(rawUptimeSeconds);
  if (!Number.isFinite(uptimeSeconds) || uptimeSeconds < 0) {
    return `<span class="invite-uptime-chip invite-slot-uptime uptime-unknown" title="ADB稼働時間未取得">UPTIME未取得</span>`;
  }
  const fetchedAt = Number(row.adbUptimeFetchedAt || Date.now());
  const value = currentUptimeValue(uptimeSeconds, fetchedAt);
  return `<span class="invite-uptime-chip invite-slot-uptime ${uptimeBandClass(value.hours)}" data-uptime-base="${esc(uptimeSeconds)}" data-uptime-fetched-at="${esc(fetchedAt)}" data-uptime-prefix="UPTIME " title="${esc(uptimeTitle(value.hours))}">UPTIME ${esc(uptimeLabel(value.hours))}</span>`;
}

function formatOsVersion(value) {
  const text = String(value || "").trim();
  if (!text) return "";
  const release = text
    .replace(/^OS\s*/i, "")
    .replace(/\s*\/\s*SDK\s*\d+\s*$/i, "")
    .trim();
  return release ? `OS ${release}` : "";
}

function renderInviteFactorSelect(row, field, options = {}) {
  const value = row[field] || "";
  const baseChoices = INVITE_FACTOR_OPTIONS[field] || [["", "?"]];
  const hasCurrentChoice = baseChoices.some(([optionValue]) => optionValue === value);
  const choices = field === "inviteType" && value && !hasCurrentChoice
    ? [...baseChoices, [value, `${value}（旧データ）`, true]]
    : baseChoices;
  const device = options.device || row.serial || row.managementId || "";
  const product = options.product ? ` data-invite-product="${esc(normalizeInviteProduct(options.product))}"` : "";
  const className = options.className ? ` ${esc(options.className)}` : "";
  return `
    <select class="table-input device-edit-input invite-factor-select${className}" data-field="${esc(field)}" data-device="${esc(device)}"${product} data-original="${esc(value)}">
      ${choices.map(([optionValue, label, disabled]) => `<option value="${esc(optionValue)}" ${optionValue === value ? "selected" : ""} ${disabled ? "disabled" : ""}>${esc(label)}</option>`).join("")}
    </select>
  `;
}

function renderInvitePartnerSelect(row, options = {}) {
  const device = options.device || row.serial || row.managementId || "";
  const product = options.product ? ` data-invite-product="${esc(normalizeInviteProduct(options.product))}"` : "";
  const className = options.className ? ` ${esc(options.className)}` : "";
  const value = invitePartnerLabel(row.invitePartner || "");
  return `
    <input class="table-input device-edit-input invite-factor-select invite-partner-select${className}" type="text" maxlength="80"
      list="invitePartnerOptions" value="${esc(value)}" data-field="invitePartner" data-device="${esc(device)}"
      ${product} data-original="${esc(value)}" placeholder="親・相手を選択／iPhone名を入力" autocomplete="off">
  `;
}

function buildInvitePartnerSuggestions(rows = []) {
  const suggestions = new Set();
  const add = (value) => {
    const label = invitePartnerLabel(value);
    if (label) suggestions.add(label);
  };
  const candidates = [
    ...(Array.isArray(rows) ? rows : []),
    ...(state.summary?.offlineDevices || []).filter((row) => row && row.status !== "archived"),
  ];
  for (const item of sortDeviceRows(candidates)) {
    add(invitePartnerOptionLabel(item));
    add(inviteProfileForRow(item, "lite").invitePartner);
    add(inviteProfileForRow(item, "main").invitePartner);
    for (const entry of Array.isArray(item?.inviteHistory) ? item.inviteHistory : []) add(entry?.partner);
  }
  return [...suggestions].sort((left, right) => left.localeCompare(right, "ja"));
}

function invitePartnerOptionLabel(row) {
  if (!row) return "";
  const number = row.laixiNumber || row.managementId || "";
  const shortName = row.deviceLabel || row.laixiName || row.uiName || "";
  return [number, shortName].filter(Boolean).join(" / ");
}

function renderDeviceTaskSelect(row, kind) {
  const config = DEVICE_TASK_SELECTS[kind];
  if (!config) return "";
  const checked = deviceTaskCheckedTags(row, kind);
  const labels = checked.length ? checked.map((tag) => deviceTaskTagLabel(kind, tag)) : ["未設定"];
  const note = deviceTaskNote(row, kind);
  return `<div class="device-task-cell">${labels.map((label) => `<span class="device-task-chip ${checked.length ? "" : "empty"}">${esc(label)}</span>`).join("")}${note}</div>`;
}

function renderDeviceTasksCell(row) {
  const items = [
    ["チェックイン", "ci", "円"],
    ["動画180分", "video180", ""],
    ["追加視聴", "video10", "円"],
  ].map(([label, kind, suffix]) => renderDeviceTaskLine(row, kind, label, suffix));
  return `<div class="device-task-stack">${items.join("")}${renderDeviceTaskErrorStatus(row)}<div class="device-task-group-spacer" aria-hidden="true"></div>${renderOperationGroupMembership(row)}</div>`;
}

function renderDeviceTaskLine(row, kind, label, suffix = "") {
  const checked = deviceTaskCheckedTags(row, kind);
  const value = checked.length ? checked.map((tag) => deviceTaskTagLabel(kind, tag)).join(" / ") : "-";
  const note = deviceTaskPlainNote(row, kind);
  const valueText = value === "-" || !suffix || value.endsWith(suffix) ? value : `${value}${suffix}`;
  return `
    <div class="device-task-line ${checked.length ? "" : "empty"}">
      <span>${esc(label)}</span>
      <b>${esc(valueText)}</b>
      ${note ? `<em>${esc(note)}</em>` : ""}
    </div>
  `;
}

function deviceTaskPlainNote(row, kind) {
  const tags = Array.isArray(row.tags) ? row.tags : [];
  if (kind === "video180" && tags.includes("V180_DONE")) return "完了";
  if (kind === "video10" && tags.includes("V10_DONE")) return "完了";
  return "";
}

function renderDeviceTaskErrorStatus(row) {
  const tags = Array.isArray(row?.tags) ? row.tags : [];
  const errorCount = Number(row?.taskHistory?.errorStats?.error || 0);
  if (tags.includes("STATE_ERROR")) {
    return `<div class="device-task-error-status current">ERROR中</div>`;
  }
  if (tags.includes("STATE_ERROR_HISTORY") || row?.hasErrorHistory || errorCount > 0) {
    return `<div class="device-task-error-status history">ERROR歴あり</div>`;
  }
  return "";
}

function deviceTaskCheckedTags(row, kind) {
  const tags = Array.isArray(row.tags) ? row.tags : [];
  if (kind === "ci") {
    return tags.filter((tag) => /^CI_([1-9]\d{0,5})$/.test(String(tag || "")));
  }
  const config = DEVICE_TASK_SELECTS[kind];
  if (!config) return [];
  return config.tags.filter((tag) => tags.includes(tag));
}

function deviceTaskTagLabel(kind, tag) {
  if (kind === "ci") {
    const match = /^CI_([1-9]\d{0,5})$/.exec(String(tag || ""));
    if (match) return match[1];
  }
  const options = DEVICE_TASK_SELECTS[kind]?.options || [];
  const found = options.find(([value]) => value === tag);
  return found ? found[1] : tag;
}

function deviceTaskNote(row, kind) {
  const tags = Array.isArray(row.tags) ? row.tags : [];
  if (kind === "ci") {
    if (tags.includes("STATE_ERROR")) return `<div class="device-task-note error">ERROR中</div>`;
    if (tags.includes("STATE_ERROR_HISTORY")) return `<div class="device-task-note error-history">ERROR歴あり</div>`;
  }
  if (kind === "video180" && tags.includes("V180_DONE")) {
    return `<div class="device-task-note done">完了</div>`;
  }
  if (kind === "video10" && tags.includes("V10_DONE")) {
    return `<div class="device-task-note done">完了</div>`;
  }
  return "";
}

function renderDeviceHistoryButton(row) {
  const taskCount = Number(row?.taskHistory?.completedCount ?? row?.taskHistory?.count ?? 0);
  const withdrawalCount = deviceWithdrawals(row).length;
  const inviteEntries = inviteHistoryEntries(row);
  const inviteCount = inviteEntries.length;
  const inviteStats = inviteHistoryStats(row, inviteEntries);
  const errorCount = Number(row?.taskHistory?.errorStats?.error || 0);
  const disconnectCount = Number(row?.connectionIncidentStats?.total || 0);
  const recoveryCount = Number(row?.recoveryAttemptStats?.total || 0);
  const count = taskCount + withdrawalCount + inviteCount + errorCount + disconnectCount + recoveryCount;
  const device = row.serial || row.managementId || "";
  const rateTone = inviteSuccessRateTone(inviteStats);
  const rateTitle = inviteStats.success + inviteStats.fail
    ? `招待成功 ${inviteStats.success}件 / 失敗 ${inviteStats.fail}件`
    : "招待結果の記録なし";
  const historyTitle = `完走 ${taskCount}件 / 招待 ${inviteCount}件 / 出金 ${withdrawalCount}件 / ERROR ${errorCount}件 / 切断 ${disconnectCount}件 / 復旧 ${recoveryCount}回`;
  if (!count) {
    return `<div class="history-cell-stack">
      <button class="history-link-btn empty" data-device="${esc(device)}" type="button" title="${esc(historyTitle)}" disabled><span>完了0 招待0</span><span>切断0 復旧0</span></button>
      <button class="invite-device-rate-btn empty" data-invite-analytics-device="${esc(device)}" type="button" title="${esc(rateTitle)}">招待 -</button>
    </div>`;
  }
  const disconnectClass = disconnectCount ? " disconnect" : "";
  return `<div class="history-cell-stack">
    <button class="history-link-btn${disconnectClass}" data-device="${esc(device)}" type="button" title="${esc(`${historyTitle} / クリックして履歴を表示`)}"><span>完了${esc(taskCount)} 招待${esc(inviteCount)}</span><span>切断${esc(disconnectCount)} 復旧${esc(recoveryCount)}</span></button>
    <button class="invite-device-rate-btn ${esc(rateTone)}" data-invite-analytics-device="${esc(device)}" type="button" title="${esc(rateTitle)}">招待 ${esc(inviteStats.rateLabel)}</button>
  </div>`;
}

function renderTaskHistoryCell(row) {
  const history = row.taskHistory || {};
  const count = Number(history.count || 0);
  if (!count) return `<span class="task-history-pill empty" title="">-</span>`;
  const items = Array.isArray(history.items) ? history.items : [];
  const title = items.length
    ? items.flatMap((item) => {
        const resetLines = Array.isArray(item.resetHistory)
          ? item.resetHistory.map((entry) => [
              "リセット",
              entry.at || "",
              entry.reason || "",
              historyRecordedAmountYen(entry.amountYen),
              historyRecordedUptime(entry.uptimeSeconds, entry.uptimeSource),
              entry.summary || "",
            ].filter(Boolean).join(" / "))
          : [];
        return [item.text || item.cycleId || "", ...resetLines].filter(Boolean);
      }).join("\n")
    : "";
  const latest = history.latest?.text || "";
  const latestShort = latest
    .replace(/^#\d+\s*\/\s*/, "")
    .replace(/\s*\/\s*/g, " ");
  return `<span class="task-history-pill" title="${esc(title)}"><b>履歴${esc(count)}</b><small>${esc(latestShort || "詳細")}</small></span>`;
}

function deviceWithdrawals(row) {
  const matcher = globalThis.AndroidFleetWithdrawalMatching?.withdrawalBelongsToDevice;
  return (state.summary?.withdrawals || [])
    .filter((item) => matcher ? matcher(item, row) : false)
    .slice()
    .sort((a, b) => String(b.withdrawalDate || b.recordedAt || "").localeCompare(String(a.withdrawalDate || a.recordedAt || "")));
}

function inviteHistoryLines(row) {
  return String(row?.inviteOpsNote || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
}

function inviteHistoryEntries(row) {
  const structured = Array.isArray(row?.inviteHistory) ? row.inviteHistory.filter((entry) => entry && (entry.at || entry.result)) : [];
  if (structured.length) {
    return structured.map((entry) => ({
      ...entry,
      product: normalizeInviteProduct(entry.product),
    }));
  }
  return inviteHistoryLines(row).map((text) => ({ legacy: true, product: "lite", text }));
}

let deviceHistoryRestoreFocus = null;

function showDeviceHistoryDialog(row) {
  if (!row) return;
  closeDeviceHistoryDialog();
  deviceHistoryRestoreFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  const taskItems = Array.isArray(row.taskHistory?.items) ? row.taskHistory.items : [];
  const completedTaskCount = Number(row.taskHistory?.completedCount ?? taskItems.length);
  const withdrawals = deviceWithdrawals(row);
  const inviteEntries = inviteHistoryEntries(row);
  const inviteStats = inviteHistoryStats(row, inviteEntries);
  const errorOutcomes = Array.isArray(row.taskHistory?.errorOutcomes) ? row.taskHistory.errorOutcomes : [];
  const errorStats = row.taskHistory?.errorStats || {};
  const connectionIncidents = Array.isArray(row.connectionIncidents) ? row.connectionIncidents : [];
  const connectionStats = row.connectionIncidentStats || {};
  const recoveryAttempts = Array.isArray(row.recoveryAttempts) ? row.recoveryAttempts : [];
  const recoveryStats = row.recoveryAttemptStats || {};
  const adbState = currentHistoryAdbState(row);
  const uptimeText = historyUptimeText(row, adbState);
  const batteryText = historyBatteryText(row, adbState);
  const adbText = adbState.connected === false ? "ADB OFFLINE" : adbState.connected === true ? "ADB OK" : "ADB未確認";
  const inviteNotes = INVITE_PRODUCTS.map((product) => {
    const note = String(inviteProfileForRow(row, product.value).inviteOpsNote || "").trim();
    return note ? `${product.label}: ${note}` : "";
  }).filter(Boolean);
  const notes = [row.notes, ...inviteNotes].map((value) => String(value || "").trim()).filter(Boolean);
  const numberLabel = row.laixiNumber || row.xiaoweiNumber || "-";
  const nameLabel = row.deviceLabel || row.laixiName || row.xiaoweiName || row.deviceName || row.serial || "端末名なし";
  const cumulativeRevenue = withdrawals.reduce((sum, item) => sum + Number(item.amountYen || 0), 0);
  const overlay = document.createElement("div");
  overlay.className = "device-history-dialog-backdrop";
  overlay.innerHTML = `
    <div class="device-history-dialog" role="dialog" aria-modal="true" aria-labelledby="deviceHistoryDialogTitle">
      <div class="device-history-dialog-head">
        <div class="device-history-title">
          <h3 id="deviceHistoryDialogTitle">端末履歴</h3>
          <p>${esc(numberLabel)} / ${esc(nameLabel)}</p>
        </div>
        <div class="device-history-head-actions">
          <button class="section-head-action retire-device-action" type="button">管理対象から外す</button>
          <button class="device-history-close" type="button" aria-label="閉じる">×</button>
        </div>
        ${historyKpiStrip([
          { label: "稼働", value: `${taskItems.length}回` },
          { label: "完走", value: `${completedTaskCount}件` },
          { label: "招待", value: `${inviteEntries.length}件` },
          { label: "ERROR率", value: errorStats.rateLabel || "-", tone: Number(errorStats.error || 0) ? "error" : "good" },
          { label: "切断", value: `${Number(connectionStats.total || 0)}件`, tone: connectionStats.chronic || Number(connectionStats.open || 0) ? "error" : Number(connectionStats.total || 0) ? "warn" : "good" },
          { label: "復旧実行", value: `${Number(recoveryStats.total || 0)}回`, tone: recoveryStats.repeated ? "error" : Number(recoveryStats.total || 0) ? "warn" : "good" },
          { label: "累計収益", value: yen(cumulativeRevenue), tone: "money" },
        ])}
      </div>
      <div class="device-history-body">
        ${historyConnectionTable(connectionIncidents, connectionStats, recoveryAttempts, recoveryStats)}
        ${historyTaskTable(taskItems, errorOutcomes, errorStats, withdrawals)}
        ${historyInviteTable(row, inviteEntries)}
        ${historyWithdrawalTable(withdrawals)}
        <div class="device-history-current-panels">
          ${historyInfoSheet("端末情報・現在値", historyDeviceCurrentCards(row, { uptimeText, batteryText, adbText }), "device")}
          ${historyInfoSheet("招待検証・現在値", historyInviteCurrentCards(row, inviteStats), "invite")}
        </div>
        <div class="device-history-note"><b>備考</b><span>${esc(notes.join("\n") || "記録なし")}</span></div>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelector(".retire-device-action")?.addEventListener("click", (event) => retireDeviceFromHistory(row, event.currentTarget));
  overlay.querySelector(".device-history-close")?.addEventListener("click", closeDeviceHistoryDialog);
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeDeviceHistoryDialog();
    const productButton = event.target.closest("[data-history-invite-product]");
    const typeButton = event.target.closest("[data-history-invite-type]");
    if (productButton || typeButton) {
      const section = event.target.closest(".device-history-sheet.invite");
      if (!section) return;
      const filters = {
        product: productButton
          ? normalizeInviteProduct(productButton.dataset.historyInviteProduct)
          : normalizeInviteProduct(section.dataset.inviteProduct),
        type: typeButton ? typeButton.dataset.historyInviteType || "" : section.dataset.inviteType || "",
      };
      section.outerHTML = historyInviteTable(row, inviteEntries, filters);
    }
  });
  document.addEventListener("keydown", handleDeviceHistoryDialogKeydown);
  requestAnimationFrame(() => overlay.querySelector(".device-history-close")?.focus());
}

function closeDeviceHistoryDialog() {
  const overlay = document.querySelector(".device-history-dialog-backdrop");
  if (!overlay) return;
  overlay.remove();
  document.removeEventListener("keydown", handleDeviceHistoryDialogKeydown);
  if (deviceHistoryRestoreFocus?.isConnected) deviceHistoryRestoreFocus.focus();
  deviceHistoryRestoreFocus = null;
}

function handleDeviceHistoryDialogKeydown(event) {
  if (event.key !== "Escape") return;
  event.preventDefault();
  closeDeviceHistoryDialog();
}

function historyKpiStrip(cards) {
  return `<div class="device-history-kpis">${cards.map((card) => `
    <div class="device-history-kpi ${esc(card.tone || "")}">
      <span>${esc(card.label)}</span>
      <strong>${esc(card.value || "-")}</strong>
    </div>
  `).join("")}</div>`;
}

function historyRateStrip(items, label) {
  return `<div class="history-rate-strip" aria-label="${esc(label)}">${items.map((item) => `
    <span class="history-rate-item ${esc(item.tone || "")}"><small>${esc(item.label)}</small><b>${esc(item.value)}</b></span>
  `).join("")}</div>`;
}

function historyConnectionTable(incidents, stats = {}, recoveryAttempts = [], recoveryStats = {}) {
  const rows = (Array.isArray(incidents) ? incidents.slice() : [])
    .sort((a, b) => String(b?.startedAt || "").localeCompare(String(a?.startedAt || "")));
  const repairRows = (Array.isArray(recoveryAttempts) ? recoveryAttempts.slice() : [])
    .sort((a, b) => String(b?.at || "").localeCompare(String(a?.at || "")));
  const summaryItems = [
    { label: "切断", value: `${Number(stats.total || 0)}件`, tone: Number(stats.total || 0) ? "error" : "good" },
    { label: "30日", value: `${Number(stats.last30Days || 0)}件`, tone: stats.chronic ? "error" : "" },
    { label: "未復旧", value: `${Number(stats.open || 0)}件`, tone: Number(stats.open || 0) ? "error" : "good" },
    { label: "復旧実行", value: `${Number(recoveryStats.total || 0)}回`, tone: recoveryStats.repeated ? "error" : Number(recoveryStats.total || 0) ? "pending" : "good" },
    { label: "停止合計", value: historyConnectionDuration(stats.totalDurationSeconds), tone: "" },
    ...(Number(stats.ignored || 0) ? [{ label: "集計外", value: `${Number(stats.ignored)}件`, tone: "pending" }] : []),
    { label: "判定", value: stats.chronic ? "多発" : "通常", tone: stats.chronic ? "error" : "good" },
  ];
  return `
    <section class="device-history-sheet connection">
      <div class="device-history-sheet-head">
        <h4>ADB切断・復旧履歴</h4>
        ${historyRateStrip(summaryItems, "ADB切断・復旧集計")}
      </div>
      <div class="device-history-table-wrap connection-history-scroll" tabindex="0">
        <table class="device-history-table connection-history-table">
          <colgroup><col class="col-start"><col class="col-recovered"><col class="col-duration"><col class="col-status"><col class="col-reason"></colgroup>
          <thead><tr><th>検知</th><th>復旧</th><th>停止時間</th><th>状態</th><th>内容</th></tr></thead>
          <tbody>${rows.length ? rows.map(renderConnectionHistoryTableRow).join("") : historyEmptyTableRow(5)}</tbody>
        </table>
      </div>
      ${repairRows.length ? `
        <div class="device-history-subhead">復旧ボタン実行履歴</div>
        <div class="device-history-table-wrap recovery-attempt-scroll" tabindex="0">
          <table class="device-history-table recovery-attempt-table">
            <thead><tr><th>実行日時</th><th>処理</th><th>強力復旧</th><th>実行ID</th></tr></thead>
            <tbody>${repairRows.map(renderRecoveryAttemptTableRow).join("")}</tbody>
          </table>
        </div>
      ` : ""}
    </section>
  `;
}

function renderRecoveryAttemptTableRow(attempt) {
  return `<tr>
    <td>${esc(historyDateTimeLabel(attempt?.at) || "-")}</td>
    <td class="history-table-tone pending">自動復旧を実行</td>
    <td>${attempt?.deepRepair === false ? "通常" : "あり"}</td>
    <td class="history-table-memo" title="${esc(attempt?.requestId || "-")}">${esc(attempt?.requestId || "-")}</td>
  </tr>`;
}

function renderConnectionHistoryTableRow(incident) {
  const status = incident?.status === "open" ? "未復旧" : incident?.status === "ignored" ? "集計外" : "復旧済";
  const tone = incident?.status === "open" ? "error" : incident?.status === "ignored" ? "pending" : "good";
  const endAt = incident?.status === "ignored" ? incident?.ignoredAt : incident?.recoveredAt;
  return `<tr>
    <td>${esc(historyDateTimeLabel(incident?.startedAt) || "-")}</td>
    <td>${esc(historyDateTimeLabel(endAt) || (incident?.status === "open" ? "未復旧" : "-"))}</td>
    <td>${esc(historyConnectionDuration(incident?.durationSeconds, incident?.startedAt, incident?.status))}</td>
    <td class="history-table-tone ${esc(tone)}">${esc(status)}</td>
    <td class="history-table-memo" title="${esc(incident?.reason || "ADBから消失（原因不明）")}">${esc(incident?.reason || "ADBから消失（原因不明）")}</td>
  </tr>`;
}

function historyConnectionDuration(seconds, startedAt = "", status = "") {
  let value = Number(seconds || 0);
  if (status === "open" && startedAt) {
    const startedMs = Date.parse(startedAt);
    if (Number.isFinite(startedMs)) value = Math.max(value, Math.floor((Date.now() - startedMs) / 1000));
  }
  if (!Number.isFinite(value) || value <= 0) return status === "ignored" ? "集計外" : "0分";
  const days = Math.floor(value / 86400);
  const hours = Math.floor((value % 86400) / 3600);
  const rawMinutes = Math.floor((value % 3600) / 60);
  const minutes = days || hours ? rawMinutes : Math.max(1, rawMinutes);
  return [days ? `${days}日` : "", hours ? `${hours}時間` : "", minutes ? `${minutes}分` : ""].filter(Boolean).join(" ");
}

function historyTaskTable(taskItems, errorOutcomes, errorStats, withdrawals) {
  const usedOutcomes = new Set();
  const rows = taskItems.map((item) => {
    const outcome = historyTaskOutcome(item, errorOutcomes);
    if (outcome) usedOutcomes.add(historyOutcomeKey(outcome));
    return renderTaskHistoryTableRow(item, outcome, withdrawals);
  });
  for (const outcome of errorOutcomes) {
    if (!usedOutcomes.has(historyOutcomeKey(outcome))) rows.push(renderOrphanErrorHistoryTableRow(outcome));
  }
  const unclassified = Number(errorStats.unclassified || 0);
  const summaryItems = [
    { label: "エラーなし", value: `${Number(errorStats.noError || 0)}件`, tone: "good" },
    { label: "初日", value: `${Number(errorStats.day1 || 0)}件`, tone: "error" },
    { label: "2日目以降", value: `${Number(errorStats.day2Plus || 0)}件`, tone: "error" },
    ...(unclassified ? [{ label: "判定待ち", value: `${unclassified}件`, tone: "pending" }] : []),
    { label: "ERROR率", value: errorStats.rateLabel || "-", tone: Number(errorStats.error || 0) ? "error" : "good" },
  ];
  return `
    <section class="device-history-sheet task">
      <div class="device-history-sheet-head">
        <h4>稼働・タスク履歴</h4>
        ${historyRateStrip(summaryItems, "ERROR集計")}
      </div>
      <div class="device-history-table-wrap task-history-scroll" tabindex="0">
        <table class="device-history-table task-history-table">
          <colgroup>
            <col class="col-start"><col class="col-end"><col class="col-sequence"><col class="col-status"><col class="col-day">
            <col class="col-ci"><col class="col-video"><col class="col-video10"><col class="col-error"><col class="col-money"><col class="col-memo">
          </colgroup>
          <thead><tr><th>開始</th><th>終了</th><th>回</th><th>状態</th><th>DAY</th><th>チェックイン</th><th>動画180分</th><th>追加視聴</th><th>ERROR</th><th>収益</th><th>メモ</th></tr></thead>
          <tbody>${rows.length ? rows.join("") : historyEmptyTableRow(11)}</tbody>
        </table>
      </div>
    </section>
  `;
}

function renderTaskHistoryTableRow(item, outcome, withdrawals) {
  const range = taskHistoryDateRangeParts(item);
  const status = item.status === "active" ? "実行中" : item.status === "completed" ? "完了" : item.status || "記録";
  const statusTone = item.status === "completed" ? "good" : item.status === "active" ? "active" : "";
  const payout = historyTaskPayout(item, withdrawals);
  const memo = historyTaskMemo(item, payout);
  return `<tr>
    <td>${esc(range.started || "-")}</td>
    <td>${esc(range.ended || "-")}</td>
    <td>${item.sequence ? `#${esc(item.sequence)}` : "-"}</td>
    <td class="history-table-tone ${esc(statusTone)}">${esc(status)}</td>
    <td class="history-table-tone day">${item.day ? `DAY${esc(String(item.day).padStart(2, "0"))}` : "-"}</td>
    <td>${historyTaskValueCell(item, "ci", "チェックイン")}</td>
    <td>${historyTaskValueCell(item, "video180", "動画180分", "V180_DONE")}</td>
    <td>${historyTaskValueCell(item, "video10", "追加視聴", "V10_DONE")}</td>
    ${historyTaskErrorCell(outcome, item.status)}
    <td class="history-table-tone money">${payout ? esc(yen(payout.amount)) : "-"}</td>
    <td class="history-table-memo" title="${esc(memo)}">${esc(memo)}</td>
  </tr>`;
}

function renderOrphanErrorHistoryTableRow(outcome) {
  const range = taskHistoryDateRangeParts(outcome);
  return `<tr class="history-orphan-error-row">
    <td>${esc(range.started || monthDayLabel(outcome.firstErrorAt || outcome.at || "") || "-")}</td>
    <td>${esc(range.ended || (outcome.provisional ? "進行中" : "-"))}</td>
    <td>${outcome.sequence ? `#${esc(outcome.sequence)}` : "-"}</td>
    <td>判定記録</td><td>-</td><td>-</td><td>-</td><td>-</td>
    ${historyTaskErrorCell(outcome, outcome.provisional ? "active" : "completed")}
    <td>-</td><td class="history-table-memo">ERROR判定履歴のみ</td>
  </tr>`;
}

function historyTaskOutcome(item, outcomes) {
  const own = Array.isArray(item?.errorOutcomes) ? item.errorOutcomes : [];
  const matches = own.length ? own : (Array.isArray(outcomes) ? outcomes : []).filter((outcome) =>
    (item?.cycleId && outcome?.cycleId === item.cycleId) ||
    (item?.sequence && outcome?.sequence && Number(outcome.sequence) === Number(item.sequence))
  );
  return matches.find((outcome) => ["day1", "day2plus"].includes(outcome?.category)) || matches[0] || null;
}

function historyOutcomeKey(outcome) {
  return String(outcome?.id || `${outcome?.cycleId || ""}:${outcome?.sequence || ""}:${outcome?.category || ""}:${outcome?.at || ""}`);
}

function historyTaskErrorCell(outcome, status) {
  if (!outcome) {
    const active = status === "active";
    return `<td class="history-error-cell pending"><strong>${active ? "判定中" : "判定待ち"}</strong></td>`;
  }
  const tone = outcome.category === "none" ? "good" : outcome.category === "unknown" ? "pending" : "error";
  const details = [
    outcome.firstErrorDay ? `DAY${String(outcome.firstErrorDay).padStart(2, "0")}` : "",
    outcome.firstErrorAt ? historyDateTimeLabel(outcome.firstErrorAt) : "",
    outcome.provisional ? "進行中" : "",
  ].filter(Boolean).join("  ");
  return `<td class="history-error-cell ${esc(tone)}"><strong>${esc(historyCompactErrorLabel(outcome))}</strong>${details ? `<small>${esc(details)}</small>` : ""}</td>`;
}

function historyCompactErrorLabel(outcome) {
  if (outcome?.category === "none") return "エラーなし";
  if (outcome?.category === "day1") return "初日ERROR";
  if (outcome?.category === "day2plus") return "2日目以降ERROR";
  return "判定待ち";
}

function historyTaskValueCell(item, field, label, doneTag = "") {
  const value = historyTaskValue(item?.[field], label);
  if (!value) return '<span class="history-table-empty">-</span>';
  const tags = Array.isArray(item?.tags) ? item.tags : [];
  const done = doneTag && tags.includes(doneTag);
  return `<strong>${esc(value)}</strong>${done ? '<small class="history-table-done">完了</small>' : ""}`;
}

function historyTaskPayout(item, withdrawals) {
  const matches = (Array.isArray(withdrawals) ? withdrawals : []).filter((withdrawal) =>
    (item?.cycleId && withdrawal?.cycleId === item.cycleId) ||
    (item?.sequence && withdrawal?.sequence && Number(withdrawal.sequence) === Number(item.sequence))
  );
  const amount = matches.reduce((sum, withdrawal) => sum + Number(withdrawal.amountYen || 0), 0);
  return amount > 0 ? { amount, count: matches.length } : null;
}

function historyTaskMemo(item, payout) {
  const parts = [];
  if (Number(item?.finalYen || 0) > 0) parts.push(`最終記録 ${yen(item.finalYen)}`);
  if (payout?.count > 1) parts.push(`出金 ${payout.count}件`);
  for (const reset of Array.isArray(item?.resetHistory) ? item.resetHistory : []) {
    const resetDetails = [
      monthDayLabel(reset.at || "") ? `リセット ${monthDayLabel(reset.at)}` : "リセット",
      reset.reason || "",
      historyRecordedAmountYen(reset.amountYen),
      historyRecordedUptime(reset.uptimeSeconds, reset.uptimeSource),
      ...historyTextParts(reset.summary),
    ].filter(Boolean);
    parts.push(resetDetails.join(" "));
  }
  return parts.join(" / ") || "-";
}

function inviteFilterButtonText(label, stats) {
  return `${label} ${stats.rateLabel}${stats.total ? ` (${stats.total})` : ""}`;
}

function renderInviteFilterTabs(row, entries, filters = {}, scope = "history") {
  const product = normalizeInviteProduct(filters.product);
  const type = String(filters.type || "");
  const productTabs = INVITE_PRODUCTS.map((item) => {
    const stats = inviteHistoryStats(row, entries, { product: item.value, type });
    return `<button class="invite-analytics-filter-btn ${item.value === product ? "active" : ""}" type="button"
      data-${scope}-invite-product="${esc(item.value)}" aria-pressed="${item.value === product ? "true" : "false"}">${esc(inviteFilterButtonText(item.label, stats))}</button>`;
  }).join("");
  const typeTabs = [
    { value: "", label: "全体" },
    ...INVITE_TYPE_ORDER.map((value) => ({ value, label: value })),
  ].map((item) => {
    const stats = inviteHistoryStats(row, entries, { product, type: item.value });
    return `<button class="invite-analytics-filter-btn ${item.value === type ? "active" : ""}" type="button"
      data-${scope}-invite-type="${esc(item.value)}" aria-pressed="${item.value === type ? "true" : "false"}">${esc(inviteFilterButtonText(item.label, stats))}</button>`;
  }).join("");
  return `
    <div class="invite-analytics-filter-bar">
      <div class="invite-analytics-filter-group"><strong>アプリ</strong><div class="invite-analytics-filter-tabs">${productTabs}</div></div>
      <div class="invite-analytics-filter-group"><strong>招待種別</strong><div class="invite-analytics-filter-tabs">${typeTabs}</div></div>
    </div>
  `;
}

function historyInviteTable(row, entries, filters = { product: "lite", type: "" }) {
  const selected = {
    product: normalizeInviteProduct(filters.product),
    type: String(filters.type || ""),
  };
  const stats = inviteHistoryStats(row, entries, selected);
  const rows = filterInviteEntries(entries, selected)
    .slice()
    .sort((a, b) => String(b?.at || "").localeCompare(String(a?.at || "")));
  return `
    <section class="device-history-sheet invite" data-invite-product="${esc(selected.product)}" data-invite-type="${esc(selected.type)}">
      <div class="device-history-sheet-head">
        <h4>招待検証（${selected.product === "main" ? "TikTok本家" : "TikTok Lite"}${selected.type ? ` / ${esc(selected.type)}` : ""}）</h4>
        ${historyRateStrip([
          { label: "成功", value: `${stats.success}件`, tone: "good" },
          { label: "失敗", value: `${stats.fail}件`, tone: "error" },
          { label: "成功率", value: stats.rateLabel, tone: stats.fail ? "" : "good" },
        ], "招待成功率")}
      </div>
      ${renderInviteFilterTabs(row, entries, selected, "history")}
      <div class="device-history-table-wrap invite-history-scroll" tabindex="0">
        <table class="device-history-table invite-history-table">
          <colgroup><col class="col-date"><col class="col-product"><col class="col-type"><col class="col-role"><col class="col-result"><col class="col-partner"><col class="col-sim"><col class="col-network"><col class="col-switch-day"><col class="col-method"><col class="col-os"><col class="col-uptime"><col class="col-note"></colgroup>
          <thead><tr><th>日付</th><th>アプリ</th><th>招待</th><th>親 or 子</th><th>結果</th><th>相手</th><th>SIM</th><th>通信</th><th>切替DAY</th><th>導入方法</th><th>OS</th><th>UPTIME</th><th>備考</th></tr></thead>
          <tbody>${rows.length ? rows.map(renderInviteHistoryTableRow).join("") : historyEmptyTableRow(13)}</tbody>
        </table>
      </div>
    </section>
  `;
}

function renderInviteHistoryTableRow(entry) {
  if (entry?.legacy) {
    return `<tr><td>-</td><td>Lite</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td class="history-table-memo">${esc(entry.text || "記録なし")}</td></tr>`;
  }
  const partner = invitePartnerLabel(entry?.partner) || entry?.partner || "-";
  const result = entry?.result || "-";
  const resultTone = /成功|OK/i.test(result) ? "good" : /失敗|NG/i.test(result) ? "error" : "";
  return `<tr>
    <td>${esc(monthDayLabel(entry?.at || "") || "-")}</td>
    <td>${normalizeInviteProduct(entry?.product) === "main" ? "本家" : "Lite"}</td>
    <td>${esc(entry?.type || "-")}</td>
    <td>${esc(entry?.role || "-")}</td>
    <td class="history-table-tone ${esc(resultTone)}">${esc(result)}</td>
    <td class="history-table-partner" title="${esc(partner)}">${esc(partner)}</td>
    <td>${esc(entry?.simStatus || "-")}</td>
    <td>${esc(entry?.networkType || "-")}</td>
    <td>${entry?.networkSwitchedDay ? `DAY${esc(String(entry.networkSwitchedDay).padStart(2, "0"))}` : "-"}</td>
    <td>${esc(entry?.ttlRegisterMethod || "-")}</td>
    <td>${esc(formatOsVersion(entry?.osVersion) || "-")}</td>
    <td>${esc(historyRecordedUptime(entry?.uptimeSeconds, entry?.uptimeSource) || "-")}</td>
    <td class="history-table-memo" title="${esc(entry?.note || "-")}">${esc(entry?.note || "-")}</td>
  </tr>`;
}

function historyRecordedUptime(seconds, source = "") {
  if (seconds === null || seconds === undefined || seconds === "") return "";
  const value = Number(seconds);
  if (!Number.isFinite(value) || value < 0) return "";
  return `UPTIME ${uptimeLabel(value / 3600)}${source === "manual" ? "（手入力）" : ""}`;
}

function historyRecordedAmountYen(value) {
  if (value === null || value === undefined || value === "") return "";
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount < 0) return "";
  return `${amount.toLocaleString("ja-JP")}円`;
}

function historyWithdrawalTable(withdrawals) {
  const rows = Array.isArray(withdrawals) ? withdrawals : [];
  return `
    <section class="device-history-sheet money">
      <div class="device-history-sheet-head"><h4>出金・個別収益</h4><span class="history-sheet-count">${esc(rows.length)}件</span></div>
      <div class="device-history-table-wrap withdrawal-history-scroll" tabindex="0">
        <table class="device-history-table withdrawal-history-table">
          <colgroup><col class="col-date"><col class="col-money"><col class="col-site"><col class="col-day"><col class="col-reflect"><col class="col-cycle"><col class="col-note"></colgroup>
          <thead><tr><th>日付</th><th>金額</th><th>拠点</th><th>DAY</th><th>反映</th><th>稼働回</th><th>内容</th></tr></thead>
          <tbody>${rows.length ? rows.map(renderWithdrawalHistoryTableRow).join("") : historyEmptyTableRow(7)}</tbody>
        </table>
      </div>
    </section>
  `;
}

function renderWithdrawalHistoryTableRow(row) {
  const reflected = row.resetDone || row.resetDoneAt ? "非稼働反映済" : "記録のみ";
  return `<tr>
    <td>${esc(monthDayLabel(row.withdrawalDate || row.recordedAt || "") || "-")}</td>
    <td class="history-table-tone money">${esc(yen(row.amountYen))}</td>
    <td>${esc(row.siteName || "-")}</td>
    <td class="history-table-tone day">${row.day ? `DAY${esc(String(row.day).padStart(2, "0"))}` : "-"}</td>
    <td class="history-table-tone ${row.resetDone || row.resetDoneAt ? "good" : ""}">${esc(reflected)}</td>
    <td>${row.sequence ? `#${esc(row.sequence)}` : esc(row.cycleId || "-")}</td>
    <td class="history-table-memo" title="${esc(toJapaneseMemo(row.memo) || "-")}">${esc(toJapaneseMemo(row.memo) || "-")}</td>
  </tr>`;
}

function historyEmptyTableRow(columns) {
  return `<tr class="history-table-empty-row"><td colspan="${Number(columns)}">記録なし</td></tr>`;
}

function historyInfoSheet(title, cards, kind = "") {
  const chunks = [];
  for (let index = 0; index < cards.length; index += 6) chunks.push(cards.slice(index, index + 6));
  const body = chunks.map((chunk) => `
    <tr class="history-info-labels">${chunk.map((card) => `<th>${esc(card.label)}</th>`).join("")}${"<th></th>".repeat(6 - chunk.length)}</tr>
    <tr class="history-info-values">${chunk.map((card) => `<td class="${esc(card.tone || "")}" title="${esc(`${card.label}: ${card.value || "-"}`)}">${esc(card.value || "-")}</td>`).join("")}${"<td></td>".repeat(6 - chunk.length)}</tr>
  `).join("");
  return `
    <section class="device-history-sheet info ${esc(kind)}">
      <div class="device-history-sheet-head"><h4>${esc(title)}</h4></div>
      <div class="device-history-table-wrap history-info-scroll" tabindex="0">
        <table class="device-history-info-table"><tbody>${body}</tbody></table>
      </div>
    </section>
  `;
}

function historyDeviceCurrentCards(row, live) {
  const install = historyDeviceInstallSnapshot(row);
  const connectionStats = row.connectionIncidentStats || {};
  const recoveryStats = row.recoveryAttemptStats || {};
  return [
    { label: "番号", value: row.laixiNumber || row.xiaoweiNumber || "-" },
    { label: "XiaoWei名", value: row.laixiName || row.xiaoweiName || "-" },
    { label: "マスタ", value: row.deviceName || "-" },
    { label: "短縮名", value: row.modelGroup || row.shortNameOverride || "-" },
    { label: "端末ID", value: row.serial || "-" },
    { label: "XiaoWei番号", value: row.xiaoweiNumber || row.laixiNumber || "-" },
    { label: "キャリア", value: row.carrierCode || "未設定" },
    { label: "状態", value: historyStatusLabel(row.status), tone: String(row.status || "").toLowerCase() },
    { label: "OS", value: formatOsVersion(row.deviceOsVersion || row.osVersion) || "未取得" },
    { label: "SIM", value: row.deviceSimStatus || row.simStatus || "未設定" },
    { label: "通信", value: row.deviceNetworkType || row.networkType || "未設定" },
    { label: "切替日", value: row.networkSwitchedDay ? `DAY${row.networkSwitchedDay}` : "記録なし" },
    { label: "UPTIME", value: live.uptimeText || "未取得" },
    { label: "電池", value: live.batteryText || "未取得" },
    { label: "ADB", value: live.adbText || "未確認", tone: live.adbText === "ADB OFFLINE" ? "error" : "good" },
    { label: "切断履歴", value: `${Number(connectionStats.total || 0)}件`, tone: connectionStats.chronic ? "error" : "" },
    { label: "30日以内", value: `${Number(connectionStats.last30Days || 0)}件`, tone: connectionStats.chronic ? "error" : "" },
    { label: "直近切断", value: connectionStats.latestAt ? historyDateTimeLabel(connectionStats.latestAt) : "記録なし" },
    { label: "復旧実行", value: `${Number(recoveryStats.total || 0)}回`, tone: recoveryStats.repeated ? "error" : "" },
    { label: "直近復旧操作", value: recoveryStats.latestAt ? historyDateTimeLabel(recoveryStats.latestAt) : "記録なし" },
    { label: "初期設定", value: install.initialSettings },
    { label: "アプリ", value: install.appState },
    { label: "Agent", value: install.agent },
    { label: "初回登録", value: row.firstSeenAt ? formatDateTime(row.firstSeenAt) : "記録なし" },
    { label: "最終認識", value: row.lastSeenAt ? formatDateTime(row.lastSeenAt) : "記録なし" },
    { label: "元の名前", value: row.originalName || "記録なし" },
  ];
}

function historyDeviceInstallSnapshot(row) {
  const settings = row.deviceSettings && typeof row.deviceSettings === "object" ? row.deviceSettings : {};
  const baselineChecks = [
    settings.emergencyAlertsOff?.observed,
    settings.autoRotateOff?.observed,
    settings.dataSaverOn?.observed,
    settings.nfcOff?.observed,
    settings.silentOn?.observed,
    settings.userAppNotificationsOff?.observed,
  ];
  const completedSettings = baselineChecks.filter((value) => value === true).length;
  const checkedSettings = baselineChecks.filter((value) => value === true || value === false).length;
  const initialSettings = completedSettings === baselineChecks.length
    ? "完了"
    : checkedSettings ? `${completedSettings}/${baselineChecks.length}` : "未確認";
  const agent = row.swipeAgentInstalled === true
    ? row.swipeAgentAccessibilityEnabled === false ? "導入済・権限OFF" : "導入済"
    : row.swipeAgentInstalled === false ? "未導入" : "未確認";
  const appState = [
    row.ttlInstalled === true ? "TTL導入済" : row.ttlInstalled === false ? "TTLなし" : "TTL未確認",
    row.lineInstalled === true ? "LINE導入済" : row.lineInstalled === false ? "LINEなし" : "LINE未確認",
  ].join("  ");
  return { initialSettings, agent, appState };
}

function historyInviteCurrentCards(row, stats) {
  const profileCards = INVITE_PRODUCTS.flatMap((product) => {
    const profile = inviteProfileForRow(row, product.value);
    const result = profile.inviteResult || "結果未設定";
    const prefix = product.label;
    return [
      { label: `${prefix} 招待`, value: profile.inviteType || "招待未設定" },
      { label: `${prefix} 親 or 子`, value: profile.inviteRole || "親子未設定" },
      { label: `${prefix} 結果`, value: result, tone: /成功|OK/i.test(result) ? "good" : /失敗|NG/i.test(result) ? "error" : "" },
      { label: `${prefix} 相手`, value: invitePartnerLabel(profile.invitePartner) || "相手未設定" },
      { label: `${prefix} 導入方法`, value: profile.ttlRegisterMethod || "未設定" },
    ];
  });
  return [
    ...profileCards,
    { label: "SIM", value: row.simStatus || "未設定" },
    { label: "通信", value: row.networkType || "未設定" },
    { label: "OS", value: formatOsVersion(row.osVersion) || "未取得" },
    { label: "全履歴 成功", value: `${stats.success}件`, tone: "good" },
    { label: "全履歴 失敗", value: `${stats.fail}件`, tone: stats.fail ? "error" : "" },
    { label: "全履歴 成功率", value: stats.rateLabel, tone: stats.fail ? "" : "good" },
    { label: "Wi-Fi切替DAY", value: row.networkSwitchedDay ? `DAY${row.networkSwitchedDay}` : "記録なし" },
  ];
}

async function retireDeviceFromHistory(row, button = null) {
  const number = row?.laixiNumber || row?.xiaoweiNumber || "-";
  const name = row?.deviceLabel || row?.laixiName || row?.deviceName || row?.serial || "端末";
  if (!window.confirm(`${number} / ${name} を管理対象から外しますか？\n履歴を残したまま、空いている9000番台へ移します。`)) return;
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/fleet-db/devices/retire", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ device: row.serial || row.managementId, reason: "管理画面から手動で除外" }),
    });
    logLine(`管理対象外: ${number} → ${result.device?.xiaoweiNumber || "9000番台"} / ${name} / 履歴保存済 / バックアップ ${result.backup || "-"}`);
    closeDeviceHistoryDialog();
    await loadLocalSummaryOnly();
  } catch (error) {
    logLine("管理対象外 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function showRetiredDevicesDialog(button = null) {
  setBusy(true, button);
  let result = null;
  try {
    result = await fetchJson("/api/fleet-db/retired-devices");
  } catch (error) {
    logLine("管理対象外一覧 NG: " + error.message);
    result = { ok: false, devices: [], error: error.message };
  } finally {
    setBusy(false);
  }
  closeAdbDropDialog();
  const rows = Array.isArray(result.devices) ? result.devices : [];
  const overlay = document.createElement("div");
  overlay.className = "adb-drop-dialog-backdrop";
  overlay.innerHTML = `
    <div class="adb-drop-dialog adb-missing-list-dialog retired-devices-dialog" role="dialog" aria-modal="true" aria-labelledby="retiredDevicesDialogTitle">
      <div class="adb-drop-dialog-head">
        <div>
          <h3 id="retiredDevicesDialogTitle">管理対象外（9000番台）</h3>
          <p>${esc(rows.length)}台 / 履歴はDBに保存されています</p>
        </div>
        <button class="adb-drop-close" type="button" aria-label="閉じる">×</button>
      </div>
      ${rows.length ? `
        <div class="adb-missing-table-wrap">
          <table class="adb-missing-table retired-devices-table">
            <thead><tr><th>番号</th><th>端末名</th><th>外した日時</th><th>理由</th><th>端末ID</th><th></th></tr></thead>
            <tbody>${rows.map((row) => `
              <tr>
                <td><strong>${esc(row.xiaoweiNumber || "-")}</strong>${row.retiredFromXiaoweiNumber ? `<span>元 ${esc(row.retiredFromXiaoweiNumber)}</span>` : ""}</td>
                <td><strong>${esc(row.deviceLabel || row.deviceName || "端末名なし")}</strong><span>履歴 ${esc(row.historyCount || 0)}件</span></td>
                <td>${esc(formatDateTime(row.retiredAt || ""))}</td>
                <td>${esc(row.retiredReason || "-")}</td>
                <td><code>${esc(row.serial || "")}</code></td>
                <td><button class="section-head-action restore-retired-device-action" data-device="${esc(row.serial || row.managementId || "")}" type="button">一覧へ戻す</button></td>
              </tr>
            `).join("")}</tbody>
          </table>
        </div>
      ` : `<div class="adb-missing-empty">管理対象外の端末はありません。</div>`}
      <div class="adb-drop-actions"><button class="section-head-action adb-drop-close-action" type="button">閉じる</button></div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelectorAll(".restore-retired-device-action").forEach((restoreButton) => {
    restoreButton.addEventListener("click", () => restoreRetiredDevice(restoreButton.dataset.device, restoreButton));
  });
  overlay.querySelectorAll(".adb-drop-close, .adb-drop-close-action").forEach((closeButton) => {
    closeButton.addEventListener("click", closeAdbDropDialog);
  });
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeAdbDropDialog();
  });
}

async function restoreRetiredDevice(device, button = null) {
  if (!window.confirm("この端末を管理一覧へ戻しますか？")) return;
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/fleet-db/devices/restore", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ device }),
    });
    logLine(`管理対象へ復帰: ${result.device?.xiaoweiNumber || "-"} / ${device}`);
    await loadLocalSummaryOnly();
    await showRetiredDevicesDialog();
  } catch (error) {
    logLine("管理対象への復帰 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function historySection(title, count, lines, kind = "") {
  const body = lines.length
    ? lines.map((line) => `<li>${line}</li>`).join("")
    : `<li class="empty"><span>記録なし</span></li>`;
  return `
    <section class="device-history-section ${esc(kind)}">
      <h4>${esc(title)}<span>${esc(count)}件</span></h4>
      <ul>${body}</ul>
    </section>
  `;
}

function historyIdentityLine(row) {
  const chips = [
    ["番号", row.laixiNumber || row.xiaoweiNumber || "-", "number"],
    ["XiaoWei名", row.laixiName || row.xiaoweiName || "-", "xiaowei"],
    ["マスタ", row.deviceName || "-", "master"],
    ["端末ID", row.serial || "-", "serial"],
  ];
  return `<div class="device-history-identity">${chips.map(([label, value, tone]) => `
    <span class="${esc(tone)}"><small>${esc(label)}</small><b>${esc(value)}</b></span>
  `).join("")}</div>`;
}

function historySummaryBlock(title, cards, kind = "") {
  return `
    <section class="device-history-summary-block ${esc(kind)}">
      <h4>${esc(title)}</h4>
      <div class="device-history-summary">
        ${cards.map((card) => {
          const value = card.value || "-";
          const classes = [card.tone || "", card.className || ""].filter(Boolean).join(" ");
          return `<div class="${esc(classes)}" title="${esc(`${card.label}: ${value}`)}"><span>${esc(card.label)}</span><strong>${esc(value)}</strong></div>`;
        }).join("")}
      </div>
    </section>
  `;
}

function historyDeviceSummary(row, live) {
  const settings = row.deviceSettings && typeof row.deviceSettings === "object" ? row.deviceSettings : {};
  const baselineChecks = [
    settings.emergencyAlertsOff?.observed,
    settings.autoRotateOff?.observed,
    settings.dataSaverOn?.observed,
    settings.nfcOff?.observed,
    settings.silentOn?.observed,
    settings.userAppNotificationsOff?.observed,
  ];
  const completedSettings = baselineChecks.filter((value) => value === true).length;
  const checkedSettings = baselineChecks.filter((value) => value === true || value === false).length;
  const initialSettings = completedSettings === baselineChecks.length
    ? "完了"
    : checkedSettings ? `${completedSettings}/${baselineChecks.length}` : "未確認";
  const agent = row.swipeAgentInstalled === true
    ? row.swipeAgentAccessibilityEnabled === false ? "導入済・権限OFF" : "導入済"
    : row.swipeAgentInstalled === false ? "未導入" : "未確認";
  const appState = [
    row.ttlInstalled === true ? "TTL導入済" : row.ttlInstalled === false ? "TTLなし" : "TTL未確認",
    row.lineInstalled === true ? "LINE導入済" : row.lineInstalled === false ? "LINEなし" : "LINE未確認",
  ].join("  ");
  return historySummaryBlock("端末情報", [
    { label: "状態", value: historyStatusLabel(row.status), tone: String(row.status || "").toLowerCase() },
    { label: "OS", value: formatOsVersion(row.deviceOsVersion || row.osVersion) || "未取得" },
    { label: "SIM", value: row.deviceSimStatus || row.simStatus || "未設定" },
    { label: "通信", value: row.deviceNetworkType || row.networkType || "未設定" },
    { label: "UPTIME", value: live.uptimeText || "未取得" },
    { label: "電池", value: live.batteryText || "未取得" },
    { label: "ADB", value: live.adbText || "未確認", tone: live.adbText === "ADB OFFLINE" ? "warn" : "" },
    { label: "初期設定", value: initialSettings },
    { label: "アプリ", value: appState },
    { label: "Agent", value: agent },
    { label: "初回登録", value: row.firstSeenAt ? formatDateTime(row.firstSeenAt) : "記録なし" },
    { label: "最終認識", value: row.lastSeenAt ? formatDateTime(row.lastSeenAt) : "記録なし" },
  ], "device");
}

function historyStatusLabel(status) {
  const value = String(status || "UNKNOWN").toUpperCase();
  if (["WAITING", "INACTIVE", "NO CYCLE"].includes(value)) return "非稼働";
  if (value === "ONLINE") return "ONLINE";
  if (value === "ACTIVE") return "稼働中";
  return value;
}

function historyErrorSummary(stats = {}) {
  return historySummaryBlock("ERROR集計", [
    { label: "ERROR率", value: stats.rateLabel || "-", tone: Number(stats.error || 0) ? "warn" : "good" },
    { label: "集計対象", value: `${Number(stats.total || 0)}件` },
    { label: "エラーなし", value: `${Number(stats.noError || 0)}件`, tone: "good" },
    { label: "初日にエラー", value: `${Number(stats.day1 || 0)}件`, tone: "warn" },
    { label: "2日目以降", value: `${Number(stats.day2Plus || 0)}件`, tone: "warn" },
    { label: "旧履歴・判定待ち", value: `${Number(stats.unclassified || 0)}件`, tone: Number(stats.unclassified || 0) ? "pending" : "" },
  ], "error");
}

function historyInviteSummary(row, stats) {
  return historySummaryBlock("招待検証・現在値", historyInviteCurrentCards(row, stats), "invite");
}

function inviteEntryMatchesFilter(entry, filters = {}) {
  const product = filters.product ? normalizeInviteProduct(filters.product) : "";
  const type = String(filters.type || "");
  if (product && normalizeInviteProduct(entry?.product) !== product) return false;
  if (type && String(entry?.type || "") !== type) return false;
  return true;
}

function filterInviteEntries(entries = [], filters = {}) {
  return (Array.isArray(entries) ? entries : []).filter((entry) => inviteEntryMatchesFilter(entry, filters));
}

function inviteHistoryStats(row, entries = [], filters = {}) {
  const filteredEntries = filterInviteEntries(entries, filters);
  let success = 0;
  let fail = 0;
  for (const entry of filteredEntries) {
    const result = String(entry?.result || entry?.text || "");
    if (/成功|OK/i.test(result)) success += 1;
    if (/失敗|NG/i.test(result)) fail += 1;
  }
  if (!entries.length) {
    const product = filters.product ? normalizeInviteProduct(filters.product) : "lite";
    const profile = inviteProfileForRow(row, product);
    if ((!filters.type || profile.inviteType === filters.type) && ["成功", "OK"].includes(profile.inviteResult)) success = 1;
    if ((!filters.type || profile.inviteType === filters.type) && ["失敗", "NG"].includes(profile.inviteResult)) fail = 1;
  }
  const total = success + fail;
  const rateLabel = total ? `${Math.round((success / total) * 100)}%` : "-";
  return { success, fail, total, rate: total ? Math.round((success / total) * 100) : null, rateLabel };
}

function inviteResultKind(value) {
  const result = String(value || "").trim();
  if (/成功|OK/i.test(result)) return "success";
  if (/失敗|NG/i.test(result)) return "fail";
  return "";
}

function inviteSuccessRateTone(stats = {}) {
  const total = Number(stats.total ?? (Number(stats.success || 0) + Number(stats.fail || 0)));
  if (!total) return "empty";
  const rate = Number.isFinite(Number(stats.rate))
    ? Number(stats.rate)
    : Math.round((Number(stats.success || 0) / total) * 100);
  if (rate >= 70) return "good";
  if (rate >= 40) return "pending";
  return "error";
}

function inviteAnalyticsDeviceKey(row) {
  return String(row?.serial || row?.managementId || row?.laixiNumber || "");
}

function inviteAnalyticsDeviceLabel(row) {
  const number = row?.laixiNumber || row?.xiaoweiNumber || row?.managementId || "-";
  const name = row?.deviceLabel || row?.laixiName || row?.xiaoweiName || row?.uiName || row?.deviceName || row?.serial || "端末名なし";
  return `${number} / ${name}`;
}

function inviteAnalyticsRecords(rows = []) {
  const records = [];
  for (const row of Array.isArray(rows) ? rows : []) {
    const storedEntries = inviteHistoryEntries(row)
      .filter((entry) => entry && inviteResultKind(entry.result || entry.text));
    const fallbackEntries = INVITE_PRODUCTS.map((product) => {
      const profile = inviteProfileForRow(row, product.value);
      if (!inviteResultKind(profile.inviteResult)) return null;
      return {
        at: "",
        product: product.value,
        type: profile.inviteType || "",
        role: profile.inviteRole || "",
        result: profile.inviteResult || "",
        partner: profile.invitePartner || "",
        simStatus: row.simStatus || "",
        networkType: row.networkType || "",
        ttlRegisterMethod: profile.ttlRegisterMethod || "",
        osVersion: row.osVersion || "",
        uptimeSeconds: null,
        uptimeSource: "",
        note: profile.inviteOpsNote || "",
      };
    }).filter(Boolean);
    const entries = storedEntries.length ? storedEntries : fallbackEntries;
    for (const entry of entries) {
      const result = String(entry?.result || entry?.text || "");
      const kind = inviteResultKind(result);
      if (!kind) continue;
      const rawUptimeSeconds = entry?.uptimeSeconds;
      const uptimeSeconds = rawUptimeSeconds === null || rawUptimeSeconds === undefined || rawUptimeSeconds === ""
        ? null
        : Number(rawUptimeSeconds);
      records.push({
        deviceKey: inviteAnalyticsDeviceKey(row),
        deviceLabel: inviteAnalyticsDeviceLabel(row),
        row,
        at: String(entry?.at || ""),
        product: normalizeInviteProduct(entry?.product),
        type: String(entry?.type || ""),
        role: String(entry?.role || ""),
        result,
        kind,
        partner: String(entry?.partner || ""),
        uptimeSeconds: Number.isFinite(uptimeSeconds) && uptimeSeconds >= 0 ? uptimeSeconds : null,
        uptimeSource: String(entry?.uptimeSource || ""),
        note: String(entry?.note || ""),
      });
    }
  }
  return records.sort((left, right) => String(right.at).localeCompare(String(left.at)));
}

function inviteAnalyticsAverageHours(records = []) {
  const hours = records
    .map((record) => record?.uptimeSeconds)
    .filter((value) => value !== null && value !== undefined && value !== "" && Number.isFinite(Number(value)) && Number(value) >= 0)
    .map((value) => Number(value) / 3600);
  if (!hours.length) return null;
  return hours.reduce((sum, value) => sum + value, 0) / hours.length;
}

function inviteAnalyticsMedianHours(records = []) {
  const hours = records
    .map((record) => record?.uptimeSeconds)
    .filter((value) => value !== null && value !== undefined && value !== "" && Number.isFinite(Number(value)) && Number(value) >= 0)
    .map((value) => Number(value) / 3600)
    .sort((left, right) => left - right);
  if (!hours.length) return null;
  const middle = Math.floor(hours.length / 2);
  return hours.length % 2 ? hours[middle] : (hours[middle - 1] + hours[middle]) / 2;
}

function inviteAnalyticsUptimeBands(records = []) {
  const bands = [
    { label: "0–24h", min: 0, max: 24 },
    { label: "24–72h", min: 24, max: 72 },
    { label: "72–120h", min: 72, max: 120 },
    { label: "120–200h", min: 120, max: 200 },
    { label: "200–300h", min: 200, max: 300 },
    { label: "300h以上", min: 300, max: Infinity },
  ].map((band) => ({ ...band, success: 0, fail: 0, total: 0, rate: null, rateLabel: "-" }));
  let unknown = 0;
  for (const record of records) {
    if (record?.uptimeSeconds === null || record?.uptimeSeconds === undefined || record?.uptimeSeconds === ""
        || !Number.isFinite(Number(record.uptimeSeconds)) || Number(record.uptimeSeconds) < 0) {
      unknown += 1;
      continue;
    }
    const hours = Number(record.uptimeSeconds) / 3600;
    const band = bands.find((item) => hours >= item.min && hours < item.max);
    if (!band) continue;
    if (record.kind === "success") band.success += 1;
    if (record.kind === "fail") band.fail += 1;
    band.total = band.success + band.fail;
    band.rate = band.total ? Math.round((band.success / band.total) * 100) : null;
    band.rateLabel = band.rate === null ? "-" : `${band.rate}%`;
  }
  return { bands, unknown };
}

function inviteAnalyticsRelationships(records = []) {
  const grouped = new Map();
  for (const record of records) {
    const role = String(record?.role || "");
    const partner = invitePartnerLabel(record?.partner) || String(record?.partner || "").trim();
    if (!partner || !/[親子]|parent|child/i.test(role)) continue;
    const isChild = /子|child/i.test(role);
    const parent = isChild ? partner : record.deviceLabel;
    const child = isChild ? record.deviceLabel : partner;
    const key = `${parent}\u0000${child}`;
    const current = grouped.get(key) || {
      parent,
      child,
      success: 0,
      fail: 0,
      total: 0,
      latestAt: "",
      sourceDeviceKey: record.deviceKey,
    };
    if (record.kind === "success") current.success += 1;
    if (record.kind === "fail") current.fail += 1;
    current.total = current.success + current.fail;
    if (String(record.at) > String(current.latestAt)) {
      current.latestAt = record.at;
      current.sourceDeviceKey = record.deviceKey;
    }
    grouped.set(key, current);
  }
  return [...grouped.values()]
    .map((item) => ({
      ...item,
      rate: item.total ? Math.round((item.success / item.total) * 100) : null,
      rateLabel: item.total ? `${Math.round((item.success / item.total) * 100)}%` : "-",
    }))
    .sort((left, right) => String(right.latestAt).localeCompare(String(left.latestAt)));
}

function inviteAnalyticsSnapshot(rows = [], filters = {}) {
  const devices = Array.isArray(rows) ? rows : [];
  const allRecords = inviteAnalyticsRecords(devices);
  const product = filters.product ? normalizeInviteProduct(filters.product) : "";
  const type = String(filters.type || "");
  const records = allRecords.filter((record) => {
    if (product && normalizeInviteProduct(record.product) !== product) return false;
    if (type && String(record.type || "") !== type) return false;
    return true;
  });
  const successRecords = records.filter((record) => record.kind === "success");
  const failRecords = records.filter((record) => record.kind === "fail");
  const success = successRecords.length;
  const fail = failRecords.length;
  const total = success + fail;
  const rate = total ? Math.round((success / total) * 100) : null;
  const deviceStats = devices.map((row) => {
    const deviceKey = inviteAnalyticsDeviceKey(row);
    const ownRecords = records.filter((record) => record.deviceKey === deviceKey);
    const ownSuccess = ownRecords.filter((record) => record.kind === "success").length;
    const ownFail = ownRecords.filter((record) => record.kind === "fail").length;
    const ownTotal = ownSuccess + ownFail;
    const ownRate = ownTotal ? Math.round((ownSuccess / ownTotal) * 100) : null;
    return {
      row,
      deviceKey,
      deviceLabel: inviteAnalyticsDeviceLabel(row),
      success: ownSuccess,
      fail: ownFail,
      total: ownTotal,
      rate: ownRate,
      rateLabel: ownRate === null ? "-" : `${ownRate}%`,
      successAverageHours: inviteAnalyticsAverageHours(ownRecords.filter((record) => record.kind === "success")),
      recordedUptime: ownRecords.filter((record) => record.uptimeSeconds !== null).length,
    };
  }).filter((item) => item.total)
    .sort((left, right) => {
      if (right.rate !== left.rate) return Number(right.rate || 0) - Number(left.rate || 0);
      if (right.total !== left.total) return right.total - left.total;
      return left.deviceLabel.localeCompare(right.deviceLabel, "ja");
    });
  const uptime = inviteAnalyticsUptimeBands(records);
  return {
    records,
    deviceStats,
    relationships: inviteAnalyticsRelationships(records),
    uptimeBands: uptime.bands,
    unknownUptime: uptime.unknown,
    success,
    fail,
    total,
    rate,
    rateLabel: rate === null ? "-" : `${rate}%`,
    recordedUptime: records.filter((record) => record.uptimeSeconds !== null).length,
    successAverageHours: inviteAnalyticsAverageHours(successRecords),
    successMedianHours: inviteAnalyticsMedianHours(successRecords),
    failAverageHours: inviteAnalyticsAverageHours(failRecords),
  };
}

function inviteAnalyticsHoursLabel(value) {
  return value !== null && value !== undefined && value !== "" && Number.isFinite(Number(value))
    ? `${Number(value).toFixed(1)}h`
    : "-";
}

function renderInviteAnalyticsUptimeChart(analytics) {
  const bands = Array.isArray(analytics?.uptimeBands) ? analytics.uptimeBands : [];
  if (!bands.some((band) => band.total)) {
    return `<div class="invite-analytics-empty">UPTIME付きの招待履歴がありません</div>`;
  }
  return `<div class="invite-uptime-chart">${bands.map((band) => {
    const rate = Number.isFinite(Number(band.rate)) ? Number(band.rate) : 0;
    const tone = inviteSuccessRateTone(band);
    return `<div class="invite-uptime-chart-row ${esc(tone)}">
      <strong>${esc(band.label)}</strong>
      <div class="invite-rate-track" aria-label="${esc(`${band.label} 成功率 ${band.rateLabel}`)}"><span style="width:${esc(rate)}%"></span></div>
      <b>${esc(band.rateLabel)}</b>
      <small>成功 ${esc(band.success)} / 失敗 ${esc(band.fail)} / n=${esc(band.total)}</small>
    </div>`;
  }).join("")}</div>`;
}

function renderInviteAnalyticsDeviceTable(analytics, focusDevice = "") {
  const rows = Array.isArray(analytics?.deviceStats) ? analytics.deviceStats : [];
  if (!rows.length) return `<div class="invite-analytics-empty">端末別の招待結果はまだありません</div>`;
  return `<div class="invite-analytics-table-wrap">
    <table class="invite-analytics-table invite-device-rate-table">
      <thead><tr><th>端末</th><th>成功率</th><th>成功</th><th>失敗</th><th>成功時UPTIME平均</th><th>履歴</th></tr></thead>
      <tbody>${rows.map((item) => {
        const focused = focusDevice && [item.deviceKey, item.row?.managementId, item.row?.laixiNumber].map(String).includes(String(focusDevice));
        const rate = Number.isFinite(Number(item.rate)) ? Number(item.rate) : 0;
        return `<tr class="${focused ? "focused" : ""}">
          <td><strong>${esc(item.deviceLabel)}</strong></td>
          <td><div class="invite-device-rate-value ${esc(inviteSuccessRateTone(item))}"><b>${esc(item.rateLabel)}</b><span class="invite-rate-track"><i style="width:${esc(rate)}%"></i></span><small>n=${esc(item.total)}</small></div></td>
          <td class="good">${esc(item.success)}</td>
          <td class="${item.fail ? "error" : ""}">${esc(item.fail)}</td>
          <td>${esc(inviteAnalyticsHoursLabel(item.successAverageHours))}<small>${esc(item.recordedUptime)}/${esc(item.total)}件取得</small></td>
          <td><button class="invite-open-history-btn" data-invite-history-device="${esc(item.deviceKey)}" type="button">個別履歴</button></td>
        </tr>`;
      }).join("")}</tbody>
    </table>
  </div>`;
}

function renderInviteAnalyticsRelationships(analytics) {
  const rows = Array.isArray(analytics?.relationships) ? analytics.relationships : [];
  if (!rows.length) {
    return `<div class="invite-analytics-empty">親・子・招待相手の組み合わせがまだ記録されていません</div>`;
  }
  return `<div class="invite-analytics-table-wrap">
    <table class="invite-analytics-table invite-relationship-table">
      <thead><tr><th>親</th><th></th><th>子</th><th>成功率</th><th>記録</th><th>最終</th></tr></thead>
      <tbody>${rows.map((item) => `<tr>
        <td><strong>${esc(item.parent)}</strong></td>
        <td class="invite-relation-arrow">→</td>
        <td><strong>${esc(item.child)}</strong></td>
        <td class="${esc(inviteSuccessRateTone(item))}">${esc(item.rateLabel)}</td>
        <td>成功 ${esc(item.success)} / 失敗 ${esc(item.fail)}</td>
        <td>${esc(monthDayLabel(item.latestAt) || "-")}</td>
      </tr>`).join("")}</tbody>
    </table>
  </div>`;
}

function renderInviteAnalyticsRecentRecords(analytics) {
  const rows = (Array.isArray(analytics?.records) ? analytics.records : []).slice(0, 300);
  if (!rows.length) return `<div class="invite-analytics-empty">招待結果の履歴はまだありません</div>`;
  return `<div class="invite-analytics-table-wrap invite-analytics-record-scroll">
    <table class="invite-analytics-table invite-analytics-record-table">
      <thead><tr><th>日付</th><th>アプリ</th><th>招待種別</th><th>端末</th><th>結果</th><th>招待時UPTIME</th><th>親 or 子</th><th>相手</th></tr></thead>
      <tbody>${rows.map((record) => `<tr>
        <td>${esc(historyDateTimeLabel(record.at) || "-")}</td>
        <td>${record.product === "main" ? "本家" : "Lite"}</td>
        <td>${esc(record.type || "旧・未分類")}</td>
        <td><strong>${esc(record.deviceLabel)}</strong></td>
        <td class="${record.kind === "success" ? "good" : "error"}">${esc(record.result || (record.kind === "success" ? "OK" : "NG"))}</td>
        <td>${esc(historyRecordedUptime(record.uptimeSeconds, record.uptimeSource) || "未取得")}</td>
        <td>${esc(record.role || "-")}</td>
        <td>${esc(invitePartnerLabel(record.partner) || record.partner || "-")}</td>
      </tr>`).join("")}</tbody>
    </table>
  </div>`;
}

function normalizeInviteAnalyticsProduct(value) {
  return value === "lite" || value === "main" ? value : "";
}

function renderInviteAnalyticsFilterTabs(rows, filters = {}) {
  const product = normalizeInviteAnalyticsProduct(filters.product);
  const type = String(filters.type || "");
  const productTabs = [
    { value: "", label: "全アプリ" },
    ...INVITE_PRODUCTS,
  ].map((item) => {
    const stats = inviteAnalyticsSnapshot(rows, { product: item.value, type });
    return `<button class="invite-analytics-filter-btn ${item.value === product ? "active" : ""}" type="button"
      data-analytics-invite-product="${esc(item.value)}" aria-pressed="${item.value === product ? "true" : "false"}">${esc(inviteFilterButtonText(item.label, stats))}</button>`;
  }).join("");
  const typeTabs = [
    { value: "", label: "全体" },
    ...INVITE_TYPE_ORDER.map((value) => ({ value, label: value })),
  ].map((item) => {
    const stats = inviteAnalyticsSnapshot(rows, { product, type: item.value });
    return `<button class="invite-analytics-filter-btn ${item.value === type ? "active" : ""}" type="button"
      data-analytics-invite-type="${esc(item.value)}" aria-pressed="${item.value === type ? "true" : "false"}">${esc(inviteFilterButtonText(item.label, stats))}</button>`;
  }).join("");
  return `
    <div class="invite-analytics-filter-bar">
      <div class="invite-analytics-filter-group"><strong>アプリ</strong><div class="invite-analytics-filter-tabs">${productTabs}</div></div>
      <div class="invite-analytics-filter-group"><strong>招待種別</strong><div class="invite-analytics-filter-tabs">${typeTabs}</div></div>
    </div>
  `;
}

function renderInviteAnalyticsBody(rows, filters = {}, focusDevice = "") {
  const selected = {
    product: normalizeInviteAnalyticsProduct(filters.product),
    type: String(filters.type || ""),
  };
  const analytics = inviteAnalyticsSnapshot(rows, selected);
  const scopeLabel = [
    selected.product === "main" ? "TikTok本家" : selected.product === "lite" ? "TikTok Lite" : "全アプリ",
    selected.type || "全種別",
  ].join(" / ");
  const legacyCount = analytics.records.filter((record) => !INVITE_TYPE_ORDER.includes(record.type)).length;
  return `
    ${renderInviteAnalyticsFilterTabs(rows, selected)}
    <div class="invite-analytics-scope-note">
      <strong>${esc(scopeLabel)}</strong>
      <span>${legacyCount && !selected.type ? `旧「通常」・未分類 ${legacyCount}件は全体集計にのみ含みます。` : "選択中のアプリ・招待種別だけを集計しています。"}</span>
    </div>
    <div class="invite-analytics-kpis">
      <div class="${esc(inviteSuccessRateTone(analytics))}"><span>選択範囲の成功率</span><strong>${esc(analytics.rateLabel)}</strong><small>n=${esc(analytics.total)}</small></div>
      <div class="good"><span>成功</span><strong>${esc(analytics.success)}件</strong></div>
      <div class="${analytics.fail ? "error" : "good"}"><span>失敗</span><strong>${esc(analytics.fail)}件</strong></div>
      <div><span>成功時UPTIME平均</span><strong>${esc(inviteAnalyticsHoursLabel(analytics.successAverageHours))}</strong></div>
      <div><span>成功時UPTIME中央値</span><strong>${esc(inviteAnalyticsHoursLabel(analytics.successMedianHours))}</strong></div>
      <div><span>失敗時UPTIME平均</span><strong>${esc(inviteAnalyticsHoursLabel(analytics.failAverageHours))}</strong><small>UPTIME取得 ${esc(analytics.recordedUptime)}/${esc(analytics.total)}件</small></div>
    </div>
    <section class="invite-analytics-section uptime">
      <div class="invite-analytics-section-head"><div><h4>稼働時間別の成功率</h4><p>招待結果を保存した時点のUPTIME帯で比較。未取得 ${esc(analytics.unknownUptime)}件はグラフ外です。</p></div></div>
      ${renderInviteAnalyticsUptimeChart(analytics)}
    </section>
    <section class="invite-analytics-section devices">
      <div class="invite-analytics-section-head"><div><h4>端末別 成功率ランキング</h4><p>成功率順。母数 n を併記し、少数データの100%を過信しない表示です。</p></div><span>${esc(analytics.deviceStats.length)}台</span></div>
      ${renderInviteAnalyticsDeviceTable(analytics, focusDevice)}
    </section>
    <section class="invite-analytics-section relationships">
      <div class="invite-analytics-section-head"><div><h4>親と子の関係</h4><p>履歴の「親 or 子」と「相手」から組み立てます。自由入力の相手もそのまま表示します。</p></div><span>${esc(analytics.relationships.length)}組</span></div>
      ${renderInviteAnalyticsRelationships(analytics)}
    </section>
    <section class="invite-analytics-section records">
      <div class="invite-analytics-section-head"><div><h4>招待結果一覧</h4><p>新しい順。最大300件を表示します。</p></div><span>${esc(analytics.records.length)}件</span></div>
      ${renderInviteAnalyticsRecentRecords(analytics)}
    </section>
  `;
}

let inviteAnalyticsRestoreFocus = null;

function showInviteAnalyticsDialog(focusDevice = "", options = {}) {
  closeInviteAnalyticsDialog();
  const rows = Array.isArray(options.rows) ? options.rows : inviteAnalyticsRows();
  const title = options.title || "招待成功率・稼働時間分析";
  const description = options.description
    || "接続DBと未接続DBの保存済み招待履歴を合算して比較します。待機時間は結果保存時点のUPTIMEです。";
  const filters = { product: "", type: "" };
  inviteAnalyticsRestoreFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  const overlay = document.createElement("div");
  overlay.className = "invite-analytics-dialog-backdrop";
  overlay.innerHTML = `
    <div class="invite-analytics-dialog" role="dialog" aria-modal="true" aria-labelledby="inviteAnalyticsDialogTitle">
      <div class="invite-analytics-dialog-head">
        <div>
          <h3 id="inviteAnalyticsDialogTitle">${esc(title)}</h3>
          <p>${esc(description)}</p>
        </div>
        <button class="invite-analytics-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="invite-analytics-body">
        ${renderInviteAnalyticsBody(rows, filters, focusDevice)}
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.querySelector(".invite-analytics-close")?.addEventListener("click", closeInviteAnalyticsDialog);
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeInviteAnalyticsDialog();
    const productButton = event.target.closest("[data-analytics-invite-product]");
    const typeButton = event.target.closest("[data-analytics-invite-type]");
    if (productButton || typeButton) {
      if (productButton) filters.product = normalizeInviteAnalyticsProduct(productButton.dataset.analyticsInviteProduct);
      if (typeButton) filters.type = typeButton.dataset.analyticsInviteType || "";
      const body = overlay.querySelector(".invite-analytics-body");
      if (body) body.innerHTML = renderInviteAnalyticsBody(rows, filters, focusDevice);
      return;
    }
    const historyButton = event.target.closest("[data-invite-history-device]");
    if (!historyButton) return;
    const device = historyButton.dataset.inviteHistoryDevice || "";
    const row = rows.find((item) => [item?.serial, item?.managementId, item?.laixiNumber].map(String).includes(String(device)));
    closeInviteAnalyticsDialog();
    if (row?.isOffline) {
      showInviteAnalyticsDialog(device, {
        rows: [row],
        title: `未接続端末 No.${row.number || "-"} 招待履歴`,
        description: "未接続DBに手入力で保存した招待結果と、その時点のUPTIMEを表示します。",
      });
    } else {
      showDeviceHistoryDialog(row);
    }
  });
  document.addEventListener("keydown", handleInviteAnalyticsDialogKeydown);
  requestAnimationFrame(() => {
    overlay.querySelector("tr.focused")?.scrollIntoView({ block: "center" });
    overlay.querySelector(".invite-analytics-close")?.focus({ preventScroll: true });
  });
}

function closeInviteAnalyticsDialog() {
  const overlay = document.querySelector(".invite-analytics-dialog-backdrop");
  if (!overlay) return;
  overlay.remove();
  document.removeEventListener("keydown", handleInviteAnalyticsDialogKeydown);
  if (inviteAnalyticsRestoreFocus?.isConnected) inviteAnalyticsRestoreFocus.focus();
  inviteAnalyticsRestoreFocus = null;
}

function handleInviteAnalyticsDialogKeydown(event) {
  if (event.key !== "Escape") return;
  event.preventDefault();
  closeInviteAnalyticsDialog();
}

function invitePartnerLabel(value) {
  const target = String(value || "");
  if (!target) return "";
  const row = inviteAnalyticsRows().find((item) =>
    String(item.serial || "") === target || String(item.managementId || "") === target || String(item.laixiNumber || "") === target
  );
  if (!row) return target;
  return invitePartnerOptionLabel(row) || target;
}

function currentHistoryAdbState(row) {
  const devices = Array.isArray(state.adbDevices?.devices) ? state.adbDevices.devices : [];
  const hasSnapshot = Boolean(state.adbDevices && !state.adbDevices.skipped && Array.isArray(state.adbDevices.devices));
  const serial = String(row?.serial || "");
  const adb = devices.find((device) => String(device?.serial || "") === serial);
  const connected = hasSnapshot && serial
    ? Boolean(adb && (adb.status === "device" || adb.connected === true))
    : row?.adbConnected === true ? true : row?.adbConnected === false ? false : null;
  return {
    connected,
    uptimeSeconds: adb?.uptimeSeconds ?? row?.adbUptimeSeconds ?? row?.adbLastUptimeSeconds,
    uptimeFetchedAt: adb?.uptimeFetchedAt ?? row?.adbUptimeFetchedAt ?? (Date.parse(row?.adbLastUptimeCheckedAt || "") || 0),
    batteryPercent: connected === false ? null : (adb?.batteryPercent ?? row?.batteryPercent ?? row?.adbLastBatteryPercent),
  };
}

function historyUptimeText(row, adbState = currentHistoryAdbState(row)) {
  const rawSeconds = adbState.uptimeSeconds;
  const seconds = rawSeconds === null || rawSeconds === undefined || rawSeconds === "" ? NaN : Number(rawSeconds);
  if (!Number.isFinite(seconds) || seconds < 0) return "UPTIME未取得";
  const value = currentUptimeValue(seconds, adbState.uptimeFetchedAt || Date.now());
  return `UPTIME ${uptimeLabel(value.hours)}`;
}

function historyBatteryText(row, adbState = currentHistoryAdbState(row)) {
  const value = adbState.batteryPercent;
  if (adbState.connected === false) return "電池 OFFLINE";
  if (value === "" || value === null || value === undefined) return "電池未取得";
  return `電池 ${value}%`;
}

function renderTaskHistoryLine(item) {
  const range = taskHistoryDateRangeParts(item);
  const dateText = [
    range.started ? `開始 ${range.started}` : "",
    range.ended ? `終了 ${range.ended}` : "",
  ].filter(Boolean).join("\n") || "-";
  const status = item.status === "active" ? "実行中" : item.status === "completed" ? "完了" : item.status || "記録";
  const details = [
    item.sequence ? { label: "回", value: `#${item.sequence}` } : null,
    { label: "状態", value: status, tone: item.status === "completed" ? "good" : "" },
    item.day ? { label: "DAY", value: `DAY${String(item.day).padStart(2, "0")}`, tone: "day" } : null,
    item.ci ? { label: "チェックイン", value: historyTaskValue(item.ci, "チェックイン") } : null,
    item.video180 ? { label: "動画180分", value: historyTaskValue(item.video180, "動画180分") } : null,
    item.video10 ? { label: "追加視聴", value: historyTaskValue(item.video10, "追加視聴") } : null,
  ].filter(Boolean);
  const resets = Array.isArray(item.resetHistory) ? item.resetHistory : [];
  for (const entry of resets) {
    details.push({
      label: `リセット ${monthDayLabel(entry.at || "") || ""}`.trim(),
      value: [
        entry.reason || "",
        historyRecordedAmountYen(entry.amountYen),
        historyRecordedUptime(entry.uptimeSeconds, entry.uptimeSource),
      ].filter(Boolean).join("  ") || "実施",
      tone: "reset",
    });
    for (const part of historyTextParts(entry.summary)) {
      details.push({ label: "リセット内容", value: part, tone: "reset" });
    }
  }
  if (!details.length) details.push({ label: "記録", value: item.text || item.cycleId || "記録なし", wide: true });
  return historyTimelineRow(dateText, details);
}

function historyTaskValue(value, label) {
  return String(value || "").replace(new RegExp(`^${label}\\s*`), "") || String(value || "");
}

function renderErrorHistoryLine(outcome) {
  const range = taskHistoryDateRangeParts(outcome);
  const dateText = [
    range.started ? `開始 ${range.started}` : "",
    range.ended ? `終了 ${range.ended}` : outcome.provisional ? "進行中" : "",
  ].filter(Boolean).join("\n") || monthDayLabel(outcome.firstErrorAt || outcome.at || "") || "-";
  const label = errorOutcomeLabel(outcome);
  const details = [
    { label: "判定", value: label, tone: outcome.category === "none" ? "good" : outcome.category === "unknown" ? "pending" : "error" },
    outcome.firstErrorDay ? { label: "初回発生DAY", value: `DAY${String(outcome.firstErrorDay).padStart(2, "0")}`, tone: "day" } : null,
    outcome.firstErrorAt ? { label: "初回発生", value: historyDateTimeLabel(outcome.firstErrorAt), tone: "error" } : null,
    { label: "記録状態", value: outcome.provisional ? "進行中" : "確定", tone: outcome.provisional ? "pending" : "" },
    outcome.sequence ? { label: "回", value: `#${outcome.sequence}` } : null,
  ].filter(Boolean);
  return historyTimelineRow(dateText, details);
}

function errorOutcomeLabel(outcome) {
  if (outcome?.category === "none") return "エラー出なかった";
  if (outcome?.category === "day1") return "初日にエラー発生";
  if (outcome?.category === "day2plus") return "2日目以降にエラー発生";
  return "旧履歴・初回DAY判定待ち";
}

function taskHistoryDateRangeParts(item) {
  const started = monthDayLabel(item?.operationStartedAt || item?.startedAt || "");
  const ended = monthDayLabel(item?.operationEndedAt || item?.endedAt || "");
  return { started, ended };
}

function monthDayLabel(value) {
  const text = String(value || "").trim();
  if (!text) return "";
  const direct = /^(\d{4})-(\d{2})-(\d{2})/.exec(text);
  if (direct) return `${direct[2]}/${direct[3]}`;
  const date = new Date(text);
  if (Number.isNaN(date.getTime())) return "";
  const pad = (number) => String(number).padStart(2, "0");
  return `${pad(date.getMonth() + 1)}/${pad(date.getDate())}`;
}

function historyDateTimeLabel(value) {
  const date = new Date(String(value || ""));
  if (Number.isNaN(date.getTime())) return monthDayLabel(value) || "記録なし";
  const pad = (number) => String(number).padStart(2, "0");
  return `${pad(date.getMonth() + 1)}/${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function renderWithdrawalHistoryLine(row) {
  const dateText = monthDayLabel(row.withdrawalDate || row.recordedAt || "") || "-";
  const details = [
    row.siteName ? { label: "拠点", value: row.siteName } : null,
    row.amountYen ? { label: "金額", value: yen(row.amountYen), tone: "money" } : null,
    row.day ? { label: "DAY", value: `DAY${String(row.day).padStart(2, "0")}`, tone: "day" } : null,
    row.resetDone || row.resetDoneAt ? { label: "反映", value: "非稼働反映済", tone: "good" } : null,
    row.memo ? { label: "内容", value: toJapaneseMemo(row.memo), wide: true } : null,
  ].filter(Boolean);
  return historyTimelineRow(dateText, details);
}

function renderInviteHistoryLine(entry) {
  if (entry && !entry.legacy) {
    const dateText = monthDayLabel(entry.at || "") || "-";
    const partner = invitePartnerLabel(entry.partner) || entry.partner || "";
    return historyTimelineRow(dateText, [
      entry.type ? { label: "招待", value: entry.type } : null,
      entry.role ? { label: "親or子", value: entry.role } : null,
      entry.result ? { label: "結果", value: entry.result, tone: /成功|OK/i.test(entry.result) ? "good" : /失敗|NG/i.test(entry.result) ? "error" : "" } : null,
      partner ? { label: "相手", value: partner, wide: true } : null,
      entry.simStatus ? { label: "SIM", value: entry.simStatus } : null,
      entry.networkType ? { label: "通信", value: entry.networkType } : null,
      entry.networkSwitchedDay ? { label: "切替DAY", value: `DAY${String(entry.networkSwitchedDay).padStart(2, "0")}` } : null,
      entry.ttlRegisterMethod ? { label: "導入方法", value: entry.ttlRegisterMethod } : null,
      entry.osVersion ? { label: "OS", value: formatOsVersion(entry.osVersion) } : null,
      entry.note ? { label: "備考", value: entry.note, wide: true } : null,
    ].filter(Boolean));
  }
  const text = String(entry?.text || entry || "").trim();
  const match = /^(\d{4}-\d{2}-\d{2}|\d{1,2}\/\d{1,2})\s*(.*)$/.exec(text);
  const details = historyTextParts(match ? match[2] || text : text).map((value) => ({ label: "記録", value, wide: true }));
  if (match) return historyTimelineRow(monthDayLabel(match[1]) || match[1], details);
  return historyTimelineRow("-", details);
}

function historyTextParts(value) {
  return String(value || "")
    .split(/\s+\/\s+|\s*・\s*/)
    .map((part) => part.trim())
    .filter(Boolean);
}

function historyTimelineRow(dateText, details) {
  const rows = (Array.isArray(details) ? details : [{ label: "記録", value: details }]).filter((item) => item && (item.value || item.label));
  const body = rows.length ? rows.map(historyDetailChip).join("") : historyDetailChip({ label: "記録", value: "記録なし" });
  return `<div class="history-timeline-row"><div class="history-timeline-date">${esc(dateText)}</div><div class="history-timeline-detail">${body}</div></div>`;
}

function historyDetailChip(item) {
  const value = typeof item === "string" ? item : item.value;
  const label = typeof item === "string" ? "" : item.label;
  const classes = ["history-detail-chip", item?.tone || "", item?.wide ? "wide" : ""].filter(Boolean).join(" ");
  return `<span class="${esc(classes)}">${label ? `<small>${esc(label)}</small>` : ""}<b>${esc(value || "-")}</b></span>`;
}

function handleDeviceTaskSelectChange(event) {
  const select = event.target.closest(".device-task-select");
  if (!select) {
    handleDeviceNameInput(event);
    return;
  }
  const device = select.dataset.device || "";
  const kind = select.dataset.kind || "";
  const config = DEVICE_TASK_SELECTS[kind];
  if (!device || !config) return;
  const nextTag = select.value;
  const previous = select.dataset.original || "";
  const changed = nextTag !== previous;
  select.classList.toggle("changed-input", changed);
  select.classList.remove("input-error");
  select.title = changed ? "": "";
  updateDeviceNameSaveState();
}

function renderSwipeModeSelect(row) {
  const device = row.serial || row.managementId || "";
  const current = row.swipeModePreference || "auto";
  const recommendation = normalizeSwipeModeRecommendation(row);
  const options = [
    ["auto", ""],
    ["agent", "Agent推奨"],
    ["adb", "ADB推奨"],
    ["disabled", "無効"],
  ].map(([value, label]) =>
    `<option value="${esc(value)}" ${value === current ? "selected" : ""}>${esc(label)}</option>`
  ).join("");
  return `
    <div class="swipe-mode-cell">
      <select class="table-input device-edit-input swipe-mode-select" data-field="swipeModePreference" data-device="${esc(device)}" data-original="${esc(current)}">
        ${options}
      </select>
      ${swipeModeChip({ swipeModePreference: current, swipeModeRecommendation: recommendation })}
    </div>
  `;
}

function renderSwipeMethodCell(row) {
  return `
    <div class="swipe-method-stack">
      ${swipeAgentPill(row)}
      ${renderSwipeModeSelect(row)}
    </div>
  `;
}

function renderDeviceMaster(master) {
  const data = master && master.ok !== false ? master : { entries: [], counts: {} };
  const entries = Array.isArray(data.entries) ? data.entries : [];
  const query = (el("deviceMasterSearchInput")?.value || "").trim().toLowerCase();
  const filtered = entries.filter((entry) => {
    if (!query) return true;
    return [
      entry.shortName,
      entry.modelCode,
      entry.salesName,
      entry.maker,
      entry.carrierCode,
      entry.route,
    ].join(" ").toLowerCase().includes(query);
  });
  const excluded = data.counts?.excluded ?? (Array.isArray(data.excluded) ? data.excluded.length : 0);
  el("deviceMasterMeta").textContent = `${entries.length}件 / 表示 ${filtered.length}件 / 除外 ${excluded}件`;
  el("deviceMasterRows").innerHTML = filtered.slice(0, 800).map((entry) => `
    <tr data-master-id="${esc(entry.id || "")}">
      <td class="master-short-name">
        <input class="master-short-input" type="text" value="${esc(entry.shortName || "")}" data-id="${esc(entry.id || "")}" data-original="${esc(entry.shortName || "")}">
      </td>
      <td>${esc(entry.modelCode || "")}</td>
      <td>${esc(entry.salesName || "")}</td>
      <td>${esc(entry.maker || "")}</td>
      <td><span class="carrier-chip">${esc(entry.carrierCode || "UNKNOWN")}</span></td>
      <td>${esc(entry.route || "")}</td>
      <td>
        <span class="row-actions">
          <button class="icon-action edit-master-btn" data-id="${esc(entry.id || "")}" type="button">編集</button>
          <button class="icon-action danger-action delete-master-btn" data-id="${esc(entry.id || "")}" type="button">削除</button>
        </span>
      </td>
    </tr>
  `).join("");
}

async function loadDeviceMaster() {
  setBusy(true);
  logLine("端末マスタ再読込 実行中...");
  try {
    const result = await fetchJson("/api/device-master");
    state.deviceMaster = result;
    renderDeviceMaster(result);
    logLine(`端末マスタ再読込 OK: ${result.counts?.entries || 0}件`);
  } catch (error) {
    logLine("端末マスタ再読込 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function saveDeviceMasterEntry(event) {
  event.preventDefault();
  const entry = {
    id: el("deviceMasterIdInput").value,
    shortName: el("deviceMasterShortInput").value,
    modelCode: el("deviceMasterModelInput").value,
    salesName: el("deviceMasterSalesInput").value,
    maker: el("deviceMasterMakerInput").value,
    carrierCode: el("deviceMasterCarrierInput").value,
    route: el("deviceMasterRouteInput").value,
    source: el("deviceMasterIdInput").value ? "manual edit" : "manual",
  };
  if (!entry.shortName.trim() || !entry.salesName.trim()) {
    logLine("端末マスタ保存 NG: 短縮名と販売名を入力してください");
    return;
  }
  setBusy(true);
  logLine("端末マスタ保存 実行中...");
  try {
    const result = await fetchJson("/api/device-master/entries", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ entry }),
    });
    clearDeviceMasterForm();
    await refreshDeviceMasterAndLocalSummary();
    logLine(`端末マスタ保存 OK: ${result.entry?.shortName || ""} ${result.entry?.salesName || ""}${formatMasterRefreshLog(result.refresh)}`);
  } catch (error) {
    logLine("端末マスタ保存 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function handleDeviceMasterRowAction(event) {
  const editButton = event.target.closest(".edit-master-btn");
  const deleteButton = event.target.closest(".delete-master-btn");
  if (editButton) return startDeviceMasterEdit(editButton.dataset.id);
  if (deleteButton) return deleteDeviceMasterEntry(deleteButton.dataset.id);
}

function handleDeviceMasterInlineKeydown(event) {
  const input = event.target.closest(".master-short-input");
  if (!input) return;
  if (event.key === "Enter") {
    event.preventDefault();
    input.blur();
  }
  if (event.key === "Escape") {
    input.value = input.dataset.original || "";
    input.blur();
  }
}

async function handleDeviceMasterInlineChange(event) {
  const input = event.target.closest(".master-short-input");
  if (!input) return;
  const id = input.dataset.id || "";
  const entry = (state.deviceMaster?.entries || []).find((item) => item.id === id);
  if (!entry) return;
  const nextShort = input.value
    .trim()
    .replace(/[^ A-Za-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .slice(0, 24)
    .trim();
  input.value = nextShort;
  if (!nextShort) {
    input.value = input.dataset.original || "";
    logLine("端末マスタ保存 NG: 短縮名は空にできません");
    return;
  }
  if (nextShort === (input.dataset.original || "")) return;

  input.disabled = true;
  input.classList.add("saving");
  try {
    const result = await fetchJson("/api/device-master/entries", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ entry: { ...entry, shortName: nextShort, source: "inline shortName edit" } }),
    });
    await refreshDeviceMasterAndLocalSummary();
    logLine(`端末マスタ短縮名保存 OK: ${result.entry?.shortName || nextShort} ${entry.salesName || ""}${formatMasterRefreshLog(result.refresh)}`);
  } catch (error) {
    input.disabled = false;
    input.classList.remove("saving");
    input.classList.add("error");
    logLine("端末マスタ短縮名保存 NG: " + error.message);
  }
}

function startDeviceMasterEdit(id) {
  const entry = (state.deviceMaster?.entries || []).find((item) => item.id === id);
  if (!entry) return;
  el("deviceMasterIdInput").value = entry.id || "";
  el("deviceMasterShortInput").value = entry.shortName || "";
  el("deviceMasterModelInput").value = entry.modelCode || "";
  el("deviceMasterSalesInput").value = entry.salesName || "";
  el("deviceMasterMakerInput").value = entry.maker || "";
  el("deviceMasterCarrierInput").value = entry.carrierCode || "UNKNOWN";
  el("deviceMasterRouteInput").value = entry.route || "";
  el("deviceMasterCancelBtn").classList.remove("hidden");
  el("deviceMasterSaveBtn").textContent = "編集保存";
}

function clearDeviceMasterForm() {
  el("deviceMasterIdInput").value = "";
  el("deviceMasterShortInput").value = "";
  el("deviceMasterModelInput").value = "";
  el("deviceMasterSalesInput").value = "";
  el("deviceMasterMakerInput").value = "";
  el("deviceMasterCarrierInput").value = "UNKNOWN";
  el("deviceMasterRouteInput").value = "";
  el("deviceMasterCancelBtn").classList.add("hidden");
  el("deviceMasterSaveBtn").textContent = "マスタ保存";
}

async function deleteDeviceMasterEntry(id) {
  if (!id || !confirm("この端末マスタ行を削除しますか？")) return;
  setBusy(true);
  logLine("端末マスタ削除 実行中...");
  try {
    await fetchJson("/api/device-master/entries/delete", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id }),
    });
    await refreshDeviceMasterAndLocalSummary();
    logLine("端末マスタ削除 OK");
  } catch (error) {
    logLine("端末マスタ削除 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function importDeviceMasterCsv() {
  const csv = el("deviceMasterCsvInput").value.trim();
  if (!csv) {
    logLine("CSV取込 NG: CSVを貼り付けてください");
    return;
  }
  setBusy(true);
  logLine("CSV取込 実行中...");
  try {
    const result = await fetchJson("/api/device-master/import-csv", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ csv }),
    });
    el("deviceMasterCsvInput").value = "";
    await refreshDeviceMasterAndLocalSummary();
    logLine(`CSV取込 OK: ${result.imported || 0}件 / 除外 ${result.excluded || 0}件${formatMasterRefreshLog(result.refresh)}`);
  } catch (error) {
    logLine("CSV取込 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function formatMasterRefreshLog(refresh) {
  const sync = refresh?.codeSync;
  if (!sync) return "";
  const changedDevices = Number(sync.changedDevices || 0);
  const changedWithdrawals = Number(sync.changedWithdrawals || 0);
  if (!changedDevices && !changedWithdrawals) return " / 端末名変更なし";
  return ` / 端末名再取得 ${changedDevices}件`;
}

function sortDeviceRows(rows) {
  return rows.slice().sort(compareDeviceDayRows);
}

async function runDeviceNumberResequence(button = null, mode = "model") {
  const rows = state.summary?.devices || [];
  if (!rows.length) {
    window.alert("再採番する端末がありません。");
    return;
  }
  const dayMode = mode === "day";
  const label = dayMode ? "DAY順再採番" : "機種順再採番";
  const source = dayMode ? "day-order-resequence" : "model-order-resequence";
  const activeCount = rows.filter((row) => deviceOrderBand(row) === "active").length;
  const inactiveCount = rows.length - activeCount;
  const ok = window.confirm([
    dayMode
      ? "元の方式でメイン番号を振り直してXiaoWeiへ反映します。"
      : "メイン番号を機種順に振り直してXiaoWeiへ反映します。",
    dayMode
      ? `稼働 ${activeCount}台はDAYが大きい順に1番から、非稼働 ${inactiveCount}台は機種・キャリア順に1000番から再採番します。`
      : `稼働 ${activeCount}台は1番から、非稼働 ${inactiveCount}台は1000番から再採番します。`,
    "既存のメイン番号は変わる場合があります。",
    "名前連番（サブ番号）、DAY順、チェック状態は変更しません。",
    "続けますか？",
  ].join("\n"));
  if (!ok) return;

  setBusy(true, button);
  let dbUpdated = false;
  let flash = { message: "完了", type: "ok" };
  try {
    const applyResult = await applyPendingTagBoardChangesBeforeXiaoweiSync();
    if (applyResult.cancelled) {
      flash = { message: "中止", type: "warn" };
      return;
    }
    const result = await fetchJson("/api/fleet-db/device-order", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ order: [], source, numberingMode: mode }),
    });
    dbUpdated = true;
    logLine(`${label} DB OK: メイン番号変更 ${(result.numberChanges || []).length}台 / 名前連番・DAY順維持`);

    try {
      const syncResult = await fetchJson("/api/xiaowei/numbers/sync", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ apply: true }),
      });
      logLine(`${label} XiaoWei反映 OK: 対象 ${syncResult.logicalRequested ?? syncResult.requested ?? 0}件 / 成功 ${syncResult.succeeded || 0} / 失敗 ${syncResult.failed || 0}`);
      if (Number(syncResult.disconnectedMatched || 0) > 0) {
        logLine(`${label} 未接続も強制対象: ${syncResult.disconnectedMatched}台 / 番号変更 ${syncResult.disconnectedRequested || 0}台 / 成功 ${syncResult.disconnectedSucceeded || 0}台 / 失敗 ${syncResult.disconnectedFailed || 0}台`);
        if (syncResult.xiaoweiRestartRecommended) logLine(`${label}: 未接続端末の並びはXiaoWei再起動後に画面へ反映されます`);
      }
      if (Number(syncResult.failed || 0) > 0) flash = { message: "要確認", type: "warn" };
    } catch (syncError) {
      flash = { message: "同期待ち", type: "warn" };
      logLine(`${label} XiaoWei反映 NG: ${syncError.message}`);
      window.alert(`メイン番号はDBへ${dayMode ? "元のDAY順方式" : "機種順"}で保存しましたが、XiaoWeiへの反映に失敗しました。\n${syncError.message}\n接続確認後に「XiaoWei番号反映」を実行してください。`);
    }
    await loadLocalSummaryOnly();
    reloadTagBoardFrame();
  } catch (error) {
    logLine(`${label} ${dbUpdated ? "確認" : "NG"}: ${error.message}`);
    flash = { message: "失敗", type: "error" };
    if (!dbUpdated) window.alert(`${label}に失敗しました。\n${error.message}`);
  } finally {
    setBusy(false);
    flashButtonResult(button, flash.message, flash.type);
  }
}

function compareDeviceDayRows(a, b) {
  const band = deviceOrderBandRank(a) - deviceOrderBandRank(b);
  if (band) return band;
  if (deviceOrderBand(a) === "active") {
    const day = Number(b?.day || 0) - Number(a?.day || 0);
    if (day) return day;
  } else {
    const number = managementNumber(a) - managementNumber(b);
    if (number) return number;
  }
  return naturalDeviceRowCompare(a, b);
}

function deviceOrderBand(row) {
  const tags = Array.isArray(row?.tags) ? row.tags.map((tag) => String(tag).toUpperCase()) : [];
  const status = String(row?.status || "").toUpperCase();
  if (tags.includes("WAITING") || tags.includes("GROUP_REST") || tags.includes("GROUP_INACTIVE") || status === "WAITING" || status === "INACTIVE") {
    return "inactive";
  }
  if (tags.includes("GROUP_ACTIVE") || Number(row?.day || 0) > 0) {
    return "active";
  }
  return "inactive";
}

function deviceOrderBandRank(row) {
  return deviceOrderBand(row) === "active" ? 0 : 1;
}

function naturalDeviceRowCompare(a, b) {
  const keyA = String(a.modelGroup || a.deviceDisplayCode || a.deviceLabel || a.laixiName || a.deviceName || a.serial || "").trim();
  const keyB = String(b.modelGroup || b.deviceDisplayCode || b.deviceLabel || b.laixiName || b.deviceName || b.serial || "").trim();
  const rank = naturalDeviceNameRank(keyA) - naturalDeviceNameRank(keyB);
  if (rank) return rank;
  return keyA.localeCompare(keyB, "en", { numeric: true, sensitivity: "base" })
    || String(a.carrierCode || "").localeCompare(String(b.carrierCode || ""), "en", { numeric: true })
    || managementNumber(a) - managementNumber(b)
    || String(a.serial || "").localeCompare(String(b.serial || ""), "en", { numeric: true });
}

function naturalDeviceNameRank(value) {
  const first = String(value || "").trim().charAt(0);
  if (/\d/.test(first)) return 0;
  if (/[A-Za-z]/.test(first)) return 1;
  return 2;
}

function managementNumber(row) {
  const id = String(row.laixiNumber || row.managementId || row.xiaoweiSort || "");
  const match = /(\d+)/.exec(id);
  return match ? Number(match[1]) : 9999;
}

function openDeviceNameSequenceDialog() {
  closeDeviceNameSequenceDialog();
  const rows = sortDeviceRows(state.summary?.devices || []).filter((row) => deviceNameSequence(row));
  const sequenceById = new Map(rows.map((row) => [
    String(row.serial || row.managementId || ""),
    String(deviceNameSequence(row)).padStart(2, "0"),
  ]).filter(([id]) => id));
  const originalById = new Map(sequenceById);
  const overlay = document.createElement("div");
  overlay.className = "custom-order-backdrop";
  overlay.innerHTML = `
    <div class="custom-order-dialog" role="dialog" aria-modal="true" aria-labelledby="deviceNameSequenceTitle">
      <div class="custom-order-head">
        <div><h3 id="deviceNameSequenceTitle">XiaoWei名の連番変更</h3><p>A25-01などの末尾連番を01〜999で変更します。メイン番号とXiaoWeiの機種順は変わりません。</p></div>
        <button class="custom-order-close" type="button" aria-label="閉じる">×</button>
      </div>
      <div class="custom-order-tools">
        <input class="custom-order-search" type="search" placeholder="メイン番号・機種名・端末IDで検索">
        <span class="custom-order-count"></span>
      </div>
      <div class="custom-order-selected"></div>
      <div class="custom-order-list"></div>
      <div class="custom-order-actions">
        <span class="spacer"></span>
        <button class="custom-order-cancel" type="button">キャンセル</button>
        <button class="custom-order-save primary-action" type="button">連番を保存・同期</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const search = overlay.querySelector(".custom-order-search");
  const list = overlay.querySelector(".custom-order-list");
  const selectedPanel = overlay.querySelector(".custom-order-selected");
  const count = overlay.querySelector(".custom-order-count");

  const labelFor = (row) => [
    `No.${row.laixiNumber || row.xiaoweiNumber || row.xiaoweiSort || "-"}`,
    row.deviceLabel || row.deviceDisplayCode || row.laixiName || row.deviceName,
    row.serial ? `ID:${row.serial}` : "",
  ].filter(Boolean).join(" / ");
  function render() {
    const activeCount = rows.filter((row) => deviceOrderBand(row) === "active").length;
    const inactiveCount = rows.length - activeCount;
    count.textContent = `全 ${rows.length}台`;
    selectedPanel.innerHTML = `<div class="custom-order-band-summary"><strong>表示名だけ変更</strong><span>稼働 ${activeCount}台</span><span>非稼働 ${inactiveCount}台</span><span>メイン番号・機種順を維持</span><span>DB・チェック一覧はDAY順</span></div>`;
    const query = String(search.value || "").trim().toLowerCase();
    const visibleRows = rows.filter((row) => {
      const id = String(row.serial || row.managementId || "");
      const searchable = `${sequenceById.get(id) || ""} ${row.managementId || ""} ${labelFor(row)}`.toLowerCase();
      return !query || searchable.includes(query);
    });
    list.innerHTML = [
      { key: "active", label: "稼働端末", range: "DAY順" },
      { key: "inactive", label: "非稼働端末", range: "メイン番号順" },
    ].map((group) => {
      const groupRows = visibleRows.filter((row) => deviceOrderBand(row) === group.key);
      if (!groupRows.length) return "";
      return `<section class="custom-order-list-band" data-order-band="${group.key}"><h4>${group.label} <span>${group.range} / ${groupRows.length}台</span></h4>${groupRows.map((row) => {
        const id = String(row.serial || row.managementId || "");
        const dayLabel = group.key === "active" ? `DAY${String(Number(row.day || 0)).padStart(2, "0")}` : "非稼働";
        const mainNumber = row.laixiNumber || row.xiaoweiNumber || row.xiaoweiSort || "-";
        const base = row.modelGroup || String(row.deviceDisplayCode || "").replace(/-\d{2,3}$/, "") || "端末";
        const carrier = row.carrierCode && row.carrierCode !== "UNKNOWN" ? row.carrierCode : "";
        return `<label class="device-name-sequence-row" data-order-band="${group.key}"><span class="device-main-number">No.${esc(mainNumber)}</span><b>${esc(dayLabel)}</b><span class="device-name-sequence-editor"><span>${esc(base)}-</span><input class="device-name-sequence-input" type="text" inputmode="numeric" pattern="[0-9]{1,3}" maxlength="3" value="${esc(sequenceById.get(id) || "")}" data-device-name-sequence="${esc(id)}" aria-label="${esc(labelFor(row))}の表示名連番"><em>${esc(carrier)}</em><small>${esc(row.serial || row.managementId || "")}</small></span></label>`;
      }).join("")}</section>`;
    }).join("");
  }
  list.addEventListener("input", (event) => {
    const input = event.target.closest("[data-device-name-sequence]");
    if (!input) return;
    const cleanValue = String(input.value || "").replace(/\D/g, "").slice(0, 3);
    if (input.value !== cleanValue) input.value = cleanValue;
    sequenceById.set(input.dataset.deviceNameSequence || "", cleanValue);
  });
  search.addEventListener("input", render);
  overlay.querySelector(".custom-order-close").addEventListener("click", closeDeviceNameSequenceDialog);
  overlay.querySelector(".custom-order-cancel").addEventListener("click", closeDeviceNameSequenceDialog);
  overlay.querySelector(".custom-order-save").addEventListener("click", (event) => saveDeviceNameSequences(rows, sequenceById, originalById, event.currentTarget));
  overlay.addEventListener("click", (event) => { if (event.target === overlay) closeDeviceNameSequenceDialog(); });
  overlay.addEventListener("keydown", (event) => { if (event.key === "Escape") closeDeviceNameSequenceDialog(); });
  render();
  search.focus();
}

function closeDeviceNameSequenceDialog() {
  document.querySelector(".custom-order-backdrop")?.remove();
}

function deviceNameSequence(row) {
  const direct = Number(row?.deviceNameSequence || 0);
  if (Number.isInteger(direct) && direct >= 1 && direct <= MAX_DEVICE_NAME_SEQUENCE) return direct;
  const match = /-(\d{1,3})$/.exec(String(row?.deviceDisplayCode || ""));
  return match ? Number(match[1]) : 0;
}

function deviceNameSequencePayload(rows, sequenceById, originalById) {
  const changes = [];
  const owners = new Map();
  for (const row of rows) {
    const id = String(row.serial || row.managementId || "");
    const rawSequence = String(sequenceById.get(id) || "").trim();
    if (!rawSequence) throw new Error(`${id} の表示名連番を入力してください`);
    const sequence = Number(rawSequence);
    if (!Number.isInteger(sequence) || sequence < 1 || sequence > MAX_DEVICE_NAME_SEQUENCE) {
      throw new Error(`${id} の表示名連番は1〜${MAX_DEVICE_NAME_SEQUENCE}で入力してください`);
    }
    const group = `${row.modelGroup || ""}::${row.carrierCode || "UNKNOWN"}`;
    const ownerKey = `${group}::${sequence}`;
    if (owners.has(ownerKey) && owners.get(ownerKey) !== id) {
      throw new Error(`${row.modelGroup || "同一機種"} ${row.carrierCode || ""} の連番 ${String(sequence).padStart(2, "0")} が重複しています`);
    }
    owners.set(ownerKey, id);
    if (sequence !== Number(originalById.get(id) || 0)) changes.push({ device: id, sequence });
  }
  return changes;
}

async function saveDeviceNameSequences(rows, sequenceById, originalById, button) {
  let changes = [];
  try {
    changes = deviceNameSequencePayload(rows, sequenceById, originalById);
  } catch (error) {
    window.alert(error.message);
    return;
  }
  if (!changes.length) {
    window.alert("表示名連番の変更はありません。");
    return;
  }
  if (!window.confirm(`${changes.length}台のXiaoWei名連番を保存して同期しますか？\nメイン番号、機種順、DAY順は変更しません。`)) return;
  setBusy(true, button);
  try {
    const result = await fetchJson("/api/fleet-db/device-name-sequences", {
      method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ changes }),
    });
    closeDeviceNameSequenceDialog();
    await loadLocalSummaryOnly();
    reloadTagBoardFrame();
    logLine(`XiaoWei名連番 保存 OK: ${result.changedDevices || 0}台 / メイン番号変更 0台 / DAY順維持`);
    try {
      const syncResult = await fetchJson("/api/xiaowei/display-names/sync", {
        method: "POST", headers: { "content-type": "application/json" }, body: "{}",
      });
      logLine(`XiaoWei名連番 同期 OK: 失敗 ${(syncResult.failedSteps || []).length}件`);
      await loadLocalSummaryOnly();
      reloadTagBoardFrame();
    } catch (syncError) {
      logLine(`XiaoWei名連番 同期 NG: ${syncError.message}`);
      window.alert(`連番はDBへ保存しましたが、XiaoWei名への同期に失敗しました。\n${syncError.message}\n接続後に「XiaoWei名/番号同期」を実行してください。`);
    }
  } catch (error) {
    window.alert("XiaoWei名連番の保存に失敗しました。\n" + error.message);
  } finally {
    setBusy(false);
  }
}

function formatManagementName(row) {
  const number = formatXiaoWeiNumber(row.laixiNumber || row.managementId || row.xiaoweiSort || "");
  const name = row.deviceLabel || row.laixiName || row.deviceName || row.uiName || "";
  return [number, name].filter(Boolean).join(" ");
}

function formatManagementId(value) {
  const text = String(value || "").trim();
  const numberMatch = /^(?:A-)?(\d+)$/.exec(text);
  if (numberMatch) return numberMatch[1].padStart(2, "0");
  return text.replace(/^A-/i, "");
}

function formatXiaoWeiNumber(value) {
  const text = String(value || "").trim();
  const match = /^(?:A-)?(\d+)$/.exec(text);
  if (!match) return text.replace(/^A-/i, "");
  const raw = match[1];
  return String(Number(raw)).padStart(raw.length >= 3 ? 3 : 2, "0");
}

function formatXiaoWeiDeviceOptionLabel(row) {
  const number = formatXiaoWeiNumber(row.laixiNumber || row.managementId || row.xiaoweiSort || "");
  const label = row.deviceLabel || row.laixiName || row.deviceName || row.uiName || row.serial || "";
  return [number, label].filter(Boolean).join(" ");
}

function renderWithdrawals(rows) {
  const total = rows.reduce((sum, row) => sum + Number(row.amountYen || 0), 0);
  el("withdrawalTotal").textContent = `${rows.length}件 / ${yen(total)}`;
  el("withdrawalRows").innerHTML = rows.slice().reverse().map((row) => {
    const cycleLinked = row.source === "checklist_inactive_reset" || row.resetDone || row.resetDoneAt;
    return `
    <tr class="site-row ${siteClass(row.siteName)}">
      <td>${esc(row.withdrawalDate || "")}</td>
      <td>${siteBadge(row.siteName)}</td>
      <td>${esc(row.deviceName || "")}</td>
      <td class="num yen">${yen(row.amountYen || 0)}</td>
      <td>
        ${cycleLinked ? `<span class="done-label">自動登録・保護中</span>` : `<span class="row-actions">
          <button class="icon-action edit-withdrawal-btn" data-id="${esc(row.withdrawalId || "")}" type="button">訂正</button>
          <button class="icon-action danger-action delete-withdrawal-btn" data-id="${esc(row.withdrawalId || "")}" type="button" title="削除">削除</button>
        </span>`}
      </td>
      <td>${row.resetDone || row.resetDoneAt ? `<span class="done-label">非稼働反映済</span>` : `<span class="muted">記録のみ</span>`}</td>
      <td>${esc(toJapaneseMemo(row.memo || ""))}</td>
    </tr>
  `;
  }).join("");
}

async function handleWithdrawalRowAction(event) {
  const editButton = event.target.closest(".edit-withdrawal-btn");
  const deleteButton = event.target.closest(".delete-withdrawal-btn");
  if (editButton) return startWithdrawalEdit(editButton.dataset.id);
  if (deleteButton) return deleteWithdrawal(deleteButton.dataset.id);
}

function startWithdrawalEdit(withdrawalId) {
  const row = findWithdrawalInState(withdrawalId);
  if (!row) {
    logLine("出金編集 NG: 履歴が見つかりません");
    return;
  }
  el("withdrawalIdInput").value = row.withdrawalId || "";
  el("withdrawalDateInput").value = row.withdrawalDate || localDateInputValue();
  const deviceSelection = withdrawalDeviceEditSelection(row);
  state.withdrawalDeviceSelection = deviceSelection;
  el("withdrawalDeviceSelect").value = deviceSelection.label;
  el("withdrawalAmountInput").value = row.amountYen || "";
  el("withdrawalMemoInput").value = toJapaneseMemo(row.memo || "");
  el("addWithdrawalBtn").textContent = "出金更新";
  el("cancelWithdrawalEditBtn").classList.remove("hidden");
  el("withdrawalAmountInput").focus();
}

function withdrawalDeviceEditSelection(row) {
  const candidates = state.withdrawalDeviceOptions || [];
  const subjectId = String(row?.subjectId || "").toLowerCase();
  const serial = String(row?.serial || "");
  const candidate = candidates.find((entry) => (
    subjectId && String(entry.subjectId || "").toLowerCase() === subjectId
  ) || (serial && entry.device === serial));
  if (candidate) return candidate;
  const subjectKind = String(row?.subjectKind || (serial ? "fleet" : "")).toLowerCase();
  const device = serial || String(row?.managementId || "");
  return {
    label: row?.deviceName || row?.managementId || row?.serial || "",
    device,
    deviceName: row?.deviceName || device,
    subjectKind,
    subjectId: subjectId || (subjectKind && device ? `${subjectKind}:${device}` : ""),
  };
}

async function deleteWithdrawal(withdrawalId) {
  const row = findWithdrawalInState(withdrawalId);
  if (!row) return logLine("出金削除 NG: 履歴が見つかりません");
  const ok = window.confirm("この出金履歴を削除します。よろしいですか？");
  if (!ok) return;
  setBusy(true);
  try {
    const result = await fetchJson("/api/fleet-db/withdrawals/delete", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ withdrawalId }),
    });
    logLine("出金削除 OK: " + (result.deleted?.managementId || ""));
    clearWithdrawalForm();
    await loadSummary();
  } catch (error) {
    logLine("出金削除 NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function markWithdrawalResetDone(withdrawalId) {
  const row = findWithdrawalInState(withdrawalId);
  if (!row) return logLine("リセット NG: 履歴が見つかりません");
  const ok = window.confirm("この出金履歴をリセット扱いにします。よろしいですか？");
  if (!ok) return;
  setBusy(true);
  try {
    const result = await fetchJson("/api/fleet-db/withdrawals/reset-done", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ withdrawalId }),
    });
    logLine("リセット OK: " + (result.withdrawal?.managementId || ""));
    logRefreshWarnings("リセット更新", result.refresh);
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("リセット NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

async function handleDeviceRowAction(event) {
  const inviteAnalyticsButton = event.target.closest("[data-invite-analytics-device]");
  if (inviteAnalyticsButton) {
    showInviteAnalyticsDialog(inviteAnalyticsButton.dataset.inviteAnalyticsDevice || "");
    return;
  }
  const groupButton = event.target.closest("[data-operation-group-edit]");
  if (groupButton) {
    openOperationGroupDialog(groupButton.dataset.operationGroupEdit || "", groupButton);
    return;
  }
  const historyButton = event.target.closest(".history-link-btn");
  if (historyButton) {
    const device = historyButton.dataset.device || historyButton.closest("tr")?.dataset.device || "";
    const row = (state.summary?.devices || []).find((item) => item && (item.serial === device || item.managementId === device || item.laixiNumber === device));
    showDeviceHistoryDialog(row);
    return;
  }
  const resetButton = event.target.closest(".device-reset-btn");
  if (!resetButton) return;
  const device = resetButton.dataset.device;
  const ok = window.confirm("この端末をリセットします。よろしいですか？");
  if (!ok) return;
  setBusy(true);
  try {
    const result = await fetchJson("/api/fleet-db/devices/reset", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ device, reason: "manual_error_reset" }),
    });
    logLine("端末リセット OK: " + (result.device?.managementId || ""));
    logRefreshWarnings("端末リセット更新", result.refresh);
    reloadTagBoardFrame();
    await loadSummary();
  } catch (error) {
    logLine("端末リセット NG: " + error.message);
  } finally {
    setBusy(false);
  }
}

function handleDeviceNameInput(event) {
  const input = event.target.closest(".device-edit-input");
  if (!input) return;
  const changed = input.value.trim() !== (input.dataset.original || "");
  input.classList.toggle("changed-input", changed);
  input.classList.remove("input-error");
  input.title = changed ? "": "";
  updateDeviceNameSaveState();
}

function changedDeviceNameInputs() {
  return [...document.querySelectorAll(".device-edit-input")]
    .filter((input) => input.value.trim() !== (input.dataset.original || ""));
}

function changedDeviceTaskSelects() {
  return [...document.querySelectorAll(".device-task-select")]
    .filter((select) => select.value !== (select.dataset.original || ""));
}

function changedInviteInputs() {
  return changedDeviceNameInputs().filter((input) => INVITE_EDIT_FIELDS.has(input.dataset.field || ""));
}

function updateDeviceNameSaveState() {
  const button = el("saveDeviceNamesBtn");
  const status = el("deviceNameSaveStatus");
  if (!button || !status) return;
  const count = changedDeviceNameInputs().length + changedDeviceTaskSelects().length;
  const errorCount = document.querySelectorAll(".device-edit-input.input-error, .device-task-select.input-error").length;
  button.disabled = state.busy || count === 0;
  status.textContent = errorCount ? `${errorCount}件失敗` : count ? `${count}件未保存` : "";
  status.className = ["mini-status", errorCount ? "error" : count ? "warn" : ""].filter(Boolean).join(" ");

  const inviteButton = el("saveInviteFactorsBtn");
  const inviteStatus = el("inviteFactorsSaveStatus");
  if (inviteButton && inviteStatus) {
    const inviteInputs = changedInviteInputs();
    const inviteErrors = inviteInputs.filter((input) => input.classList.contains("input-error")).length;
    inviteButton.disabled = state.busy || inviteInputs.length === 0;
    inviteStatus.textContent = inviteErrors ? `${inviteErrors}件失敗` : inviteInputs.length ? `${inviteInputs.length}件未保存` : "";
    inviteStatus.className = ["mini-status", "invite-save-status", inviteErrors ? "error" : inviteInputs.length ? "warn" : ""].filter(Boolean).join(" ");
  }
}

async function saveChangedDeviceNames() {
  const inputs = changedDeviceNameInputs();
  const taskSelects = changedDeviceTaskSelects();
  const inviteInputCount = inputs.filter((input) => INVITE_EDIT_FIELDS.has(input.dataset.field || "")).length;
  const total = inputs.length + taskSelects.length;
  if (!total) return;
  setBusy(true);
  el("deviceNameSaveStatus").textContent = `${total}件保存中...`;
  if (inviteInputCount) el("inviteFactorsSaveStatus").textContent = `${inviteInputCount}件保存中...`;
  let failed = 0;
  try {
    const groups = new Map();
    for (const input of inputs) {
      const device = input.dataset.device || input.closest("tr")?.dataset.device || "";
      if (!device) continue;
      const inviteProduct = input.dataset.inviteProduct
        ? normalizeInviteProduct(input.dataset.inviteProduct)
        : "";
      const key = `${device}\u001f${inviteProduct}`;
      if (!groups.has(key)) groups.set(key, { device, inviteProduct, inputs: [] });
      groups.get(key).inputs.push(input);
    }
    for (const group of groups.values()) {
      const { device, inviteProduct, inputs: groupInputs } = group;
      const body = { device, syncName: false };
      if (inviteProduct) body.inviteProduct = inviteProduct;
      for (const input of groupInputs) body[input.dataset.field || "name"] = input.value.trim();
      try {
        const result = await fetchJson("/api/fleet-db/devices/update", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(body),
        });
        for (const input of groupInputs) {
          input.dataset.original = input.value.trim();
          input.classList.remove("changed-input", "input-error");
          input.title = "";
        }
        logLine(`端末保存 OK: ${result.device?.managementId || device}${inviteProduct ? ` / ${inviteProduct === "main" ? "本家" : "Lite"}` : ""}`);
      } catch (error) {
        failed += 1;
        for (const input of groupInputs) {
          input.classList.add("input-error");
          input.title = error.message;
        }
        logLine("端末名保存 NG: " + error.message);
      }
    }
    if (taskSelects.length) {
      const changes = [];
      for (const select of taskSelects) {
        const device = select.dataset.device || select.closest("tr")?.dataset.device || "";
        const kind = select.dataset.kind || "";
        const config = DEVICE_TASK_SELECTS[kind];
        if (!device || !config) continue;
        const nextTag = select.value;
        for (const tag of config.tags) {
          changes.push({
            serial: device,
            managementId: device,
            tag,
            checked: tag === nextTag,
          });
        }
      }
      if (changes.length) {
        try {
          const result = await fetchJson("/api/tag-board/tags/apply", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ changes }),
          });
          for (const select of taskSelects) {
            select.dataset.original = select.value;
            select.classList.remove("changed-input", "input-error");
            select.title = "";
          }
          logLine(`DBタスク反映 OK: ${taskSelects.length}件 / チェック ${result.applied || 0}件`);
          reloadTagBoardFrame();
        } catch (error) {
          failed += 1;
          for (const select of taskSelects) {
            select.classList.add("input-error");
            select.title = error.message;
          }
          logLine("DBタスク反映 NG: " + error.message);
        }
      }
    }
    if (!failed) await loadSummary();
    else {
      el("deviceNameSaveStatus").textContent = `${failed}件失敗`;
      el("deviceNameSaveStatus").className = "mini-status error";
    }
  } finally {
    setBusy(false);
    updateDeviceNameSaveState();
    if (!failed && inviteInputCount) {
      const inviteStatus = el("inviteFactorsSaveStatus");
      inviteStatus.textContent = "保存済";
      inviteStatus.className = "mini-status invite-save-status success";
      window.setTimeout(() => {
        if (!changedInviteInputs().length) updateDeviceNameSaveState();
      }, 2000);
    }
  }
}

function logRefreshWarnings(label, refresh) {
  if (!refresh) return;
  const failed = Object.entries(refresh)
    .filter(([, result]) => result && result.ok === false)
    .map(([name]) => name);
  if (failed.length) logLine(`${label} 注意: ${failed.join(", ")}`);
}

function findWithdrawalInState(withdrawalId) {
  return (state.summary?.withdrawals || []).find((row) => row.withdrawalId === withdrawalId);
}

function renderDeviceRevenue(rows) {
  el("deviceRevenueRows").innerHTML = rows.map((row) => `
    <tr class="site-row ${siteClass(row.siteName)}">
      <td>${siteBadge(row.siteName)}</td>
      <td class="num">${esc(row.deviceNumber || row.managementId || "")}</td>
      <td>${esc(row.deviceName)}</td>
      <td class="num">${esc(row.count)}</td>
      <td class="num yen">${yen(row.totalYen)}</td>
      <td class="num yen">${yen(row.monthYen)}</td>
      <td class="num">${yen(row.averageYen)}</td>
      <td>${esc(row.lastWithdrawalDate)}</td>
    </tr>
  `).join("");
}

function renderMonthlyRevenue(rows, siteRows, siteTotals) {
  const currentMonth = localDateInputValue().slice(0, 7);
  const latest = rows.find((row) => row.month === currentMonth) || { month: currentMonth, totalYen: 0, count: 0, yen3000: 0, over5000: 0 };
  const allTotal = rows.reduce((sum, row) => sum + Number(row.totalYen || 0), 0);
  el("monthlyCards").innerHTML = [
    card("今月", currentMonth, yen(latest.totalYen || 0)),
    card("今月件数", "出金", `${latest.count || 0}件`),
    card("3000～4999円", "今月", `${latest.yen3000 || 0}件`),
    card("5000円以上", "今月", `${latest.over5000 || 0}件`),
    card("累計", "DB全体", yen(allTotal)),
  ].join("");
  el("siteRevenueRows").innerHTML = siteTotals.map((row) => `
    <tr class="site-row ${siteClass(row.siteName)}">
      <td>${siteBadge(row.siteName)}</td>
      <td class="num">${esc(row.count)}</td>
      <td class="num yen">${yen(row.monthYen)}</td>
      <td class="num yen">${yen(row.totalYen)}</td>
    </tr>
  `).join("");
  el("monthlyRows").innerHTML = rows.slice().reverse().map((row) => `
    <tr>
      <td>${esc(row.month)}</td>
      <td class="num">${esc(row.count)}</td>
      <td class="num">${esc(row.yen3000)}</td>
      <td class="num">${esc(row.over5000)}</td>
      <td class="num yen">${yen(row.totalYen)}</td>
    </tr>
  `).join("");
  el("monthlySiteRows").innerHTML = siteRows.slice().reverse().map((row) => `
    <tr class="site-row ${siteClass(row.siteName)}">
      <td>${esc(row.month)}</td>
      <td>${siteBadge(row.siteName)}</td>
      <td class="num">${esc(row.count)}</td>
      <td class="num">${esc(row.yen3000)}</td>
      <td class="num">${esc(row.over5000)}</td>
      <td class="num yen">${yen(row.totalYen)}</td>
    </tr>
  `).join("");
}

function renderRewardCalculator() {
  if (!el("calcCiSelect")) return;
  const ciYen = Number(el("calcCiSelect").value || 0);
  const video180Points = Number(el("calc180Select").value || 0);
  const selected10 = el("calc10Select").value;
  const custom10 = Number(el("calc10CustomInput").value || 0);
  const video10Yen = selected10 === "custom" ? Math.max(0, custom10) : Number(selected10 || 0);
  el("calc10CustomInput").disabled = selected10 !== "custom";

  const projection = buildRewardProjection({
    ciTotalYen: ciYen,
    video180DailyPoints: video180Points,
    video10TotalYen: video10Yen,
  });
  const day3000 = projection.day3000 ? `${projection.day3000}日目` : "";
  const day5000 = projection.day5000 ? `${projection.day5000}日目` : "";
  el("calcFormulaLine").textContent = `チェックイン ${yen(ciYen)} + 動画180分 ${number(video180Points)}P/日 x ${VIDEO_TASK_DAYS}日 + 追加視聴 ${yen(video10Yen)} / ${VIDEO_TASK_DAYS}日`;
  el("calcSummaryCards").innerHTML = [
    calcCard("最終見込み", yen(projection.finalYen), projection.finalYen >= 5000 ? "good" : projection.finalYen >= 3000 ? "warn" : "bad"),
    calcCard("3000円到達", day3000, projection.day3000 ? "good" : "bad"),
    calcCard("5000円到達", day5000, projection.day5000 ? "good" : "warn"),
  ].join("");
  el("calcRows").innerHTML = projection.rows.map((row) => {
    const reached5000 = row.totalYen >= 5000;
    const reached3000 = row.totalYen >= 3000;
    const klass = reached5000 ? "reach-row-5000" : reached3000 ? "reach-row-3000" : "";
    const badges = [
      reached3000 ? `<span class="reach-pill ok3000">3000</span>` : "",
      reached5000 ? `<span class="reach-pill ok5000">5000</span>` : "",
    ].filter(Boolean).join(" ");
    return `<tr class="${klass}">
      <td>${row.day}日目</td>
      <td class="num">${row.ciMultiplier}</td>
      <td class="num">${number(row.ciPoints)}</td>
      <td class="num">${number(row.video180Points)}</td>
      <td class="num">${yen(row.video10Yen)}</td>
      <td class="num">${yen(row.dayPoints / 100)}</td>
      <td class="num yen">${yen(row.totalYen)}</td>
      <td>${badges || `<span class="reach-pill">-</span>`}</td>
    </tr>`;
  }).join("");
  el("calcCiRows").innerHTML = projection.rows.map((row) => `
    <tr>
      <td>${row.day}日目</td>
      <td class="num">${row.ciMultiplier} / 45</td>
      <td class="num">${number(row.ciPoints)}</td>
      <td class="num yen">${yen(row.ciPoints / 100)}</td>
    </tr>
  `).join("");
  el("calcUnitExplanation").innerHTML = renderCiUnitExplanation(ciYen, projection.rows);
}

function renderCiUnitExplanation(ciYen, rows) {
  const unitYen = ciYen / CI_MULTIPLIER_TOTAL;
  const first = rows[0] || { ciMultiplier: 0, ciPoints: 0 };
  const last = rows[13] || rows[rows.length - 1] || { ciMultiplier: 0, ciPoints: 0 };
  return `
    <div class="calc-unit-title">口数の説明</div>
    <div class="calc-unit-formula">報酬総額 ${yen(ciYen)} ÷ 45口 = 1口あたり ${yen(round(unitYen, 2))}</div>
    <div class="calc-unit-grid">
      <div><b>1日目</b><span>${yen(round(unitYen, 2))} x ${first.ciMultiplier}口 = ${yen(first.ciPoints / 100)}</span></div>
      <div><b>14日目</b><span>${yen(round(unitYen, 2))} x ${last.ciMultiplier}口 = ${yen(last.ciPoints / 100)}</span></div>
    </div>
    <div class="calc-unit-caption">日ごとの45口配分は、3,3,3,1,1,1,5,1,1,2,3,5,6,10口です。</div>
  `;
}

function buildRewardProjection(options) {
  const ciTotalYen = Number(options.ciTotalYen || 0);
  const video180DailyPoints = Number(options.video180DailyPoints || 0);
  const video10TotalYen = Number(options.video10TotalYen || 0);
  const ciTotalPoints = Math.round(ciTotalYen * 100);
  const ciUnit = ciTotalPoints / CI_MULTIPLIER_TOTAL;
  const video10DailyYen = video10TotalYen / VIDEO_TASK_DAYS;
  const rows = [];
  let totalPoints = 0;
  let ciAllocatedPoints = 0;
  for (let day = 1; day <= 14; day += 1) {
    const ciMultiplier = CI_MULTIPLIERS[day - 1] || 0;
    const ciPoints = day === CI_MULTIPLIERS.length
      ? ciTotalPoints - ciAllocatedPoints
      : Math.round(ciUnit * ciMultiplier);
    ciAllocatedPoints += ciPoints;
    const video180Points = day <= VIDEO_TASK_DAYS ? video180DailyPoints : 0;
    const video10Yen = day <= VIDEO_TASK_DAYS ? video10DailyYen : 0;
    const video10Points = Math.round(video10Yen * 100);
    const dayPoints = ciPoints + video180Points + video10Points;
    totalPoints += dayPoints;
    rows.push({
      day,
      ciMultiplier,
      ciPoints,
      video180Points,
      video10Yen: round(video10Yen, 2),
      dayPoints,
      totalYen: round(totalPoints / 100, 2),
    });
  }
  return {
    rows,
    finalYen: rows.length ? rows[rows.length - 1].totalYen : 0,
    day3000: firstReachDay(rows, 3000),
    day5000: firstReachDay(rows, 5000),
  };
}

function firstReachDay(rows, targetYen) {
  const row = rows.find((item) => item.totalYen >= targetYen);
  return row ? row.day : null;
}

function calcCard(label, value, klass) {
  return `<div class="calc-card ${esc(klass || "")}"><div class="label">${esc(label)}</div><div class="value">${esc(value)}</div></div>`;
}

function card(label, sub, value) {
  return `<div class="revenue-card"><div class="label">${esc(label)} / ${esc(sub)}</div><div class="value">${esc(value)}</div></div>`;
}

function statusPill(status, row = {}) {
  if (row.adbConnected === false) {
    return `<span class="status-pill status-offline">OFFLINE</span>`;
  }
  const value = status || "UNKNOWN";
  const klass = value === "ONLINE" ? "status-online" : (value === "WAITING" || value === "INACTIVE") ? "status-waiting" : value === "ACTIVE" ? "status-active" : "status-unknown";
  const label = value === "WAITING" || value === "INACTIVE" || value === "NO CYCLE" ? "非稼働" : value;
  return `<span class="status-pill ${klass}">${esc(label)}</span>`;
}

function swipeAgentPill(row) {
  if (row.swipeAgentInstalled === true) {
    const version = [row.swipeAgentVersionName, row.swipeAgentVersionCode].filter(Boolean).join("/");
    if (row.swipeAgentAccessibilityEnabled === false) {
      return `<span class="status-pill swipe-agent-pill status-waiting" title="Agentのユーザー補助権限が無効です">権限なし</span>`;
    }
    const title = [version ? `Agent ${version}` : "Agent", row.swipeAgentCheckedAt || ""].filter(Boolean).join(" / ");
    return `<span class="status-pill swipe-agent-pill status-online" title="${esc(title)}">導入済</span>`;
  }
  if (row.swipeAgentInstalled === false) {
    const title = row.swipeAgentLastError || row.swipeAgentCheckedAt || "";
    return `<span class="status-pill swipe-agent-pill status-waiting" title="${esc(title)}">未導入</span>`;
  }
  return `<span class="status-pill swipe-agent-pill status-unknown">未確認</span>`;
}

function normalizeSwipeModeRecommendation(row) {
  const manual = row.swipeModePreference || "auto";
  if (manual === "agent") return { mode: "agent", source: "manual", label: "Agent推奨" };
  if (manual === "adb") return { mode: "adb", source: "manual", label: "ADB推奨" };
  if (manual === "disabled") return { mode: "disabled", source: "manual", label: "無効" };
  const recommendation = row.swipeModeRecommendation || {};
  if (recommendation.mode) return recommendation;
  const lastError = String(row.swipeAgentLastError || "");
  if (row.swipeAgentInstalled === false || row.swipeAgentAccessibilityEnabled === false || /WRITE_SECURE_SETTINGS|Permission denial|accessibility/i.test(lastError)) {
    return { mode: "adb", source: "auto", label: "ADB推奨" };
  }
  return { mode: "agent", source: "auto", label: "Agent推奨" };
}

function swipeModeChip(row) {
  const recommendation = normalizeSwipeModeRecommendation(row || {});
  const mode = recommendation.mode || "agent";
  const source = recommendation.source === "manual" ? "手動固定" : "自動判定";
  const fullLabel = recommendation.label || (mode === "adb" ? "ADB推奨" : mode === "disabled" ? "無効" : "Agent推奨");
  const label = mode === "adb" ? "ADB" : mode === "disabled" ? "無効" : "Agent";
  return `<span class="swipe-mode-chip ${esc(mode)}" title="${esc(`${source}: ${fullLabel}`)}">${esc(label)}</span>`;
}

function swipeModeCardClass(row) {
  const recommendation = normalizeSwipeModeRecommendation(row || {});
  return `swipe-mode-card-${recommendation.mode || "agent"}`;
}

function uptimePill(row, adbDevice) {
  const seconds = Number(adbDevice?.uptimeSeconds);
  if (!Number.isFinite(seconds) || seconds < 0) {
    const title = adbDevice?.uptimeError || (row.serial ? "ADB未接続または稼働時間未取得" : "端末IDなし");
    return `<span class="uptime-pill uptime-unknown" title="${esc(title)}">-</span>`;
  }
  const fetchedAt = Number(adbDevice?.uptimeFetchedAt || state.adbDevices?.uptimeFetchedAt || Date.now());
  const value = currentUptimeValue(seconds, fetchedAt);
  const title = uptimeTitle(value.hours, adbDevice?.uptimeRaw);
  return `<span class="uptime-pill ${uptimeBandClass(value.hours)}" data-uptime-base="${esc(seconds)}" data-uptime-fetched-at="${esc(fetchedAt)}" data-uptime-raw="${esc(adbDevice?.uptimeRaw || "")}" title="${esc(title)}">${esc(uptimeLabel(value.hours))}</span>`;
}

function uptimeBandClass(hours) {
  if (hours >= 500) return "uptime-500";
  if (hours >= 400) return "uptime-400";
  if (hours >= 300) return "uptime-300";
  if (hours >= 200) return "uptime-200";
  if (hours >= 100) return "uptime-100";
  return "uptime-000";
}

function currentUptimeValue(baseSeconds, fetchedAt) {
  const elapsedSeconds = Math.max(0, Math.floor((Date.now() - Number(fetchedAt || Date.now())) / 1000));
  const seconds = Math.max(0, Number(baseSeconds || 0) + elapsedSeconds);
  return { seconds, hours: seconds / 3600 };
}

function uptimeLabel(hours) {
  return hours >= 100 ? `${Math.floor(hours)}h` : `${hours.toFixed(1)}h`;
}

function uptimeTitle(hours, raw = "") {
  const days = hours / 24;
  return `${hours.toFixed(1)}時間 / ${days.toFixed(1)}日${raw ? ` / ${raw}` : ""}`;
}

function startUptimeTicker() {
  if (state.uptimeTickTimer) return;
  state.uptimeTickTimer = window.setInterval(tickUptimePills, 30000);
}

function tickUptimePills() {
  for (const pill of document.querySelectorAll(".uptime-pill[data-uptime-base], .invite-uptime-chip[data-uptime-base]")) {
    const baseSeconds = Number(pill.dataset.uptimeBase);
    const fetchedAt = Number(pill.dataset.uptimeFetchedAt);
    if (!Number.isFinite(baseSeconds) || !Number.isFinite(fetchedAt)) continue;
    const value = currentUptimeValue(baseSeconds, fetchedAt);
    const prefix = pill.dataset.uptimePrefix || "";
    pill.textContent = `${prefix}${uptimeLabel(value.hours)}`;
    pill.title = uptimeTitle(value.hours, pill.dataset.uptimeRaw || "");
    pill.classList.remove("uptime-000", "uptime-100", "uptime-200", "uptime-300", "uptime-400", "uptime-500");
    pill.classList.add(uptimeBandClass(value.hours));
  }
  tickOfflineDeviceRows();
}

function tickOfflineDeviceRows() {
  const rows = state.summary?.offlineDevices || [];
  let statusChanged = false;
  for (const element of document.querySelectorAll("#offlineDeviceRows tr[data-offline-id]")) {
    const row = rows.find((item) => item.offlineId === element.dataset.offlineId);
    if (!row) continue;
    const nowMs = Date.now();
    const status = offlineStatusInfo(row, nowMs);
    if (status.key !== element.dataset.offlineStatus) {
      statusChanged = true;
      break;
    }
    const day = offlineCurrentDay(row, new Date(nowMs));
    const uptimeMinutes = offlineCurrentUptimeMinutes(row, nowMs);
    const uptimeHours = uptimeMinutes / 60;
    const rest = offlineRestTiming(row, nowMs);
    const dayElement = element.querySelector(".offline-day-value");
    const uptimeElement = element.querySelector(".offline-uptime-value");
    const restElement = element.querySelector(".offline-rest-value");
    if (dayElement) dayElement.textContent = day ? `DAY ${day}` : "-";
    if (uptimeElement) {
      uptimeElement.textContent = uptimeLabel(uptimeHours);
      uptimeElement.classList.remove("uptime-000", "uptime-100", "uptime-200", "uptime-300", "uptime-400", "uptime-500");
      uptimeElement.classList.add(uptimeBandClass(uptimeHours));
    }
    if (restElement && status.key === "resting") restElement.textContent = `残り ${offlineDurationLabel(rest.remainingMinutes)}`;
  }
  if (statusChanged) renderOfflineDeviceDb(rows);
}

function siteName(value) {
  return String(value || state.summary?.settings?.siteName || "本店");
}

function siteClass(value) {
  const name = siteName(value);
  let hash = 0;
  for (const char of name) hash = (hash * 31 + char.charCodeAt(0)) >>> 0;
  return `site-${hash % 8}`;
}

function siteBadge(value) {
  const name = siteName(value);
  return `<span class="site-badge ${siteClass(name)}" title="${esc(name)}">${esc(name)}</span>`;
}

function toJapaneseMemo(memo) {
  return String(memo || "")
    .replace(/3000 yen withdrawn,\s*reset,\s*then moved to waiting\.?/gi, "3,000円出金後、リセットして非稼働へ移動")
    .replace(/yen withdrawn,\s*reset,\s*then moved to waiting\.?/gi, "円出金後、リセットして非稼働へ移動")
    .replace(/withdrawn/gi, "出金")
    .replace(/reset done/gi, "リセット済み")
    .replace(/reset/gi, "リセット")
    .replace(/moved to waiting/gi, "非稼働へ移動")
    .replace(/individual revenue memo/gi, "個別収益メモ")
    .trim();
}

function looksCorruptedText(value) {
  const text = String(value || "");
  for (const char of text) {
    const code = char.charCodeAt(0);
    if (code === 0xfffd) return true;
    if (code >= 0x8340 && code <= 0x9fff) return true;
    if (code >= 0xe000 && code <= 0xf8ff) return true;
    if (code >= 0xff61 && code <= 0xff9f) return true;
  }
  return false;
}

function setBusy(busy, activeButton = null, loadingText = "処理中...") {
  const safeLoadingText = looksCorruptedText(loadingText) ? "処理中..." : String(loadingText || "処理中...");
  state.busy = busy;
  for (const button of document.querySelectorAll("button")) button.disabled = busy;
  for (const input of document.querySelectorAll("#clipboardTargetGrid input[type='checkbox'], #clipboardActiveOnlyInput")) {
    input.disabled = busy;
  }
  for (const input of document.querySelectorAll("#apnTargetGrid input[type='checkbox']")) {
    input.disabled = busy || state.apnSetup.running || input.dataset.adbConnected !== "true";
  }
  if (busy && activeButton) {
    activeButton.dataset.originalText = activeButton.dataset.originalText || activeButton.textContent;
    activeButton.textContent = safeLoadingText;
    activeButton.classList.add("is-loading");
  }
  if (!busy) {
    for (const button of document.querySelectorAll("button.is-loading")) {
      button.textContent = button.dataset.originalText || button.textContent;
      delete button.dataset.originalText;
      button.classList.remove("is-loading");
    }
    updateDeviceNameSaveState();
    renderApnSelectionStatus();
    if (!el("rootPseudoResetModal")?.classList.contains("hidden")) updateRootPseudoResetExecuteState();
  }
}

function flashButtonResult(button, message = "完了", type = "ok", ms = 1800) {
  if (!button || !button.isConnected) return;
  const klass = type === "error" ? "flash-error" : type === "warn" ? "flash-warn" : "flash-ok";
  const original = button.dataset.flashOriginal || button.dataset.originalText || button.textContent;
  if (button.dataset.flashTimer) window.clearTimeout(Number(button.dataset.flashTimer));
  button.dataset.flashOriginal = original;
  button.textContent = message;
  button.classList.remove("flash-ok", "flash-warn", "flash-error");
  button.classList.add(klass);
  button.dataset.flashTimer = String(window.setTimeout(() => {
    if (!button.isConnected) return;
    button.textContent = button.dataset.flashOriginal || original;
    delete button.dataset.flashOriginal;
    delete button.dataset.flashTimer;
    button.classList.remove("flash-ok", "flash-warn", "flash-error");
  }, ms));
}

function setSwipeStopControlsLocked(locked) {
  const ids = [
    "swipeAgentStartBtn",
    "swipeAgentStopBtn",
    "adbSwipeStopBtn",
    "swipeRecoveryTestBtn",
    "swipeLiveRecoveryTestBtn",
    "swipeAgentApplyBulkBtn",
    "swipeAgentSelectAllBtn",
    "swipeAgentSelectActiveBtn",
    "swipeAgentClearSelectionBtn",
    "swipeAgentRefreshBtn",
    "swipeAgentStatusBtn",
    "swipeAgentInstallBtn",
  ];
  for (const id of ids) {
    const button = el(id);
    if (button) button.disabled = Boolean(locked);
  }
}

function logLine(message) {
  const text = String(message ?? "");
  const entry = createSyncLogEntry(text);
  state.syncLogs.unshift(entry);
  state.syncLogs = state.syncLogs.slice(0, 5000);
  state.syncLogPending.push(entry);
  renderSyncLogs();
  persistLogLines(state.syncLogs.slice(0, LOG_STORAGE_LIMIT).map(formatSyncLogEntry).join("\n"));
  scheduleSyncLogFlush();
}

function restoreLogLines() {
  if (!el("logBox")) return;
  try {
    const lines = JSON.parse(localStorage.getItem(LOG_STORAGE_KEY) || "[]");
    if (Array.isArray(lines) && lines.length) {
      state.syncLogs = lines.map((line, index) => parseLegacySyncLogLine(line, index));
      renderSyncLogs();
    }
  } catch (_) {
    localStorage.removeItem(LOG_STORAGE_KEY);
  }
}

function persistLogLines(text) {
  try {
    const lines = String(text || "").split("\n").filter(Boolean).slice(0, LOG_STORAGE_LIMIT);
    localStorage.setItem(LOG_STORAGE_KEY, JSON.stringify(lines));
  } catch (_) {
    // Logging must never break the operation being logged.
  }
}

function createSyncLogEntry(message) {
  const at = new Date().toISOString();
  const failureProbe = String(message || "")
    .replace(/(?:失敗|エラー)\s*[:：=]?\s*0(?:件|台)?(?=\s*(?:\/|$))/gi, "")
    .replace(/\b(?:failed|failures?|errors?)\s*[:=]?\s*0\b/gi, "");
  const failure = /(?:NG|失敗|ERROR|エラー|未認識|接続できません|見つかりません)/i.test(failureProbe);
  const success = !failure && /(?:OK|完了|保存|反映|取得成功|変更なし)/i.test(message);
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
    at,
    level: failure ? "failure" : success ? "success" : "info",
    category: /同期|反映|DB再読込|DAY更新|端末名再取得/i.test(message) ? "sync" : "operation",
    message,
  };
}

function parseLegacySyncLogLine(line, index) {
  const text = String(line || "");
  const message = text.replace(/^\[[^\]]+\]\s*/, "");
  return { ...createSyncLogEntry(message), id: `legacy-${index}-${message.slice(0, 20)}` };
}

function formatSyncLogEntry(entry) {
  const date = new Date(entry.at || Date.now());
  const stamp = Number.isNaN(date.getTime()) ? String(entry.at || "") : date.toLocaleString("ja-JP", { hour12: false });
  return `[${stamp}] ${entry.message || ""}`;
}

function renderSyncLogs() {
  const box = el("logBox");
  if (!box) return;
  const filter = el("syncLogFilter")?.value || "all";
  const query = (el("syncLogSearch")?.value || "").trim().toLowerCase();
  const filtered = state.syncLogs.filter((entry) => {
    if (filter === "success" && entry.level !== "success") return false;
    if (filter === "failure" && entry.level !== "failure") return false;
    if (filter === "sync" && entry.category !== "sync") return false;
    return !query || `${entry.message} ${entry.at}`.toLowerCase().includes(query);
  });
  box.textContent = filtered.map(formatSyncLogEntry).join("\n");
  const meta = el("syncLogMeta");
  if (meta) meta.textContent = `保存 ${state.syncLogs.length}件 / 表示 ${filtered.length}件 / 最大5000件`;
}

async function loadPersistentSyncLogs() {
  try {
    const result = await fetchJson("/api/fleet-db/sync-log");
    const serverEntries = Array.isArray(result.entries) ? result.entries.slice().reverse() : [];
    const byId = new Map(serverEntries.map((entry) => [entry.id, entry]));
    for (const entry of state.syncLogs) if (!byId.has(entry.id)) byId.set(entry.id, entry);
    state.syncLogs = [...byId.values()]
      .sort((a, b) => String(b.at).localeCompare(String(a.at)))
      .slice(0, Number(result.limit || 5000));
    renderSyncLogs();
  } catch (_) {
    renderSyncLogs();
  }
}

function scheduleSyncLogFlush() {
  if (state.syncLogFlushTimer) return;
  state.syncLogFlushTimer = window.setTimeout(flushSyncLogs, 400);
}

async function flushSyncLogs() {
  window.clearTimeout(state.syncLogFlushTimer);
  state.syncLogFlushTimer = 0;
  const entries = state.syncLogPending.splice(0, 100);
  if (!entries.length) return;
  try {
    await fetchJson("/api/fleet-db/sync-log", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ entries }),
    });
  } catch (_) {
    state.syncLogPending.unshift(...entries);
  }
  if (state.syncLogPending.length) scheduleSyncLogFlush();
}

function downloadSyncLogs() {
  const content = state.syncLogs.map(formatSyncLogEntry).join("\r\n");
  const blob = new Blob(["\uFEFF", content], { type: "text/plain;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `AndroidFleet-同期ログ-${new Date().toISOString().slice(0, 10)}.txt`;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}

async function clearSyncLogs() {
  if (!window.confirm("同期ログをすべて消去しますか？この操作は元に戻せません。")) return;
  try {
    await fetchJson("/api/fleet-db/sync-log/clear", { method: "POST" });
    state.syncLogs = [];
    state.syncLogPending = [];
    localStorage.removeItem(LOG_STORAGE_KEY);
    renderSyncLogs();
  } catch (error) {
    window.alert("同期ログの消去に失敗しました。\n" + error.message);
  }
}

function summarizeActionResult(result) {
  if (result.failedSteps && result.failedSteps.length) return "失敗 " + result.failedSteps.join(", ");
  if (result.file) return result.file;
  if (result.result && result.result.json) {
    const json = result.result.json;
    if (json.synced) return "同期済 " + JSON.stringify(json.counts || {});
    if (json.queued) return "保留: " + (json.reason || "");
  }
  return "";
}

function summarizeSyncStepDurations(refresh) {
  const labels = {
    backupBeforeRefresh: "DBバックアップ",
    deviceCodeSync: "端末名再取得",
    tagBoard: "チェック表生成",
    displayNames: "表示名",
    numbers: "番号",
    tagBoardAfterDisplayNames: "チェック表更新",
    sheets: "Sheets",
  };
  return Object.entries(refresh || {})
    .filter(([, result]) => Boolean(result) && Number.isFinite(Number(result.durationMs)))
    .map(([name, result]) => `${labels[name] || name} ${(Number(result.durationMs) / 1000).toFixed(1)}秒`)
    .join(" / ");
}

function yen(value) {
  return "\u00a5" + Number(value || 0).toLocaleString("ja-JP");
}

function number(value) {
  return Number(value || 0).toLocaleString("ja-JP");
}

function round(value, digits) {
  const scale = 10 ** digits;
  return Math.round(Number(value || 0) * scale) / scale;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, Number(value || 0)));
}

function formatDate(value) {
  if (!value) return "";
  return String(value).slice(0, 10);
}

function formatDateTime(value) {
  if (!value) return "";
  return new Date(value).toLocaleString("ja-JP");
}

function localDateInputValue(date = new Date()) {
  const parts = new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date).reduce((map, part) => {
    map[part.type] = part.value;
    return map;
  }, {});
  return `${parts.year}-${parts.month}-${parts.day}`;
}

function localTimestampForFile() {
  const date = new Date();
  const parts = new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(date).reduce((map, part) => {
    map[part.type] = part.value;
    return map;
  }, {});
  return `${parts.year}${parts.month}${parts.day}-${parts.hour}${parts.minute}${parts.second}`;
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  }[char]));
}
