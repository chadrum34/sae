"use strict";

const fs = require("node:fs");
const path = require("node:path");

const args = parseArgs(process.argv.slice(2));
const appRootArg = args["app-root"] || args.appRoot;
if (!appRootArg || !args.merge || !args.manifest) {
  console.error("Usage: node apply-data-merge.js --app-root <path> --merge <path> --manifest <path>");
  process.exit(2);
}

const appRoot = path.resolve(appRootArg);
const merge = readJson(args.merge);
const manifest = readJson(args.manifest);
const masterPath = path.join(appRoot, "data", "fleet-db", "device-master.json");
const fleetDbPath = path.join(appRoot, "data", "fleet-db", "fleet-db.json");
const mapPath = path.join(appRoot, "config", "device-name-map.json");
const updatesPath = path.join(appRoot, "config", "applied-updates.json");
const allowedPatchExpectedKeys = new Set([
  "id", "shortName", "modelCode", "salesName", "maker", "carrierCode", "route", "notes", "source", "createdAt", "updatedAt", "disabled",
]);
const allowedPatchSetKeys = new Set(["shortName", "salesName", "maker", "route", "notes", "source", "createdAt", "updatedAt", "disabled"]);

const master = readJson(masterPath);
const masterChanges = prepareDeviceMasterChanges(
  Array.isArray(master.entries) ? master.entries : [],
  merge.deviceMasterEntries,
  merge.deviceMasterEntryPatches,
  { strictAdditions: Number(merge.schemaVersion || 1) >= 3 },
);
const addedMasterEntries = masterChanges.added;
const alreadyAddedMasterEntries = masterChanges.alreadyAdded;
const patchedMasterEntries = masterChanges.patched;
const alreadyPatchedMasterEntries = masterChanges.alreadyPatched;
const nameMap = readJson(mapPath);
nameMap.exact = objectOrEmpty(nameMap.exact);
nameMap.short = objectOrEmpty(nameMap.short);
const exactChanges = prepareNameMapChanges(
  nameMap.exact,
  normalizeNameMapAdditions(merge.nameMapExact, merge.nameMapExactAdditions, "exact"),
  merge.nameMapExactPatches,
  "exact",
);
const shortChanges = prepareNameMapChanges(
  nameMap.short,
  normalizeNameMapAdditions(merge.nameMapShort, merge.nameMapShortAdditions, "short"),
  merge.nameMapShortPatches,
  "short",
);
const addedExact = exactChanges.added;
const addedShort = shortChanges.added;

if (addedMasterEntries || patchedMasterEntries) {
  master.entries = masterChanges.entries;
  master.updatedAt = new Date().toISOString();
  writeJsonAtomic(masterPath, master);
}
if (exactChanges.changed || shortChanges.changed) {
  nameMap.exact = exactChanges.entries;
  nameMap.short = shortChanges.entries;
  writeJsonAtomic(mapPath, nameMap);
}

const fleetAction = applyFleetDbActions(fleetDbPath, merge.fleetDbActions || {});

const updates = fs.existsSync(updatesPath) ? readJson(updatesPath) : [];
const list = Array.isArray(updates) ? updates : [];
const appliedFileHashes = Object.fromEntries((manifest.files || [])
  .map((file) => [normalizeRelativePath(file && file.path), String(file && file.newSha256 || "").toLowerCase()])
  .filter(([relativePath, hash]) => relativePath && /^[0-9a-f]{64}$/.test(hash)));
const updateId = String(manifest.updateId || "");
const existingUpdate = list.find((item) => String(item && item.updateId || "") === updateId);
if (existingUpdate) {
  existingUpdate.displayName = String(manifest.displayName || existingUpdate.displayName || "");
  existingUpdate.files = appliedFileHashes;
} else {
  list.push({
    updateId,
    displayName: String(manifest.displayName || ""),
    appliedAt: new Date().toISOString(),
    files: appliedFileHashes,
  });
}
writeJsonAtomic(updatesPath, list);

console.log(JSON.stringify({
  ok: true,
  addedMasterEntries,
  alreadyAddedMasterEntries,
  patchedMasterEntries,
  alreadyPatchedMasterEntries,
  addedExact,
  addedShort,
  patchedExact: exactChanges.patched,
  patchedShort: shortChanges.patched,
  removedExact: exactChanges.removed,
  removedShort: shortChanges.removed,
  alreadyPatchedExact: exactChanges.alreadyPatched,
  alreadyPatchedShort: shortChanges.alreadyPatched,
  fleetAction,
  updateId: manifest.updateId,
}));

function prepareDeviceMasterChanges(currentEntries, additionsValue, patchesValue, options = {}) {
  const entries = currentEntries.map((entry) => cloneObject(entry));
  let added = 0;
  let alreadyAdded = 0;
  for (const sourceEntry of additionsValue || []) {
    const entry = cloneObject(sourceEntry);
    const id = String(entry && entry.id || "");
    const modelCode = String(entry && entry.modelCode || "");
    const matches = entries.filter((item) => (
      (id && equalIgnoreCase(item && item.id, id)) ||
      (modelCode && equalIgnoreCase(item && item.modelCode, modelCode))
    ));
    if (!matches.length) {
      entries.push(entry);
      added += 1;
    } else if (options.strictAdditions === true) {
      const identical = matches.length === 1 && Object.entries(entry)
        .every(([key, value]) => samePatchValue(matches[0] && matches[0][key], value));
      if (!identical) {
        throw new Error(`Device master addition conflicts with an existing identity. id=${id} modelCode=${modelCode}`);
      }
      alreadyAdded += 1;
    }
  }

  const patches = normalizeDeviceMasterEntryPatches(patchesValue);
  const plans = [];
  let alreadyPatched = 0;
  for (const patch of patches) {
    const matches = entries
      .map((entry, index) => ({ entry, index }))
      .filter(({ entry }) => (
        equalIgnoreCase(entry && entry.id, patch.id)
        && equalIgnoreCase(entry && entry.modelCode, patch.modelCode)
        && equalIgnoreCase(entry && entry.carrierCode, patch.carrierCode)
      ));
    const label = `${patch.id}/${patch.modelCode}/${patch.carrierCode}`;
    if (matches.length !== 1) {
      throw new Error(`Device master patch target count does not match. guard=${label} found=${matches.length}`);
    }
    const target = matches[0].entry;
    const setAlreadyMatches = Object.entries(patch.set)
      .every(([key, value]) => samePatchValue(target && target[key], value));
    if (setAlreadyMatches) {
      const unchangedGuardMismatches = patchFieldMismatches(target, patch.expectedCurrent)
        .filter((key) => !Object.prototype.hasOwnProperty.call(patch.set, key));
      if (unchangedGuardMismatches.length) {
        throw new Error(`Device master patch guard mismatch. guard=${label} fields=${unchangedGuardMismatches.join(",")}`);
      }
      alreadyPatched += 1;
      continue;
    }
    const guardMismatches = patchFieldMismatches(target, patch.expectedCurrent);
    if (guardMismatches.length) {
      throw new Error(`Device master patch expected-current mismatch. guard=${label} fields=${guardMismatches.join(",")}`);
    }
    plans.push({ index: matches[0].index, set: patch.set });
  }

  for (const plan of plans) Object.assign(entries[plan.index], plan.set);
  return { entries, added, alreadyAdded, patched: plans.length, alreadyPatched };
}

function prepareNameMapChanges(currentEntries, additionsValue, patchesValue, label) {
  const entries = { ...objectOrEmpty(currentEntries) };
  let added = 0;
  for (const { key, value } of additionsValue) {
    if (!Object.prototype.hasOwnProperty.call(entries, key)) {
      entries[key] = String(value);
      added += 1;
    } else if (String(entries[key]) !== String(value)) {
      throw new Error(`Name-map ${label} addition conflicts with an existing value. key=${key}`);
    }
  }

  const patches = normalizeNameMapPatches(patchesValue, label);
  const plans = [];
  let alreadyPatched = 0;
  for (const patch of patches) {
    const exists = Object.prototype.hasOwnProperty.call(entries, patch.key);
    const current = exists ? String(entries[patch.key]) : "";
    if (patch.remove === true) {
      if (!exists) {
        alreadyPatched += 1;
        continue;
      }
      if (current !== patch.expectedCurrent) {
        throw new Error(`Name-map ${label} patch expected-current mismatch. key=${patch.key}`);
      }
      plans.push({ type: "remove", key: patch.key });
      continue;
    }
    if (exists && current === patch.set) {
      alreadyPatched += 1;
      continue;
    }
    if (!exists || current !== patch.expectedCurrent) {
      throw new Error(`Name-map ${label} patch expected-current mismatch. key=${patch.key}`);
    }
    plans.push({ type: "set", key: patch.key, value: patch.set });
  }

  let patched = 0;
  let removed = 0;
  for (const plan of plans) {
    if (plan.type === "remove") {
      delete entries[plan.key];
      removed += 1;
    } else {
      entries[plan.key] = plan.value;
      patched += 1;
    }
  }
  return {
    entries,
    added,
    patched,
    removed,
    alreadyPatched,
    changed: added + patched + removed > 0,
  };
}

function normalizeNameMapAdditions(legacyValue, additionsValue, label) {
  const result = [];
  const seen = new Set();
  for (const [key, value] of Object.entries(objectOrEmpty(legacyValue))) {
    result.push({ key, value: String(value) });
    seen.add(key);
  }
  if (additionsValue == null) return result;
  if (!Array.isArray(additionsValue)) throw new Error(`nameMap${label}Additions must be an array`);
  additionsValue.forEach((entry, index) => {
    const prefix = `nameMap${label}Additions[${index}]`;
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) throw new Error(`${prefix} must be an object`);
    const key = String(entry.key == null ? "" : entry.key).trim();
    const value = String(entry.value == null ? "" : entry.value).trim();
    if (!key || !value) throw new Error(`${prefix} key and value are required`);
    if (seen.has(key)) throw new Error(`Duplicate name-map ${label} addition key: ${key}`);
    seen.add(key);
    result.push({ key, value });
  });
  return result;
}

function normalizeNameMapPatches(value, label) {
  if (value == null) return [];
  if (!Array.isArray(value)) throw new Error(`nameMap${label}Patches must be an array`);
  const seen = new Set();
  return value.map((patch, index) => {
    const prefix = `nameMap${label}Patches[${index}]`;
    if (!patch || typeof patch !== "object" || Array.isArray(patch)) {
      throw new Error(`${prefix} must be an object`);
    }
    const key = String(patch.key == null ? "" : patch.key).trim();
    const expectedCurrent = String(patch.expectedCurrent == null ? "" : patch.expectedCurrent).trim();
    const remove = patch.remove === true;
    const hasSet = Object.prototype.hasOwnProperty.call(patch, "set");
    const set = hasSet ? String(patch.set == null ? "" : patch.set).trim() : "";
    if (!key) throw new Error(`${prefix}.key is required`);
    if (!expectedCurrent) throw new Error(`${prefix}.expectedCurrent is required`);
    if (remove === hasSet) throw new Error(`${prefix} must specify exactly one of set or remove`);
    if (hasSet && !set) throw new Error(`${prefix}.set must not be empty`);
    if (seen.has(key)) throw new Error(`Duplicate name-map ${label} patch key: ${key}`);
    seen.add(key);
    return remove ? { key, expectedCurrent, remove: true } : { key, expectedCurrent, set };
  });
}

function normalizeDeviceMasterEntryPatches(value) {
  if (value == null) return [];
  if (!Array.isArray(value)) throw new Error("deviceMasterEntryPatches must be an array");
  const seen = new Set();
  return value.map((patch, index) => {
    if (!patch || typeof patch !== "object" || Array.isArray(patch)) {
      throw new Error(`deviceMasterEntryPatches[${index}] must be an object`);
    }
    const id = requiredPatchIdentity(patch.id, "id", index);
    const modelCode = requiredPatchIdentity(patch.modelCode, "modelCode", index);
    const carrierCode = requiredPatchIdentity(patch.carrierCode, "carrierCode", index);
    const identityKey = [id, modelCode, carrierCode].map((item) => item.toLowerCase()).join("|");
    if (seen.has(identityKey)) throw new Error(`Duplicate device master patch guard: ${id}/${modelCode}/${carrierCode}`);
    seen.add(identityKey);
    const expectedCurrent = normalizePatchFields(
      patch.expectedCurrent,
      allowedPatchExpectedKeys,
      `deviceMasterEntryPatches[${index}].expectedCurrent`,
    );
    const set = normalizePatchFields(
      patch.set,
      allowedPatchSetKeys,
      `deviceMasterEntryPatches[${index}].set`,
    );
    if (!Object.keys(expectedCurrent).length) {
      throw new Error(`deviceMasterEntryPatches[${index}].expectedCurrent must not be empty`);
    }
    if (!Object.keys(set).length) {
      throw new Error(`deviceMasterEntryPatches[${index}].set must not be empty`);
    }
    for (const key of Object.keys(set)) {
      if (!Object.prototype.hasOwnProperty.call(expectedCurrent, key)) {
        throw new Error(`deviceMasterEntryPatches[${index}].expectedCurrent.${key} is required for a guarded update`);
      }
    }
    return { id, modelCode, carrierCode, expectedCurrent, set };
  });
}

function requiredPatchIdentity(value, field, index) {
  const result = String(value == null ? "" : value).trim();
  if (!result) throw new Error(`deviceMasterEntryPatches[${index}].${field} is required`);
  return result;
}

function normalizePatchFields(value, allowedKeys, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`${label} must be an object`);
  }
  const result = {};
  for (const [key, fieldValue] of Object.entries(value)) {
    if (!allowedKeys.has(key)) throw new Error(`${label}.${key} is not allowed`);
    if (fieldValue == null || typeof fieldValue === "object") {
      throw new Error(`${label}.${key} must be a scalar value`);
    }
    if (key === "disabled") {
      if (typeof fieldValue !== "boolean") throw new Error(`${label}.${key} must be a boolean`);
      result[key] = fieldValue;
    } else {
      result[key] = String(fieldValue);
    }
  }
  return result;
}

function patchFieldMismatches(entry, expectedCurrent) {
  return Object.entries(expectedCurrent)
    .filter(([key, value]) => !samePatchValue(entry && entry[key], value))
    .map(([key]) => key);
}

function samePatchValue(left, right) {
  if (typeof right === "boolean") return (left === true) === right;
  return String(left == null ? "" : left) === String(right == null ? "" : right);
}

function cloneObject(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? { ...value } : value;
}

function applyFleetDbActions(filePath, actions) {
  const requestedNumbers = [...new Set((actions.activateNumbers || [])
    .map(Number)
    .filter((value) => Number.isInteger(value) && value >= 1000 && value < 9000))];
  if (!requestedNumbers.length) return { activated: 0, requested: 0 };

  const db = readJson(filePath);
  db.physicalDevices = recordMap(db.physicalDevices, ["serial", "managementId"]);
  db.cycles = recordMap(db.cycles, ["cycleId"]);
  db.maintenance = objectOrEmpty(db.maintenance);
  db.maintenance.appliedActions = objectOrEmpty(db.maintenance.appliedActions);
  const actionId = String(actions.activationId || "").trim();
  const allRows = Object.entries(db.physicalDevices)
    .map(([key, device]) => ({
      key,
      device,
      number: currentDeviceNumber(device),
      cycle: currentCycleForDevice(db, device, key),
    }))
    .filter((row) => row.device && !row.device.excluded && !row.device.retiredAt);
  const expectedDeviceCount = Number(actions.expectedDeviceCount || 0);
  if (expectedDeviceCount && allRows.length !== expectedDeviceCount) {
    throw new Error(`Fleet device count does not match. expected=${expectedDeviceCount} found=${allRows.length}`);
  }
  const activeBefore = allRows.filter((row) => hasGroupTag(row.cycle, "GROUP_ACTIVE"));
  const alreadyAssigned = activeBefore
    .map((row) => currentDeviceNumber(row.device))
    .filter((number) => Number.isInteger(number) && number >= 1 && number <= requestedNumbers.length)
    .sort((left, right) => left - right);
  const expectedAssigned = Array.from({ length: requestedNumbers.length }, (_, index) => index + 1);
  if (actionId && db.maintenance.appliedActions[actionId] && JSON.stringify(alreadyAssigned) === JSON.stringify(expectedAssigned)) {
    return {
      activated: 0,
      requested: requestedNumbers.length,
      alreadyApplied: true,
      activeAfter: activeBefore.length,
      actionId,
    };
  }
  if (actionId && db.maintenance.appliedActions[actionId]) {
    delete db.maintenance.appliedActions[actionId];
  }
  const expectedActiveBefore = Number(actions.expectedActiveBefore);
  if (Number.isInteger(expectedActiveBefore) && expectedActiveBefore >= 0 && activeBefore.length !== expectedActiveBefore) {
    throw new Error(`Active device count does not match. expected=${expectedActiveBefore} found=${activeBefore.length}`);
  }

  const wanted = new Set(requestedNumbers);
  let targets = allRows
    .filter((row) => wanted.has(row.number))
    .sort((left, right) => left.number - right.number);
  let selectionMode = "display-numbers";
  if (targets.length !== requestedNumbers.length) {
    const fallbackCount = Number(actions.fallbackFirstInactive || 0);
    if (fallbackCount !== requestedNumbers.length) {
      const found = targets.map((row) => row.number);
      throw new Error(`Activation targets do not match. expected=${requestedNumbers.join(",")} found=${found.join(",")}`);
    }
    targets = allRows
      .filter((row) => !hasGroupTag(row.cycle, "GROUP_ACTIVE"))
      .sort(compareDeviceRows)
      .slice(0, fallbackCount);
    if (targets.length !== fallbackCount) {
      throw new Error(`Inactive activation fallback is incomplete. expected=${fallbackCount} found=${targets.length}`);
    }
    selectionMode = "first-inactive";
  }

  const at = new Date().toISOString();
  const sourceNumbers = targets.map((row) => row.number);
  targets.forEach((row, index) => {
    const device = row.device;
    device.serial = String(device.serial || row.key || "").trim();
    if (!device.serial) throw new Error(`Device serial is missing: ${row.number}`);
    device.cycleIds = Array.isArray(device.cycleIds) ? device.cycleIds : [];
    const cycle = ensureActiveCycle(db, device, at);
    const tags = new Set((Array.isArray(cycle.tags) ? cycle.tags : [])
      .filter((tag) => !["GROUP_ACTIVE", "GROUP_INACTIVE", "GROUP_REST", "WAITING"].includes(String(tag))));
    tags.add("GROUP_ACTIVE");
    cycle.tags = [...tags];
    cycle.status = "active";
    cycle.operationStartedAt = cycle.operationStartedAt || at;
    cycle.operationEndedAt = "";
    cycle.updatedAt = at;
    device.xiaoweiSort = index + 1;
    device.laixiNumberOverride = index + 1;
    device.updatedAt = at;
    row.cycle = cycle;
  });

  const targetKeys = new Set(targets.map((row) => row.key));
  const remainingInactive = allRows
    .filter((row) => !targetKeys.has(row.key) && !hasGroupTag(currentCycleForDevice(db, row.device, row.key), "GROUP_ACTIVE"))
    .sort(compareDeviceRows);
  remainingInactive.forEach((row, index) => {
    row.device.xiaoweiSort = 1000 + index;
    row.device.laixiNumberOverride = 1000 + index;
    row.device.updatedAt = at;
  });

  const activeAfter = allRows.filter((row) => hasGroupTag(currentCycleForDevice(db, row.device, row.key), "GROUP_ACTIVE"));
  const inactiveAfter = allRows.filter((row) => !hasGroupTag(currentCycleForDevice(db, row.device, row.key), "GROUP_ACTIVE"));
  const assignedAfter = activeAfter
    .map((row) => currentDeviceNumber(row.device))
    .filter((number) => number >= 1 && number <= requestedNumbers.length)
    .sort((left, right) => left - right);
  if (activeAfter.length !== requestedNumbers.length || JSON.stringify(assignedAfter) !== JSON.stringify(expectedAssigned)) {
    throw new Error(`Activation verification failed. active=${activeAfter.length} assigned=${assignedAfter.join(",")}`);
  }
  if (actionId) {
    db.maintenance.appliedActions[actionId] = {
      type: "activateNumbers",
      appliedAt: at,
      selectionMode,
      sourceNumbers,
      assignedNumbers: targets.map((row, index) => index + 1),
      activeAfter: activeAfter.length,
      inactiveAfter: inactiveAfter.length,
    };
  }
  db.updatedAt = at;
  writeJsonAtomic(filePath, db);
  return {
    activated: targets.length,
    requested: requestedNumbers.length,
    sourceNumbers,
    selectionMode,
    activeBefore: activeBefore.length,
    activeAfter: activeAfter.length,
    inactiveAfter: inactiveAfter.length,
    actionId,
  };
}

function ensureActiveCycle(db, device, at) {
  const wantedSerial = identity(device.serial);
  let cycle = device.cycleIds.map((id) => db.cycles[id]).find((item) => item && item.status === "active");
  if (!cycle) {
    cycle = Object.values(db.cycles).find((item) => item && item.status === "active" && identity(item.physicalSerial) === wantedSerial);
  }
  if (cycle) {
    if (!device.cycleIds.includes(cycle.cycleId)) device.cycleIds.push(cycle.cycleId);
    return cycle;
  }

  let sequence = device.cycleIds.reduce((max, id) => {
    const item = db.cycles[id];
    const suffix = /-(\d+)$/.exec(String(id || ""));
    return Math.max(max, Number(item && item.sequence || 0), suffix ? Number(suffix[1]) : 0);
  }, 0) + 1;
  let cycleId = `${device.serial}-${String(sequence).padStart(3, "0")}`;
  while (db.cycles[cycleId]) {
    sequence += 1;
    cycleId = `${device.serial}-${String(sequence).padStart(3, "0")}`;
  }
  cycle = {
    cycleId,
    physicalSerial: device.serial,
    managementId: String(device.managementId || ""),
    sequence,
    status: "active",
    startedAt: at,
    endedAt: "",
    operationStartedAt: at,
    operationEndedAt: "",
    startReason: "kazuma_bulk_activation_repair",
    tags: ["GROUP_ACTIVE"],
    economics: {},
    snapshots: [],
    outcome: {},
    updatedAt: at,
  };
  db.cycles[cycleId] = cycle;
  device.cycleIds.push(cycleId);
  return cycle;
}

function currentDeviceNumber(device) {
  for (const value of [device && device.laixiNumberOverride, device && device.xiaoweiSort, device && device.number]) {
    const number = Number(value);
    if (Number.isInteger(number) && number > 0) return number;
  }
  return 0;
}

function currentCycleForDevice(db, device, key = "") {
  const cycleIds = Array.isArray(device && device.cycleIds) ? device.cycleIds : [];
  const direct = cycleIds.map((cycleId) => db.cycles[cycleId]).find((cycle) => cycle && cycle.status === "active");
  if (direct) return direct;
  const serial = identity(device && device.serial || key);
  const managementId = identity(device && device.managementId);
  return Object.values(db.cycles).find((cycle) => cycle && cycle.status === "active" && (
    (serial && identity(cycle.physicalSerial) === serial) ||
    (managementId && identity(cycle.managementId) === managementId)
  )) || null;
}

function hasGroupTag(cycle, tag) {
  return Boolean(cycle && Array.isArray(cycle.tags) && cycle.tags.includes(tag));
}

function compareDeviceRows(left, right) {
  const leftNumber = Number.isInteger(left.number) && left.number > 0 ? left.number : Number.MAX_SAFE_INTEGER;
  const rightNumber = Number.isInteger(right.number) && right.number > 0 ? right.number : Number.MAX_SAFE_INTEGER;
  return leftNumber - rightNumber
    || String(left.device && left.device.managementId || "").localeCompare(String(right.device && right.device.managementId || ""), "en", { numeric: true })
    || String(left.key).localeCompare(String(right.key), "en", { numeric: true });
}

function recordMap(value, identityFields) {
  if (value && typeof value === "object" && !Array.isArray(value)) return value;
  const result = {};
  for (const item of Array.isArray(value) ? value : []) {
    if (!item || typeof item !== "object") continue;
    const key = identityFields.map((field) => String(item[field] || "").trim()).find(Boolean);
    if (key) result[key] = item;
  }
  return result;
}

function identity(value) {
  return String(value || "").trim().toLowerCase();
}

function parseArgs(values) {
  const result = {};
  for (let i = 0; i < values.length; i += 1) {
    const key = String(values[i] || "");
    if (!key.startsWith("--")) continue;
    result[key.slice(2)] = values[i + 1];
    i += 1;
  }
  return result;
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(path.resolve(filePath), "utf8").replace(/^\uFEFF/, ""));
}

function writeJsonAtomic(filePath, value) {
  const fullPath = path.resolve(filePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  const temporaryPath = `${fullPath}.update-${process.pid}.tmp`;
  fs.writeFileSync(temporaryPath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  fs.renameSync(temporaryPath, fullPath);
}

function equalIgnoreCase(left, right) {
  return String(left || "").toLowerCase() === String(right || "").toLowerCase();
}

function normalizeRelativePath(value) {
  const normalized = String(value || "").replace(/\\/g, "/").replace(/^\/+/, "");
  if (!normalized || normalized.split("/").includes("..")) return "";
  return normalized;
}

function objectOrEmpty(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
