﻿Android Fleet 差分更新

1. Android Fleetを閉じます。
2. ZIPをすべて展開します。
3. 1-RUN-UPDATE.cmd をダブルクリックします。
   本体選択が出た場合は、既存のAndroid Fleet配布フォルダを選択します。
4. 更新完了後、Android Fleetが自動で開きます。

DB、チェック、履歴、ライセンスは保持されます。
対象: Notebook-Test-NoKey
更新: SIM・電話番号一覧・ナビボタン配置
