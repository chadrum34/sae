﻿param(
    [string]$AppRoot = "",
    [string]$NodePath = "",
    [switch]$NoLaunch,
    [switch]$NoStop,
    [switch]$NonInteractive
)

$ErrorActionPreference = "Stop"
$PatchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ManifestPath = Join-Path $PatchRoot "update-manifest.json"
$MergePath = Join-Path $PatchRoot "data-merge.json"
$PayloadRoot = Join-Path $PatchRoot "payload"
$PackagePayloadRoot = Join-Path $PatchRoot "package-payload"
$RunLogPath = Join-Path $PatchRoot "更新結果.log"
try { Start-Transcript -LiteralPath $RunLogPath -Force | Out-Null } catch {}

function Get-Sha256 {
    param([string]$Path)
    (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}

function Convert-ToAppRoot {
    param([string]$Candidate)
    if ([string]::IsNullOrWhiteSpace($Candidate)) { return "" }
    $candidatePath = [System.IO.Path]::GetFullPath($Candidate)
    foreach ($path in @(
        $candidatePath,
        (Join-Path $candidatePath "resources\app"),
        (Join-Path $candidatePath "Android Fleet-win32-x64\resources\app")
    )) {
        if ((Test-Path -LiteralPath (Join-Path $path "server.js")) -and
            (Test-Path -LiteralPath (Join-Path $path "config\customer-license.json"))) {
            return [System.IO.Path]::GetFullPath($path)
        }
    }
    return ""
}

function Resolve-AppRoot {
    param(
        [string]$Requested,
        [string]$ExpectedCustomerId = "",
        [string]$ExpectedPackageId = ""
    )
    $resolved = Convert-ToAppRoot $Requested
    if ($resolved) { return $resolved }

    $parent = Split-Path -Parent $PatchRoot
    foreach ($candidate in @($PatchRoot, $parent, (Split-Path -Parent $parent))) {
        $resolved = Convert-ToAppRoot $candidate
        if ($resolved -and (Test-AppRootIdentity -Root $resolved -ExpectedCustomerId $ExpectedCustomerId -ExpectedPackageId $ExpectedPackageId)) {
            return $resolved
        }
    }

    # A common delivery layout is Downloads\AndroidFleet-Test-Latest\Android Fleet-win32-x64
    # with this patch extracted directly under Downloads. Search only one nearby
    # folder level and require the customer/package identity to match.
    foreach ($searchRoot in @($parent, (Split-Path -Parent $parent)) | Select-Object -Unique) {
        if (-not (Test-Path -LiteralPath $searchRoot)) { continue }
        foreach ($folder in @(Get-ChildItem -LiteralPath $searchRoot -Directory -ErrorAction SilentlyContinue)) {
            $resolved = Convert-ToAppRoot $folder.FullName
            if ($resolved -and (Test-AppRootIdentity -Root $resolved -ExpectedCustomerId $ExpectedCustomerId -ExpectedPackageId $ExpectedPackageId)) {
                return $resolved
            }
        }
    }

    if ($NonInteractive) { throw "Android Fleet本体が見つかりません。-AppRoot で resources\\app を指定してください。" }

    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = "Android Fleet-win32-x64 フォルダを選択してください"
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        throw "更新をキャンセルしました。"
    }
    $resolved = Convert-ToAppRoot $dialog.SelectedPath
    if (-not $resolved) { throw "選択した場所にAndroid Fleet本体がありません。" }
    return $resolved
}

function Test-AppRootIdentity {
    param(
        [string]$Root,
        [string]$ExpectedCustomerId = "",
        [string]$ExpectedPackageId = ""
    )
    try {
        $candidate = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $Root "config\customer-license.json") | ConvertFrom-Json
        if ($ExpectedCustomerId -and ([string]$candidate.customerId -ne $ExpectedCustomerId)) { return $false }
        if ($ExpectedPackageId -and ([string]$candidate.packageId -ne $ExpectedPackageId)) { return $false }
        return $true
    } catch {
        return $false
    }
}

function Stop-AppProcesses {
    param([string]$Root)
    $installRoot = [System.IO.Path]::GetFullPath((Join-Path $Root "..\.."))
    $escaped = [regex]::Escape($installRoot)
    $targets = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        ([string]$_.ExecutablePath -match "^$escaped") -or
        ([string]$_.CommandLine -match $escaped)
    })
    foreach ($process in $targets) {
        try { Stop-Process -Id $process.ProcessId -Force -ErrorAction Stop } catch {
            throw "Android Fleetを終了できませんでした。画面を閉じて、もう一度更新してください。"
        }
    }

    # Also stop a stale Android Fleet server that owns 8787 but was launched by
    # node.exe with a relative "server.js" command line. Such a process is not
    # necessarily discoverable from the installation path above.
    $knownIds = @($targets | ForEach-Object { [int]$_.ProcessId })
    foreach ($listener in @(Get-NetTCPConnection -LocalPort 8787 -State Listen -ErrorAction SilentlyContinue)) {
        $ownerId = [int]$listener.OwningProcess
        if ($ownerId -le 0 -or $ownerId -eq $PID -or $knownIds -contains $ownerId) { continue }
        $owner = Get-CimInstance Win32_Process -Filter "ProcessId=$ownerId" -ErrorAction SilentlyContinue
        $looksLikeFleet = ([string]$owner.Name -match '^Android Fleet') -or ([string]$owner.CommandLine -match '(?i)server[.]js|Android Fleet')
        if (-not $looksLikeFleet) { continue }
        try { Stop-Process -Id $ownerId -Force -ErrorAction Stop } catch {
            throw "古いAndroid Fleetサーバーを終了できませんでした。タスクマネージャーでAndroid Fleetを閉じてください。"
        }
    }
    if ($targets.Count) { Start-Sleep -Milliseconds 1200 }
}

function Backup-File {
    param([string]$Root, [string]$RelativePath, [string]$BackupRoot)
    $source = Join-Path $Root $RelativePath
    if (-not (Test-Path -LiteralPath $source)) { return $false }
    $destination = Join-Path $BackupRoot $RelativePath
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination) | Out-Null
    Copy-Item -LiteralPath $source -Destination $destination -Force
    return $true
}

function Restore-Backup {
    param([string]$Root, [string]$BackupRoot, [object[]]$Touched)
    foreach ($item in @($Touched)) {
        $target = Join-Path $Root $item.path
        $backup = Join-Path $BackupRoot $item.path
        if ($item.existed -and (Test-Path -LiteralPath $backup)) {
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
            Copy-Item -LiteralPath $backup -Destination $target -Force
        } elseif (-not $item.existed -and (Test-Path -LiteralPath $target)) {
            Remove-Item -LiteralPath $target -Force
        }
    }
}

function Read-Json {
    param([string]$Path)
    Get-Content -Raw -Encoding UTF8 -LiteralPath $Path | ConvertFrom-Json
}

function Write-Json {
    param([string]$Path, [object]$Value, [int]$Depth = 20)
    $Value | ConvertTo-Json -Depth $Depth | Set-Content -Encoding UTF8 -LiteralPath $Path
}

function Find-Property {
    param([object]$Object, [string]$Name)
    if ($null -eq $Object) { return $null }
    $Object.PSObject.Properties | Where-Object { $_.Name -ieq $Name } | Select-Object -First 1
}

if (-not (Test-Path -LiteralPath $ManifestPath)) { throw "update-manifest.json がありません。" }
if (-not (Test-Path -LiteralPath $PayloadRoot)) { throw "payload フォルダがありません。" }

$manifest = Read-Json $ManifestPath
$packageFiles = @()
if ($manifest.PSObject.Properties.Name -contains "packageFiles") {
    $packageFiles = @($manifest.packageFiles | Where-Object { $null -ne $_ })
}
$resolvedAppRoot = Resolve-AppRoot -Requested $AppRoot -ExpectedCustomerId ([string]$manifest.customerId) -ExpectedPackageId ([string]$manifest.packageId)
$resolvedPackageRoot = [System.IO.Path]::GetFullPath((Join-Path $resolvedAppRoot "..\.."))
$licensePath = Join-Path $resolvedAppRoot "config\customer-license.json"
$license = Read-Json $licensePath
if ($manifest.customerId -and ([string]$license.customerId -ne [string]$manifest.customerId)) {
    throw "この更新は別のお客様用です。対象: $($manifest.customerName) / 検出: $($license.customerName)"
}
if ($manifest.packageId -and ([string]$license.packageId -ne [string]$manifest.packageId)) {
    throw "Android Fleetの種類が一致しないため更新を中止しました。"
}

Write-Host "Android Fleet 差分更新" -ForegroundColor Cyan
Write-Host "対象: $($license.customerName)"
Write-Host "更新: $($manifest.displayName)"
Write-Host "本体: $resolvedAppRoot"
Write-Host "DB: $(Join-Path $resolvedAppRoot 'data\fleet-db\fleet-db.json')"
Write-Host "ログ: $RunLogPath"
Write-Host "DB・チェック・履歴は保持します。" -ForegroundColor Green

if (-not $NoStop) { Stop-AppProcesses $resolvedAppRoot }

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupRoot = Join-Path ([System.IO.Path]::GetFullPath((Join-Path $resolvedAppRoot "..\.."))) "update-backups\$($manifest.updateId)-$stamp"
New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
$touched = New-Object System.Collections.Generic.List[object]
$packageTouched = New-Object System.Collections.Generic.List[object]

try {
    foreach ($file in @($manifest.files)) {
        $relative = ([string]$file.path).Replace("/", "\")
        if ($relative.Contains("..")) { throw "不正な更新パスです: $relative" }
        $source = Join-Path $PayloadRoot $relative
        $target = Join-Path $resolvedAppRoot $relative
        if (-not (Test-Path -LiteralPath $source)) { throw "更新ファイルがありません: $relative" }
        if ((Get-Sha256 $source) -ne [string]$file.newSha256) { throw "更新ファイルが破損しています: $relative" }

        $targetExists = Test-Path -LiteralPath $target
        $currentHash = if ($targetExists) { Get-Sha256 $target } else { "" }
        if ($currentHash -eq [string]$file.newSha256) {
            Write-Host "適用済み: $relative"
            continue
        }
        $acceptedOldHashes = @($file.acceptedOldSha256 | ForEach-Object { ([string]$_).ToLowerInvariant() })
        if (-not $acceptedOldHashes.Count -and $file.oldSha256) { $acceptedOldHashes = @(([string]$file.oldSha256).ToLowerInvariant()) }
        if ($acceptedOldHashes.Count -and $acceptedOldHashes -notcontains $currentHash) {
            throw "本体の版が想定と異なります: $relative`n全体版を使うか、現在の版に合う差分を作り直してください。"
        }

        $existed = Backup-File $resolvedAppRoot $relative $backupRoot
        $touched.Add([pscustomobject]@{ path = $relative; existed = $existed })
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
        Copy-Item -LiteralPath $source -Destination $target -Force
        if ((Get-Sha256 $target) -ne [string]$file.newSha256) { throw "更新後の確認に失敗しました: $relative" }
        Write-Host "更新: $relative" -ForegroundColor Green
    }

    foreach ($file in $packageFiles) {
        $relative = ([string]$file.path).Replace("/", "\")
        if ([string]::IsNullOrWhiteSpace($relative) -or
            [System.IO.Path]::IsPathRooted($relative) -or
            $relative.Contains("..") -or
            $relative -ine "CHECK-FOR-UPDATES.cmd") {
            throw "不正な配布フォルダ更新パスです: $relative"
        }
        if (-not (Test-Path -LiteralPath $PackagePayloadRoot)) { throw "package-payload フォルダがありません。" }
        $source = Join-Path $PackagePayloadRoot $relative
        $target = Join-Path $resolvedPackageRoot $relative
        if (-not (Test-Path -LiteralPath $source)) { throw "配布フォルダ用の更新ファイルがありません: $relative" }
        if ((Get-Sha256 $source) -ne [string]$file.newSha256) { throw "配布フォルダ用の更新ファイルが破損しています: $relative" }

        $targetExists = Test-Path -LiteralPath $target
        $currentHash = if ($targetExists) { Get-Sha256 $target } else { "" }
        if ($currentHash -eq [string]$file.newSha256) {
            Write-Host "適用済み: $relative"
            continue
        }
        $acceptedOldHashes = @($file.acceptedOldSha256 | ForEach-Object { ([string]$_).ToLowerInvariant() })
        if (-not $acceptedOldHashes.Count -and $file.oldSha256) { $acceptedOldHashes = @(([string]$file.oldSha256).ToLowerInvariant()) }
        if ($acceptedOldHashes.Count -and $acceptedOldHashes -notcontains $currentHash) {
            throw "配布フォルダの版が想定と異なります: $relative"
        }

        $packageBackupRoot = Join-Path $backupRoot "package-root"
        $existed = Backup-File $resolvedPackageRoot $relative $packageBackupRoot
        $packageTouched.Add([pscustomobject]@{ path = $relative; existed = $existed })
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
        Copy-Item -LiteralPath $source -Destination $target -Force
        if ((Get-Sha256 $target) -ne [string]$file.newSha256) { throw "配布フォルダ更新後の確認に失敗しました: $relative" }
        Write-Host "更新: $relative" -ForegroundColor Green
    }

    if (Test-Path -LiteralPath $MergePath) {
        foreach ($relative in @(
            "data\fleet-db\fleet-db.json",
            "data\fleet-db\device-master.json",
            "config\device-name-map.json",
            "config\applied-updates.json"
        )) {
            $existed = Backup-File $resolvedAppRoot $relative $backupRoot
            $touched.Add([pscustomobject]@{ path = $relative; existed = $existed })
        }

        $mergeScript = Join-Path $PatchRoot "apply-data-merge.js"
        if (-not (Test-Path -LiteralPath $mergeScript)) { throw "apply-data-merge.js がありません。" }
        $electronNode = [System.IO.Path]::GetFullPath((Join-Path $resolvedAppRoot "..\..\Android Fleet.exe"))
        $runtime = if ($NodePath) { $NodePath } else { $electronNode }
        if (-not (Test-Path -LiteralPath $runtime)) { throw "マスタ更新用の実行環境が見つかりません。" }

        $previousElectronRunAsNode = $env:ELECTRON_RUN_AS_NODE
        try {
            if (-not $NodePath) { $env:ELECTRON_RUN_AS_NODE = "1" }
            $mergeOutput = @(& $runtime $mergeScript --app-root $resolvedAppRoot --merge $MergePath --manifest $ManifestPath 2>&1)
            $mergeExitCode = $LASTEXITCODE
            $mergeOutput | ForEach-Object { Write-Host ([string]$_) }
            if ($mergeExitCode -ne 0) { throw "DB・端末マスタの差分合流に失敗しました。" }
        } finally {
            $env:ELECTRON_RUN_AS_NODE = $previousElectronRunAsNode
        }
    }

    Write-Host "更新完了。DB・チェック・履歴はそのままです。" -ForegroundColor Green
    Write-Host "バックアップ: $backupRoot"
    Write-Host "更新ログ: $RunLogPath"
} catch {
    Restore-Backup $resolvedAppRoot $backupRoot $touched
    Restore-Backup $resolvedPackageRoot (Join-Path $backupRoot "package-root") $packageTouched
    Write-Host "更新に失敗したため元に戻しました。" -ForegroundColor Red
    throw
}

if (-not $NoLaunch) {
    $exePath = [System.IO.Path]::GetFullPath((Join-Path $resolvedAppRoot "..\..\Android Fleet.exe"))
    if (Test-Path -LiteralPath $exePath) {
        Start-Process -FilePath $exePath -WorkingDirectory (Split-Path -Parent $exePath)
    } else {
        Write-Warning "更新は完了しましたが、Android Fleet.exeが見つからないため自動起動しませんでした。"
    }
}

try { Stop-Transcript | Out-Null } catch {}
exit 0



