﻿Android Fleet 差分更新

1. Android Fleetを閉じます。
2. このフォルダを既存の Android Fleet-win32-x64 と同じ場所へ置きます。
3. 1-差分更新.bat をダブルクリックします。
4. 更新完了後、Android Fleetが自動で開きます。

DB、チェック、履歴、ライセンスは保持されます。
対象: Kazuma
更新: XiaoWei名連番編集・更新確認修正
