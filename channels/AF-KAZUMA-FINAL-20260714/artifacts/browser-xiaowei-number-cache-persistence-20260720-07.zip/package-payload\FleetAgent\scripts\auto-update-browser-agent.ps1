﻿param(
    [Parameter(Mandatory = $true)][string]$AgentRoot,
    [switch]$Force,
    [switch]$FailOnError
)

$ErrorActionPreference = "Stop"
$AgentRoot = [System.IO.Path]::GetFullPath($AgentRoot)
$AppRoot = Join-Path $AgentRoot "app"
$NodePath = Join-Path $AgentRoot "runtime\node.exe"
$ConfigRoot = Join-Path $AgentRoot "config"
$UpdateRoot = Join-Path $AgentRoot "update"
$ClientConfigPath = Join-Path $ConfigRoot "update-client.json"
$StatePath = Join-Path $ConfigRoot "update-state.json"
$PublicKeyPath = Join-Path $ConfigRoot "update-public-key.pem"
$VerifierPath = Join-Path $AgentRoot "scripts\verify-update-index.js"
$LogPath = Join-Path $UpdateRoot "auto-update.log"

function Read-Json {
    param([string]$Path)
    Get-Content -Raw -Encoding UTF8 -LiteralPath $Path | ConvertFrom-Json
}

function Write-Json {
    param([string]$Path, [object]$Value)
    $Value | ConvertTo-Json -Depth 12 | Set-Content -Encoding UTF8 -LiteralPath $Path
}

function Write-UpdateLog {
    param([string]$Message)
    New-Item -ItemType Directory -Force -Path $UpdateRoot | Out-Null
    "[$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))] $Message" | Add-Content -Encoding UTF8 -LiteralPath $LogPath
}

function Get-Sha256 {
    param([string]$Path)
    $stream = $null
    $sha = $null
    try {
        $stream = [System.IO.File]::Open(
            $Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            [System.IO.FileShare]::ReadWrite
        )
        $sha = [System.Security.Cryptography.SHA256]::Create()
        ([System.BitConverter]::ToString($sha.ComputeHash($stream))).Replace("-", "").ToLowerInvariant()
    } finally {
        if ($stream) { $stream.Dispose() }
        if ($sha) { $sha.Dispose() }
    }
}

function Save-State {
    param([hashtable]$Values)
    $state = @{}
    if (Test-Path -LiteralPath $StatePath) {
        $current = Read-Json $StatePath
        foreach ($property in $current.PSObject.Properties) { $state[$property.Name] = $property.Value }
    }
    foreach ($key in $Values.Keys) { $state[$key] = $Values[$key] }
    Write-Json $StatePath $state
}

if (-not (Test-Path -LiteralPath $ClientConfigPath)) { exit 0 }
$config = Read-Json $ClientConfigPath
if (-not [bool]$config.enabled -or [string]::IsNullOrWhiteSpace([string]$config.manifestUrl)) { exit 0 }
if (-not (Test-Path -LiteralPath $NodePath) -or -not (Test-Path -LiteralPath $VerifierPath) -or -not (Test-Path -LiteralPath $PublicKeyPath)) {
    Write-UpdateLog "自動更新の実行ファイルが不足しているため、現在版を起動します。"
    exit 0
}

$manifestUri = $null
if (-not [uri]::TryCreate([string]$config.manifestUrl, [System.UriKind]::Absolute, [ref]$manifestUri) -or
    ($manifestUri.Scheme -ne "https" -and -not ($manifestUri.Scheme -eq "http" -and $manifestUri.IsLoopback))) {
    Write-UpdateLog "自動更新URLが安全なHTTPSではないため、現在版を起動します。"
    exit 0
}

$intervalHours = 6
$configuredInterval = 0
if ($null -ne $config.checkIntervalHours -and
    [int]::TryParse([string]$config.checkIntervalHours, [ref]$configuredInterval)) {
    $intervalHours = [Math]::Max(1, $configuredInterval)
}
if (-not $Force -and (Test-Path -LiteralPath $StatePath)) {
    $previousState = Read-Json $StatePath
    $lastChecked = [datetime]::MinValue
    if ([datetime]::TryParse([string]$previousState.lastCheckedAt, [ref]$lastChecked) -and
        $lastChecked.ToUniversalTime().AddHours($intervalHours) -gt (Get-Date).ToUniversalTime()) {
        exit 0
    }
}

$workRoot = Join-Path $env:TEMP ("android-fleet-auto-update-" + [guid]::NewGuid().ToString("N"))
try {
    New-Item -ItemType Directory -Force -Path $workRoot, $UpdateRoot | Out-Null
    $indexPath = Join-Path $workRoot "update-index.json"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $manifestUri.AbsoluteUri -OutFile $indexPath -UseBasicParsing -TimeoutSec 30

    $license = Read-Json (Join-Path $AppRoot "config\customer-license.json")
    $verifyOutput = @(& $NodePath $VerifierPath $indexPath $PublicKeyPath ([string]$license.customerId) ([string]$license.packageId) 2>&1)
    if ($LASTEXITCODE -ne 0) { throw "更新情報の署名確認に失敗しました: $($verifyOutput -join ' ')" }
    $verified = ($verifyOutput -join "`n") | ConvertFrom-Json
    Save-State @{ lastCheckedAt = (Get-Date).ToUniversalTime().ToString("o"); lastError = ""; latestUpdateId = [string]$verified.updateId }

    $appliedPath = Join-Path $AppRoot "config\applied-updates.json"
    $alreadyApplied = $false
    if (Test-Path -LiteralPath $appliedPath) {
        $alreadyApplied = @((Read-Json $appliedPath) | Where-Object { [string]$_.updateId -eq [string]$verified.updateId }).Count -gt 0
    }
    if ($alreadyApplied) {
        Write-UpdateLog "更新済み: $($verified.updateId)"
        exit 0
    }

    $zipPath = Join-Path $workRoot "update.zip"
    Invoke-WebRequest -Uri ([string]$verified.artifact.url) -OutFile $zipPath -UseBasicParsing -TimeoutSec 180
    if ((Get-Item -LiteralPath $zipPath).Length -ne [int64]$verified.artifact.bytes) { throw "更新ZIPのサイズが一致しません。" }
    if ((Get-Sha256 $zipPath) -ne [string]$verified.artifact.sha256) { throw "更新ZIPのSHA256が一致しません。" }

    $patchRoot = Join-Path $workRoot "patch"
    Expand-Archive -LiteralPath $zipPath -DestinationPath $patchRoot -Force
    $applyScript = Get-ChildItem -LiteralPath $patchRoot -Filter "apply-update.ps1" -File -Recurse | Select-Object -First 1
    if (-not $applyScript) { throw "更新ZIPにapply-update.ps1がありません。" }
    $resolvedPatchRoot = Split-Path -Parent $applyScript.FullName
    $patchManifest = Read-Json (Join-Path $resolvedPatchRoot "update-manifest.json")
    if ([string]$patchManifest.updateId -ne [string]$verified.updateId) { throw "更新IDが一致しません。" }

    Write-UpdateLog "自動更新を開始: $($verified.updateId)"
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $applyScript.FullName `
        -AppRoot $AppRoot -NodePath $NodePath -NoLaunch -NoStop -NonInteractive
    if ($LASTEXITCODE -ne 0) { throw "差分更新の適用に失敗しました。" }
    Save-State @{
        lastCheckedAt = (Get-Date).ToUniversalTime().ToString("o")
        lastAppliedAt = (Get-Date).ToUniversalTime().ToString("o")
        lastAppliedUpdateId = [string]$verified.updateId
        latestUpdateId = [string]$verified.updateId
        lastError = ""
    }
    Write-UpdateLog "自動更新完了: $($verified.updateId)"
} catch {
    $message = $_.Exception.Message
    Write-UpdateLog "自動更新NG。現在版で起動します: $message"
    try { Save-State @{ lastCheckedAt = (Get-Date).ToUniversalTime().ToString("o"); lastError = $message } } catch {}
    if ($FailOnError) { throw }
} finally {
    $resolvedTemp = [System.IO.Path]::GetFullPath($env:TEMP).TrimEnd("\") + "\"
    $resolvedWork = [System.IO.Path]::GetFullPath($workRoot)
    if ($resolvedWork.StartsWith($resolvedTemp, [System.StringComparison]::OrdinalIgnoreCase) -and
        [System.IO.Path]::GetFileName($resolvedWork).StartsWith("android-fleet-auto-update-") -and
        (Test-Path -LiteralPath $resolvedWork)) {
        Remove-Item -LiteralPath $resolvedWork -Recurse -Force -ErrorAction SilentlyContinue
    }
}

exit 0
