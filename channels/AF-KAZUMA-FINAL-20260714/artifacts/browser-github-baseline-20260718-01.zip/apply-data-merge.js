"use strict";

const fs = require("node:fs");
const path = require("node:path");

const args = parseArgs(process.argv.slice(2));
const appRootArg = args["app-root"] || args.appRoot;
if (!appRootArg || !args.merge || !args.manifest) {
  console.error("Usage: node apply-data-merge.js --app-root <path> --merge <path> --manifest <path>");
  process.exit(2);
}

const appRoot = path.resolve(appRootArg);
const merge = readJson(args.merge);
const manifest = readJson(args.manifest);
const masterPath = path.join(appRoot, "data", "fleet-db", "device-master.json");
const fleetDbPath = path.join(appRoot, "data", "fleet-db", "fleet-db.json");
const mapPath = path.join(appRoot, "config", "device-name-map.json");
const updatesPath = path.join(appRoot, "config", "applied-updates.json");

const master = readJson(masterPath);
master.entries = Array.isArray(master.entries) ? master.entries : [];
let addedMasterEntries = 0;
for (const entry of merge.deviceMasterEntries || []) {
  const id = String(entry && entry.id || "");
  const modelCode = String(entry && entry.modelCode || "");
  const existing = master.entries.find((item) => (
    (id && equalIgnoreCase(item && item.id, id)) ||
    (modelCode && equalIgnoreCase(item && item.modelCode, modelCode))
  ));
  if (!existing) {
    master.entries.push(entry);
    addedMasterEntries += 1;
  }
}
master.updatedAt = new Date().toISOString();
writeJsonAtomic(masterPath, master);

const nameMap = readJson(mapPath);
nameMap.exact = objectOrEmpty(nameMap.exact);
nameMap.short = objectOrEmpty(nameMap.short);
let addedExact = 0;
let addedShort = 0;
for (const [key, value] of Object.entries(merge.nameMapExact || {})) {
  if (!Object.prototype.hasOwnProperty.call(nameMap.exact, key)) {
    nameMap.exact[key] = value;
    addedExact += 1;
  }
}
for (const [key, value] of Object.entries(merge.nameMapShort || {})) {
  if (!Object.prototype.hasOwnProperty.call(nameMap.short, key)) {
    nameMap.short[key] = value;
    addedShort += 1;
  }
}
writeJsonAtomic(mapPath, nameMap);

const fleetAction = applyFleetDbActions(fleetDbPath, merge.fleetDbActions || {});

const updates = fs.existsSync(updatesPath) ? readJson(updatesPath) : [];
const list = Array.isArray(updates) ? updates : [];
if (!list.some((item) => String(item && item.updateId || "") === String(manifest.updateId || ""))) {
  list.push({
    updateId: String(manifest.updateId || ""),
    displayName: String(manifest.displayName || ""),
    appliedAt: new Date().toISOString(),
  });
}
writeJsonAtomic(updatesPath, list);

console.log(JSON.stringify({ ok: true, addedMasterEntries, addedExact, addedShort, fleetAction, updateId: manifest.updateId }));

function applyFleetDbActions(filePath, actions) {
  const requestedNumbers = [...new Set((actions.activateNumbers || [])
    .map(Number)
    .filter((value) => Number.isInteger(value) && value >= 1000 && value < 9000))];
  if (!requestedNumbers.length) return { activated: 0, requested: 0 };

  const db = readJson(filePath);
  db.physicalDevices = recordMap(db.physicalDevices, ["serial", "managementId"]);
  db.cycles = recordMap(db.cycles, ["cycleId"]);
  db.maintenance = objectOrEmpty(db.maintenance);
  db.maintenance.appliedActions = objectOrEmpty(db.maintenance.appliedActions);
  const actionId = String(actions.activationId || "").trim();
  const allRows = Object.entries(db.physicalDevices)
    .map(([key, device]) => ({
      key,
      device,
      number: currentDeviceNumber(device),
      cycle: currentCycleForDevice(db, device, key),
    }))
    .filter((row) => row.device && !row.device.excluded && !row.device.retiredAt);
  const expectedDeviceCount = Number(actions.expectedDeviceCount || 0);
  if (expectedDeviceCount && allRows.length !== expectedDeviceCount) {
    throw new Error(`Fleet device count does not match. expected=${expectedDeviceCount} found=${allRows.length}`);
  }
  const activeBefore = allRows.filter((row) => hasGroupTag(row.cycle, "GROUP_ACTIVE"));
  const alreadyAssigned = activeBefore
    .map((row) => currentDeviceNumber(row.device))
    .filter((number) => Number.isInteger(number) && number >= 1 && number <= requestedNumbers.length)
    .sort((left, right) => left - right);
  const expectedAssigned = Array.from({ length: requestedNumbers.length }, (_, index) => index + 1);
  if (actionId && db.maintenance.appliedActions[actionId] && JSON.stringify(alreadyAssigned) === JSON.stringify(expectedAssigned)) {
    return {
      activated: 0,
      requested: requestedNumbers.length,
      alreadyApplied: true,
      activeAfter: activeBefore.length,
      actionId,
    };
  }
  if (actionId && db.maintenance.appliedActions[actionId]) {
    delete db.maintenance.appliedActions[actionId];
  }
  const expectedActiveBefore = Number(actions.expectedActiveBefore);
  if (Number.isInteger(expectedActiveBefore) && expectedActiveBefore >= 0 && activeBefore.length !== expectedActiveBefore) {
    throw new Error(`Active device count does not match. expected=${expectedActiveBefore} found=${activeBefore.length}`);
  }

  const wanted = new Set(requestedNumbers);
  let targets = allRows
    .filter((row) => wanted.has(row.number))
    .sort((left, right) => left.number - right.number);
  let selectionMode = "display-numbers";
  if (targets.length !== requestedNumbers.length) {
    const fallbackCount = Number(actions.fallbackFirstInactive || 0);
    if (fallbackCount !== requestedNumbers.length) {
      const found = targets.map((row) => row.number);
      throw new Error(`Activation targets do not match. expected=${requestedNumbers.join(",")} found=${found.join(",")}`);
    }
    targets = allRows
      .filter((row) => !hasGroupTag(row.cycle, "GROUP_ACTIVE"))
      .sort(compareDeviceRows)
      .slice(0, fallbackCount);
    if (targets.length !== fallbackCount) {
      throw new Error(`Inactive activation fallback is incomplete. expected=${fallbackCount} found=${targets.length}`);
    }
    selectionMode = "first-inactive";
  }

  const at = new Date().toISOString();
  const sourceNumbers = targets.map((row) => row.number);
  targets.forEach((row, index) => {
    const device = row.device;
    device.serial = String(device.serial || row.key || "").trim();
    if (!device.serial) throw new Error(`Device serial is missing: ${row.number}`);
    device.cycleIds = Array.isArray(device.cycleIds) ? device.cycleIds : [];
    const cycle = ensureActiveCycle(db, device, at);
    const tags = new Set((Array.isArray(cycle.tags) ? cycle.tags : [])
      .filter((tag) => !["GROUP_ACTIVE", "GROUP_INACTIVE", "GROUP_REST", "WAITING"].includes(String(tag))));
    tags.add("GROUP_ACTIVE");
    cycle.tags = [...tags];
    cycle.status = "active";
    cycle.operationStartedAt = cycle.operationStartedAt || at;
    cycle.operationEndedAt = "";
    cycle.updatedAt = at;
    device.xiaoweiSort = index + 1;
    device.laixiNumberOverride = index + 1;
    device.updatedAt = at;
    row.cycle = cycle;
  });

  const targetKeys = new Set(targets.map((row) => row.key));
  const remainingInactive = allRows
    .filter((row) => !targetKeys.has(row.key) && !hasGroupTag(currentCycleForDevice(db, row.device, row.key), "GROUP_ACTIVE"))
    .sort(compareDeviceRows);
  remainingInactive.forEach((row, index) => {
    row.device.xiaoweiSort = 1000 + index;
    row.device.laixiNumberOverride = 1000 + index;
    row.device.updatedAt = at;
  });

  const activeAfter = allRows.filter((row) => hasGroupTag(currentCycleForDevice(db, row.device, row.key), "GROUP_ACTIVE"));
  const inactiveAfter = allRows.filter((row) => !hasGroupTag(currentCycleForDevice(db, row.device, row.key), "GROUP_ACTIVE"));
  const assignedAfter = activeAfter
    .map((row) => currentDeviceNumber(row.device))
    .filter((number) => number >= 1 && number <= requestedNumbers.length)
    .sort((left, right) => left - right);
  if (activeAfter.length !== requestedNumbers.length || JSON.stringify(assignedAfter) !== JSON.stringify(expectedAssigned)) {
    throw new Error(`Activation verification failed. active=${activeAfter.length} assigned=${assignedAfter.join(",")}`);
  }
  if (actionId) {
    db.maintenance.appliedActions[actionId] = {
      type: "activateNumbers",
      appliedAt: at,
      selectionMode,
      sourceNumbers,
      assignedNumbers: targets.map((row, index) => index + 1),
      activeAfter: activeAfter.length,
      inactiveAfter: inactiveAfter.length,
    };
  }
  db.updatedAt = at;
  writeJsonAtomic(filePath, db);
  return {
    activated: targets.length,
    requested: requestedNumbers.length,
    sourceNumbers,
    selectionMode,
    activeBefore: activeBefore.length,
    activeAfter: activeAfter.length,
    inactiveAfter: inactiveAfter.length,
    actionId,
  };
}

function ensureActiveCycle(db, device, at) {
  const wantedSerial = identity(device.serial);
  let cycle = device.cycleIds.map((id) => db.cycles[id]).find((item) => item && item.status === "active");
  if (!cycle) {
    cycle = Object.values(db.cycles).find((item) => item && item.status === "active" && identity(item.physicalSerial) === wantedSerial);
  }
  if (cycle) {
    if (!device.cycleIds.includes(cycle.cycleId)) device.cycleIds.push(cycle.cycleId);
    return cycle;
  }

  let sequence = device.cycleIds.reduce((max, id) => {
    const item = db.cycles[id];
    const suffix = /-(\d+)$/.exec(String(id || ""));
    return Math.max(max, Number(item && item.sequence || 0), suffix ? Number(suffix[1]) : 0);
  }, 0) + 1;
  let cycleId = `${device.serial}-${String(sequence).padStart(3, "0")}`;
  while (db.cycles[cycleId]) {
    sequence += 1;
    cycleId = `${device.serial}-${String(sequence).padStart(3, "0")}`;
  }
  cycle = {
    cycleId,
    physicalSerial: device.serial,
    managementId: String(device.managementId || ""),
    sequence,
    status: "active",
    startedAt: at,
    endedAt: "",
    operationStartedAt: at,
    operationEndedAt: "",
    startReason: "kazuma_bulk_activation_repair",
    tags: ["GROUP_ACTIVE"],
    economics: {},
    snapshots: [],
    outcome: {},
    updatedAt: at,
  };
  db.cycles[cycleId] = cycle;
  device.cycleIds.push(cycleId);
  return cycle;
}

function currentDeviceNumber(device) {
  for (const value of [device && device.laixiNumberOverride, device && device.xiaoweiSort, device && device.number]) {
    const number = Number(value);
    if (Number.isInteger(number) && number > 0) return number;
  }
  return 0;
}

function currentCycleForDevice(db, device, key = "") {
  const cycleIds = Array.isArray(device && device.cycleIds) ? device.cycleIds : [];
  const direct = cycleIds.map((cycleId) => db.cycles[cycleId]).find((cycle) => cycle && cycle.status === "active");
  if (direct) return direct;
  const serial = identity(device && device.serial || key);
  const managementId = identity(device && device.managementId);
  return Object.values(db.cycles).find((cycle) => cycle && cycle.status === "active" && (
    (serial && identity(cycle.physicalSerial) === serial) ||
    (managementId && identity(cycle.managementId) === managementId)
  )) || null;
}

function hasGroupTag(cycle, tag) {
  return Boolean(cycle && Array.isArray(cycle.tags) && cycle.tags.includes(tag));
}

function compareDeviceRows(left, right) {
  const leftNumber = Number.isInteger(left.number) && left.number > 0 ? left.number : Number.MAX_SAFE_INTEGER;
  const rightNumber = Number.isInteger(right.number) && right.number > 0 ? right.number : Number.MAX_SAFE_INTEGER;
  return leftNumber - rightNumber
    || String(left.device && left.device.managementId || "").localeCompare(String(right.device && right.device.managementId || ""), "en", { numeric: true })
    || String(left.key).localeCompare(String(right.key), "en", { numeric: true });
}

function recordMap(value, identityFields) {
  if (value && typeof value === "object" && !Array.isArray(value)) return value;
  const result = {};
  for (const item of Array.isArray(value) ? value : []) {
    if (!item || typeof item !== "object") continue;
    const key = identityFields.map((field) => String(item[field] || "").trim()).find(Boolean);
    if (key) result[key] = item;
  }
  return result;
}

function identity(value) {
  return String(value || "").trim().toLowerCase();
}

function parseArgs(values) {
  const result = {};
  for (let i = 0; i < values.length; i += 1) {
    const key = String(values[i] || "");
    if (!key.startsWith("--")) continue;
    result[key.slice(2)] = values[i + 1];
    i += 1;
  }
  return result;
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(path.resolve(filePath), "utf8").replace(/^\uFEFF/, ""));
}

function writeJsonAtomic(filePath, value) {
  const fullPath = path.resolve(filePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  const temporaryPath = `${fullPath}.update-${process.pid}.tmp`;
  fs.writeFileSync(temporaryPath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  fs.renameSync(temporaryPath, fullPath);
}

function equalIgnoreCase(left, right) {
  return String(left || "").toLowerCase() === String(right || "").toLowerCase();
}

function objectOrEmpty(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
