﻿@echo off
chcp 65001 >nul
title Android Fleet 差分更新
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0apply-update.ps1"
set EXIT_CODE=%ERRORLEVEL%
echo.
if not "%EXIT_CODE%"=="0" echo 更新に失敗しました。表示された内容をそのまま連絡してください。
pause
exit /b %EXIT_CODE%
