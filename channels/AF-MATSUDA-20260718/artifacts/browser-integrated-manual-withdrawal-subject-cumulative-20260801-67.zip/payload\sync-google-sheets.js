"use strict";

const fs = require("fs");
const crypto = require("crypto");
const http = require("http");
const https = require("https");
const os = require("os");
const path = require("path");
const { createConfigPaths, ensureConfigPaths } = require("./lib/config-paths");
const { CI_MULTIPLIERS, CI_MULTIPLIER_TOTAL } = require("./lib/fleet-economics");
const { checkinPointsFromTag, findCheckinAmountTag } = require("./lib/checkin-amount");
const {
  findVideo180AmountTag,
  findVideo10AmountTag,
  video180PointsFromTag,
  video10YenFromTag,
} = require("./lib/task-amounts");

const rootDir = __dirname;
const paths = ensureConfigPaths(createConfigPaths({ rootDir }));
const configPath = path.resolve(process.env.ANDROID_FLEET_SHEETS_CONFIG || path.join(rootDir, "config", "sheets-sync.json"));
const defaultConfigPath = path.join(rootDir, "config", "sheets-sync.example.json");
const statePath = path.join(paths.sheetsDir, "sync-state.json");
const pendingPath = path.join(paths.sheetsDir, "pending-sync.jsonl");
const fleetDbPath = path.join(paths.dataDir, "fleet-db", "fleet-db.json");
const args = new Set(process.argv.slice(2));
const PENDING_QUEUE_VERSION = 2;
const DEFAULT_PENDING_MAX_ENTRIES = 20;
const DEFAULT_PENDING_MAX_BYTES = 8 * 1024 * 1024;
const MIN_PENDING_MAX_BYTES = 4096;
const PENDING_LOCK_WAIT_MS = 15000;
const PENDING_LOCK_STALE_MS = 2 * 60 * 1000;
const REDACTED = "[REDACTED]";
const FINGERPRINT_IGNORED_KEYS = new Set([
  "at",
  "capturedAt",
  "fingerprint",
  "firstSeenAt",
  "lastScan",
  "lastSeenAt",
  "occurrences",
  "queueVersion",
  "queuedAt",
  "syncedAt",
]);
let activeQueueSecrets = [];

if (require.main === module) {
  const command = args.has("--compact-pending") ? compactPendingQueueCommand : main;
  Promise.resolve().then(command).catch((error) => {
    if (!error.pendingSheetsFailureQueued) {
      try {
        queuePendingFailure(pendingPath, {
          at: new Date().toISOString(),
          ok: false,
          reason: "Sheets sync failed before a recoverable payload was prepared.",
          error: error.message || String(error),
        }, { secrets: activeQueueSecrets });
      } catch (queueError) {
        console.error(`Failed to update Sheets pending queue: ${redactString(queueError.message, activeQueueSecrets)}`);
      }
    }
    console.error(redactString(error.stack || error.message, activeQueueSecrets));
    process.exitCode = 1;
  });
}

function compactPendingQueueCommand() {
  const config = loadConfig();
  const token = resolveToken(config);
  activeQueueSecrets = token ? [token] : [];
  log({ ok: true, compacted: true, ...compactPendingQueue(pendingPath, { secrets: activeQueueSecrets }) });
}

async function main() {
  const config = loadConfig();
  if (!config.enabled || !config.webhookUrl) {
    log({ ok: true, skipped: true, reason: "Sheets webhook is not configured." });
    return;
  }

  const state = readJson(statePath, { anomalyKeys: {}, historyDates: {}, withdrawalIds: {} });
  state.anomalyKeys = state.anomalyKeys || {};
  state.historyDates = state.historyDates || {};
  state.withdrawalIds = state.withdrawalIds || {};
  const latest = readJson(paths.monitorLatestFile, null);
  const fleetDb = readJson(fleetDbPath, null);
  if (!latest) throw new Error("No monitor latest.json found.");

  const mode = {
    current: config.sendCurrent !== false && !args.has("--no-current"),
    anomalies: config.sendAnomalies !== false && !args.has("--no-anomalies"),
    history: Boolean(config.sendHistory || args.has("--history")),
    withdrawals: config.sendWithdrawals !== false && !args.has("--no-withdrawals"),
  };

  const payload = buildPayload(latest, state, mode, fleetDb);
  if (!payload.currentRows.length && !payload.anomalyRows.length && !payload.historyRows.length && !payload.withdrawalRows.length) {
    log({ ok: true, skipped: true, reason: "No rows to sync." });
    return;
  }

  const token = resolveToken(config);
  activeQueueSecrets = token ? [token] : [];
  if (!token) {
    queuePendingFailure(pendingPath, { at: new Date().toISOString(), reason: "Sheets token is missing.", payload });
    log({ ok: true, queued: true, reason: "Sheets token is missing.", counts: counts(payload) });
    return;
  }

  let response;
  try {
    response = await postJson(config.webhookUrl, {
      token,
      spreadsheetId: config.spreadsheetId,
      payload,
    }, Number(config.timeoutMs || 30000));
  } catch (error) {
    queuePendingFailure(pendingPath, {
      at: new Date().toISOString(),
      reason: "Sheets webhook request failed.",
      error: error.message || String(error),
      payload,
    }, { secrets: [token] });
    error.pendingSheetsFailureQueued = true;
    throw error;
  }

  if (!response || response.ok !== true) {
    queuePendingFailure(pendingPath, { at: new Date().toISOString(), reason: "Sheets webhook returned an error.", response, payload }, { secrets: [token] });
    const error = new Error(`Sheets webhook failed: ${JSON.stringify(response).slice(0, 500)}`);
    error.pendingSheetsFailureQueued = true;
    throw error;
  }
  if (payload.withdrawalRows.length && Number(response.withdrawals) !== payload.withdrawalRows.length) {
    queuePendingFailure(pendingPath, { at: new Date().toISOString(), reason: "Sheets webhook did not confirm withdrawal rows.", response, payload }, { secrets: [token] });
    const error = new Error(`Sheets webhook did not confirm withdrawal rows: ${JSON.stringify(response).slice(0, 500)}`);
    error.pendingSheetsFailureQueued = true;
    throw error;
  }

  for (const row of payload.anomalyRows) state.anomalyKeys[row.key] = row.syncedAt;
  for (const row of payload.historyRows) state.historyDates[row.historyKey] = row.syncedAt;
  for (const row of payload.withdrawalRows) state.withdrawalIds[row.withdrawalId] = row.syncedAt;
  writeJson(statePath, state);
  log({ ok: true, synced: true, counts: counts(payload), response });
}

function buildPayload(latest, state, mode, fleetDb) {
  const capturedAt = latest.at || new Date().toISOString();
  const records = normalizeRecords(latest);
  const pointRowsById = fleetDb ? pointRowsFromFleetDb(fleetDb) : {};
  const currentRows = mode.current ? currentRowsFrom(records, pointRowsById) : [];
  const anomalyRows = mode.anomalies ? anomalyRowsFrom(records, capturedAt, state) : [];
  const historyRows = mode.history ? historyRowsFrom(records, capturedAt, state) : [];
  const withdrawalRows = mode.withdrawals && fleetDb ? withdrawalRowsFromFleetDb(fleetDb, state) : [];
  return {
    capturedAt,
    summary: {
      expectedCount: Number(latest.expectedCount || 0),
      adbConnectedCount: Number(latest.connectedCount || 0),
      xiaoweiConnectedCount: Number(latest.xiaoweiConnectedCount || 0),
      unexpectedConnectedCount: Number(latest.unexpectedConnectedCount || 0),
      decisionSource: latest.decision && latest.decision.source || "",
      decisionSummary: latest.decision && latest.decision.summary || "",
    },
    currentRows,
    anomalyRows,
    historyRows,
    withdrawalRows,
  };
}

function pointRowsFromFleetDb(db) {
  const result = {};
  for (const cycle of Object.values(db.cycles || {})) {
    if (!cycle || cycle.status !== "active" || !cycle.managementId) continue;
    const tags = Array.isArray(cycle.tags) ? cycle.tags : [];
    const startDate = inferStartDateFromEconomics(cycle.economics, cycle.startedAt);
    const ciInfo = buildCiInfo(cycle.economics, tags);
    const video10Info = buildVideo10Info(cycle.economics, tags);
    const video180TagPoints = video180PointsFromTag(findVideo180AmountTag(tags));
    const video10TagPoints = video10YenFromTag(findVideo10AmountTag(tags)) * 100;
    result[cycle.managementId] = {
      terminalName: `${cycle.managementId} ${deviceNameFromDb(db, cycle)}`.trim(),
      tags,
      isWaiting: tags.includes("WAITING"),
      startDate,
      endDate: cycle.endedAt ? localDate(cycle.endedAt) : endDateFromStart(startDate),
      elapsedDay: cycle.economics && cycle.economics.elapsedDay || "",
      currentPoints: cycle.currentPoints !== undefined && cycle.currentPoints !== null ? cycle.currentPoints : "",
      currentYen: cycle.currentYen !== undefined && cycle.currentYen !== null ? cycle.currentYen : "",
      ciRemainingPoints: cycle.economics && !cycle.economics.ciErrorAfter && cycle.economics.remainingCiPoints || "",
      ciRewardLabel: ciInfo.label,
      ciTotalPoints: ciInfo.totalPoints,
      ciTodayPoints: ciInfo.todayPoints,
      ciDay: ciInfo.day,
      ciErrorAfter: ciInfo.errorAfter,
      video180Points: tags.includes("V180_DONE")
        ? ""
        : video180TagPoints || cycle.economics && cycle.economics.video180TotalPoints || "",
      video180Label: buildVideo180Label(cycle.economics, tags),
      video10Points: tags.includes("V10_DONE")
        ? ""
        : video10TagPoints || cycle.economics && cycle.economics.video10Points || "",
      video10Label: video10Info.label,
      video10Yen: video10Info.yen,
      pointScreenType: cycle.lastPointScreenType || "",
      pointReadingStatus: cycle.lastPointStatus || "",
      pointReadingAt: cycle.lastPointReadingAt || "",
      projectedTotalPoints: firstNonBlank(cycle.manualProjection && cycle.manualProjection.projectedTotalPoints, cycle.economics && cycle.economics.projectedTotalPoints),
      projectedGrossYen: firstNonBlank(cycle.manualProjection && cycle.manualProjection.projectedGrossYen, cycle.economics && cycle.economics.projectedGrossYen),
      decisionOverride: cycle.manualProjection && cycle.manualProjection.decision || "",
    };
  }
  return result;
}

function normalizeRecords(latest) {
  return (latest.devices || [])
    .filter((device) => device.expected || device.adbStatus === "device")
    .map((device) => {
      const anomaly = (latest.anomalies || []).find((item) => item.serial === device.serial);
      return {
        id: device.number ? `A-${String(device.number).padStart(2, "0")}` : "",
        number: device.number || "",
        name: device.name || device.model || "",
        serial: device.serial || "",
        expected: Boolean(device.expected),
        adbStatus: device.adbStatus || "",
        xiaoweiStatus: device.xiaoweiStatus || "",
        batteryPercent: device.battery && device.battery.percent !== undefined ? device.battery.percent : "",
        screenOn: device.screen && device.screen.isOn !== undefined ? device.screen.isOn : "",
        anomalyType: anomaly ? anomaly.type : "",
        anomalyCount: anomaly ? anomaly.count : "",
      };
    })
    .sort((a, b) => Number(a.number || 9999) - Number(b.number || 9999));
}

function currentRowsFrom(records, pointRowsById) {
  const byId = Object.fromEntries(records.filter((record) => record.id).map((record) => [record.id, record]));
  const rows = [];
  const maxNumber = Math.max(37, ...Object.keys(byId).map(managementNumber), ...Object.keys(pointRowsById).map(managementNumber));
  for (let n = 1; n <= maxNumber; n++) {
    const id = `A-${String(n).padStart(2, "0")}`;
    const record = byId[id];
    const point = pointRowsById[id] || {};
    rows.push({
      id,
      terminalName: point.terminalName || (record ? `${id} ${record.name || ""}`.trim() : id),
      status: statusFor(record, id),
      displayStatus: displayStatusFor(record, point, id),
      adbStatus: record && record.adbStatus || "",
      xiaoweiStatus: record && record.xiaoweiStatus || (id === "A-05" ? "excluded" : ""),
      startDate: point.startDate || "",
      endDate: point.endDate || "",
      elapsedDay: point.elapsedDay || "",
      batteryPercent: record && record.batteryPercent !== "" ? record.batteryPercent : "",
      screenOn: record && record.screenOn !== "" ? record.screenOn : "",
      currentPoints: point.currentPoints || "",
      currentYen: point.currentYen || "",
      ciRemainingPoints: point.ciRemainingPoints || "",
      ciRewardLabel: point.ciRewardLabel || "None",
      ciTotalPoints: point.ciTotalPoints || "",
      ciTodayPoints: point.ciTodayPoints || "",
      ciDay: point.ciDay || "",
      video180Points: point.video180Points || "",
      video180Label: point.video180Label || "None",
      video10Points: point.video10Points || "",
      video10Label: point.video10Label || "None",
      video10Yen: point.video10Yen || "",
      pointScreenType: point.pointScreenType || "",
      pointReadingStatus: point.pointReadingStatus || "",
      pointReadingAt: point.pointReadingAt || "",
      projectedTotalPoints: point.projectedTotalPoints || "",
      projectedGrossYen: point.projectedGrossYen || "",
      decisionOverride: point.decisionOverride || "",
      anomalyType: record && record.anomalyType || "",
      lastScan: record ? new Date().toISOString() : "",
    });
  }
  return rows;
}

function managementNumber(id) {
  const match = /^A-(\d+)$/.exec(String(id || ""));
  return match ? Number(match[1]) : 0;
}

function anomalyRowsFrom(records, capturedAt, state) {
  return records
    .filter((record) => record.anomalyType)
    .map((record) => {
      const day = capturedAt.slice(0, 10);
      const key = `${day}:${record.id}:${record.anomalyType}`;
      return {
        key,
        syncedAt: new Date().toISOString(),
        queuedAt: capturedAt,
        managementId: record.id,
        deviceName: record.name,
        serial: record.serial,
        anomalyType: record.anomalyType,
        consecutiveCount: record.anomalyCount,
        severity: record.anomalyType === "xiaowei_only" ? "warn" : "critical",
        fact: `ADB=${record.adbStatus}; XiaoWei=${record.xiaoweiStatus}`,
        automaticAction: "rescan",
        actionResult: "not run",
        status: "open",
        memo: record.anomalyType === "xiaowei_only" ? "Visible in XiaoWei; direct ADB missing" : "",
      };
    })
    .filter((row) => !state.anomalyKeys[row.key]);
}

function historyRowsFrom(records, capturedAt, state) {
  const day = capturedAt.slice(0, 10);
  return records
    .filter((record) => record.id)
    .map((record) => ({
      historyKey: `${day}:${record.id}`,
      syncedAt: new Date().toISOString(),
      date: day,
      managementId: record.id,
      number: record.number,
      name: record.name,
      status: statusFor(record, record.id),
      tag: record.anomalyType || "",
      memo: `ADB=${record.adbStatus}; XiaoWei=${record.xiaoweiStatus}; batt=${record.batteryPercent}; screen=${record.screenOn}`,
    }))
    .filter((row) => !state.historyDates[row.historyKey]);
}

function withdrawalRowsFromFleetDb(db, state) {
  const synced = state.withdrawalIds || {};
  return (db.withdrawals || [])
    .filter((row) => row && row.withdrawalId && !synced[row.withdrawalId])
    .sort((a, b) => String(a.withdrawalDate || "").localeCompare(String(b.withdrawalDate || "")) || String(a.managementId || "").localeCompare(String(b.managementId || ""), "en"))
    .map((row) => ({
      syncedAt: new Date().toISOString(),
      withdrawalId: row.withdrawalId,
      withdrawalDate: row.withdrawalDate || "",
      recordedAt: row.recordedAt || "",
      managementId: row.managementId || "",
      deviceName: row.deviceName || "",
      serial: row.serial || "",
      cycleId: row.cycleId || "",
      sequence: row.sequence || "",
      amountYen: row.amountYen || "",
      amountPoints: row.amountPoints || "",
      finalCurrentPoints: row.finalCurrentPoints === null || row.finalCurrentPoints === undefined ? "" : row.finalCurrentPoints,
      finalCurrentYen: row.finalCurrentYen === null || row.finalCurrentYen === undefined ? "" : row.finalCurrentYen,
      day: row.day || "",
      ciTag: row.ciTag || "",
      video180Tag: row.video180Tag || "",
      video10Tag: row.video10Tag || "",
      inviteOkTag: row.inviteOkTag || "",
      inviteNgTag: row.inviteNgTag || "",
      sourceSnapshotDate: row.sourceSnapshotDate || "",
      sourceTags: Array.isArray(row.sourceTags) ? row.sourceTags.join(" ") : "",
      memo: row.memo || "",
    }));
}

function statusFor(record, id) {
  if (id === "A-05") return "Excluded";
  if (!record) return "No data";
  if (record.anomalyType === "xiaowei_only") return "XiaoWei only";
  if (record.anomalyType === "missing") return "Missing";
  if (record.adbStatus === "device" && record.xiaoweiStatus === "api_connected") return "OK";
  if (record.adbStatus === "device") return "ADB only";
  return record.adbStatus || "Unknown";
}

function displayStatusFor(record, point, id) {
  if (point && point.isWaiting) return "WAITING";
  return statusFor(record, id);
}

function deviceNameFromDb(db, cycle) {
  const device = db.physicalDevices && db.physicalDevices[cycle.physicalSerial] || {};
  return device.name || device.xiaoweiName || "";
}

function buildCiInfo(economics, tags) {
  const ciTag = economics && economics.ciTag || findCheckinAmountTag(tags);
  const totalPoints = checkinPointsFromTag(ciTag);
  const day = Number(economics && economics.elapsedDay || 0);
  const errorAfter = Boolean(economics && economics.ciErrorAfter || tags.includes("CI_ERR"));
  if (!totalPoints) return { label: "None", totalPoints: "", todayPoints: "", day: "", errorAfter };
  const todayPoints = day >= 1 && day <= CI_MULTIPLIERS.length ? Math.round(totalPoints / CI_MULTIPLIER_TOTAL * CI_MULTIPLIERS[day - 1]) : "";
  const remainingPoints = !errorAfter && economics && economics.remainingCiPoints ? economics.remainingCiPoints : "";
  const yen = Math.round(totalPoints / 100);
  const parts = [`CI ${yen} yen`];
  if (day) parts.push(`D${day}`);
  if (todayPoints !== "") parts.push(`today ${formatNumber(todayPoints)}P`);
  if (remainingPoints !== "") parts.push(`rem ${formatNumber(remainingPoints)}P`);
  if (errorAfter) parts.push("after error");
  return { label: parts.join(" / "), totalPoints, todayPoints, day, errorAfter };
}

function buildVideo180Label(economics, tags) {
  if (tags.includes("V180_DONE")) return "Done";
  const tag = findVideo180AmountTag(tags) || economics && economics.video180Tag;
  const points = Number(video180PointsFromTag(tag) || economics && economics.video180TotalPoints || 0);
  return points ? `180m ${formatNumber(points)}P` : "None";
}

function buildVideo10Info(economics, tags) {
  if (tags.includes("V10_DONE")) return { yen: "", label: "Done" };
  const tag = findVideo10AmountTag(tags) || economics && economics.video10Tag;
  const yen = video10YenFromTag(tag);
  return { yen: yen || "", label: yen ? `10m ${formatNumber(yen)} yen` : "None" };
}

function endDateFromStart(startDate) {
  if (!startDate) return "";
  const date = new Date(`${startDate}T00:00:00+09:00`);
  if (Number.isNaN(date.getTime())) return "";
  date.setDate(date.getDate() + 13);
  return localDate(date.toISOString());
}

function formatNumber(value) {
  return new Intl.NumberFormat("en-US").format(Number(value || 0));
}

function firstNonBlank(...values) {
  for (const value of values) {
    if (value !== undefined && value !== null && value !== "") return value;
  }
  return "";
}

function loadConfig() {
  const base = readJson(defaultConfigPath, {});
  const local = readJson(configPath, {});
  return { ...base, ...local };
}

function resolveToken(config) {
  const envName = config.tokenEnv || "ANDROID_FLEET_SHEETS_TOKEN";
  const tokenFile = config.tokenFile || path.join(os.homedir(), ".android-fleet-sheets-token.txt");
  return (
    process.env[envName]
    || config.token
    || readText(tokenFile).trim()
  );
}

function inferStartDateFromEconomics(economics, fallbackStartedAt) {
  const day = Number(economics && economics.elapsedDay || 0);
  if (!day) return "";
  const now = new Date();
  now.setDate(now.getDate() - day + 1);
  return localDate(now.toISOString());
}

function localDate(value) {
  const date = new Date(value);
  const parts = new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const byType = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${byType.year}-${byType.month}-${byType.day}`;
}

function readJson(filePath, fallback) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    return JSON.parse(fs.readFileSync(filePath, "utf8").replace(/^\uFEFF/, ""));
  } catch {
    return fallback;
  }
}

function readText(filePath) {
  try {
    if (!filePath || !fs.existsSync(filePath)) return "";
    return fs.readFileSync(filePath, "utf8").replace(/^\uFEFF/, "");
  } catch {
    return "";
  }
}

function writeJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

function queuePendingFailure(filePath, value, options = {}) {
  const maxEntries = positiveInteger(options.maxEntries || process.env.ANDROID_FLEET_SHEETS_PENDING_MAX_ENTRIES, DEFAULT_PENDING_MAX_ENTRIES);
  const maxBytes = Math.max(
    MIN_PENDING_MAX_BYTES,
    positiveInteger(options.maxBytes || process.env.ANDROID_FLEET_SHEETS_PENDING_MAX_BYTES, DEFAULT_PENDING_MAX_BYTES),
  );
  const secrets = uniqueSecrets([...(options.secrets || []), ...activeQueueSecrets]);
  return withPendingQueueLock(filePath, () => {
    const existing = readPendingEntries(filePath, { secrets });
    const incoming = normalizePendingEntry(value, { secrets, now: options.now });
    const deduplicated = deduplicatePendingEntries([...existing.entries, incoming]);
    const bounded = boundPendingEntries(deduplicated, { maxEntries, maxBytes });
    writePendingEntriesAtomic(filePath, bounded.entries, bounded.text);
    return {
      entries: bounded.entries.length,
      bytes: Buffer.byteLength(bounded.text),
      deduplicated: existing.entries.length + 1 - deduplicated.length,
      dropped: deduplicated.length - bounded.entries.length,
      legacyEntries: existing.legacyEntries,
      malformedLines: existing.malformedLines,
    };
  });
}

function compactPendingQueue(filePath, options = {}) {
  const maxEntries = positiveInteger(options.maxEntries || process.env.ANDROID_FLEET_SHEETS_PENDING_MAX_ENTRIES, DEFAULT_PENDING_MAX_ENTRIES);
  const maxBytes = Math.max(
    MIN_PENDING_MAX_BYTES,
    positiveInteger(options.maxBytes || process.env.ANDROID_FLEET_SHEETS_PENDING_MAX_BYTES, DEFAULT_PENDING_MAX_BYTES),
  );
  const secrets = uniqueSecrets([...(options.secrets || []), ...activeQueueSecrets]);
  return withPendingQueueLock(filePath, () => {
    const existing = readPendingEntries(filePath, { secrets });
    const deduplicated = deduplicatePendingEntries(existing.entries);
    const bounded = boundPendingEntries(deduplicated, { maxEntries, maxBytes });
    writePendingEntriesAtomic(filePath, bounded.entries, bounded.text);
    return {
      entries: bounded.entries.length,
      bytes: Buffer.byteLength(bounded.text),
      deduplicated: existing.entries.length - deduplicated.length,
      dropped: deduplicated.length - bounded.entries.length,
      legacyEntries: existing.legacyEntries,
      malformedLines: existing.malformedLines,
    };
  });
}

function withPendingQueueLock(filePath, action) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const lockPath = `${filePath}.lock`;
  const deadline = Date.now() + PENDING_LOCK_WAIT_MS;
  let descriptor;
  while (descriptor === undefined) {
    try {
      descriptor = fs.openSync(lockPath, "wx", 0o600);
    } catch (error) {
      if (!error || error.code !== "EEXIST") throw error;
      let stale = false;
      try {
        stale = Date.now() - fs.statSync(lockPath).mtimeMs > PENDING_LOCK_STALE_MS;
      } catch (statError) {
        if (statError && statError.code !== "ENOENT") throw statError;
      }
      if (stale) {
        try {
          fs.unlinkSync(lockPath);
        } catch (unlinkError) {
          if (unlinkError && unlinkError.code !== "ENOENT") throw unlinkError;
        }
        continue;
      }
      if (Date.now() >= deadline) throw new Error(`Timed out waiting for Sheets pending queue lock: ${lockPath}`);
      sleepSync(50);
    }
  }
  try {
    fs.writeFileSync(descriptor, JSON.stringify({ pid: process.pid, at: new Date().toISOString() }), "utf8");
    fs.fsyncSync(descriptor);
  } catch (error) {
    try {
      fs.closeSync(descriptor);
    } finally {
      try {
        fs.unlinkSync(lockPath);
      } catch (unlinkError) {
        if (unlinkError && unlinkError.code !== "ENOENT") throw unlinkError;
      }
    }
    throw error;
  }
  try {
    return action();
  } finally {
    try {
      fs.closeSync(descriptor);
    } finally {
      try {
        fs.unlinkSync(lockPath);
      } catch (error) {
        if (error && error.code !== "ENOENT") throw error;
      }
    }
  }
}

function sleepSync(milliseconds) {
  const signal = new Int32Array(new SharedArrayBuffer(4));
  Atomics.wait(signal, 0, 0, Math.max(1, Number(milliseconds) || 1));
}

function readPendingEntries(filePath, options = {}) {
  if (!filePath || !fs.existsSync(filePath)) {
    return { entries: [], legacyEntries: 0, malformedLines: 0 };
  }
  const text = fs.readFileSync(filePath, "utf8").replace(/^\uFEFF/, "");
  const entries = [];
  let legacyEntries = 0;
  let malformedLines = 0;
  let malformedBytes = 0;
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim()) continue;
    try {
      const parsed = JSON.parse(line);
      if (Number(parsed && parsed.queueVersion) !== PENDING_QUEUE_VERSION) legacyEntries += 1;
      entries.push(normalizePendingEntry(parsed, options));
    } catch {
      malformedLines += 1;
      malformedBytes += Buffer.byteLength(line);
    }
  }
  if (malformedLines) {
    const stat = fs.statSync(filePath);
    entries.push(normalizePendingEntry({
      at: stat.mtime.toISOString(),
      reason: "Legacy Sheets pending queue contained malformed JSON lines.",
      migration: { malformedLines, malformedBytes },
    }, options));
  }
  return { entries, legacyEntries, malformedLines };
}

function normalizePendingEntry(value, options = {}) {
  const sanitized = sanitizeQueueValue(value && typeof value === "object" ? value : { error: String(value || "Unknown Sheets failure") }, options);
  const details = { ...sanitized };
  for (const key of ["queueVersion", "fingerprint", "firstSeenAt", "lastSeenAt", "occurrences", "at"]) delete details[key];
  const observedAt = validIsoTime(sanitized.lastSeenAt || sanitized.at || options.now) || new Date().toISOString();
  const firstSeenAt = validIsoTime(sanitized.firstSeenAt || sanitized.at) || observedAt;
  return {
    queueVersion: PENDING_QUEUE_VERSION,
    fingerprint: pendingFailureFingerprint(sanitized),
    firstSeenAt,
    lastSeenAt: observedAt,
    occurrences: positiveInteger(sanitized.occurrences, 1),
    at: observedAt,
    ...details,
  };
}

function deduplicatePendingEntries(entries) {
  const byFingerprint = new Map();
  for (const entry of entries) {
    const previous = byFingerprint.get(entry.fingerprint);
    if (!previous) {
      byFingerprint.set(entry.fingerprint, entry);
      continue;
    }
    const merged = {
      ...entry,
      firstSeenAt: earlierIsoTime(previous.firstSeenAt, entry.firstSeenAt),
      lastSeenAt: laterIsoTime(previous.lastSeenAt, entry.lastSeenAt),
      occurrences: positiveInteger(previous.occurrences, 1) + positiveInteger(entry.occurrences, 1),
    };
    merged.at = merged.lastSeenAt;
    byFingerprint.delete(entry.fingerprint);
    byFingerprint.set(entry.fingerprint, merged);
  }
  return [...byFingerprint.values()];
}

function boundPendingEntries(entries, options) {
  const bounded = entries.slice(-options.maxEntries);
  let text = serializePendingEntries(bounded);
  while (bounded.length > 1 && Buffer.byteLength(text) > options.maxBytes) {
    bounded.shift();
    text = serializePendingEntries(bounded);
  }
  if (bounded.length === 1 && Buffer.byteLength(text) > options.maxBytes) {
    bounded[0] = compactOversizedPendingEntry(bounded[0]);
    text = serializePendingEntries(bounded);
  }
  if (bounded.length === 1 && Buffer.byteLength(text) > options.maxBytes) {
    bounded[0] = minimalPendingEntry(bounded[0]);
    text = serializePendingEntries(bounded);
  }
  if (Buffer.byteLength(text) > options.maxBytes) {
    throw new Error(`Sheets pending queue metadata exceeds ${options.maxBytes} bytes.`);
  }
  return { entries: bounded, text };
}

function compactOversizedPendingEntry(entry) {
  if (!entry.payload) return minimalPendingEntry(entry);
  const payloadJson = JSON.stringify(entry.payload);
  const rowKeys = ["currentRows", "anomalyRows", "historyRows", "withdrawalRows"];
  const rowCounts = Object.fromEntries(rowKeys.map((key) => [key, Array.isArray(entry.payload[key]) ? entry.payload[key].length : 0]));
  const rowSamples = Object.fromEntries(rowKeys.map((key) => [key, Array.isArray(entry.payload[key]) ? entry.payload[key].slice(0, 2) : []]));
  return {
    ...entry,
    payload: {
      truncated: true,
      originalBytes: Buffer.byteLength(payloadJson),
      sha256: sha256(payloadJson),
      capturedAt: entry.payload.capturedAt || "",
      summary: entry.payload.summary || {},
      rowCounts,
      rowSamples,
    },
  };
}

function minimalPendingEntry(entry) {
  const payload = entry.payload || {};
  const payloadJson = JSON.stringify(payload);
  const originalBytes = Number(payload.originalBytes || 0) || Buffer.byteLength(payloadJson);
  const payloadSha256 = String(payload.sha256 || "") || sha256(payloadJson);
  return {
    queueVersion: PENDING_QUEUE_VERSION,
    fingerprint: entry.fingerprint,
    firstSeenAt: entry.firstSeenAt,
    lastSeenAt: entry.lastSeenAt,
    occurrences: entry.occurrences,
    at: entry.at,
    reason: truncateText(entry.reason || "Sheets sync failure", 500),
    error: truncateText(entry.error || "", 1000),
    response: summarizeResponse(entry.response),
    payload: {
      truncated: true,
      originalBytes,
      sha256: payloadSha256,
      capturedAt: payload.capturedAt || "",
      summary: payload.summary || {},
      rowCounts: {
        currentRows: Array.isArray(payload.currentRows) ? payload.currentRows.length : Number(payload.rowCounts && payload.rowCounts.currentRows || 0),
        anomalyRows: Array.isArray(payload.anomalyRows) ? payload.anomalyRows.length : Number(payload.rowCounts && payload.rowCounts.anomalyRows || 0),
        historyRows: Array.isArray(payload.historyRows) ? payload.historyRows.length : Number(payload.rowCounts && payload.rowCounts.historyRows || 0),
        withdrawalRows: Array.isArray(payload.withdrawalRows) ? payload.withdrawalRows.length : Number(payload.rowCounts && payload.rowCounts.withdrawalRows || 0),
      },
    },
  };
}

function summarizeResponse(response) {
  if (response === undefined) return undefined;
  if (!response || typeof response !== "object") return truncateText(String(response), 500);
  const summary = {};
  for (const key of ["ok", "code", "status", "message", "error", "current", "anomalies", "history", "withdrawals"]) {
    if (response[key] !== undefined) summary[key] = typeof response[key] === "string" ? truncateText(response[key], 500) : response[key];
  }
  return summary;
}

function serializePendingEntries(entries) {
  return entries.length ? `${entries.map((entry) => JSON.stringify(entry)).join("\n")}\n` : "";
}

function writePendingEntriesAtomic(filePath, entries, serialized = serializePendingEntries(entries)) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tempPath = `${filePath}.${process.pid}.${crypto.randomBytes(6).toString("hex")}.tmp`;
  let descriptor;
  try {
    descriptor = fs.openSync(tempPath, "wx", 0o600);
    fs.writeFileSync(descriptor, serialized, "utf8");
    fs.fsyncSync(descriptor);
    fs.closeSync(descriptor);
    descriptor = undefined;
    fs.renameSync(tempPath, filePath);
  } finally {
    if (descriptor !== undefined) fs.closeSync(descriptor);
    if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
  }
}

function pendingFailureFingerprint(value) {
  return sha256(JSON.stringify(canonicalizeForFingerprint(value)));
}

function canonicalizeForFingerprint(value) {
  if (Array.isArray(value)) return value.map(canonicalizeForFingerprint);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.keys(value)
    .filter((key) => !FINGERPRINT_IGNORED_KEYS.has(key))
    .sort()
    .map((key) => [key, canonicalizeForFingerprint(value[key])]));
}

function sanitizeQueueValue(value, options = {}, seen = new WeakSet()) {
  if (value === null || value === undefined) return value;
  if (typeof value === "string") return redactString(value, options.secrets || []);
  if (typeof value !== "object") return value;
  if (value instanceof Date) return value.toISOString();
  if (seen.has(value)) return "[CIRCULAR]";
  seen.add(value);
  if (Array.isArray(value)) return value.map((item) => sanitizeQueueValue(item, options, seen));
  const sanitized = {};
  for (const [childKey, childValue] of Object.entries(value)) {
    if (isSecretKey(childKey)) sanitized[childKey] = REDACTED;
    else sanitized[childKey] = sanitizeQueueValue(childValue, options, seen);
  }
  return sanitized;
}

function isSecretKey(key) {
  return /(token|authorization|api[_-]?key|secret|password)/i.test(String(key || ""));
}

function redactString(value, secrets = []) {
  let text = String(value || "");
  for (const secret of uniqueSecrets(secrets)) text = text.split(secret).join(REDACTED);
  return text
    .replace(/\bBearer\s+[^\s,;]+/gi, `Bearer ${REDACTED}`)
    .replace(/([?&](?:access_?token|token|api_?key)=)[^&\s]+/gi, `$1${REDACTED}`)
    .replace(/(["'](?:access_?token|token|api_?key)["']\s*:\s*["'])[^"']+(["'])/gi, `$1${REDACTED}$2`);
}

function uniqueSecrets(values) {
  return [...new Set((values || []).map((value) => String(value || "")).filter(Boolean))];
}

function positiveInteger(value, fallback) {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

function validIsoTime(value) {
  const date = new Date(value || "");
  return Number.isNaN(date.getTime()) ? "" : date.toISOString();
}

function earlierIsoTime(left, right) {
  const leftTime = validIsoTime(left);
  const rightTime = validIsoTime(right);
  if (!leftTime) return rightTime;
  if (!rightTime) return leftTime;
  return leftTime < rightTime ? leftTime : rightTime;
}

function laterIsoTime(left, right) {
  const leftTime = validIsoTime(left);
  const rightTime = validIsoTime(right);
  if (!leftTime) return rightTime;
  if (!rightTime) return leftTime;
  return leftTime > rightTime ? leftTime : rightTime;
}

function truncateText(value, maxLength) {
  const text = String(value || "");
  return text.length <= maxLength ? text : `${text.slice(0, Math.max(0, maxLength - 3))}...`;
}

function sha256(value) {
  return crypto.createHash("sha256").update(String(value || ""), "utf8").digest("hex");
}

function postJson(targetUrl, payload, timeoutMs, redirectCount = 0) {
  return new Promise((resolve, reject) => {
    const url = new URL(targetUrl);
    const body = JSON.stringify(payload);
    const transport = url.protocol === "https:" ? https : http;
    const request = transport.request({
      method: "POST",
      hostname: url.hostname,
      port: url.port || (url.protocol === "https:" ? 443 : 80),
      path: `${url.pathname}${url.search}`,
      headers: {
        "content-type": "application/json",
        "content-length": Buffer.byteLength(body),
      },
      timeout: timeoutMs,
    }, (response) => {
      const chunks = [];
      response.on("data", (chunk) => chunks.push(chunk));
      response.on("end", () => {
        const text = Buffer.concat(chunks).toString("utf8");
        if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
          if (redirectCount >= 5) {
            reject(new Error("Too many redirects from Sheets webhook."));
            return;
          }
          const nextUrl = new URL(response.headers.location, targetUrl).toString();
          getJson(nextUrl, timeoutMs, redirectCount + 1).then(resolve, reject);
          return;
        }
        try {
          resolve(JSON.parse(text));
        } catch {
          reject(new Error(`Webhook returned non-JSON HTTP ${response.statusCode}: ${text.slice(0, 500)}`));
        }
      });
    });
    request.on("timeout", () => request.destroy(new Error("Sheets webhook timed out.")));
    request.on("error", reject);
    request.end(body);
  });
}

function getJson(targetUrl, timeoutMs, redirectCount = 0) {
  return new Promise((resolve, reject) => {
    const url = new URL(targetUrl);
    const transport = url.protocol === "https:" ? https : http;
    const request = transport.request({
      method: "GET",
      hostname: url.hostname,
      port: url.port || (url.protocol === "https:" ? 443 : 80),
      path: `${url.pathname}${url.search}`,
      timeout: timeoutMs,
    }, (response) => {
      const chunks = [];
      response.on("data", (chunk) => chunks.push(chunk));
      response.on("end", () => {
        const text = Buffer.concat(chunks).toString("utf8");
        if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
          if (redirectCount >= 5) {
            reject(new Error("Too many redirects from Sheets webhook."));
            return;
          }
          getJson(new URL(response.headers.location, targetUrl).toString(), timeoutMs, redirectCount + 1).then(resolve, reject);
          return;
        }
        try {
          resolve(JSON.parse(text));
        } catch {
          reject(new Error(`Webhook returned non-JSON HTTP ${response.statusCode}: ${text.slice(0, 500)}`));
        }
      });
    });
    request.on("timeout", () => request.destroy(new Error("Sheets webhook timed out.")));
    request.on("error", reject);
    request.end();
  });
}

function counts(payload) {
  return {
    current: payload.currentRows.length,
    anomalies: payload.anomalyRows.length,
    history: payload.historyRows.length,
    withdrawals: payload.withdrawalRows.length,
  };
}

function log(value) {
  if (!args.has("--quiet")) console.log(JSON.stringify(sanitizeQueueValue(value, { secrets: activeQueueSecrets }), null, 2));
}

module.exports = {
  buildPayload,
  pointRowsFromFleetDb,
  normalizeRecords,
  currentRowsFrom,
  anomalyRowsFrom,
  historyRowsFrom,
  withdrawalRowsFromFleetDb,
  queuePendingFailure,
  compactPendingQueue,
  readPendingEntries,
  pendingFailureFingerprint,
  sanitizeQueueValue,
};
