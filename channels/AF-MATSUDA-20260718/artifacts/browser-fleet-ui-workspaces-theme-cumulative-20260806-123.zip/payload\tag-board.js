"use strict";

const fs = require("fs");
const path = require("path");
const { createConfigPaths, ensureConfigPaths } = require("./lib/config-paths");
const { readJson, writeJson } = require("./lib/monitor-state");
const { CANONICAL_TAGS, canonicalizeTags, sortTags, tagLabel, tagDescriptionJa } = require("./lib/tag-schema");
const {
  MAX_CHECKIN_YEN,
  checkinYenFromTag,
  findCheckinAmountTag,
  isCheckinAmountTag,
} = require("./lib/checkin-amount");
const {
  MAX_RESET_AMOUNT_YEN,
  MAX_UPTIME_HOURS,
  effectiveDeviceUptimeSeconds,
  uptimeHoursToSeconds,
} = require("./lib/inactive-reset");
const {
  findVideo180AmountTag,
  findVideo10AmountTag,
  video180PointsFromTag,
  video10YenFromTag,
} = require("./lib/task-amounts");

const rootDir = __dirname;
const paths = ensureConfigPaths(createConfigPaths({ rootDir }));
const dbDir = path.join(paths.dataDir, "fleet-db");
const dbPath = path.join(dbDir, "fleet-db.json");
const boardPath = path.join(dbDir, "device-tag-board.md");
const csvPath = path.join(dbDir, "device-tag-board.csv");
const jsonPath = path.join(dbDir, "device-tag-board.json");
const matrixMdPath = path.join(dbDir, "device-tag-matrix.md");
const matrixCsvPath = path.join(dbDir, "device-tag-matrix.csv");
const matrixHtmlPath = path.join(dbDir, "device-tag-matrix.html");
const matrixJsonPath = path.join(dbDir, "device-tag-matrix.json");
const transposedHtmlPath = path.join(dbDir, "device-tag-transposed.html");
const INACTIVE_NUMBER_START = 1000;
const CHECKIN_AMOUNT_ROW = "CI_AMOUNT_INPUT";

const preferredTags = CANONICAL_TAGS;
const boardVisibleTags = [
  "GROUP_ACTIVE",
  "GROUP_INACTIVE",
  "STATE_ERROR",
  "STATE_ERROR_HISTORY",
  CHECKIN_AMOUNT_ROW,
  "V180_7500",
  "V180_15000",
  "V180_22500",
  "V180_DONE",
  "V10_1190",
  "V10_1438",
  "V10_2262",
  "V10_DONE",
  "DAY_01",
  "DAY_02",
  "DAY_03",
  "DAY_04",
  "DAY_05",
  "DAY_06",
  "DAY_07",
  "DAY_08",
  "DAY_09",
  "DAY_10",
  "DAY_11",
  "DAY_12",
  "DAY_13",
  "DAY_14",
  "STATE_CI_KEEP",
];

if (require.main === module) main();

module.exports = {
  findTagBoardDeviceMatches,
  normalizeTagBoardDeviceNumber,
};

function main() {
  const db = readJson(dbPath, null);
  if (!db) {
    throw new Error("fleet-db.json not found. Run update-fleet-db.js first.");
  }

  const rows = buildRows(db);
  const matrix = buildMatrix(rows);
  fs.mkdirSync(dbDir, { recursive: true });
  writeJson(jsonPath, rows);
  writeCsv(csvPath, rows);
  writeMarkdown(boardPath, rows, db);
  writeJson(matrixJsonPath, matrix);
  writeMatrixCsv(matrixCsvPath, matrix);
  writeMatrixMarkdown(matrixMdPath, matrix, db);
  writeMatrixHtml(matrixHtmlPath, matrix, db);
  writeTransposedHtml(transposedHtmlPath, matrix, db);

  console.log(JSON.stringify({
    ok: true,
    rows: rows.length,
    boardPath,
    csvPath,
    jsonPath,
    matrixMdPath,
    matrixCsvPath,
    matrixHtmlPath,
    matrixJsonPath,
    transposedHtmlPath,
  }, null, 2));
}

function normalizeTagBoardDeviceNumber(rawValue) {
  const compact = String(rawValue === undefined || rawValue === null ? "" : rawValue)
    .normalize("NFKC")
    .trim()
    .toUpperCase()
    .replace(/[‐‑‒–—―ー−ｰ－]/g, "-")
    .replace(/\s+/g, "");
  if (!compact) return { ok: false, number: "", error: "empty" };

  const match = compact.match(/^(?:(?:A|NO\.?)?-?)?0*(\d{1,4})$/);
  if (!match) return { ok: false, number: "", error: "invalid" };

  const value = Number(match[1]);
  if (!Number.isInteger(value) || value < 1 || value >= 9000) {
    return { ok: false, number: "", error: "range" };
  }
  return { ok: true, number: String(value), value, error: "" };
}

function findTagBoardDeviceMatches(devices, rawQuery) {
  const normalized = normalizeTagBoardDeviceNumber(rawQuery);
  if (!normalized.ok) {
    return { ok: false, number: "", indexes: [], error: normalized.error };
  }

  const rows = Array.isArray(devices) ? devices : [];
  const indexes = [];
  for (let index = 0; index < rows.length; index += 1) {
    const displayNumber = normalizeTagBoardDeviceNumber(rows[index] && rows[index].displayId);
    if (displayNumber.ok && displayNumber.number === normalized.number) indexes.push(index);
  }
  return {
    ok: indexes.length > 0,
    number: normalized.number,
    indexes,
    error: indexes.length > 0 ? "" : "not_found",
  };
}

function buildRows(db) {
  const devices = db.physicalDevices || {};
  const activeSerials = new Set();
  const rows = Object.values(db.cycles || {})
    .filter((cycle) => cycle.status === "active")
    .map((cycle) => {
      const device = devices[cycle.physicalSerial] || {};
      const deviceNumber = tagBoardDeviceNumber(device);
      if (cycle.physicalSerial) activeSerials.add(String(cycle.physicalSerial));
      const tags = withFleetGroupTag(canonicalizeTags(Array.isArray(cycle.tags) ? cycle.tags : []));
      return {
        cycleId: cycle.cycleId || "",
        managementId: cycle.managementId || device.managementId || "",
        displayId: "",
        name: tagBoardDeviceName(device),
        sortLabel: device.uiNameOverride || device.name || device.xiaoweiName || "",
        deviceCode: device.deviceCode || "",
        deviceDisplayCode: tagBoardDisplayCode(device),
        uiNameOverride: device.uiNameOverride || "",
        xiaoweiName: device.xiaoweiName || "",
        serial: cycle.physicalSerial,
        status: firstTag(tags, /^STATE_/),
        ci: findCheckinAmountTag(tags),
        video180: taskTagSummary(tags, /^V180_(?!DONE$)/, "V180_DONE"),
        video10: taskTagSummary(tags, /^V10_(?!DONE$)/, "V10_DONE"),
        day: firstTag(tags, /^DAY_/),
        decision: firstTag(tags, /^DEC_/),
        network: firstTag(tags, /^NET_/),
        can3000: tags.includes("OK_3000") ? "OK_3000" : tags.includes("NG_3000") ? "NG_3000" : "",
        currentPoints: value(cycle.currentPoints),
        currentYen: value(cycle.currentYen),
        pointScreenType: cycle.lastPointScreenType || "",
        projectedGrossYen: value(cycle.economics && cycle.economics.projectedGrossYen),
        dayYieldYenWith200hWait: value(cycle.economics && cycle.economics.dayYieldYenWith200hWait),
        adbStatus: cycle.lastAdbStatus || "",
        xiaoweiStatus: cycle.lastXiaoweiStatus || "",
        adbLastUptimeSeconds: device.adbLastUptimeSeconds ?? null,
        adbLastUptimeCheckedAt: device.adbLastUptimeCheckedAt || "",
        xiaoweiSort: value(deviceNumber),
        laixiNumber: value(deviceNumber),
        allTags: tags.join(" / "),
      };
    });
  for (const device of Object.values(devices)) {
    const serial = String(device.serial || "");
    if (!serial || activeSerials.has(serial)) continue;
    const tags = withFleetGroupTag([]);
    const deviceNumber = tagBoardDeviceNumber(device);
    rows.push({
      cycleId: "",
      managementId: device.managementId || "",
      displayId: "",
      name: tagBoardDeviceName(device),
      sortLabel: device.uiNameOverride || device.name || device.xiaoweiName || "",
      deviceCode: device.deviceCode || "",
      deviceDisplayCode: tagBoardDisplayCode(device),
      uiNameOverride: device.uiNameOverride || "",
      xiaoweiName: device.xiaoweiName || "",
      serial,
      status: "",
      ci: "",
      video180: "",
      video10: "",
      day: "",
      decision: "",
      network: "",
      can3000: "",
      currentPoints: "",
      currentYen: "",
      pointScreenType: "",
      projectedGrossYen: "",
      dayYieldYenWith200hWait: "",
      adbStatus: "",
      xiaoweiStatus: "",
      adbLastUptimeSeconds: device.adbLastUptimeSeconds ?? null,
      adbLastUptimeCheckedAt: device.adbLastUptimeCheckedAt || "",
      xiaoweiSort: value(deviceNumber),
      laixiNumber: value(deviceNumber),
      allTags: tags.join(" / "),
    });
  }
  annotateTagBoardDisplayIds(rows);
  return rows.sort(compareBoardRows);
}

function compareBoardRows(a, b) {
  const groupA = boardSortGroup(a);
  const groupB = boardSortGroup(b);
  if (groupA !== groupB) return groupA - groupB;

  if (groupA === 0) return compareTagBoardNumberRows(a, b);

  const numberA = managementNumber(a.displayId || a.managementId);
  const numberB = managementNumber(b.displayId || b.managementId);
  if (numberA !== numberB) return numberA - numberB;

  return String(a.displayId || a.managementId).localeCompare(String(b.displayId || b.managementId), "en");
}

function boardSortGroup(row) {
  const tags = String(row.allTags || "");
  const xiaoweiSort = Number(row.xiaoweiSort || 0);
  if (tags.includes("GROUP_INACTIVE") || tags.includes("GROUP_REST") || tags.includes("WAITING")) return 9;
  return 0;
}

function withFleetGroupTag(tags) {
  const result = tags.filter((tag) => !/^GROUP_/.test(tag));
  const groupTag = fleetGroupTag(tags);
  if (groupTag) result.unshift(groupTag);
  return sortTags(result);
}

function fleetGroupTag(tags) {
  if (tags.includes("GROUP_REST") || tags.includes("WAITING")) return "GROUP_INACTIVE";
  if (tags.includes("GROUP_INACTIVE")) return "GROUP_INACTIVE";
  if (tags.includes("GROUP_ACTIVE")) return "GROUP_ACTIVE";
  if (!tags.some((tag) => /^DAY_\d{2}$/.test(tag))) return "GROUP_INACTIVE";
  return "GROUP_ACTIVE";
}

function managementNumber(value) {
  const match = String(value || "").match(/(\d+)/);
  return match ? Number(match[1]) : Number.MAX_SAFE_INTEGER;
}

function annotateTagBoardDisplayIds(rows) {
  const bands = [
    { key: "active", start: 1, end: INACTIVE_NUMBER_START },
    { key: "inactive", start: INACTIVE_NUMBER_START, end: 9000 },
  ];
  for (const band of bands) {
    const bandRows = rows.filter((row) => tagBoardNumberBand(row) === band.key);
    const used = new Set();
    const pending = [];
    for (const row of bandRows) {
      const storedNumber = tagBoardStoredNumber(row);
      if (storedNumber >= band.start && storedNumber < band.end && !used.has(storedNumber)) {
        assignTagBoardNumber(row, storedNumber, "db_canonical");
        used.add(storedNumber);
      } else {
        pending.push(row);
      }
    }
    pending.sort(compareTagBoardNumberRows);
    let next = band.start;
    for (const row of pending) {
      while (next < band.end && used.has(next)) next += 1;
      if (next >= band.end) throw new Error(`Tag board ${band.key} number range is full`);
      assignTagBoardNumber(row, next, "db_projection");
      used.add(next);
      next += 1;
    }
  }
  assertTagBoardNumberSync(rows);
}

function tagBoardDeviceNumber(device) {
  for (const input of [
    device && device.laixiNumberOverride,
    device && device.xiaoweiSort,
    device && device.laixiNumber,
    device && device.number,
  ]) {
    const number = Number(input);
    if (Number.isInteger(number) && number > 0) return number;
  }
  return "";
}

function tagBoardStoredNumber(row) {
  for (const input of [row && row.laixiNumber, row && row.xiaoweiSort]) {
    const number = Number(input);
    if (Number.isInteger(number) && number > 0) return number;
  }
  return 0;
}

function assignTagBoardNumber(row, number, source) {
  row.displayId = String(number);
  row.laixiNumber = String(number);
  row.xiaoweiSort = number;
  row.numberSource = source;
}

function assertTagBoardNumberSync(rows) {
  const seen = new Map();
  const errors = [];
  for (const row of rows) {
    const displayId = String(row.displayId || "");
    const laixiNumber = String(row.laixiNumber || "");
    if (!displayId) errors.push(`${row.serial}: missing displayId`);
    if (displayId !== laixiNumber) errors.push(`${row.serial}: displayId ${displayId} != laixiNumber ${laixiNumber}`);
    if (displayId) {
      const previous = seen.get(displayId);
      if (previous) errors.push(`${row.serial}: duplicate displayId ${displayId} with ${previous}`);
      else seen.set(displayId, row.serial);
    }
  }
  if (errors.length) {
    throw new Error(`Tag board number sync failed: ${errors.slice(0, 10).join("; ")}`);
  }
}

function compareTagBoardNumberRows(a, b) {
  const dayA = Number(String(a.day || "").replace(/^DAY_/, "") || 0);
  const dayB = Number(String(b.day || "").replace(/^DAY_/, "") || 0);
  if (dayA !== dayB) return dayB - dayA;
  const partsA = parseSortLabel(a.sortLabel || a.name);
  const partsB = parseSortLabel(b.sortLabel || b.name);
  const model = String(partsA.modelGroup || "").localeCompare(String(partsB.modelGroup || ""), "en", { numeric: true });
  if (model !== 0) return model;
  const carrier = carrierSortValue(partsA.carrierCode) - carrierSortValue(partsB.carrierCode)
    || String(partsA.carrierCode || "").localeCompare(String(partsB.carrierCode || ""), "en", { numeric: true });
  if (carrier !== 0) return carrier;
  const label = String(partsA.deviceCode || a.sortLabel || a.name || "").localeCompare(String(partsB.deviceCode || b.sortLabel || b.name || ""), "en", { numeric: true });
  if (label !== 0) return label;
  return String(a.managementId || a.serial).localeCompare(String(b.managementId || b.serial), "en", { numeric: true });
}

function parseSortLabel(value) {
  const text = String(value || "").trim();
  const match = /^([A-Za-z0-9]+)(?:-\d+)?(?:\s+([A-Z]+))?/.exec(text);
  return {
    modelGroup: match ? match[1].toUpperCase() : text.toUpperCase(),
    carrierCode: match && match[2] ? match[2].toUpperCase() : "UNKNOWN",
    deviceCode: text,
  };
}

function carrierSortValue(value) {
  return {
    DOCOMO: 10,
    KDDI: 20,
    SBM: 30,
    RAKUTEN: 40,
    SIMFREE: 50,
    UNKNOWN: 90,
  }[String(value || "UNKNOWN").toUpperCase()] || 80;
}

function tagBoardNumberBand(row) {
  const tags = String(row.allTags || "");
  if (tags.includes("GROUP_REST") || tags.includes("WAITING")) return "inactive";
  if (tags.includes("GROUP_INACTIVE")) return "inactive";
  if (tags.includes("GROUP_ACTIVE")) return "active";
  return row.day ? "active" : "inactive";
}

function firstTag(tags, pattern) {
  return tags.find((tag) => pattern.test(tag)) || "";
}

function taskTagSummary(tags, amountPattern, doneTag) {
  const amount = firstTag(tags, amountPattern);
  const done = tags.includes(doneTag) ? doneTag : "";
  return [amount, done].filter(Boolean).join(" + ");
}

function value(input) {
  return input === undefined || input === null ? "" : input;
}

function writeCsv(filePath, rows) {
  const headers = [
    "managementId",
    "displayId",
    "name",
    "xiaoweiName",
    "serial",
    "status",
    "ci",
    "video180",
    "video10",
    "day",
    "decision",
    "network",
    "can3000",
    "currentPoints",
    "currentYen",
    "pointScreenType",
    "projectedGrossYen",
    "dayYieldYenWith200hWait",
    "xiaoweiSort",
    "laixiNumber",
    "allTags",
  ];
  const lines = [headers.join(",")];
  for (const row of rows) {
    lines.push(headers.map((header) => csvCell(row[header])).join(","));
  }
  fs.writeFileSync(filePath, `${lines.join("\n")}\n`, "utf8");
}

function writeMarkdown(filePath, rows, db) {
  const now = new Date().toISOString();
  const tagIndex = buildTagIndex(rows);
  const headers = ["??", "??", "??", "CI", "180?", "10?", "DAY", "??", "3000?", "??"];
  const lines = [
    "# Device Tag Board",
    "",
    `Generated: ${now}`,
    "",
    "Tags are managed only in the local DB. XiaoWei receives device names and numbers only.",
    "",
    "## Device View",
    "",
    `| ${headers.join(" | ")} |`,
    `| ${headers.map(() => "---").join(" | ")} |`,
    ...rows.map((row) => `| ${[
      row.displayId || row.managementId,
      row.name,
      row.status,
      row.ci,
      row.video180,
      row.video10,
      row.day,
      row.decision,
      row.can3000,
      row.currentYen || row.projectedGrossYen,
    ].map(mdCell).join(" | ")} |`),
    "",
    "## Tag View",
    "",
    ...Object.entries(tagIndex).map(([tag, ids]) => `- ${tag}: ${ids.join(", ")}`),
    "",
    "## Tag Translation",
    "",
    ...matrixLikeTags(rows).map((tag) => `- ${tag}: ${tagDescriptionJa(tag) || tagLabel(tag)}`),
    "",
    "## Source",
    "",
    `- DB updatedAt: ${db.updatedAt || ""}`,
    `- Active rows: ${rows.length}`,
    "",
  ];
  fs.writeFileSync(filePath, lines.join("\n"), "utf8");
}

function buildTagIndex(rows) {
  const result = {};
  for (const row of rows) {
    for (const tag of row.allTags.split(" / ").filter(Boolean)) {
      result[tag] = result[tag] || [];
      result[tag].push(row.displayId || row.managementId || row.serial);
    }
  }
  return Object.fromEntries(Object.entries(result).sort(([a], [b]) => sortTags([a, b])[0] === a ? -1 : 1));
}

function matrixLikeTags(rows) {
  const discovered = new Set();
  for (const row of rows) {
    for (const tag of row.allTags.split(" / ").filter(Boolean)) {
      discovered.add(tag);
    }
  }
  const ordered = [];
  for (const tag of preferredTags) {
    if (discovered.has(tag)) ordered.push(tag);
  }
  for (const tag of sortTags([...discovered])) {
    if (!ordered.includes(tag)) ordered.push(tag);
  }
  return ordered;
}

function buildMatrix(rows) {
  const discovered = new Set();
  for (const row of rows) {
    for (const tag of row.allTags.split(" / ").filter(Boolean)) {
      discovered.add(tag);
    }
  }

  const ordered = [];
  for (const tag of boardVisibleTags) {
    if (!ordered.includes(tag)) ordered.push(tag);
  }
  for (const tag of sortTags([...discovered]).filter((tag) => boardVisibleTags.includes(tag))) {
    if (tag === "STATE_ACTIVE") continue;
    if (!ordered.includes(tag)) ordered.push(tag);
  }

  return {
    generatedAt: new Date().toISOString(),
    tags: ordered,
    devices: rows.map((row) => {
      const tagSet = new Set(row.allTags.split(" / ").filter(Boolean));
      const checkinTag = findCheckinAmountTag([...tagSet]);
      const checkinAmountYen = checkinYenFromTag(checkinTag);
      return {
        managementId: row.managementId,
        displayId: row.displayId || row.managementId,
        name: row.name,
        xiaoweiName: row.xiaoweiName,
        serial: row.serial,
        currentPoints: row.currentPoints,
        currentYen: row.currentYen,
        pointScreenType: row.pointScreenType,
        projectedGrossYen: row.projectedGrossYen,
        dayYieldYenWith200hWait: row.dayYieldYenWith200hWait,
        adbStatus: row.adbStatus,
        xiaoweiStatus: row.xiaoweiStatus,
        adbLastUptimeSeconds: row.adbLastUptimeSeconds,
        adbLastUptimeCheckedAt: row.adbLastUptimeCheckedAt,
        xiaoweiSort: row.xiaoweiSort,
        laixiNumber: row.laixiNumber,
        checkinTag,
        checkinAmountYen,
        video180Amount: video180PointsFromTag(findVideo180AmountTag([...tagSet])),
        video10Amount: video10YenFromTag(findVideo10AmountTag([...tagSet])),
        tags: Object.fromEntries(ordered.map((tag) => [
          tag,
          tag === CHECKIN_AMOUNT_ROW ? Boolean(checkinAmountYen) : tagSet.has(tag),
        ])),
      };
    }),
  };
}

function matrixTagCellValue(device, tag, checkedValue) {
  if (tag === CHECKIN_AMOUNT_ROW) return device.checkinAmountYen || "";
  return device.tags[tag] ? checkedValue : "";
}

function matrixTagHeader(tag) {
  return tag === CHECKIN_AMOUNT_ROW ? "チェックイン円" : tag;
}

function writeMatrixCsv(filePath, matrix) {
  const headers = ["端末", "名前", "見込み円", ...matrix.tags.map(matrixTagHeader)];
  const lines = [headers.join(",")];
  for (const device of matrix.devices) {
    const row = [
      device.managementId,
      device.displayId,
      device.name,
      device.xiaoweiName,
      device.serial,
      device.currentPoints,
      device.currentYen,
      device.pointScreenType,
      device.currentYen || device.projectedGrossYen,
      device.dayYieldYenWith200hWait,
      device.xiaoweiSort,
      device.laixiNumber,
      ...matrix.tags.map((tag) => matrixTagCellValue(device, tag, "1")),
    ];
    lines.push(row.map(csvCell).join(","));
  }
  fs.writeFileSync(filePath, `${lines.join("\n")}\n`, "utf8");
}

function writeMatrixMarkdown(filePath, matrix, db) {
  const headers = ["端末", "名前", "見込み円", ...matrix.tags.map(matrixTagHeader)];
  const lines = [
    "# Device Tag Matrix",
    "",
    `Generated: ${matrix.generatedAt}`,
    "",
    "Tags are managed only in the local DB. XiaoWei receives device names and numbers only.",
    "",
    `| ${headers.map(mdCell).join(" | ")} |`,
    `| ${headers.map(() => "---").join(" | ")} |`,
    ...matrix.devices.map((device) => `| ${[
      device.displayId || device.managementId,
      device.name,
      device.projectedGrossYen,
      ...matrix.tags.map((tag) => matrixTagCellValue(device, tag, "checked")),
    ].map(mdCell).join(" | ")} |`),
    "",
    "## Source",
    "",
    `- DB updatedAt: ${db.updatedAt || ""}`,
    `- Active rows: ${matrix.devices.length}`,
    `- Tag columns: ${matrix.tags.length}`,
    "",
  ];
  fs.writeFileSync(filePath, lines.join("\n"), "utf8");
}

function writeMatrixHtml(filePath, matrix, db) {
  const styles = `
    :root { color-scheme: light dark; font-family: "Segoe UI", Meiryo, sans-serif; }
    body { margin: 0; padding: 16px; background: #111827; color: #e5e7eb; }
    h1 { margin: 0 0 8px; font-size: 20px; }
    .meta { color: #9ca3af; margin-bottom: 12px; font-size: 13px; }
    .hint { color: #cbd5e1; margin-bottom: 12px; font-size: 13px; }
    .top-scroll { overflow-x: auto; overflow-y: hidden; height: 20px; border: 1px solid #374151; border-radius: 8px; margin-bottom: 8px; background: #0f172a; }
    .top-scroll-inner { height: 1px; }
    .wrap { overflow: auto; border: 1px solid #374151; border-radius: 8px; height: calc(100vh - 116px); background: #0f172a; scrollbar-gutter: stable both-edges; }
    .top-scroll::-webkit-scrollbar,
    .wrap::-webkit-scrollbar { width: 18px; height: 18px; }
    .top-scroll::-webkit-scrollbar-thumb,
    .wrap::-webkit-scrollbar-thumb { background: #64748b; border: 4px solid #0f172a; border-radius: 999px; }
    .top-scroll::-webkit-scrollbar-track,
    .wrap::-webkit-scrollbar-track { background: #1f2937; }
    table { border-collapse: separate; border-spacing: 0; font-size: 13px; min-width: max-content; }
    th, td { border-right: 1px solid #273244; border-bottom: 1px solid #273244; padding: 7px 8px; white-space: nowrap; text-align: center; }
    th { position: sticky; top: 0; z-index: 2; background: #1f2937; color: #f9fafb; }
    th.device, td.device { position: sticky; left: 0; z-index: 3; background: #172033; text-align: left; min-width: 74px; }
    th.name, td.name { position: sticky; left: 90px; z-index: 3; background: #172033; text-align: left; min-width: 150px; }
    th.name { z-index: 4; }
    th.device { z-index: 4; }
    .tag-head { min-width: 44px; max-width: 58px; height: 62px; line-height: 1.12; white-space: normal; word-break: keep-all; vertical-align: bottom; font-size: 11px; padding: 5px 4px; }
    .tag-head.day { min-width: 34px; max-width: 38px; }
    .tag-head.short { min-width: 46px; max-width: 52px; }
    .tag-head .line { display: block; }
    .tag-head .sub { color: #cbd5e1; font-size: 10px; }
    input[type="checkbox"] { width: 17px; height: 17px; accent-color: #22c55e; }
    .empty input[type="checkbox"] { opacity: .45; }
    .yen { color: #fbbf24; font-variant-numeric: tabular-nums; }
    .error { background: #3b1722; }
    .ci { background: #263247; }
    .task { background: #17343f; }
    .day { background: #25223c; }
    .invite { background: #3a2a15; }
    .profit { background: #173422; }
    .cycle { background: #2b2d42; }
  `;
  const html = `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>チェック一覧</title>
${faviconLinks()}
<style>${styles}</style>
</head>
<body>
<div class="meta">表示端末 ${matrix.devices.length}台 / チェック項目 ${matrix.tags.length}件 / ${escapeHtml(matrix.generatedAt)}</div>
<div class="hint">チェックはローカルDBで管理します。XiaoWeiへは端末名と番号だけ同期します。</div>
<div class="top-scroll"><div class="top-scroll-inner"></div></div>
<div class="wrap">
<table>
<thead>
<tr>
<th class="device">端末</th>
<th class="name">名前</th>
<th>見込み円</th>
${matrix.tags.map((tag) => `<th class="tag-head ${tagClass(tag)}">${tagLabelHtml(tag)}</th>`).join("")}
</tr>
</thead>
<tbody>
${matrix.devices.map((device) => `<tr>
<td class="device">${escapeHtml(device.displayId || device.managementId)}</td>
<td class="name">${escapeHtml(device.name)}</td>
<td class="yen">${escapeHtml(device.projectedGrossYen)}</td>
${matrix.tags.map((tag) => tag === CHECKIN_AMOUNT_ROW
    ? `<td class="${device.checkinAmountYen ? "checked" : "empty"} ${tagClass(tag)}"><span>${device.checkinAmountYen ? `${escapeHtml(device.checkinAmountYen)}円` : ""}</span></td>`
    : `<td class="${device.tags[tag] ? "checked" : "empty"} ${tagClass(tag)}"><input type="checkbox" ${device.tags[tag] ? "checked" : ""} disabled></td>`).join("")}
</tr>`).join("\n")}
</tbody>
</table>
</div>
<script>
(() => {
  const wrap = document.querySelector('.wrap');
  const topScroll = document.querySelector('.top-scroll');
  const topInner = document.querySelector('.top-scroll-inner');
  const table = document.querySelector('table');
  if (!wrap || !topScroll || !topInner || !table) return;
  const syncWidth = () => {
    topInner.style.width = table.scrollWidth + 'px';
  };
  syncWidth();
  window.addEventListener('resize', syncWidth);
  topScroll.addEventListener('scroll', () => {
    if (wrap.scrollLeft !== topScroll.scrollLeft) wrap.scrollLeft = topScroll.scrollLeft;
  });
  wrap.addEventListener('scroll', () => {
    if (topScroll.scrollLeft !== wrap.scrollLeft) topScroll.scrollLeft = wrap.scrollLeft;
  });
})();
</script>
</body>
</html>`;
  fs.writeFileSync(filePath, html, "utf8");
}

function writeTransposedHtml(filePath, matrix, db) {
  const fleetCounts = fleetCountSummary(matrix);
  const styles = `
    :root {
      color-scheme: dark;
      --bg: #0b1020;
      --panel: #111827;
      --panel-2: #162033;
      --line: #263246;
      --line-soft: #293648;
      --text: #e5e7eb;
      --muted: #94a3b8;
      --green: #22c55e;
      --cyan: #22d3ee;
      --pink: #fb7185;
      --yellow: #facc15;
      --ink: #080d14;
      font-family: "Segoe UI", Meiryo, sans-serif;
    }
    html, body { width: 100%; height: 100%; min-height: 100vh; min-height: 100dvh; }
    body { box-sizing: border-box; margin: 0; padding: 0; background: var(--bg); color: var(--text); overflow: hidden; display: grid; grid-template-rows: 42px auto auto minmax(0, 1fr); gap: 0; }
    *, *::before, *::after { box-sizing: border-box; }
    .topbar { display: flex; align-items: center; gap: 8px; min-height: 0; padding: 0 10px 0 6px; border-bottom: 1px solid #3a485b; background: #121b2c; overflow: hidden; }
    .brand-lockup { display: none; }
    .brand-mark { width: 24px; height: 24px; border-radius: 5px; background: var(--ink); box-shadow: 5px 0 0 var(--cyan), 10px 0 0 var(--pink); flex: 0 0 auto; }
    h1 { align-self: stretch; display: flex; align-items: center; margin: 0 8px 0 0; padding: 0 12px; min-width: 120px; background: #121b2c; color: #f8fafc; border-right: 1px solid #3a485b; font-size: 17px; letter-spacing: 0; line-height: 1; }
    h1::after { content: none; }
    .brand-sub { display: block; margin-top: 3px; color: #3f3505; font-size: 10px; font-weight: 800; }
    .command-strip { display: contents; }
    .stats-strip { display: contents; }
    button { min-height: 32px; border: 1px solid #303846; background: #121923; color: #f8fafc; border-radius: 4px; padding: 5px 11px; font-weight: 900; cursor: pointer; }
    button:hover { border-color: var(--yellow); }
    button.secondary { border-color: #1f8a4c; background: #0f3f28; }
    button.utility { border-color: #0e7490; background: #123142; }
    button:disabled { opacity: .45; cursor: not-allowed; }
    .button-help-popover {
      position: fixed;
      z-index: 10000;
      min-width: 220px;
      max-width: 360px;
      border: 1px solid #475569;
      border-radius: 7px;
      padding: 9px 10px;
      background: #020617;
      color: #e5e7eb;
      box-shadow: 0 14px 34px rgba(0,0,0,.42);
      font-size: 12px;
      font-weight: 800;
      line-height: 1.55;
      pointer-events: none;
    }
    .button-help-popover::before {
      content: "";
      position: absolute;
      left: 18px;
      top: -6px;
      width: 10px;
      height: 10px;
      border-left: 1px solid #475569;
      border-top: 1px solid #475569;
      background: #020617;
      transform: rotate(45deg);
    }
    .button-help-popover[hidden] { display: none; }
    #restartAdb { display: none; }
    body.embedded #syncXiaowei { display: none; }
    #applyChanges { border-color: #155e75; background: #164e63; color: #e0f2fe; }
    #applyChanges:not(:disabled) { border-color: #0891b2; background: #0e7490; box-shadow: inset 0 0 0 1px rgba(34,211,238,.18); }
    #applyChanges:disabled { opacity: .64; }
    .status { display: inline-flex; align-items: center; min-height: 28px; border: 1px solid #475569; background: #1e293b; color: #e2e8f0; border-radius: 4px; padding: 3px 9px; font-size: 12px; font-weight: 900; white-space: nowrap; }
    .status.warn { border-color: #a16207; background: #422006; color: var(--yellow); }
    .status.ok { color: #86efac; }
    .status.error { border-color: #991b1b; background: #3b121f; color: #fca5a5; }
    .confirm-overlay {
      position: fixed;
      inset: 0;
      z-index: 20000;
      display: grid;
      place-items: center;
      padding: 24px;
      background: rgba(2, 6, 23, .74);
    }
    .confirm-dialog {
      width: min(980px, 100%);
      max-height: calc(100vh - 48px);
      min-width: 0;
      max-width: 100%;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      border: 1px solid #475569;
      border-radius: 8px;
      background: #0b1220;
      color: #e5e7eb;
      box-shadow: 0 24px 70px rgba(0,0,0,.55);
      padding: 18px;
    }
    .confirm-dialog h2 { margin: 0 0 12px; font-size: 18px; }
    .confirm-dialog p { margin: 0 0 10px; line-height: 1.65; }
    .confirm-dialog label { display: grid; gap: 5px; margin: 10px 0; font-size: 12px; color: #cbd5e1; font-weight: 800; }
    .confirm-dialog select,
    .confirm-dialog input { min-height: 34px; border: 1px solid #334155; border-radius: 6px; background: #020617; color: #e5e7eb; padding: 5px 9px; font-weight: 800; }
    .confirm-device-list { min-height: 0; overflow: auto; display: grid; gap: 10px; margin: 6px 0 4px; padding: 2px; }
    .confirm-device-row { display: grid; grid-template-columns: minmax(150px, 1.2fr) minmax(150px, 1fr) minmax(120px, .8fr) minmax(280px, 1.7fr); gap: 10px; align-items: end; border: 1px solid #334155; border-radius: 7px; background: #020617; padding: 10px; }
    .confirm-device-row > * { min-width: 0; }
    .confirm-device-row select,
    .confirm-device-row input { max-width: 100%; }
    .confirm-device-identity { align-self: center; min-width: 0; }
    .confirm-device-identity strong,
    .confirm-device-identity span { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .confirm-device-identity strong { color: #fde68a; font-size: 14px; }
    .confirm-device-identity span { margin-top: 4px; color: #cbd5e1; font-size: 11px; }
    .confirm-device-row label { margin: 0; }
    .confirm-uptime-choice { display: grid; grid-template-columns: auto auto minmax(105px, 1fr); gap: 6px 10px; align-items: center; }
    .confirm-uptime-choice > span { grid-column: 1 / -1; color: #93c5fd; font-size: 12px; font-weight: 900; }
    .confirm-uptime-mode { display: inline-flex !important; grid-template-columns: none !important; align-items: center; gap: 5px !important; margin: 0 !important; white-space: nowrap; }
    .confirm-uptime-mode input { width: 16px; min-height: 16px; margin: 0; padding: 0; }
    .confirm-uptime-manual { display: flex; align-items: center; gap: 5px; min-width: 0; }
    .confirm-uptime-manual input { width: 100%; min-width: 78px; text-align: right; }
    .confirm-uptime-manual span { color: #cbd5e1; font-size: 11px; }
    .confirm-device-row.invalid { border-color: #ef4444; }
    .confirm-device-row input:invalid,
    .confirm-device-row input.input-error { border-color: #ef4444; outline: 2px solid rgba(239,68,68,.2); }
    .confirm-device-warning { color: #fca5a5 !important; }
    .confirm-actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 16px; }
    .confirm-actions .yes { border-color: #15803d; background: #14532d; }
    .confirm-actions .no { border-color: #64748b; background: #1e293b; }
    @media (max-width: 760px) {
      .confirm-overlay { padding: 10px; }
      .confirm-dialog { max-height: calc(100vh - 20px); padding: 12px; }
      .confirm-device-row { grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); }
      .confirm-uptime-choice { grid-column: 1 / -1; }
    }
    .tag-note { color: #a9b9ce; font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 330px; }
    .flow-note { display: flex; align-items: center; gap: 8px 14px; flex-wrap: wrap; overflow: visible; color: #a9b9ce; font-size: 11px; border-bottom: 1px solid var(--line-soft); background: #0d141e; padding: 5px 10px; line-height: 1.45; white-space: normal; }
    .flow-note-text { flex: 1 1 360px; min-width: 180px; }
    .flow-note-text::before { content: ">"; color: var(--yellow); margin-right: 6px; font-size: 9px; }
    body.embedded .flow-note { max-height: none; overflow: visible; }
    .device-search { display: flex; align-items: center; gap: 6px; flex: 0 1 auto; min-width: 0; margin-left: auto; }
    .device-search label { color: #e2e8f0; font-size: 12px; font-weight: 900; white-space: nowrap; }
    .device-search input { width: 118px; min-width: 76px; height: 30px; border: 1px solid #475569; border-radius: 4px; background: #020617; color: #f8fafc; padding: 4px 8px; font-size: 14px; font-weight: 900; font-variant-numeric: tabular-nums; }
    .device-search input:focus { border-color: var(--yellow); outline: 2px solid rgba(250,204,21,.24); outline-offset: 1px; }
    .device-search.not-found input { border-color: #ef4444; outline-color: rgba(239,68,68,.25); }
    .device-search button { min-height: 30px; height: 30px; padding: 3px 9px; }
    .device-search-result { min-width: 78px; color: #86efac; font-size: 11px; font-weight: 900; white-space: nowrap; }
    .device-search-result.error { color: #fca5a5; }
    .fleet-counts { display: inline-flex; align-items: center; gap: 5px; font-size: 11px; color: #cbd5e1; }
    .fleet-count { display: inline-flex; align-items: center; justify-content: center; min-height: 30px; padding: 3px 10px; border: 1px solid #303846; border-radius: 5px; background: #101720; font-size: 12px; font-variant-numeric: tabular-nums; font-weight: 900; white-space: nowrap; }
    .fleet-count.active { color: #bbf7d0; border-color: #166534; background: #0d2c1c; }
    .fleet-count.inactive { color: #fde68a; border-color: #92400e; background: #2a1d0b; }
    .fleet-count.sleeping { color: #ddd6fe; border-color: #5b21b6; background: #211b35; }
    .meta { color: var(--muted); margin-left: auto; font-size: 10px; white-space: nowrap; }
    .hint { display: none; }
    .device-editor {
      min-width: 0;
      display: grid;
      grid-template-columns: minmax(118px, 1.35fr) minmax(92px, .85fr) minmax(112px, 1fr) minmax(116px, 1fr) minmax(176px, 1.55fr) minmax(176px, 1.55fr) minmax(88px, .8fr);
      gap: 5px;
      align-items: end;
      padding: 6px 8px;
      border-bottom: 1px solid #263247;
      background: #121b27;
      box-shadow: inset 0 -1px 0 rgba(96,165,250,.09);
    }
    .device-editor[hidden] { display: none; }
    .device-editor-identity {
      min-width: 0;
      align-self: center;
      padding: 1px 5px;
    }
    .device-editor-identity strong,
    .device-editor-identity span { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .device-editor-identity strong { color: #fde68a; font-size: 15px; line-height: 1.25; }
    .device-editor-identity span { color: #94a3b8; font-size: 10px; line-height: 1.35; }
    .device-editor label { min-width: 0; display: grid; gap: 2px; color: #94a3b8; font-size: 9px; font-weight: 900; letter-spacing: .02em; }
    .device-editor select,
    .device-editor input[type="number"] {
      width: 100%;
      min-width: 0;
      height: 29px;
      border: 1px solid #334155;
      border-radius: 4px;
      background: #020617;
      color: #f8fafc;
      padding: 3px 6px;
      font-size: 12px;
      font-weight: 900;
      font-variant-numeric: tabular-nums;
    }
    .device-editor select:focus,
    .device-editor input[type="number"]:focus { border-color: var(--yellow); outline: 2px solid rgba(250,204,21,.2); }
    .editor-history-note { color: #fda4af; font-size: 9px; }
    .editor-task-control { min-width: 0; display: grid; grid-template-columns: minmax(0, 1fr) 43px; gap: 4px; }
    .editor-done-toggle {
      min-width: 0;
      min-height: 29px;
      height: 29px;
      padding: 3px 4px;
      border-color: #334155;
      background: #111827;
      color: #94a3b8;
      font-size: 10px;
    }
    .editor-done-toggle[aria-pressed="true"] { border-color: #0891b2; background: #155e75; color: #ecfeff; }
    .editor-backend-note { grid-column: 1 / -1; margin-top: -1px; color: #64748b; font-size: 8px; font-weight: 800; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .matrix-state-store { display: none !important; }
    .wrap { overflow-x: hidden; overflow-y: auto; border: 0; min-height: 0; height: 100%; background: var(--panel); scrollbar-gutter: stable both-edges; }
    .wrap::-webkit-scrollbar { width: 18px; height: 18px; }
    .wrap::-webkit-scrollbar-thumb { background: #64748b; border: 4px solid var(--panel); border-radius: 999px; }
    .wrap::-webkit-scrollbar-track { background: #080d14; }
    .matrix-grid { display: flex; flex-direction: column; gap: 0; padding: 0; }
    .matrix-section { width: 100%; overflow: hidden; border-bottom: 2px solid #080d14; background: #0d141e; }
    table { border-collapse: separate; border-spacing: 0; font-size: 13px; width: 100%; table-layout: fixed; }
    th, td { border-right: 1px solid #1b212c; border-bottom: 1px solid #1b212c; padding: 3px 3px; white-space: nowrap; text-align: center; }
    th { position: sticky; top: 0; z-index: 2; background: #1b2430; color: #f9fafb; border-bottom: 2px solid var(--yellow); }
    tbody tr:nth-child(2n) td { box-shadow: inset 0 1px 0 rgba(255,255,255,.015); }
    tbody tr:hover td { filter: brightness(1.18); }
    col.tag-col { width: 88px; }
    th.tag, td.tag { position: sticky; left: 0; z-index: 3; background: #172231; text-align: left; width: 88px; min-width: 88px; max-width: 88px; overflow: visible; white-space: normal; line-height: 1.08; box-shadow: 2px 0 0 #080d14; font-weight: 900; vertical-align: middle; }
    th.tag { z-index: 4; }
    td.tag { padding: 4px 6px 4px 8px; }
    .tag-label { display: block; white-space: normal; word-break: keep-all; }
    .tag-label .line { display: block; }
    .tag-label .sub { display: block; color: #dbeafe; font-size: 11px; font-variant-numeric: tabular-nums; margin-top: 1px; }
    .device-head { width: 60px; min-width: 60px; max-width: 60px; white-space: normal; line-height: 1.03; font-size: 9px; vertical-align: bottom; padding: 4px 2px; overflow: hidden; background: #22313a; cursor: pointer; }
    .device-head .id { display: block; color: #f8fafc; font-weight: 900; font-size: 12px; }
    .device-head .park { display: block; color: var(--yellow); font-weight: 900; font-size: 11px; font-variant-numeric: tabular-nums; }
    .device-head .name { display: block; color: #e5e7eb; overflow: hidden; text-overflow: ellipsis; }
    .device-head .conn { display: block; color: var(--muted); font-size: 9px; font-weight: 800; letter-spacing: .02em; }
    .device-head.offline-device { background: #3a1820; box-shadow: inset 0 3px 0 #ef4444; }
    .device-head.offline-device .id,
    .device-head.offline-device .conn { color: #fca5a5; }
    .device-head.sleeping-device { background: #24213d; box-shadow: inset 0 3px 0 #a78bfa; }
    .device-head.sleeping-device .id,
    .device-head.sleeping-device .conn { color: #c4b5fd; }
    .tag.group { background: #1f2937; color: #fde68a; border-left: 4px solid var(--yellow); }
    .tag.error { background: #3b121f; color: #fecaca; border-left: 4px solid #fb7185; }
    .tag.ci { background: #151f32; color: #bfdbfe; border-left: 4px solid #60a5fa; }
    .tag.task { background: #102a30; color: #99f6e4; border-left: 4px solid var(--cyan); }
    .tag.day { background: #211d37; color: #ddd6fe; border-left: 4px solid #a78bfa; }
    .tag.invite { background: #2c220f; color: #fde68a; border-left: 4px solid var(--yellow); }
    .tag.profit { background: #102617; color: #bbf7d0; border-left: 4px solid var(--green); }
    .tag.cycle { background: #1e2338; color: #c7d2fe; border-left: 4px solid #818cf8; }
    .checked { background: #1f2937; color: #e5e7eb; font-weight: 700; }
    .empty { color: #4b5563; }
    td.ci.empty { background: #172238; }
    td.ci.checked { background: #1e3a5f; color: #bfdbfe; }
    td.task.empty { background: #102a30; }
    td.task.checked { background: #12514b; color: #99f6e4; }
    td.day.empty { background: #1c1b31; }
    td.day.checked { background: #342d63; color: #ddd6fe; }
    td.invite.empty { background: #241c12; }
    td.invite.checked { background: #6b4b12; color: #fde68a; }
    td.profit.empty { background: #102617; }
    td.profit.checked { background: #166534; color: #bbf7d0; }
    td.cycle.empty { background: #1f2235; }
    td.cycle.checked { background: #3730a3; color: #c7d2fe; }
    td.error.empty { background: #2b151d; }
    td.error.checked { background: #4a1f2b; color: #fecaca; }
    td.group.empty { background: #1b2231; }
    td.group.checked { background: #5a4314; color: #fde68a; }
    td.group input[type="checkbox"] { accent-color: var(--yellow); }
    td.ci input[type="checkbox"] { accent-color: #60a5fa; }
    .ci-amount-editor { display: inline-flex; align-items: center; justify-content: center; gap: 2px; width: 100%; color: #bfdbfe; font-size: 11px; font-weight: 900; }
    .ci-amount-input { width: 54px; min-width: 0; height: 25px; border: 1px solid #3b82f6; border-radius: 4px; background: #08111f; color: #f8fafc; padding: 2px 3px; text-align: right; font-size: 12px; font-weight: 900; font-variant-numeric: tabular-nums; }
    .ci-amount-input:focus { border-color: var(--yellow); outline: 2px solid rgba(250,204,21,.24); outline-offset: 1px; }
    .ci-amount-input:invalid,
    .ci-amount-input.input-error { border-color: #ef4444; outline-color: rgba(239,68,68,.3); }
    td.ci.changed .ci-amount-input { border-color: var(--yellow); }
    td.task input[type="checkbox"] { accent-color: var(--cyan); }
    td.day input[type="checkbox"] { accent-color: #a78bfa; }
    td.error input[type="checkbox"] { accent-color: #fb7185; }
    td.profit input[type="checkbox"] { accent-color: var(--green); }
    td.cycle input[type="checkbox"] { accent-color: #818cf8; }
    td.offline-device,
    td.offline-device.empty { background: #2b151d; }
    td.offline-device.checked { background: #3f2022; color: #fecaca; }
    td.sleeping-device,
    td.sleeping-device.empty { background: #1e1b34; }
    td.sleeping-device.checked { background: #2c2854; color: #ddd6fe; }
    input[type="checkbox"] { width: 18px; height: 18px; accent-color: var(--yellow); cursor: pointer; filter: drop-shadow(0 1px 1px rgba(0,0,0,.45)); }
    td.empty input[type="checkbox"] { opacity: .42; }
    td.changed { outline: 2px solid var(--yellow); outline-offset: -2px; box-shadow: inset 0 0 0 1px rgba(250,204,21,.35); }
    td.dense-summary { height: 29px; padding: 2px; cursor: pointer; font-size: 10px; font-weight: 900; font-variant-numeric: tabular-nums; overflow: hidden; text-overflow: ellipsis; }
    td.dense-summary:hover { box-shadow: inset 0 0 0 1px rgba(250,204,21,.55); }
    td.dense-summary .dense-value { display: block; max-width: 100%; overflow: hidden; text-overflow: ellipsis; }
    th.selected-device,
    td.selected-device { position: relative; box-shadow: inset 2px 0 0 var(--yellow), inset -2px 0 0 var(--yellow); }
    th.selected-device { background: #26324a; }
    td.selected-device { filter: brightness(1.16); }
    td.dense-summary.changed { outline: 2px solid var(--yellow); outline-offset: -2px; }
    @media (max-width: 1050px) {
      .device-editor { grid-template-columns: minmax(118px, 1.2fr) repeat(3, minmax(100px, 1fr)); overflow-x: auto; }
      .device-editor > * { min-width: 100px; }
    }
    body.changes-settled td.changed { outline: none !important; }
    th.device-search-match, td.device-search-match { position: relative; }
    th.device-search-match::after, td.device-search-match::after { content: ""; position: absolute; inset: 0; z-index: 1; pointer-events: none; background: rgba(250,204,21,.12); box-shadow: inset 3px 0 0 var(--yellow), inset -3px 0 0 var(--yellow); }
    th.device-search-match::after { background: rgba(250,204,21,.2); box-shadow: inset 0 0 0 3px var(--yellow); }
  `;
  const clientMatrix = {
    tags: matrix.tags.map((tag) => ({
      tag,
      label: displayTagName(tag),
      klass: tagClass(tag),
      kind: tag === CHECKIN_AMOUNT_ROW ? 'ci-amount' : tag.startsWith('GROUP_') ? 'group' : 'tag',
    })),
    devices: matrix.devices.map((device) => ({
      managementId: device.managementId,
      displayId: device.displayId || device.managementId,
      name: shortDeviceName(device.deviceDisplayCode || device.name),
      serial: device.serial,
      park: parkingLabel(device),
      yen: formatCurrentYen(device),
      conn: connectionLabel(device),
      connectionClass: connectionClass(device),
      adbLastUptimeSeconds: device.adbLastUptimeSeconds,
      adbLastUptimeCheckedAt: device.adbLastUptimeCheckedAt,
      checkinTag: device.checkinTag,
      checkinAmountYen: device.checkinAmountYen,
      video180Amount: device.video180Amount,
      video10Amount: device.video10Amount,
      tags: device.tags,
    })),
  };
  const html = `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>チェック一覧</title>
${faviconLinks()}
<style>${styles}</style>
</head>
<body>
<div class="topbar">
<span class="fleet-counts" title="チェック一覧の表示台数">
<span class="fleet-count active">稼働 ${fleetCounts.active}台</span>
<span class="fleet-count inactive">非稼働 ${fleetCounts.inactive}台</span>
</span>
<button id="syncXiaowei" class="secondary">XiaoWei同期</button>
<button id="applyChanges" disabled>DBへ反映</button>
<span id="changeStatus" class="status">変更なし</span>
<span class="tag-note">チェック変更はDBへ反映してから、必要に応じてXiaoWeiへ同期します。</span>
<div class="meta">表示端末 ${matrix.devices.length}台 / チェック項目 ${matrix.tags.length}件 / ${escapeHtml(matrix.generatedAt)}</div>
</div>
<div class="flow-note">
<div class="flow-note-text">流れ: チェック変更 → DBへ反映 → XiaoWei同期。古い情報が残る時は画面更新してください。</div>
<form id="deviceSearchForm" class="device-search" role="search">
<label for="deviceSearchInput">端末番号</label>
<input id="deviceSearchInput" type="search" inputmode="text" autocomplete="off" placeholder="例: 25 / A-25" aria-describedby="deviceSearchResult">
<button id="deviceSearchSubmit" class="utility" type="submit">移動</button>
<button id="deviceSearchClear" type="button" disabled>解除</button>
<span id="deviceSearchResult" class="device-search-result" aria-live="polite"></span>
</form>
</div>
<section id="deviceEditor" class="device-editor" aria-label="選択端末のチェック編集" hidden>
  <div class="device-editor-identity">
    <strong id="deviceEditorTitle">端末を選択</strong>
    <span id="deviceEditorSubtitle">端末列またはセルを押すと編集できます</span>
  </div>
  <label>稼働状態
    <select id="editorFleetState">
      <option value="">未設定</option>
      <option value="active">稼働</option>
      <option value="inactive">非稼働</option>
    </select>
  </label>
  <label><span>ERROR <small id="editorErrorHistory" class="editor-history-note"></small></span>
    <select id="editorErrorState">
      <option value="">現在なし</option>
      <option value="current">エラー中</option>
    </select>
  </label>
  <label>チェックイン（円）
    <input id="editorCheckinAmount" type="number" min="1" max="${MAX_CHECKIN_YEN}" step="1" inputmode="numeric" placeholder="空欄">
  </label>
  <label>180分
    <span class="editor-task-control">
      <input id="editorVideo180Amount" type="number" min="1" max="999999" step="1" inputmode="numeric" list="editorVideo180Options" placeholder="P数">
      <datalist id="editorVideo180Options"><option value="7500"><option value="15000"><option value="22500"></datalist>
      <button id="editorVideo180Done" class="editor-done-toggle" type="button" aria-pressed="false">完了</button>
    </span>
  </label>
  <label>追加視聴
    <span class="editor-task-control">
      <input id="editorVideo10Amount" type="number" min="1" max="999999" step="1" inputmode="numeric" list="editorVideo10Options" placeholder="円">
      <datalist id="editorVideo10Options"><option value="1190"><option value="1438"><option value="2262"></datalist>
      <button id="editorVideo10Done" class="editor-done-toggle" type="button" aria-pressed="false">完了</button>
    </span>
  </label>
  <label>DAY
    <input id="editorDay" type="number" min="1" max="14" step="1" inputmode="numeric" placeholder="空欄">
  </label>
  <div class="editor-backend-note">金額・P数・DAYは直接入力できます。ERROR歴は履歴保護のため表示のみです。</div>
</section>
<div id="matrixStateStore" class="matrix-state-store" aria-hidden="true"></div>
<div class="wrap">
<div id="matrixGrid" class="matrix-grid"></div>
</div>
<script>
(() => {
  if (window.self !== window.top) document.body.classList.add('embedded');
  if (new URL(window.location.href).searchParams.get('generated') === '1') {
    window.history.replaceState(null, '', window.location.pathname);
  }
  const matrixData = ${scriptJson(clientMatrix)};
  const effectiveDeviceUptimeSeconds = ${effectiveDeviceUptimeSeconds.toString()};
  const uptimeHoursToSeconds = ${uptimeHoursToSeconds.toString()};
  const maxResetAmountYen = ${MAX_RESET_AMOUNT_YEN};
  const maxUptimeHours = ${MAX_UPTIME_HOURS};
  const normalizeTagBoardDeviceNumber = ${normalizeTagBoardDeviceNumber.toString()};
  const findTagBoardDeviceMatches = ${findTagBoardDeviceMatches.toString()};
  const wrap = document.querySelector('.wrap');
  const matrixGrid = document.querySelector('#matrixGrid');
  const syncButton = document.querySelector('#syncXiaowei');
  const applyButton = document.querySelector('#applyChanges');
  const status = document.querySelector('#changeStatus');
  const deviceSearchForm = document.querySelector('#deviceSearchForm');
  const deviceSearchInput = document.querySelector('#deviceSearchInput');
  const deviceSearchClear = document.querySelector('#deviceSearchClear');
  const deviceSearchResult = document.querySelector('#deviceSearchResult');
  const deviceEditor = document.querySelector('#deviceEditor');
  const deviceEditorTitle = document.querySelector('#deviceEditorTitle');
  const deviceEditorSubtitle = document.querySelector('#deviceEditorSubtitle');
  const editorFleetState = document.querySelector('#editorFleetState');
  const editorErrorState = document.querySelector('#editorErrorState');
  const editorErrorHistory = document.querySelector('#editorErrorHistory');
  const editorCheckinAmount = document.querySelector('#editorCheckinAmount');
  const editorVideo180Amount = document.querySelector('#editorVideo180Amount');
  const editorVideo180Done = document.querySelector('#editorVideo180Done');
  const editorVideo10Amount = document.querySelector('#editorVideo10Amount');
  const editorVideo10Done = document.querySelector('#editorVideo10Done');
  const editorDay = document.querySelector('#editorDay');
  const matrixStateStore = document.querySelector('#matrixStateStore');
  const applyEndpoint = '/api/tag-board/tags/apply';
  const syncEndpoint = '/api/xiaowei/sync';
  const tagWidth = 88;
  const deviceWidth = 60;
  const denseRows = [
    { key: 'fleet', label: '稼働状態', klass: 'group' },
    { key: 'error', label: 'ERROR', klass: 'error' },
    { key: 'checkin', label: 'チェックイン', klass: 'ci' },
    { key: 'video180', label: '180分', klass: 'task' },
    { key: 'video10', label: '追加視聴', klass: 'task' },
    { key: 'day', label: 'DAY', klass: 'day' },
  ];
  const buttonHelpTexts = {
    syncXiaowei: 'DBへ反映してからXiaoWeiへ同期します。',
    applyChanges: 'チェック変更だけをローカルDBへ保存します。',
    deviceSearchSubmit: '表示中の端末番号へ移動して、列全体を強調します。',
    deviceSearchClear: '番号検索の強調を解除します。',
  };
  const checkboxState = new Map();
  const checkinAmountState = new Map();
  const taskAmountState = new Map();
  let selectedDeviceSerial = '';
  let editorUpdating = false;
  let busy = false;
  let suppressChanged = false;

  function cellKey(serial, tag) {
    return serial + '::' + tag;
  }

  function initButtonHelp() {
    const popup = document.createElement('div');
    popup.id = 'buttonHelpPopup';
    popup.className = 'button-help-popover';
    popup.setAttribute('role', 'tooltip');
    popup.hidden = true;
    document.body.appendChild(popup);
    let activeButton = null;

    function show(button) {
      const text = button && buttonHelpTexts[button.id];
      if (!text) return;
      activeButton = button;
      popup.textContent = text;
      popup.hidden = false;
      positionButtonHelp(button, popup);
    }

    function hide() {
      activeButton = null;
      popup.hidden = true;
    }

    document.addEventListener('pointerover', (event) => {
      const button = event.target.closest('button');
      if (button) show(button);
    });
    document.addEventListener('pointerout', (event) => {
      if (!activeButton) return;
      const next = event.relatedTarget;
      if (next && activeButton.contains(next)) return;
      hide();
    });
    document.addEventListener('focusin', (event) => {
      const button = event.target.closest('button');
      if (button) show(button);
    });
    document.addEventListener('focusout', hide);
    document.addEventListener('click', hide);
    window.addEventListener('scroll', hide, true);
    window.addEventListener('resize', hide);
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') hide();
    });
  }

  function positionButtonHelp(button, popup) {
    const rect = button.getBoundingClientRect();
    const gap = 8;
    const maxWidth = Math.min(360, window.innerWidth - 18);
    popup.style.maxWidth = maxWidth + 'px';
    popup.style.left = '0px';
    popup.style.top = '0px';
    const width = popup.offsetWidth;
    const height = popup.offsetHeight;
    let left = rect.left + rect.width / 2 - width / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
    let top = rect.bottom + gap;
    if (top + height > window.innerHeight - 8) top = rect.top - height - gap;
    popup.style.left = left + 'px';
    popup.style.top = Math.max(8, top) + 'px';
  }

  function changedInputs() {
    const checkboxes = [...document.querySelectorAll('input[type="checkbox"]')]
      .filter(input => input.checked !== (input.dataset.original === '1'));
    const amounts = [...document.querySelectorAll('.ci-amount-input')]
      .filter(input => input.value.trim() !== (input.dataset.original || ''));
    const taskAmounts = [];
    for (const device of matrixData.devices) {
      for (const kind of ['video180', 'video10']) {
        if (currentTaskAmount(device, kind) !== originalTaskAmount(device, kind)) {
          taskAmounts.push({ device, kind });
        }
      }
    }
    return [...checkboxes, ...amounts, ...taskAmounts];
  }

  function checkinAmountValue(input) {
    const text = String(input && input.value || '').trim();
    if (!text) return 0;
    if (!/^\\d{1,6}$/.test(text)) return -1;
    const amount = Number(text);
    return Number.isInteger(amount) && amount >= 1 && amount <= ${MAX_CHECKIN_YEN} ? amount : -1;
  }

  function invalidCheckinInputs() {
    return [...document.querySelectorAll('.ci-amount-input')]
      .filter((input) => Boolean(input.validity && input.validity.badInput) || checkinAmountValue(input) < 0);
  }

  function invalidDenseEditorInputs() {
    return [editorCheckinAmount, editorVideo180Amount, editorVideo10Amount, editorDay]
      .filter((input) => input && input.validationMessage);
  }

  function escapeText(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    }[char]));
  }

  function tagLabelTextHtml(value) {
    const parts = String(value ?? '').trim().split(/\s+/).filter(Boolean);
    if (parts.length >= 2) {
      return '<span class="tag-label"><span class="line">' + escapeText(parts[0]) + '</span><span class="sub">' + escapeText(parts.slice(1).join(' ')) + '</span></span>';
    }
    return '<span class="tag-label"><span class="line">' + escapeText(value) + '</span></span>';
  }

  function currentChecked(device, tag) {
    const key = cellKey(device.serial, tag.tag);
    if (checkboxState.has(key)) return checkboxState.get(key);
    return Boolean(device.tags && device.tags[tag.tag]);
  }

  function currentCheckinAmount(device) {
    if (checkinAmountState.has(device.serial)) return checkinAmountState.get(device.serial);
    return device.checkinAmountYen ? String(device.checkinAmountYen) : '';
  }

  function clearDeviceSearchHighlight() {
    for (const element of document.querySelectorAll('.device-search-match')) {
      element.classList.remove('device-search-match');
    }
  }

  function applyDeviceSearch(options = {}) {
    const shouldScroll = Boolean(options.scroll);
    const behavior = options.behavior === 'auto' ? 'auto' : 'smooth';
    const rawQuery = deviceSearchInput.value;
    clearDeviceSearchHighlight();
    deviceSearchForm.classList.remove('not-found');
    deviceSearchInput.removeAttribute('aria-invalid');
    deviceSearchClear.disabled = !rawQuery.trim();

    if (!rawQuery.trim()) {
      deviceSearchResult.textContent = '';
      deviceSearchResult.className = 'device-search-result';
      return;
    }

    const result = findTagBoardDeviceMatches(matrixData.devices, rawQuery);
    if (!result.ok) {
      deviceSearchForm.classList.add('not-found');
      deviceSearchInput.setAttribute('aria-invalid', 'true');
      deviceSearchResult.textContent = result.error === 'not_found'
        ? result.number + '番はありません'
        : '番号を確認';
      deviceSearchResult.className = 'device-search-result error';
      return;
    }

    const selector = '[data-device-number="' + result.number + '"]';
    for (const element of document.querySelectorAll(selector)) {
      element.classList.add('device-search-match');
    }
    deviceSearchResult.textContent = result.number + '番を表示';
    deviceSearchResult.className = 'device-search-result';

    if (!shouldScroll) return;
    const header = document.querySelector('.device-head' + selector);
    const section = header && header.closest('.matrix-section');
    if (!section) return;
    const wrapRect = wrap.getBoundingClientRect();
    const sectionRect = section.getBoundingClientRect();
    const top = Math.max(0, wrap.scrollTop + sectionRect.top - wrapRect.top);
    if (typeof wrap.scrollTo === 'function') {
      wrap.scrollTo({ top, behavior });
    } else {
      wrap.scrollTop = top;
    }
  }

  function bindDeviceSearch() {
    deviceSearchForm.addEventListener('submit', (event) => {
      event.preventDefault();
      applyDeviceSearch({ scroll: true });
    });
    deviceSearchInput.addEventListener('input', () => {
      applyDeviceSearch({ scroll: false });
    });
    deviceSearchInput.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        if (event.isComposing) return;
        event.preventDefault();
        applyDeviceSearch({ scroll: true });
        return;
      }
      if (event.key !== 'Escape') return;
      event.preventDefault();
      deviceSearchInput.value = '';
      applyDeviceSearch({ scroll: false });
    });
    deviceSearchClear.addEventListener('click', () => {
      deviceSearchInput.value = '';
      applyDeviceSearch({ scroll: false });
      deviceSearchInput.focus();
    });
  }

  function renderStateStore() {
    matrixStateStore.innerHTML = matrixData.devices.map((device) =>
      matrixData.tags.map((tag) => {
        if (tag.kind === 'ci-amount') {
          const amount = currentCheckinAmount(device);
          const originalAmount = device.checkinAmountYen ? String(device.checkinAmountYen) : '';
          return '<input class="ci-amount-input" type="number" min="1" max="${MAX_CHECKIN_YEN}" step="1"' +
            ' value="' + escapeText(amount) + '" data-serial="' + escapeText(device.serial) + '" data-management-id="' + escapeText(device.managementId) + '"' +
            ' data-original="' + escapeText(originalAmount) + '" data-original-tag="' + escapeText(device.checkinTag || '') + '">';
        }
        const checked = currentChecked(device, tag);
        const original = Boolean(device.tags && device.tags[tag.tag]);
        return '<input type="checkbox" data-serial="' + escapeText(device.serial) + '" data-management-id="' + escapeText(device.managementId) + '"' +
          ' data-tag="' + escapeText(tag.tag) + '" data-kind="' + escapeText(tag.kind) + '" data-original="' + (original ? '1' : '0') + '"' +
          (checked ? ' checked' : '') + '>';
      }).join('')
    ).join('');
    bindCheckboxes();
    bindCheckinAmountInputs();
  }

  function currentTagValue(device, tagName) {
    return currentChecked(device, { tag: tagName });
  }

  function tagChanged(device, tagName) {
    return currentTagValue(device, tagName) !== Boolean(device.tags && device.tags[tagName]);
  }

  function anyTagChanged(device, tagNames) {
    return tagNames.some((tagName) => tagChanged(device, tagName));
  }

  function compactNumber(value) {
    const amount = Number(value || 0);
    if (!amount) return '';
    if (amount >= 1000) {
      const rounded = Math.round(amount / 100) / 10;
      return String(rounded).replace(/\\.0$/, '') + 'k';
    }
    return String(amount);
  }

  function taskAmountKey(device, kind) {
    return device.serial + '::' + kind;
  }

  function originalTaskAmount(device, kind) {
    const value = kind === 'video180' ? device.video180Amount : device.video10Amount;
    const amount = Number(value || 0);
    return Number.isSafeInteger(amount) && amount > 0 ? amount : 0;
  }

  function currentTaskAmount(device, kind) {
    const key = taskAmountKey(device, kind);
    if (taskAmountState.has(key)) return taskAmountState.get(key);
    return originalTaskAmount(device, kind);
  }

  function setTaskAmount(device, kind, value) {
    const text = String(value ?? '').trim();
    const amount = text ? Number(text) : 0;
    if (text && (!Number.isSafeInteger(amount) || amount < 1 || amount > 999999)) return false;
    const original = originalTaskAmount(device, kind);
    const key = taskAmountKey(device, kind);
    if (amount === original) taskAmountState.delete(key);
    else taskAmountState.set(key, amount);
    refreshChangeCount();
    return true;
  }

  function selectedDay(device) {
    for (let day = 1; day <= 14; day += 1) {
      if (currentTagValue(device, 'DAY_' + String(day).padStart(2, '0'))) return day;
    }
    return '';
  }

  function denseSummary(device, rowKey) {
    if (rowKey === 'fleet') {
      const active = currentTagValue(device, 'GROUP_ACTIVE');
      const inactive = currentTagValue(device, 'GROUP_INACTIVE');
      return {
        text: active ? '稼働' : inactive ? '休' : '—',
        checked: active || inactive,
        changed: anyTagChanged(device, ['GROUP_ACTIVE', 'GROUP_INACTIVE']),
      };
    }
    if (rowKey === 'error') {
      const current = currentTagValue(device, 'STATE_ERROR');
      const history = currentTagValue(device, 'STATE_ERROR_HISTORY');
      return {
        text: current && history ? '中歴' : current ? '中' : history ? '歴' : '—',
        checked: current || history,
        changed: anyTagChanged(device, ['STATE_ERROR', 'STATE_ERROR_HISTORY']),
      };
    }
    if (rowKey === 'checkin') {
      const amount = currentCheckinAmount(device);
      const original = device.checkinAmountYen ? String(device.checkinAmountYen) : '';
      return {
        text: amount ? compactNumber(amount) : '—',
        checked: Boolean(amount),
        changed: amount !== original,
      };
    }
    if (rowKey === 'video180') {
      const amount = currentTaskAmount(device, 'video180');
      const done = currentTagValue(device, 'V180_DONE');
      return {
        text: done ? '✓' + compactNumber(amount) : amount ? '▶' + compactNumber(amount) : '—',
        checked: done || Boolean(amount),
        changed: amount !== originalTaskAmount(device, 'video180') || tagChanged(device, 'V180_DONE'),
      };
    }
    if (rowKey === 'video10') {
      const amount = currentTaskAmount(device, 'video10');
      const done = currentTagValue(device, 'V10_DONE');
      return {
        text: done ? '✓' + compactNumber(amount) : amount ? '▶' + compactNumber(amount) : '—',
        checked: done || Boolean(amount),
        changed: amount !== originalTaskAmount(device, 'video10') || tagChanged(device, 'V10_DONE'),
      };
    }
    const day = selectedDay(device);
    const dayTags = Array.from({ length: 14 }, (_, index) => 'DAY_' + String(index + 1).padStart(2, '0'));
    return {
      text: day ? String(day) : '—',
      checked: Boolean(day),
      changed: anyTagChanged(device, dayTags),
    };
  }

  function renderDenseCell(device, row) {
    const summary = denseSummary(device, row.key);
    const selected = selectedDeviceSerial === device.serial;
    return '<td class="dense-summary ' + (summary.checked ? 'checked' : 'empty') + ' ' + escapeText(row.klass) + ' ' +
      escapeText(device.connectionClass) + (summary.changed ? ' changed' : '') + (selected ? ' selected-device' : '') + '"' +
      ' data-device-number="' + escapeText(device.displayId) + '" data-device-serial="' + escapeText(device.serial) + '"' +
      ' data-editor-field="' + escapeText(row.key) + '" title="' + escapeText((device.displayId || device.managementId) + ' / ' + row.label) + '">' +
      '<span class="dense-value">' + escapeText(summary.text) + '</span></td>';
  }

  function renderMatrix() {
    if (!wrap || !matrixGrid || !matrixStateStore) return;
    renderStateStore();
    const available = Math.max(180, wrap.clientWidth - 18);
    const columns = Math.max(1, Math.floor((available - tagWidth) / deviceWidth));
    const chunks = [];
    for (let i = 0; i < matrixData.devices.length; i += columns) {
      chunks.push(matrixData.devices.slice(i, i + columns));
    }

    matrixGrid.innerHTML = chunks.map((devices) => {
      const colgroup = '<col class="tag-col">' + devices.map(() => '<col>').join('');
      const head = '<tr><th class="tag">チェック</th>' + devices.map((device) =>
        '<th class="device-head ' + escapeText(device.connectionClass) + (selectedDeviceSerial === device.serial ? ' selected-device' : '') + '"' +
        ' data-device-number="' + escapeText(device.displayId) + '" data-device-serial="' + escapeText(device.serial) + '" data-editor-field="fleet">' +
        '<span class="id">' + escapeText(device.displayId || device.managementId) + '</span>' +
        '<span class="park">' + escapeText(device.park) + '</span>' +
        '<span class="name">' + escapeText(device.name) + '</span>' +
        '<span class="conn">' + escapeText(device.conn) + '</span>' +
        '</th>'
      ).join('') + '</tr>';
      const body = denseRows.map((row) => '<tr>' +
        '<td class="tag ' + escapeText(row.klass) + '">' + tagLabelTextHtml(row.label) + '</td>' +
        devices.map((device) => renderDenseCell(device, row)).join('') +
      '</tr>').join('');
      return '<section class="matrix-section"><table><colgroup>' + colgroup + '</colgroup><thead>' + head + '</thead><tbody>' + body + '</tbody></table></section>';
    }).join('');

    matrixGrid.onclick = (event) => {
      const target = event.target.closest('[data-device-serial]');
      if (!target) return;
      selectDevice(target.dataset.deviceSerial, target.dataset.editorField || '');
    };
    refreshChangeCount();
    populateDeviceEditor();
    applyDeviceSearch({ scroll: Boolean(deviceSearchInput.value.trim()), behavior: 'auto' });
  }

  function stateCheckbox(device, tagName) {
    if (!device || !tagName) return null;
    return matrixStateStore.querySelector(
      'input[type="checkbox"][data-serial="' + CSS.escape(device.serial) + '"][data-tag="' + CSS.escape(tagName) + '"]'
    );
  }

  function setDeviceTag(device, tagName, checked) {
    const input = stateCheckbox(device, tagName);
    if (!input || input.checked === Boolean(checked)) return;
    input.checked = Boolean(checked);
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function setExclusiveTags(device, tagNames, selectedTag) {
    for (const tagName of tagNames) {
      setDeviceTag(device, tagName, tagName === selectedTag);
    }
  }

  function selectedDevice() {
    return matrixData.devices.find((device) => device.serial === selectedDeviceSerial) || null;
  }

  function selectDevice(serial, field) {
    selectedDeviceSerial = String(serial || '');
    renderMatrix();
    const focusTargets = {
      fleet: editorFleetState,
      error: editorErrorState,
      checkin: editorCheckinAmount,
      video180: editorVideo180Amount,
      video10: editorVideo10Amount,
      day: editorDay,
    };
    const focusTarget = focusTargets[field];
    if (focusTarget) focusTarget.focus({ preventScroll: true });
  }

  function setDoneButton(button, pressed) {
    button.setAttribute('aria-pressed', pressed ? 'true' : 'false');
  }

  function populateDeviceEditor() {
    const device = selectedDevice();
    deviceEditor.hidden = !device;
    if (!device) return;
    editorUpdating = true;
    deviceEditorTitle.textContent = (device.displayId || device.managementId) + ' / ' + (device.name || '端末');
    deviceEditorSubtitle.textContent = [device.park, device.conn].filter(Boolean).join(' / ') || device.serial;
    editorFleetState.value = currentTagValue(device, 'GROUP_ACTIVE')
      ? 'active'
      : currentTagValue(device, 'GROUP_INACTIVE') ? 'inactive' : '';
    const errorCurrent = currentTagValue(device, 'STATE_ERROR');
    const errorHistory = currentTagValue(device, 'STATE_ERROR_HISTORY');
    editorErrorState.value = errorCurrent ? 'current' : '';
    editorErrorHistory.textContent = errorHistory ? '履歴あり' : '履歴なし';
    editorCheckinAmount.value = currentCheckinAmount(device);
    editorCheckinAmount.setCustomValidity('');
    editorVideo180Amount.value = currentTaskAmount(device, 'video180') || '';
    editorVideo180Amount.setCustomValidity('');
    setDoneButton(editorVideo180Done, currentTagValue(device, 'V180_DONE'));
    editorVideo10Amount.value = currentTaskAmount(device, 'video10') || '';
    editorVideo10Amount.setCustomValidity('');
    setDoneButton(editorVideo10Done, currentTagValue(device, 'V10_DONE'));
    editorDay.value = selectedDay(device);
    editorDay.setCustomValidity('');
    editorUpdating = false;
  }

  function refreshSelectedDeviceView() {
    const device = selectedDevice();
    if (!device) return;
    for (const cell of matrixGrid.querySelectorAll('[data-device-serial="' + CSS.escape(device.serial) + '"][data-editor-field]')) {
      if (cell.matches('th')) continue;
      const rowKey = cell.dataset.editorField;
      const row = denseRows.find((item) => item.key === rowKey);
      if (!row) continue;
      const summary = denseSummary(device, rowKey);
      cell.classList.toggle('checked', summary.checked);
      cell.classList.toggle('empty', !summary.checked);
      cell.classList.toggle('changed', summary.changed);
      const value = cell.querySelector('.dense-value');
      if (value) value.textContent = summary.text;
    }
    populateDeviceEditor();
  }

  function bindDeviceEditor() {
    editorFleetState.addEventListener('change', () => {
      if (editorUpdating) return;
      const device = selectedDevice();
      if (!device) return;
      const selected = editorFleetState.value === 'active'
        ? 'GROUP_ACTIVE'
        : editorFleetState.value === 'inactive' ? 'GROUP_INACTIVE' : '';
      setExclusiveTags(device, ['GROUP_ACTIVE', 'GROUP_INACTIVE'], selected);
      refreshSelectedDeviceView();
    });
    editorErrorState.addEventListener('change', () => {
      if (editorUpdating) return;
      const device = selectedDevice();
      if (!device) return;
      const value = editorErrorState.value;
      setDeviceTag(device, 'STATE_ERROR', value === 'current');
      refreshSelectedDeviceView();
    });
    editorCheckinAmount.addEventListener('input', () => {
      if (editorUpdating) return;
      const device = selectedDevice();
      if (!device) return;
      const input = matrixStateStore.querySelector('.ci-amount-input[data-serial="' + CSS.escape(device.serial) + '"]');
      if (!input) return;
      input.value = editorCheckinAmount.value.trim();
      input.dispatchEvent(new Event('input', { bubbles: true }));
      editorCheckinAmount.setCustomValidity(checkinAmountValue(input) < 0 ? '1〜${MAX_CHECKIN_YEN}の整数、または空欄' : '');
      refreshSelectedDeviceView();
    });
    editorVideo180Amount.addEventListener('input', () => {
      if (editorUpdating) return;
      const device = selectedDevice();
      if (!device) return;
      const valid = setTaskAmount(device, 'video180', editorVideo180Amount.value);
      editorVideo180Amount.setCustomValidity(valid ? '' : '1〜999999の整数、または空欄');
      if (!valid) return;
      refreshSelectedDeviceView();
    });
    editorVideo10Amount.addEventListener('input', () => {
      if (editorUpdating) return;
      const device = selectedDevice();
      if (!device) return;
      const valid = setTaskAmount(device, 'video10', editorVideo10Amount.value);
      editorVideo10Amount.setCustomValidity(valid ? '' : '1〜999999の整数、または空欄');
      if (!valid) return;
      refreshSelectedDeviceView();
    });
    editorVideo180Done.addEventListener('click', () => {
      const device = selectedDevice();
      if (!device) return;
      setDeviceTag(device, 'V180_DONE', editorVideo180Done.getAttribute('aria-pressed') !== 'true');
      refreshSelectedDeviceView();
    });
    editorVideo10Done.addEventListener('click', () => {
      const device = selectedDevice();
      if (!device) return;
      setDeviceTag(device, 'V10_DONE', editorVideo10Done.getAttribute('aria-pressed') !== 'true');
      refreshSelectedDeviceView();
    });
    editorDay.addEventListener('change', () => {
      if (editorUpdating) return;
      const device = selectedDevice();
      if (!device) return;
      const text = editorDay.value.trim();
      const day = text ? Number(text) : 0;
      const valid = !text || (Number.isInteger(day) && day >= 1 && day <= 14);
      editorDay.setCustomValidity(valid ? '' : 'DAYは1〜14、または空欄');
      if (!valid) {
        editorDay.reportValidity();
        return;
      }
      const dayTags = Array.from({ length: 14 }, (_, index) => 'DAY_' + String(index + 1).padStart(2, '0'));
      const selected = day ? 'DAY_' + String(day).padStart(2, '0') : '';
      setExclusiveTags(device, dayTags, selected);
      refreshSelectedDeviceView();
    });
  }

  function updateStatus(message, klass = '') {
    status.textContent = message;
    status.className = ['status', klass].filter(Boolean).join(' ');
  }

  function refreshStatusText(result) {
    const refresh = result && result.refresh;
    const sheets = refresh && refresh.sheets;
    const names = refresh && refresh.displayNames;
    const numbers = refresh && refresh.numbers;
    const sheetsJson = sheets && sheets.json;
    if (!refresh) return 'DB反映OK';
    const nameText = names && names.ok ? ' / 名前同期OK' : names ? ' / 名前同期NG' : '';
    const disconnectedText = numbers && Number(numbers.disconnectedMatched || 0) > 0
      ? ' / 未接続' + numbers.disconnectedMatched + '台も強制確認（変更' + (numbers.disconnectedRequested || 0) + '・成功' + (numbers.disconnectedSucceeded || 0) + '）' + (numbers.xiaoweiRestartRecommended ? '・XiaoWei再起動で表示反映' : '')
      : '';
    if (!sheets) return 'DB反映OK' + nameText + disconnectedText + ' / Sheets未実行';
    if (!sheets.ok) return 'DB反映OK' + nameText + disconnectedText + ' / Sheets失敗';
    if (sheetsJson && sheetsJson.synced) return 'DB反映OK' + nameText + disconnectedText + ' / Sheets同期OK';
    if (sheetsJson && sheetsJson.queued) return 'DB反映OK' + nameText + disconnectedText + ' / Sheets待機: ' + (sheetsJson.reason || 'queued');
    if (sheetsJson && sheetsJson.skipped) return 'DB反映OK' + nameText + disconnectedText + ' / Sheetsスキップ: ' + (sheetsJson.reason || 'skipped');
    return 'DB反映OK' + nameText + disconnectedText + ' / Sheets状態不明';
  }

  function refreshChangeCount() {
    if (suppressChanged) clearChangedCells();
    const count = changedInputs().length;
    const invalidCount = invalidCheckinInputs().length;
    const invalidEditorCount = invalidDenseEditorInputs().length;
    applyButton.disabled = busy || count === 0 || invalidCount > 0 || invalidEditorCount > 0;
    syncButton.disabled = busy;
    if (invalidEditorCount) {
      updateStatus('選択端末の入力値を確認してください', 'error');
      return;
    }
    if (invalidCount) {
      updateStatus('チェックイン金額は1〜${MAX_CHECKIN_YEN}の整数、または空欄にしてください', 'error');
      return;
    }
    updateStatus(count ? count + '件の変更あり' : '変更なし', count ? 'warn' : '');
  }

  function findDeviceForChange(change) {
    return matrixData.devices.find((device) =>
      String(device.serial || '') === String(change.serial || '') ||
      String(device.managementId || '') === String(change.managementId || '')
    ) || null;
  }

  function resetCandidatesFromChanges(changes) {
    const seen = new Set();
    const candidates = [];
    for (const change of changes) {
      if (change.tag !== 'GROUP_INACTIVE' || !change.checked) continue;
      const key = change.serial || change.managementId;
      if (!key || seen.has(key)) continue;
      seen.add(key);
      const device = findDeviceForChange(change);
      candidates.push({
        serial: change.serial || '',
        managementId: change.managementId || '',
        expectedCycleId: device && device.cycleId || '',
        displayId: device && (device.displayId || device.managementId) || '',
        name: device && device.name || '',
        conn: device && device.conn || '',
        adbLastUptimeSeconds: device ? device.adbLastUptimeSeconds : null,
        adbLastUptimeCheckedAt: device ? device.adbLastUptimeCheckedAt : '',
        label: device
          ? [device.displayId || device.managementId, device.name, device.conn].filter(Boolean).join(' ')
          : key,
      });
    }
    return candidates;
  }

  function resetCandidateWithUptime(candidate, device) {
    const source = device || candidate || {};
    const uptimeSeconds = effectiveDeviceUptimeSeconds(
      source.adbLastUptimeSeconds,
      source.adbLastUptimeCheckedAt,
      Date.now()
    );
    return {
      ...candidate,
      expectedCycleId: source.cycleId || candidate.expectedCycleId || '',
      adbLastUptimeSeconds: source.adbLastUptimeSeconds,
      adbLastUptimeCheckedAt: source.adbLastUptimeCheckedAt || '',
      uptimeSeconds,
    };
  }

  async function refreshResetCandidateUptimes(candidates) {
    let summaryDevices = [];
    try {
      const response = await fetch('/api/fleet-db/summary', { cache: 'no-store' });
      const result = await response.json();
      if (response.ok && result && result.ok && Array.isArray(result.devices)) summaryDevices = result.devices;
    } catch (_) {
      // The generated checklist snapshot remains a safe display fallback.
    }
    return candidates.map((candidate) => {
      const current = summaryDevices.find((device) =>
        String(device.serial || '') === String(candidate.serial || '') ||
        String(device.managementId || '') === String(candidate.managementId || '')
      );
      return resetCandidateWithUptime(candidate, current || candidate);
    });
  }

  function resetUptimeDisplay(seconds) {
    if (seconds === null || seconds === undefined || seconds === '' || !Number.isFinite(Number(seconds)) || Number(seconds) < 0) {
      return '未取得（手入力してください）';
    }
    const hours = Number(seconds) / 3600;
    return hours.toFixed(1) + '時間 / ' + (hours / 24).toFixed(1) + '日';
  }

  function resetConfirmationRowValue(row, candidate) {
    const reason = row.querySelector('.reset-reason-select').value;
    const amountInput = row.querySelector('.reset-amount-input');
    const amountText = amountInput.value.trim();
    const amountYen = amountText ? Number(amountText) : 0;
    const uptimeMode = row.querySelector('.reset-uptime-mode:checked')?.value || '';
    const manualInput = row.querySelector('.reset-uptime-hours');
    const manualUptimeSeconds = uptimeMode === 'manual' ? uptimeHoursToSeconds(manualInput.value) : null;
    const amountValid = Number.isSafeInteger(amountYen) && amountYen >= 0 && amountYen <= maxResetAmountYen;
    const displayedAvailable = candidate.uptimeSeconds !== null && candidate.uptimeSeconds !== undefined && candidate.uptimeSeconds !== ''
      && Number.isFinite(Number(candidate.uptimeSeconds)) && Number(candidate.uptimeSeconds) >= 0;
    const uptimeValid = uptimeMode === 'displayed'
      ? displayedAvailable
      : uptimeMode === 'manual' && manualUptimeSeconds !== null && !manualInput.validity.badInput;
    amountInput.classList.toggle('input-error', !amountValid);
    manualInput.classList.toggle('input-error', uptimeMode === 'manual' && !uptimeValid);
    return {
      ok: Boolean(reason) && amountValid && uptimeValid,
      serial: candidate.serial,
      managementId: candidate.managementId,
      expectedCycleId: candidate.expectedCycleId || '',
      reason,
      amountYen,
      uptimeMode,
      manualUptimeSeconds,
    };
  }

  async function showInactiveResetConfirm(inputCandidates) {
    if (!inputCandidates.length) return [];
    const candidates = await refreshResetCandidateUptimes(inputCandidates);
    return new Promise((resolve) => {
      let closed = false;
      const overlay = document.createElement('div');
      overlay.className = 'confirm-overlay';
      overlay.innerHTML =
        '<div class="confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="inactiveResetDialogTitle">' +
        '<h2 id="inactiveResetDialogTitle">非稼働へ反映する ' + candidates.length + '台を確認</h2>' +
        '<p>現在のチェック状態を履歴に保存し、タスクとDAYを外して非稼働だけ残します。出金額が1円以上なら出金履歴へ自動登録し、月間収益にも自動反映します。0円はリセット履歴のみ保存します。</p>' +
        '<p>UPTIMEはDB表示どおりが初期値です。違う端末だけ「手入力」を選んで補正してください。</p>' +
        '<div class="confirm-device-list">' +
        candidates.map((item, index) => {
          const displayedAvailable = item.uptimeSeconds !== null && item.uptimeSeconds !== undefined && item.uptimeSeconds !== ''
            && Number.isFinite(Number(item.uptimeSeconds)) && Number(item.uptimeSeconds) >= 0;
          const initialHours = displayedAvailable ? (Number(item.uptimeSeconds) / 3600).toFixed(1) : '';
          return '<section class="confirm-device-row" data-reset-index="' + index + '">' +
            '<div class="confirm-device-identity"><strong>' + escapeText(item.displayId || item.managementId || item.serial) + '</strong>' +
            '<span title="' + escapeText(item.label) + '">' + escapeText([item.name, item.conn].filter(Boolean).join(' / ') || item.serial) + '</span></div>' +
            '<label>理由<select class="reset-reason-select">' +
            '<option value="withdrawal_reset">出金後リセット</option>' +
            '<option value="error_reset">エラーが出たのでリセット</option>' +
            '</select></label>' +
            '<label>出金額（円）<input class="reset-amount-input" type="number" min="0" max="' + maxResetAmountYen + '" step="1" inputmode="numeric" placeholder="任意"></label>' +
            '<div class="confirm-uptime-choice">' +
            '<span class="' + (displayedAvailable ? '' : 'confirm-device-warning') + '">DB表示: ' + escapeText(resetUptimeDisplay(item.uptimeSeconds)) + '</span>' +
            '<label class="confirm-uptime-mode"><input class="reset-uptime-mode" type="radio" name="resetUptimeMode' + index + '" value="displayed" ' + (displayedAvailable ? 'checked' : 'disabled') + '>表示どおり</label>' +
            '<label class="confirm-uptime-mode"><input class="reset-uptime-mode" type="radio" name="resetUptimeMode' + index + '" value="manual" ' + (displayedAvailable ? '' : 'checked') + '>手入力</label>' +
            '<label class="confirm-uptime-manual"><input class="reset-uptime-hours" type="number" min="0" max="' + maxUptimeHours + '" step="0.1" inputmode="decimal" value="' + initialHours + '" ' + (displayedAvailable ? 'disabled' : '') + ' aria-label="手入力UPTIME"><span>時間</span></label>' +
            '</div>' +
            '</section>';
        }).join('') +
        '</div>' +
        '<div class="confirm-actions">' +
        '<button class="no" type="button">いいえ</button>' +
        '<button class="yes" type="button">この内容で非稼働へ反映</button>' +
        '</div>' +
        '</div>';
      document.body.appendChild(overlay);
      const rows = [...overlay.querySelectorAll('.confirm-device-row')];
      const yesButton = overlay.querySelector('.yes');
      function refreshRows() {
        let invalid = 0;
        for (const row of rows) {
          const index = Number(row.dataset.resetIndex);
          const manual = row.querySelector('.reset-uptime-mode:checked')?.value === 'manual';
          const manualInput = row.querySelector('.reset-uptime-hours');
          manualInput.disabled = !manual;
          const value = resetConfirmationRowValue(row, candidates[index]);
          row.classList.toggle('invalid', !value.ok);
          if (!value.ok) invalid += 1;
        }
        yesButton.disabled = invalid > 0;
      }
      function onKeyDown(event) {
        if (event.key === 'Escape') close(null);
      }
      function close(value) {
        if (closed) return;
        closed = true;
        document.removeEventListener('keydown', onKeyDown);
        overlay.remove();
        resolve(value);
      }
      document.addEventListener('keydown', onKeyDown);
      overlay.querySelector('.no').addEventListener('click', () => close(null));
      yesButton.addEventListener('click', () => {
        const values = rows.map((row) => {
          const index = Number(row.dataset.resetIndex);
          return resetConfirmationRowValue(row, candidates[index]);
        });
        const invalid = values.findIndex((value) => !value.ok);
        if (invalid >= 0) {
          rows[invalid].querySelector('.input-error, input, select')?.focus();
          refreshRows();
          return;
        }
        close(values.map(({ ok, ...value }) => value));
      });
      overlay.addEventListener('input', refreshRows);
      overlay.addEventListener('change', refreshRows);
      overlay.addEventListener('click', (event) => {
        if (event.target === overlay) close(null);
      });
      refreshRows();
      overlay.querySelector('.no').focus();
    });
  }

  function discardPendingChanges() {
    suppressChanged = true;
    checkboxState.clear();
    checkinAmountState.clear();
    taskAmountState.clear();
    for (const input of document.querySelectorAll('input[type="checkbox"]')) {
      input.checked = input.dataset.original === '1';
      const td = input.closest('td');
      if (!td) continue;
      td.classList.toggle('checked', input.checked);
      td.classList.toggle('empty', !input.checked);
      td.classList.remove('changed');
    }
    for (const input of document.querySelectorAll('.ci-amount-input')) {
      input.value = input.dataset.original || '';
      input.classList.remove('input-error');
      const td = input.closest('td');
      if (!td) continue;
      td.classList.toggle('checked', Boolean(input.value));
      td.classList.toggle('empty', !input.value);
      td.classList.remove('changed');
    }
    applyButton.disabled = true;
    renderMatrix();
  }

  async function applyPendingChanges() {
    const invalidEditor = invalidDenseEditorInputs();
    if (invalidEditor.length) {
      invalidEditor[0].focus();
      throw new Error(invalidEditor[0].validationMessage || '選択端末の入力値を確認してください');
    }
    const invalidAmounts = invalidCheckinInputs();
    if (invalidAmounts.length) {
      invalidAmounts[0].focus();
      throw new Error('チェックイン金額は1〜${MAX_CHECKIN_YEN}の整数、または空欄にしてください');
    }
    const changes = [...document.querySelectorAll('input[type="checkbox"]')]
      .filter(input => input.checked !== (input.dataset.original === '1'))
      .map(input => ({
        serial: input.dataset.serial,
        managementId: input.dataset.managementId,
        tag: input.dataset.tag,
        checked: input.checked,
      }));
    const checkinAmounts = [...document.querySelectorAll('.ci-amount-input')]
      .filter(input => input.value.trim() !== (input.dataset.original || ''))
      .map(input => {
        const amountYen = checkinAmountValue(input);
        return {
          serial: input.dataset.serial,
          managementId: input.dataset.managementId,
          amountYen: amountYen || null,
        };
      });
    const taskAmounts = [];
    for (const device of matrixData.devices) {
      for (const kind of ['video180', 'video10']) {
        const amount = currentTaskAmount(device, kind);
        if (amount === originalTaskAmount(device, kind)) continue;
        taskAmounts.push({
          serial: device.serial,
          managementId: device.managementId,
          kind,
          amount: amount || null,
        });
      }
    }
    if (!changes.length && !checkinAmounts.length && !taskAmounts.length) {
      settleSuccessfulChanges();
      return { ok: true, applied: 0 };
    }

    const resetConfirmations = await showInactiveResetConfirm(resetCandidatesFromChanges(changes));
    if (resetConfirmations === null) {
      discardPendingChanges();
      updateStatus('キャンセルしました（変更は破棄しました）', '');
      return { ok: true, applied: 0, cancelled: true };
    }

    updateStatus('DBへ反映中...', 'warn');
    const response = await fetch(applyEndpoint, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        changes,
        checkinAmounts,
        taskAmounts,
        resetConfirmations,
        preserveEvidence: false,
      }),
    });
    const result = await response.json();
    if (!response.ok || !result.ok) {
      if (result.dbApplied) {
        settleSuccessfulChanges();
        notifyParentDbUpdated();
        return {
          ...result,
          needsRegeneration: true,
          applyWarning: result.error || 'DB反映後の一覧更新に失敗しました',
        };
      }
      throw new Error(result.error || result.failed + '件の反映に失敗しました');
    }
    settleSuccessfulChanges();
    notifyParentDbUpdated();
    return result;
  }

  function notifyParentDbUpdated() {
    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: 'tag-board-db-updated', at: Date.now() }, '*');
      }
    } catch (_) {
      // Parent notification is best effort.
    }
  }

  function clearChangedCells() {
    for (const td of document.querySelectorAll('td.changed')) {
      td.classList.remove('changed');
    }
    for (const input of document.querySelectorAll('input[type="checkbox"]')) {
      input.dataset.original = input.checked ? '1' : '0';
    }
    for (const input of document.querySelectorAll('.ci-amount-input')) {
      input.dataset.original = input.value.trim();
      input.dataset.originalTag = input.value.trim() ? 'CI_' + input.value.trim() : '';
      input.classList.remove('input-error');
    }
  }

  function commitCurrentCheckboxState() {
    for (const input of document.querySelectorAll('input[type="checkbox"]')) {
      const key = cellKey(input.dataset.serial, input.dataset.tag);
      checkboxState.set(key, input.checked);
      input.dataset.original = input.checked ? '1' : '0';
      const td = input.closest('td');
      if (td) {
        td.classList.toggle('checked', input.checked);
        td.classList.toggle('empty', !input.checked);
        td.classList.remove('changed');
      }
    }
    for (const device of matrixData.devices) {
      for (const tag of matrixData.tags) {
        const key = cellKey(device.serial, tag.tag);
        if (checkboxState.has(key)) device.tags[tag.tag] = checkboxState.get(key);
      }
    }
    for (const input of document.querySelectorAll('.ci-amount-input')) {
      const amount = checkinAmountValue(input);
      const device = matrixData.devices.find((item) => item.serial === input.dataset.serial);
      if (!device || amount < 0) continue;
      device.checkinAmountYen = amount || 0;
      device.checkinTag = amount ? 'CI_' + amount : '';
      input.dataset.original = amount ? String(amount) : '';
      input.dataset.originalTag = device.checkinTag;
      const td = input.closest('td');
      if (td) {
        td.classList.toggle('checked', Boolean(amount));
        td.classList.toggle('empty', !amount);
        td.classList.remove('changed');
      }
    }
    for (const device of matrixData.devices) {
      device.video180Amount = currentTaskAmount(device, 'video180');
      device.video10Amount = currentTaskAmount(device, 'video10');
    }
  }

  function settleSuccessfulChanges() {
    suppressChanged = true;
    document.body.classList.add('changes-settled');
    if (document.activeElement && typeof document.activeElement.blur === 'function') {
      document.activeElement.blur();
    }
    commitCurrentCheckboxState();
    checkboxState.clear();
    checkinAmountState.clear();
    taskAmountState.clear();
    clearChangedCells();
    renderMatrix();
    refreshChangeCount();
    forceClearChangedCells();
  }

  function forceClearChangedCells() {
    for (let i = 0; i < 8; i++) {
      setTimeout(clearChangedCells, i * 80);
    }
  }

  function setBusy(nextBusy) {
    busy = nextBusy;
    syncButton.disabled = busy;
    applyButton.disabled = busy || changedInputs().length === 0 || invalidCheckinInputs().length > 0 || invalidDenseEditorInputs().length > 0;
  }

  function reloadAfterSuccess() {
    settleSuccessfulChanges();
    const url = new URL(window.location.href);
    url.searchParams.set('generated', '1');
    url.searchParams.set('ts', Date.now().toString());
    setTimeout(() => window.location.assign(url.toString()), 150);
  }

  function retryRegenerationAfterApplied(result) {
    settleSuccessfulChanges();
    const url = new URL(window.location.href);
    url.searchParams.delete('generated');
    url.searchParams.set('ts', Date.now().toString());
    updateStatus('DB反映済み / 一覧の再生成を再試行します: ' + (result.applyWarning || '一覧更新失敗'), 'warn');
    setTimeout(() => window.location.assign(url.toString()), 350);
  }

  // Keep the manual save promise until the scheduled reload so a top-level
  // XiaoWei sync can join the same DB write instead of failing on busy.
  let manualApplyFlight = null;
  let parentApplyFlight = null;
  async function applyPendingChangesFromParent() {
    if (parentApplyFlight) return parentApplyFlight;
    if (manualApplyFlight) return manualApplyFlight;
    if (busy) throw new Error('チェック一覧で別の保存処理を実行中です。完了後にもう一度お試しください');

    setBusy(true);
    updateStatus('DBへ反映中...', 'warn');
    parentApplyFlight = (async () => {
      try {
        const result = await applyPendingChanges();
        if (result.cancelled) {
          updateStatus('キャンセルしました（変更は破棄しました）', '');
          return result;
        }
        if (result.needsRegeneration) {
          updateStatus('DB反映済み / XiaoWei同期で一覧を再生成します', 'warn');
          return result;
        }
        const refreshText = refreshStatusText(result);
        const isQueued = refreshText.includes('queued');
        const isFailed = refreshText.includes('failed');
        updateStatus('DBへ反映: ' + result.applied + '件 / ' + refreshText, isFailed ? 'error' : isQueued ? 'warn' : 'ok');
        return result;
      } catch (error) {
        updateStatus('DB反映NG: ' + error.message, 'error');
        throw error;
      } finally {
        setBusy(false);
        parentApplyFlight = null;
      }
    })();
    return parentApplyFlight;
  }

  Object.defineProperty(window, 'androidFleetTagBoard', {
    configurable: false,
    enumerable: false,
    writable: false,
    value: Object.freeze({
      applyPendingChanges: applyPendingChangesFromParent,
    }),
  });

  function bindCheckboxes() {
    for (const input of document.querySelectorAll('input[type="checkbox"]')) {
      input.addEventListener('change', () => {
        suppressChanged = false;
        document.body.classList.remove('changes-settled');
        const exclusiveGroup = input.checked ? exclusiveCheckboxGroup(input.dataset.tag, input.dataset.kind) : '';
        if (exclusiveGroup) {
          for (const other of document.querySelectorAll('input[type="checkbox"][data-serial="' + CSS.escape(input.dataset.serial) + '"]')) {
            if (exclusiveCheckboxGroup(other.dataset.tag, other.dataset.kind) !== exclusiveGroup) continue;
            if (other === input || !other.checked) continue;
            other.checked = false;
            checkboxState.set(cellKey(other.dataset.serial, other.dataset.tag), false);
            const otherTd = other.closest('td');
            const otherOriginal = other.dataset.original === '1';
            if (otherTd) {
              otherTd.classList.toggle('checked', false);
              otherTd.classList.toggle('empty', true);
              otherTd.classList.toggle('changed', other.checked !== otherOriginal);
            }
          }
        }
        checkboxState.set(cellKey(input.dataset.serial, input.dataset.tag), input.checked);
        const td = input.closest('td');
        const original = input.dataset.original === '1';
        if (td) {
          td.classList.toggle('checked', input.checked);
          td.classList.toggle('empty', !input.checked);
          td.classList.toggle('changed', input.checked !== original);
        }
        refreshChangeCount();
      });
    }
  }

  function bindCheckinAmountInputs() {
    for (const input of document.querySelectorAll('.ci-amount-input')) {
      input.addEventListener('input', () => {
        suppressChanged = false;
        document.body.classList.remove('changes-settled');
        checkinAmountState.set(input.dataset.serial, input.value.trim());
        const changed = input.value.trim() !== (input.dataset.original || '');
        const invalid = Boolean(input.validity && input.validity.badInput) || checkinAmountValue(input) < 0;
        input.classList.toggle('input-error', invalid);
        const td = input.closest('td');
        if (td) {
          td.classList.toggle('checked', Boolean(input.value.trim()));
          td.classList.toggle('empty', !input.value.trim());
          td.classList.toggle('changed', changed);
        }
        refreshChangeCount();
      });
    }
  }

  function exclusiveCheckboxGroup(tag, kind) {
    const value = String(tag || '');
    if (kind === 'group') return 'group';
    if (/^CI_\d+$/.test(value)) return 'ci';
    if (/^V180_(7500|15000|22500)$/.test(value)) return 'v180_amount';
    if (/^V10_(1190|1438|2262)$/.test(value)) return 'v10_amount';
    if (/^DAY_\d{2}$/.test(value)) return 'day';
    return '';
  }

  applyButton.addEventListener('click', async () => {
    setBusy(true);
    manualApplyFlight = applyPendingChanges();
    try {
      const result = await manualApplyFlight;
      if (result.cancelled) {
        manualApplyFlight = null;
        setBusy(false);
        return;
      }
      if (result.needsRegeneration) {
        retryRegenerationAfterApplied(result);
        return;
      }
      const refreshText = refreshStatusText(result);
      const isQueued = refreshText.includes('queued');
      const isFailed = refreshText.includes('failed');
      updateStatus('DBへ反映: ' + result.applied + '件 / ' + refreshText, isFailed ? 'error' : isQueued ? 'warn' : 'ok');
      if (!isFailed) {
        reloadAfterSuccess();
      } else {
        manualApplyFlight = null;
        setBusy(false);
      }
    } catch (error) {
      manualApplyFlight = null;
      setBusy(false);
      updateStatus('DB反映NG: ' + error.message, 'error');
      console.error(error);
    }
  });

  syncButton.addEventListener('click', async () => {
    setBusy(true);
    updateStatus('XiaoWei同期中...', 'warn');
    try {
      const applyResult = await applyPendingChanges();
      if (applyResult.cancelled) {
        setBusy(false);
        return;
      }
      if (applyResult.needsRegeneration) {
        retryRegenerationAfterApplied(applyResult);
        return;
      }
      const response = await fetch(syncEndpoint, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: '{}',
      });
      const result = await response.json();
      const refreshText = refreshStatusText(result);
      if (!response.ok || !result.ok) {
        const message = (result.failedSteps && result.failedSteps.join(', ')) || refreshText;
        if (applyResult.applied) {
          updateStatus('DB反映: ' + applyResult.applied + '件 / XiaoWei同期NG: ' + message, 'warn');
          reloadAfterSuccess();
        } else {
          setBusy(false);
          updateStatus('XiaoWei同期NG: ' + message, 'error');
        }
        console.warn('sync failed', result);
        return;
      }
      const prefix = applyResult.applied ? 'DB反映: ' + applyResult.applied + '件 / ' : '';
      updateStatus(prefix + 'XiaoWei同期OK / ' + refreshText, 'ok');
      reloadAfterSuccess();
    } catch (error) {
      setBusy(false);
      updateStatus('XiaoWei同期NG: ' + error.message, 'error');
      console.error(error);
    }
  });

  let resizeTimer = 0;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(renderMatrix, 120);
  });
  bindDeviceSearch();
  bindDeviceEditor();
  initButtonHelp();
  renderMatrix();
})();
</script>
</body>
</html>`;
  fs.writeFileSync(filePath, html, "utf8");
}

function csvCell(value) {
  const text = String(value === undefined || value === null ? "" : value);
  if (!/[",\n]/.test(text)) return text;
  return `"${text.replace(/"/g, '""')}"`;
}

function mdCell(value) {
  return String(value === undefined || value === null || value === "" ? " " : value).replace(/\|/g, "\\|");
}

function escapeHtml(value) {
  return String(value === undefined || value === null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function scriptJson(value) {
  return JSON.stringify(value).replace(/</g, "\\u003c");
}

function shortTagLabel(tag) {
  return tagLabel(String(tag));
}

function faviconLinks() {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
  <rect width="64" height="64" rx="14" fill="#050816"/>
  <path d="M41 11v24.5c0 9.7-6.5 16.5-15.5 16.5C18 52 12 47.2 12 40.8c0-6.7 5.7-11.4 13.1-11.4 1.8 0 3.5.3 5 .9V11h10.9z" fill="#25f4ee"/>
  <path d="M46 15v24.5C46 49.2 39.5 56 30.5 56 23 56 17 51.2 17 44.8c0-6.7 5.7-11.4 13.1-11.4 1.8 0 3.5.3 5 .9V15H46z" fill="#fe2c55" opacity=".9"/>
  <path d="M42 13v24.5C42 47.2 35.5 54 26.5 54 19 54 13 49.2 13 42.8c0-6.7 5.7-11.4 13.1-11.4 1.8 0 3.5.3 5 .9V13H42z" fill="#ffffff"/>
</svg>`;
  const data = Buffer.from(svg).toString("base64");
  return `<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,${data}">
<link rel="shortcut icon" href="data:image/svg+xml;base64,${data}">`;
}

function tagLabelHtml(tag) {
  return tagLabelLines(tag).map((line, index) => {
    const klass = index === 0 ? "line" : "line sub";
    return `<span class="${klass}">${escapeHtml(line)}</span>`;
  }).join("");
}

function tagLabelLines(tag) {
  const text = String(tag);
  if (text === CHECKIN_AMOUNT_ROW) return ["チェックイン", ""];
  if (text === "GROUP_ACTIVE") return ["稼働中", ""];
  if (text === "GROUP_INACTIVE") return ["非稼働", ""];
  if (text === "GROUP_REST") return ["非稼働", ""];
  if (text === "STATE_CI_KEEP") return ["DAY", "KEEP"];
  if (text === "STATE_ERROR") return ["ERROR", "中"];
  if (text === "STATE_ERROR_HISTORY") return ["ERROR", "歴"];
  if (/^DAY_\d{2}$/.test(text)) return ["DAY", text.slice(4)];
  if (text === "DAY_UNK") return ["DAY", "UNK"];
  if (/^CI_\d+$/.test(text)) return ["チェック", `${text.slice(3)}円`];
  if (text === "CI_ERR") return ["チェック", "ERR"];
  if (/^V180_(\d+)$/.test(text)) return ["180分", `${text.slice(5)}P`];
  if (text === "V180_DONE") return ["180分", "完了"];
  if (text === "V10_DONE") return ["追加", "完了"];
  if (/^V10_(\d+)$/.test(text)) return ["追加", `${text.slice(4)}円`];
  if (/^INV_OK_/.test(text)) return ["INV", `OK${text.slice(7)}`];
  if (/^INV_NG_/.test(text)) return ["INV", `NG${text.slice(7)}`];
  if (text === "WITHDRAW_3000") return ["WD", "3000"];
  if (text === "RESET_DONE") return ["RESET", "完了"];
  if (text === "CYCLE_CLOSED") return ["CYCLE", "CLOSED"];
  if (/^OK_/.test(text)) return ["OK", text.replace(/^OK_/, "")];
  if (/^NG_/.test(text)) return ["NG", text.replace(/^NG_/, "")];
  if (/^DEC_/.test(text)) return ["DEC", text.replace(/^DEC_/, "")];
  if (/^STATE_/.test(text)) return ["ST", text.replace(/^STATE_/, "")];
  if (/^NET_/.test(text)) return ["NET", text.replace(/^NET_/, "")];
  if (/^WAIT_/.test(text)) return ["WAIT", text.replace(/^WAIT_/, "")];
  if (/^P[12]_/.test(text)) return text.split("_");
  return tagLabel(text).split(/\s+/).filter(Boolean);
}

function displayTagName(tag) {
  if (tag === "GROUP_ACTIVE") return "稼働中";
  if (tag === "GROUP_INACTIVE") return "非稼働";
  if (tag === "GROUP_REST") return "非稼働";
  if (tag === "STATE_CI_KEEP") return "DAY KEEP";
  if (tag === "STATE_ERROR") return "ERROR 中";
  if (tag === "STATE_ERROR_HISTORY") return "ERROR 歴";
  return tagLabelLines(tag).join(" ").trim() || tag;
}

function tagClass(tag) {
  if (/^GROUP_/.test(tag)) return "group";
  if (/ERR|ERROR|RESET/.test(tag)) return "error";
  if (/^CI_/.test(tag)) return "ci";
  if (/^INV_/.test(tag)) return "invite";
  if (/^DAY_/.test(tag)) return "day";
  if (/^V180_|^V10_/.test(tag)) return "task";
  if (/^OK_|^NG_|^WITHDRAW_/.test(tag)) return "profit";
  if (/^RESET_|^CYCLE_/.test(tag)) return "cycle";
  return "";
}

function tagLegendHtml(tags) {
  const items = tags.map((tag) => {
    const description = tagDescriptionJa(tag) || tagLabel(tag);
    return `<div class="legend-item"><span class="legend-code">${escapeHtml(displayTagName(tag))}</span><span class="legend-text">${escapeHtml(description)}</span></div>`;
  }).join("");
  return `<section class="legend"><h2>Tag Translation</h2><div class="legend-grid">${items}</div></section>`;
}

function fleetCountSummary(matrix) {
  const devices = Array.isArray(matrix.devices) ? matrix.devices : [];
  const inactive = devices.filter((device) => {
    return Boolean(device.tags && (device.tags.GROUP_INACTIVE || device.tags.GROUP_REST || device.tags.WAITING));
  }).length;
  return {
    active: devices.length - inactive,
    inactive,
    sleeping: 0,
    total: devices.length,
  };
}

function connectionClass(device) {
  if (device.tags && (device.tags.GROUP_INACTIVE || device.tags.GROUP_REST || device.tags.WAITING)) return "offline-device";
  const status = String(device.adbStatus || "").toLowerCase();
  if (status && status !== "device") return "offline-device";
  return "";
}

function connectionLabel(device) {
  if (device.tags && (device.tags.GROUP_INACTIVE || device.tags.GROUP_REST || device.tags.WAITING)) return "INACTIVE";
  const status = String(device.adbStatus || "").toLowerCase();
  if (!status) return "";
  if (status === "missing") return "OFF";
  if (status === "offline") return "ADB OFF";
  if (status === "unauthorized") return "AUTH";
  return "";
}

function parkingLabel(device) {
  return "";
}

function formatCurrentYen(device) {
  if (device.currentYen !== undefined && device.currentYen !== null && device.currentYen !== "") {
    return `¥${device.currentYen}`;
  }
  if (device.projectedGrossYen !== undefined && device.projectedGrossYen !== null && device.projectedGrossYen !== "") {
    return `E${Math.round(Number(device.projectedGrossYen || 0))}`;
  }
  return "";
}

function formatCurrentPoints(device) {
  if (device.currentPoints !== undefined && device.currentPoints !== null && device.currentPoints !== "") {
    return `P${compactNumber(device.currentPoints)}`;
  }
  if (device.pointScreenType) return device.pointScreenType;
  return "";
}

function compactNumber(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return String(value);
  if (Math.abs(number) >= 10000) return `${Math.round(number / 1000) / 10}k`;
  return String(number);
}

function shortDeviceName(name) {
  const text = String(name || "").trim();
  const replacements = [
    [/^Galaxy A25 5G$/i, "A25"],
    [/^Galaxy S20 5G$/i, "S20"],
    [/^Galaxy A06$/i, "A06"],
    [/^Pixel\s+/i, ""],
    [/^Redmi Note\s+/i, "RN "],
    [/^Redmi\s+/i, ""],
    [/^HUAWEI\s+/i, ""],
    [/^OPPO Reno\s*/i, "Reno "],
    [/^arrows\s+/i, ""],
    [/^A402FC$/i, "We2"],
    [/^M07$/i, "We2"],
  ];
  let out = text;
  for (const [pattern, replacement] of replacements) {
    out = out.replace(pattern, replacement);
  }
  return out;
}

function tagBoardDeviceName(device) {
  return tagBoardDisplayCode(device) || device.name || device.xiaoweiName || "";
}

function tagBoardDisplayCode(device) {
  const code = String(device && (device.uiNameOverride || device.deviceCode) || "").trim();
  if (!code) return "";
  const match = /^(.+?)-([A-Z]+)-(\d+)$/i.exec(code);
  if (match) return `${match[1]}-${String(Number(match[3])).padStart(2, "0")}`;
  return code.replace(/-([A-Z]+)-(\d+)$/i, (_, carrier, seq) => `-${String(Number(seq)).padStart(2, "0")}`);
}
